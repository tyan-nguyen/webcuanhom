-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 15, 2024 at 07:25 AM
-- Server version: 5.7.40
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webcuanhom`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_assignment`
--

DROP TABLE IF EXISTS `auth_assignment`;
CREATE TABLE IF NOT EXISTS `auth_assignment` (
  `item_name` varchar(64) CHARACTER SET utf8 NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_item`
--

DROP TABLE IF EXISTS `auth_item`;
CREATE TABLE IF NOT EXISTS `auth_item` (
  `name` varchar(64) CHARACTER SET utf8 NOT NULL,
  `type` int(11) NOT NULL,
  `description` text CHARACTER SET utf8,
  `rule_name` varchar(64) CHARACTER SET utf8 DEFAULT NULL,
  `data` text CHARACTER SET utf8,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `group_code` varchar(64) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `idx-auth_item-type` (`type`),
  KEY `fk_auth_item_group_code` (`group_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item`
--

INSERT INTO `auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`, `group_code`) VALUES
('/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//ajaxcrud', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//controller', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//crud', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//extension', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//form', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//model', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//module', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/asset/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/asset/compress', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/asset/template', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/cache/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/cache/flush', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/cache/flush-all', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/cache/flush-schema', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/cache/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/db-explain', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/download-mail', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/toolbar', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/view', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/user/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/user/reset-identity', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/user/set-identity', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/fixture/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/fixture/load', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/fixture/unload', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/action', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/diff', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/preview', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/view', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/hello/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/hello/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/help/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/help/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/help/list', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/help/list-action-options', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/help/usage', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/message/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/message/config', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/message/config-template', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/message/extract', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/create', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/down', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/fresh', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/history', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/mark', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/new', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/redo', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/to', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/up', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/serve/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/serve/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/auth/change-own-password', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user-permission/set', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user-permission/set-roles', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/bulk-activate', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/bulk-deactivate', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/bulk-delete', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/change-password', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/create', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/delete', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/grid-page-size', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/update', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/view', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('Admin', 1, 'Admin', NULL, NULL, 1695691644, 1695691644, NULL),
('assignRolesToUsers', 2, 'Assign roles to users', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('bindUserToIp', 2, 'Bind user to IP', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('changeOwnPassword', 2, 'Change own password', NULL, NULL, 1695691644, 1695691644, 'userCommonPermissions'),
('changeUserPassword', 2, 'Change user password', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('commonPermission', 2, 'Common permission', NULL, NULL, 1695691643, 1695691643, NULL),
('createUsers', 2, 'Create users', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('deleteUsers', 2, 'Delete users', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('editUserEmail', 2, 'Edit user email', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('editUsers', 2, 'Edit users', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('viewRegistrationIp', 2, 'View registration IP', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('viewUserEmail', 2, 'View user email', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('viewUserRoles', 2, 'View user roles', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('viewUsers', 2, 'View users', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('viewVisitLog', 2, 'View visit log', NULL, NULL, 1695691644, 1695691644, 'userManagement');

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_child`
--

DROP TABLE IF EXISTS `auth_item_child`;
CREATE TABLE IF NOT EXISTS `auth_item_child` (
  `parent` varchar(64) CHARACTER SET utf8 NOT NULL,
  `child` varchar(64) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item_child`
--

INSERT INTO `auth_item_child` (`parent`, `child`) VALUES
('changeOwnPassword', '/user-management/auth/change-own-password'),
('assignRolesToUsers', '/user-management/user-permission/set'),
('assignRolesToUsers', '/user-management/user-permission/set-roles'),
('editUsers', '/user-management/user/bulk-activate'),
('editUsers', '/user-management/user/bulk-deactivate'),
('deleteUsers', '/user-management/user/bulk-delete'),
('changeUserPassword', '/user-management/user/change-password'),
('createUsers', '/user-management/user/create'),
('deleteUsers', '/user-management/user/delete'),
('viewUsers', '/user-management/user/grid-page-size'),
('viewUsers', '/user-management/user/index'),
('editUsers', '/user-management/user/update'),
('viewUsers', '/user-management/user/view'),
('Admin', 'assignRolesToUsers'),
('Admin', 'changeOwnPassword'),
('Admin', 'changeUserPassword'),
('Admin', 'createUsers'),
('Admin', 'deleteUsers'),
('Admin', 'editUsers'),
('editUserEmail', 'viewUserEmail'),
('assignRolesToUsers', 'viewUserRoles'),
('Admin', 'viewUsers'),
('assignRolesToUsers', 'viewUsers'),
('changeUserPassword', 'viewUsers'),
('createUsers', 'viewUsers'),
('deleteUsers', 'viewUsers'),
('editUsers', 'viewUsers');

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_group`
--

DROP TABLE IF EXISTS `auth_item_group`;
CREATE TABLE IF NOT EXISTS `auth_item_group` (
  `code` varchar(64) CHARACTER SET utf8 NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item_group`
--

INSERT INTO `auth_item_group` (`code`, `name`, `created_at`, `updated_at`) VALUES
('userCommonPermissions', 'User common permission', 1695691644, 1695691644),
('userManagement', 'User management', 1695691644, 1695691644);

-- --------------------------------------------------------

--
-- Table structure for table `auth_rule`
--

DROP TABLE IF EXISTS `auth_rule`;
CREATE TABLE IF NOT EXISTS `auth_rule` (
  `name` varchar(64) CHARACTER SET utf8 NOT NULL,
  `data` text CHARACTER SET utf8,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `banle_hoa_don`
--

DROP TABLE IF EXISTS `banle_hoa_don`;
CREATE TABLE IF NOT EXISTS `banle_hoa_don` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ma_hoa_don` int(11) DEFAULT NULL,
  `so_vao_so` int(11) DEFAULT NULL,
  `nam` int(4) DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `id_nguoi_ban` int(11) DEFAULT NULL,
  `ngay_ban` date DEFAULT NULL,
  `id_nguoi_lap` int(11) DEFAULT NULL,
  `ngay_lap` date DEFAULT NULL,
  `trang_thai` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edit_mode` tinyint(1) DEFAULT NULL,
  `id_khach_hang` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_khach_hang` (`id_khach_hang`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `banle_hoa_don`
--

INSERT INTO `banle_hoa_don` (`id`, `ma_hoa_don`, `so_vao_so`, `nam`, `ghi_chu`, `id_nguoi_ban`, `ngay_ban`, `id_nguoi_lap`, `ngay_lap`, `trang_thai`, `edit_mode`, `id_khach_hang`, `date_created`, `user_created`) VALUES
(34, NULL, 4, 2024, NULL, NULL, NULL, NULL, NULL, 'DA_THANH_TOAN', 0, 5, '2024-05-18 18:47:26', 1),
(35, NULL, 1, 2024, NULL, NULL, NULL, NULL, NULL, 'DA_THANH_TOAN', 0, NULL, '2024-05-19 13:01:50', 1),
(36, NULL, 2, 2024, NULL, NULL, NULL, NULL, NULL, 'DA_THANH_TOAN', 0, NULL, '2024-05-19 13:04:04', 1),
(37, NULL, NULL, 2024, NULL, NULL, NULL, NULL, NULL, 'BAN_NHAP', 0, 1, '2024-05-19 13:06:20', 1),
(38, NULL, 3, 2024, NULL, NULL, NULL, NULL, NULL, 'DA_THANH_TOAN', 0, 2, '2024-05-19 13:13:29', 1),
(39, NULL, NULL, 2024, NULL, NULL, NULL, NULL, NULL, 'BAN_NHAP', 0, NULL, '2024-05-20 13:50:44', 1),
(40, NULL, NULL, 2024, NULL, NULL, NULL, NULL, NULL, 'BAN_NHAP', 0, 3, '2024-05-20 14:04:35', 1),
(41, NULL, 5, 2024, NULL, NULL, NULL, NULL, NULL, 'DA_THANH_TOAN', 0, NULL, '2024-05-20 14:45:40', 1),
(42, NULL, NULL, 2024, NULL, NULL, NULL, NULL, NULL, 'BAN_NHAP', 0, NULL, '2024-05-20 14:47:37', 1),
(43, NULL, NULL, 2024, NULL, NULL, NULL, NULL, NULL, 'BAN_NHAP', 0, NULL, '2024-05-20 14:48:47', 1),
(44, NULL, 6, 2024, NULL, NULL, NULL, NULL, NULL, 'DA_THANH_TOAN', 0, 3, '2024-05-20 14:50:24', 1),
(45, NULL, 7, 2024, NULL, NULL, NULL, NULL, NULL, 'DA_THANH_TOAN', 0, NULL, '2024-05-21 11:50:33', 1),
(46, NULL, NULL, 2024, NULL, NULL, NULL, NULL, NULL, 'BAN_NHAP', 0, NULL, '2024-05-21 11:59:01', 1),
(47, NULL, NULL, 2024, NULL, NULL, NULL, NULL, NULL, 'BAN_NHAP', 0, NULL, '2024-05-29 15:33:19', 1),
(49, NULL, NULL, 2024, NULL, NULL, NULL, NULL, NULL, 'BAN_NHAP', 0, NULL, '2024-05-29 15:51:11', 1),
(50, NULL, NULL, 2024, NULL, NULL, NULL, NULL, NULL, 'BAN_NHAP', 0, NULL, '2024-05-29 16:27:05', 1);

-- --------------------------------------------------------

--
-- Table structure for table `banle_hoa_don_chi_tiet`
--

DROP TABLE IF EXISTS `banle_hoa_don_chi_tiet`;
CREATE TABLE IF NOT EXISTS `banle_hoa_don_chi_tiet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_hoa_don` int(11) NOT NULL,
  `id_vat_tu` int(11) DEFAULT NULL,
  `loai_vat_tu` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `don_gia` int(11) DEFAULT NULL,
  `so_luong` double DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_hoa_don` (`id_hoa_don`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `banle_hoa_don_chi_tiet`
--

INSERT INTO `banle_hoa_don_chi_tiet` (`id`, `id_hoa_don`, `id_vat_tu`, `loai_vat_tu`, `don_gia`, `so_luong`, `ghi_chu`, `date_created`, `user_created`) VALUES
(34, 34, 643, 'Phụ kiện', 76400, 1, '', '2024-05-18 20:02:42', 1),
(37, 34, 139, 'NHOM', 399900, 1, '', '2024-05-18 21:50:11', 1),
(38, 34, 142, 'NHOM', 1789176, 5.08, '', '2024-05-19 07:00:29', 1),
(41, 34, 146, 'NHOM', 352200, 1, '', '2024-05-19 07:34:32', 1),
(42, 34, 141, 'NHOM', 352200, 1, '', '2024-05-19 12:44:33', 1),
(43, 34, 138, 'NHOM', 215000, 2, '', '2024-05-19 12:49:36', 1),
(44, 35, 138, 'NHOM', 215000, 1, '', '2024-05-19 13:02:09', 1),
(45, 36, 138, 'NHOM', 215000, 2, '', '2024-05-19 13:04:13', 1),
(46, 37, 138, 'NHOM', 215000, 1, '', '2024-05-19 13:08:03', 1),
(47, 38, 138, 'NHOM', 215000, 2, '', '2024-05-19 20:32:36', 1),
(48, 38, 643, 'Phụ kiện', 76400, 1, '', '2024-05-19 20:36:31', 1),
(49, 41, 645, 'Phụ kiện', 520000, 5, '', '2024-05-20 14:46:47', 1),
(50, 44, 184, 'NHOM', 215000, 2, '', '2024-05-20 14:50:38', 1),
(51, 45, 138, 'NHOM', 215000, 1, '', '2024-05-21 11:50:44', 1),
(52, 45, 184, 'NHOM', 215000, 2, '', '2024-05-21 11:50:56', 1),
(53, 45, 643, 'Phụ kiện', 76400, 1, '', '2024-05-21 11:55:30', 1),
(54, 46, 643, 'Phụ kiện', 76400, 1, '', '2024-05-21 11:59:46', 1),
(55, 46, 148, 'NHOM', 1201200, 1, '', '2024-05-21 12:00:02', 1),
(56, 50, 138, 'NHOM', 215000, 2, '', '2024-05-30 14:51:50', 1),
(57, 50, 650, 'Phụ kiện', 377600, 1, '', '2024-05-30 14:51:56', 1);

-- --------------------------------------------------------

--
-- Table structure for table `banle_khach_hang`
--

DROP TABLE IF EXISTS `banle_khach_hang`;
CREATE TABLE IF NOT EXISTS `banle_khach_hang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_loai_khach_hang` int(11) NOT NULL,
  `ten_khach_hang` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `dia_chi` text COLLATE utf8_unicode_ci NOT NULL,
  `so_dien_thoai` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_loai_khach_hang` (`id_loai_khach_hang`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `banle_khach_hang`
--

INSERT INTO `banle_khach_hang` (`id`, `id_loai_khach_hang`, `ten_khach_hang`, `dia_chi`, `so_dien_thoai`, `email`, `ghi_chu`, `date_created`, `user_created`) VALUES
(1, 1, 'Công ty TNHH ABC', 'Trà Vinh', '01234', 'xx@gmail.com', 'ghi chú', '2024-05-19 21:15:31', 1),
(2, 2, 'Anh Tô Văn Vũ', 'Càng Long, Trà Vinh', '01234', 'xx@gmail.com', 'ghi chú cho anh Tô Văn Vũ', '2024-05-19 21:15:57', 1),
(3, 1, 'Công ty TNHH MTV XYZ', 'Vĩnh Long', '01234', 'xx@gmail.com', 'ghi chú', '2024-05-20 06:41:20', 1),
(4, 2, 'Nguyễn Văn B', 'TP. Trà Vinh', '01234', 'a@gmail.com', 'ghi chú', NULL, NULL),
(5, 2, 'Lê Văn C', 'Cầu Ngang', '01234', 'x@gmail.com', 'ghi chú cho khách hàng Lê Văn C', '2024-05-20 14:13:38', 1),
(6, 1, 'Công ty DEF', 'Việt Nam', '0234', 'def@gmail.com', 'ghi chú cho công ty DEF', '2024-05-20 14:26:56', 1),
(7, 2, 'Nguyễn Văn E', 'Trà Vinh', '01234', 'x@gmnail.com', 'ghic hú cho khách hàng E', '2024-05-20 14:46:22', 1);

-- --------------------------------------------------------

--
-- Table structure for table `banle_loai_khach_hang`
--

DROP TABLE IF EXISTS `banle_loai_khach_hang`;
CREATE TABLE IF NOT EXISTS `banle_loai_khach_hang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten_loai_khach_hang` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `banle_loai_khach_hang`
--

INSERT INTO `banle_loai_khach_hang` (`id`, `ten_loai_khach_hang`, `ghi_chu`, `date_created`, `user_created`) VALUES
(1, 'Doanh nghiệp', NULL, NULL, NULL),
(2, 'Cá nhân', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cua_cay_nhom`
--

DROP TABLE IF EXISTS `cua_cay_nhom`;
CREATE TABLE IF NOT EXISTS `cua_cay_nhom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_he_nhom` int(11) NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ten_cay_nhom` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `so_luong` int(11) DEFAULT NULL,
  `don_gia` double DEFAULT NULL,
  `khoi_luong` float DEFAULT NULL,
  `chieu_dai` float DEFAULT NULL,
  `do_day` float DEFAULT NULL,
  `for_cua_so` tinyint(1) DEFAULT NULL,
  `for_cua_di` tinyint(1) DEFAULT NULL,
  `min_allow_cut` float DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_he_nhom` (`id_he_nhom`)
) ENGINE=InnoDB AUTO_INCREMENT=237 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_don_vi_tinh`
--

DROP TABLE IF EXISTS `cua_don_vi_tinh`;
CREATE TABLE IF NOT EXISTS `cua_don_vi_tinh` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_dvt` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=228 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_don_vi_tinh`
--

INSERT INTO `cua_don_vi_tinh` (`id`, `code`, `ten_dvt`, `date_created`, `user_created`) VALUES
(1, 'chua-phan-loai', 'Chưa phân loại', NULL, NULL),
(225, NULL, 'cái', NULL, NULL),
(226, NULL, 'cặp', NULL, NULL),
(227, NULL, 'm2', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cua_du_an`
--

DROP TABLE IF EXISTS `cua_du_an`;
CREATE TABLE IF NOT EXISTS `cua_du_an` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_du_an` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ten_khach_hang` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dia_chi` text COLLATE utf8_unicode_ci,
  `so_dien_thoai` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trang_thai` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `toi_uu_tat_ca` tinyint(4) DEFAULT NULL,
  `ngay_bat_dau_thuc_hien` date DEFAULT NULL,
  `ngay_hoan_thanh_du_an` date DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `code_mau_thiet_ke` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_du_an_chi_tiet`
--

DROP TABLE IF EXISTS `cua_du_an_chi_tiet`;
CREATE TABLE IF NOT EXISTS `cua_du_an_chi_tiet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_du_an` int(11) NOT NULL,
  `id_mau_cua` int(11) NOT NULL,
  `so_luong` int(11) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_du_an` (`id_du_an`),
  KEY `id_mau_cua` (`id_mau_cua`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_du_an_settings`
--

DROP TABLE IF EXISTS `cua_du_an_settings`;
CREATE TABLE IF NOT EXISTS `cua_du_an_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_du_an` int(11) DEFAULT NULL,
  `vet_cat` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_du_an` (`id_du_an`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_he_nhom`
--

DROP TABLE IF EXISTS `cua_he_nhom`;
CREATE TABLE IF NOT EXISTS `cua_he_nhom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_he_nhom` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `do_day_mac_dinh` float DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_he_nhom`
--

INSERT INTO `cua_he_nhom` (`id`, `code`, `ten_he_nhom`, `do_day_mac_dinh`, `ghi_chu`, `date_created`, `user_created`) VALUES
(10, 'XF55', 'Xingfa Quảng Đông hệ 55', 1.5, '', '2024-06-15 14:06:15', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_he_vach`
--

DROP TABLE IF EXISTS `cua_he_vach`;
CREATE TABLE IF NOT EXISTS `cua_he_vach` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_he_vach` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_he_vach`
--

INSERT INTO `cua_he_vach` (`id`, `code`, `ten_he_vach`, `ghi_chu`, `date_created`, `user_created`) VALUES
(6, 'CL8', 'Kính trắng CL 8ly', 'Thêm từ import file #mau 32e5M', '2024-06-15 08:50:55', 1),
(7, 'CL8_M', 'Kính mờ CL 8ly', 'Thêm từ import file #mau 9rOIB', '2024-06-15 13:54:22', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_hinh_anh`
--

DROP TABLE IF EXISTS `cua_hinh_anh`;
CREATE TABLE IF NOT EXISTS `cua_hinh_anh` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loai` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `id_tham_chieu` int(11) NOT NULL,
  `ten_hien_thi` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `duong_dan` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_file_luu` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `img_extension` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `img_size` float DEFAULT NULL,
  `img_wh` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=125 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_hinh_anh`
--

INSERT INTO `cua_hinh_anh` (`id`, `loai`, `id_tham_chieu`, `ten_hien_thi`, `duong_dan`, `ten_file_luu`, `img_extension`, `img_size`, `img_wh`, `ghi_chu`, `thoi_gian_tao`, `nguoi_tao`) VALUES
(27, 'mau-cua', 19, NULL, '143709-MmU9.jpeg', '143709-MmU9.jpeg', 'jpeg', NULL, NULL, NULL, '2023-12-16 14:37:09', 1),
(28, 'mau-cua', 20, NULL, '105439-4F6E.jpeg', '105439-4F6E.jpeg', 'jpeg', NULL, NULL, NULL, '2023-12-21 10:54:39', 1),
(29, 'mau-cua', 21, NULL, '110919-89Li.jpeg', '110919-89Li.jpeg', 'jpeg', NULL, NULL, NULL, '2023-12-21 11:09:19', 1),
(30, 'mau-cua', 22, NULL, '105626-flaI.jpeg', '105626-flaI.jpeg', 'jpeg', NULL, NULL, NULL, '2023-12-31 10:56:26', 2),
(31, 'mau-cua', 23, NULL, '231135-Csqd.jpeg', '231135-Csqd.jpeg', 'jpeg', NULL, NULL, NULL, '2023-12-31 23:11:35', 2),
(32, 'mau-cua', 24, NULL, '232416-voZg.jpeg', '232416-voZg.jpeg', 'jpeg', NULL, NULL, NULL, '2023-12-31 23:24:16', 2),
(33, 'mau-cua', 26, NULL, '103300-b8X7.jpeg', '103300-b8X7.jpeg', 'jpeg', NULL, NULL, NULL, '2024-01-24 10:33:00', 1),
(34, 'mau-cua', 27, NULL, '150756-X14S.jpeg', '150756-X14S.jpeg', 'jpeg', NULL, NULL, NULL, '2024-05-20 15:07:56', 1),
(35, 'mau-cua', 28, NULL, '151031-fkVX.jpeg', '151031-fkVX.jpeg', 'jpeg', NULL, NULL, NULL, '2024-05-20 15:10:31', 1),
(36, 'mau-cua', 29, NULL, '151836-X0jL.jpeg', '151836-X0jL.jpeg', 'jpeg', NULL, NULL, NULL, '2024-05-20 15:18:36', 1),
(37, 'mau-cua', 30, NULL, '084459-L2SK.jpeg', '084459-L2SK.jpeg', 'jpeg', NULL, NULL, NULL, '2024-05-21 08:44:59', 1),
(38, 'mau-cua', 31, NULL, '204852-ZLlM.jpeg', '204852-ZLlM.jpeg', 'jpeg', NULL, NULL, NULL, '2024-05-21 20:48:52', 1),
(39, 'mau-cua', 32, NULL, '210000-hIrz.jpeg', '210000-hIrz.jpeg', 'jpeg', NULL, NULL, NULL, '2024-05-21 21:00:00', 1),
(40, 'mau-cua', 33, NULL, '211916-cZDk.jpeg', '211916-cZDk.jpeg', 'jpeg', NULL, NULL, NULL, '2024-05-21 21:19:16', 1),
(41, 'mau-cua', 34, NULL, '212127-aeMJ.jpeg', '212127-aeMJ.jpeg', 'jpeg', NULL, NULL, NULL, '2024-05-21 21:21:27', 1),
(42, 'mau-cua', 35, NULL, '212435-TZeY.jpeg', '212435-TZeY.jpeg', 'jpeg', NULL, NULL, NULL, '2024-05-21 21:24:35', 1),
(43, 'mau-cua', 36, NULL, '212622-0V6l.jpeg', '212622-0V6l.jpeg', 'jpeg', NULL, NULL, NULL, '2024-05-21 21:26:22', 1),
(44, 'mau-cua', 37, NULL, '212807-Yn1f.jpeg', '212807-Yn1f.jpeg', 'jpeg', NULL, NULL, NULL, '2024-05-21 21:28:07', 1),
(45, 'mau-cua', 38, NULL, '213720-H208.jpeg', '213720-H208.jpeg', 'jpeg', NULL, NULL, NULL, '2024-05-21 21:37:20', 1),
(46, 'mau-cua', 39, NULL, '213951-UDbJ.jpeg', '213951-UDbJ.jpeg', 'jpeg', NULL, NULL, NULL, '2024-05-21 21:39:51', 1),
(47, 'mau-cua', 40, NULL, '214035-Q4UW.jpeg', '214035-Q4UW.jpeg', 'jpeg', NULL, NULL, NULL, '2024-05-21 21:40:35', 1),
(48, 'mau-cua', 41, NULL, '215601-QTPg.jpeg', '215601-QTPg.jpeg', 'jpeg', NULL, NULL, NULL, '2024-05-21 21:56:01', 1),
(49, 'mau-cua', 42, NULL, '220323-D7jc.jpeg', '220323-D7jc.jpeg', 'jpeg', NULL, NULL, NULL, '2024-05-21 22:03:23', 1),
(50, 'mau-cua', 43, NULL, '220556-GJAY.jpeg', '220556-GJAY.jpeg', 'jpeg', NULL, NULL, NULL, '2024-05-21 22:05:56', 1),
(51, 'mau-cua', 44, NULL, '221743-Z7jE.jpeg', '221743-Z7jE.jpeg', 'jpeg', NULL, NULL, NULL, '2024-05-21 22:17:43', 1),
(52, 'mau-cua', 45, NULL, '091643-TR7p.jpeg', '091643-TR7p.jpeg', 'jpeg', NULL, NULL, NULL, '2024-05-23 09:16:43', 1),
(53, 'mau-cua', 46, NULL, '075622-97iL.jpeg', '075622-97iL.jpeg', 'jpeg', NULL, NULL, NULL, '2024-05-27 07:56:22', 1),
(54, 'mau-cua', 47, NULL, '140737-LgTX.jpeg', '140737-LgTX.jpeg', 'jpeg', NULL, NULL, NULL, '2024-05-27 14:07:37', 1),
(55, 'mau-cua', 48, NULL, '141143-CfyM.jpeg', '141143-CfyM.jpeg', 'jpeg', NULL, NULL, NULL, '2024-05-27 14:11:43', 1),
(56, 'mau-cua', 49, NULL, '092746-xZIP.jpeg', '092746-xZIP.jpeg', 'jpeg', NULL, NULL, NULL, '2024-05-28 09:27:46', 1),
(57, 'mau-cua', 50, NULL, '082137-EKBq.jpeg', '082137-EKBq.jpeg', 'jpeg', NULL, NULL, NULL, '2024-05-29 08:21:37', 1),
(58, 'mau-cua', 51, NULL, '163500-FhUt.jpeg', '163500-FhUt.jpeg', 'jpeg', NULL, NULL, NULL, '2024-05-29 16:35:00', 1),
(59, 'mau-cua', 52, NULL, '163549-vyK4.jpeg', '163549-vyK4.jpeg', 'jpeg', NULL, NULL, NULL, '2024-05-29 16:35:49', 1),
(60, 'mau-cua', 53, NULL, '103722-2ufw.jpeg', '103722-2ufw.jpeg', 'jpeg', NULL, NULL, NULL, '2024-05-31 10:37:22', 1),
(61, 'mau-cua', 54, NULL, '222515-EomR.jpeg', '222515-EomR.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-02 22:25:15', 1),
(62, 'mau-cua', 55, NULL, '055327-yc9P.jpeg', '055327-yc9P.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-03 05:53:27', 1),
(63, 'mau-cua', 56, NULL, '055413-P3Y9.jpeg', '055413-P3Y9.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-03 05:54:13', 1),
(64, 'mau-cua', 57, NULL, '055413-jlze.jpeg', '055413-jlze.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-03 05:54:13', 1),
(65, 'mau-cua', 58, NULL, '055414-aBLW.jpeg', '055414-aBLW.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-03 05:54:14', 1),
(66, 'mau-cua', 59, NULL, '063734-rl1h.jpeg', '063734-rl1h.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-03 06:37:34', 1),
(67, 'mau-cua', 60, NULL, '063734-YviK.jpeg', '063734-YviK.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-03 06:37:34', 1),
(68, 'mau-cua', 61, NULL, '063735-Ks6X.jpeg', '063735-Ks6X.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-03 06:37:35', 1),
(69, 'mau-cua', 62, NULL, '144709-GyAs.jpeg', '144709-GyAs.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-03 14:47:09', 1),
(70, 'mau-cua', 63, NULL, '144709-ynCL.jpeg', '144709-ynCL.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-03 14:47:09', 1),
(71, 'mau-cua', 64, NULL, '144710-jGpI.jpeg', '144710-jGpI.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-03 14:47:10', 1),
(72, 'mau-cua', 65, NULL, '144710-b7kI.jpeg', '144710-b7kI.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-03 14:47:10', 1),
(73, 'mau-cua', 66, NULL, '144710-hwkQ.jpeg', '144710-hwkQ.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-03 14:47:10', 1),
(74, 'mau-cua', 67, NULL, '144711-8fbX.jpeg', '144711-8fbX.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-03 14:47:11', 1),
(75, 'mau-cua', 68, NULL, '144711-ks2j.jpeg', '144711-ks2j.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-03 14:47:11', 1),
(76, 'mau-cua', 69, NULL, '144712-nZcT.jpeg', '144712-nZcT.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-03 14:47:12', 1),
(77, 'mau-cua', 70, NULL, '145029-ymW9.jpeg', '145029-ymW9.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-03 14:50:29', 1),
(78, 'mau-cua', 71, NULL, '145029-OHMd.jpeg', '145029-OHMd.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-03 14:50:29', 1),
(79, 'mau-cua', 72, NULL, '145029-gHWd.jpeg', '145029-gHWd.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-03 14:50:29', 1),
(80, 'mau-cua', 73, NULL, '145030-X6BN.jpeg', '145030-X6BN.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-03 14:50:30', 1),
(81, 'mau-cua', 74, NULL, '145030-WPm9.jpeg', '145030-WPm9.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-03 14:50:30', 1),
(82, 'mau-cua', 75, NULL, '145031-IprP.jpeg', '145031-IprP.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-03 14:50:31', 1),
(83, 'mau-cua', 76, NULL, '145031-oZ1x.jpeg', '145031-oZ1x.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-03 14:50:31', 1),
(84, 'mau-cua', 77, NULL, '145031-3UEj.jpeg', '145031-3UEj.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-03 14:50:31', 1),
(85, 'mau-cua', 78, NULL, '151203-niSX.jpeg', '151203-niSX.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-12 15:12:03', 1),
(86, 'mau-cua', 79, NULL, '151248-OJWg.jpeg', '151248-OJWg.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-12 15:12:48', 1),
(87, 'mau-cua', 80, NULL, '151335-dIMc.jpeg', '151335-dIMc.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-12 15:13:35', 1),
(88, 'mau-cua', 81, NULL, '151642-3kQK.jpeg', '151642-3kQK.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-12 15:16:42', 1),
(89, 'mau-cua', 82, NULL, '151855-KSiv.jpeg', '151855-KSiv.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-12 15:18:55', 1),
(90, 'mau-cua', 83, NULL, '151855-EOaW.jpeg', '151855-EOaW.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-12 15:18:55', 1),
(91, 'mau-cua', 84, NULL, '151855-Euqd.jpeg', '151855-Euqd.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-12 15:18:55', 1),
(92, 'mau-cua', 85, NULL, '152956-xCEM.jpeg', '152956-xCEM.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-12 15:29:56', 1),
(93, 'mau-cua', 86, NULL, '152956-CyML.jpeg', '152956-CyML.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-12 15:29:56', 1),
(94, 'mau-cua', 87, NULL, '152956-HF7S.jpeg', '152956-HF7S.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-12 15:29:56', 1),
(95, 'mau-cua', 88, NULL, '223159-64KP.jpeg', '223159-64KP.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-12 22:31:59', 1),
(96, 'mau-cua', 89, NULL, '223159-Fd8j.jpeg', '223159-Fd8j.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-12 22:31:59', 1),
(97, 'mau-cua', 90, NULL, '223200-amOl.jpeg', '223200-amOl.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-12 22:32:00', 1),
(98, 'mau-cua', 91, NULL, '223633-Sh0E.jpeg', '223633-Sh0E.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-12 22:36:33', 1),
(99, 'mau-cua', 92, NULL, '223633-mrWo.jpeg', '223633-mrWo.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-12 22:36:33', 1),
(100, 'mau-cua', 93, NULL, '223634-8F7O.jpeg', '223634-8F7O.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-12 22:36:34', 1),
(101, 'mau-cua', 94, NULL, '225213-4P6i.jpeg', '225213-4P6i.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-12 22:52:13', 1),
(102, 'mau-cua', 95, NULL, '225214-S2hO.jpeg', '225214-S2hO.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-12 22:52:14', 1),
(103, 'mau-cua', 96, NULL, '225215-Hr9E.jpeg', '225215-Hr9E.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-12 22:52:15', 1),
(104, 'mau-cua', 97, NULL, '225216-Zf1Q.jpeg', '225216-Zf1Q.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-12 22:52:16', 1),
(105, 'mau-cua', 98, NULL, '225217-qb9Z.jpeg', '225217-qb9Z.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-12 22:52:17', 1),
(106, 'mau-cua', 99, NULL, '225218-jCNI.jpeg', '225218-jCNI.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-12 22:52:18', 1),
(107, 'mau-cua', 100, NULL, '225218-Bpv7.jpeg', '225218-Bpv7.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-12 22:52:18', 1),
(108, 'mau-cua', 101, NULL, '225219-AU2x.jpeg', '225219-AU2x.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-12 22:52:19', 1),
(109, 'mau-cua', 102, NULL, '144426-3MlA.jpeg', '144426-3MlA.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-13 14:44:26', 1),
(110, 'mau-cua', 103, NULL, '085055-kELT.jpeg', '085055-kELT.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-15 08:50:55', 1),
(111, 'mau-cua', 104, NULL, '102945-hqa5.jpeg', '102945-hqa5.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-15 10:29:45', 1),
(112, 'mau-cua', 105, NULL, '104040-e5Mf.jpeg', '104040-e5Mf.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-15 10:40:40', 1),
(113, 'mau-cua', 106, NULL, '104134-ZVGW.jpeg', '104134-ZVGW.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-15 10:41:34', 1),
(114, 'mau-cua', 107, NULL, '104217-j1zN.jpeg', '104217-j1zN.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-15 10:42:17', 1),
(115, 'mau-cua', 108, NULL, '135144-Hbdf.jpeg', '135144-Hbdf.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-15 13:51:44', 1),
(116, 'mau-cua', 109, NULL, '135422-23g9.jpeg', '135422-23g9.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-15 13:54:22', 1),
(117, 'mau-cua', 110, NULL, '135422-NIZc.jpeg', '135422-NIZc.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-15 13:54:22', 1),
(118, 'mau-cua', 111, NULL, '135423-SnfQ.jpeg', '135423-SnfQ.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-15 13:54:23', 1),
(119, 'mau-cua', 112, NULL, '140628-kFq5.jpeg', '140628-kFq5.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-15 14:06:28', 1),
(120, 'mau-cua', 113, NULL, '140628-tgpI.jpeg', '140628-tgpI.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-15 14:06:28', 1),
(121, 'mau-cua', 114, NULL, '140628-l5UJ.jpeg', '140628-l5UJ.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-15 14:06:28', 1),
(122, 'mau-cua', 115, NULL, '141623-D2ri.jpeg', '141623-D2ri.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-15 14:16:23', 1),
(123, 'mau-cua', 116, NULL, '141624-iK6C.jpeg', '141624-iK6C.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-15 14:16:24', 1),
(124, 'mau-cua', 117, NULL, '141624-lu0y.jpeg', '141624-lu0y.jpeg', 'jpeg', NULL, NULL, NULL, '2024-06-15 14:16:24', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_kho_nhom`
--

DROP TABLE IF EXISTS `cua_kho_nhom`;
CREATE TABLE IF NOT EXISTS `cua_kho_nhom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_cay_nhom` int(11) NOT NULL,
  `chieu_dai` float NOT NULL,
  `so_luong` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_cay_nhom` (`id_cay_nhom`)
) ENGINE=InnoDB AUTO_INCREMENT=321 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_kho_nhom_lich_su`
--

DROP TABLE IF EXISTS `cua_kho_nhom_lich_su`;
CREATE TABLE IF NOT EXISTS `cua_kho_nhom_lich_su` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_kho_nhom` int(11) NOT NULL,
  `so_luong` int(11) NOT NULL,
  `so_luong_cu` int(11) DEFAULT NULL,
  `so_luong_moi` int(11) DEFAULT NULL,
  `noi_dung` text COLLATE utf8_unicode_ci NOT NULL,
  `id_mau_cua` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_kho_nhom` (`id_kho_nhom`)
) ENGINE=InnoDB AUTO_INCREMENT=755 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_kho_vat_tu`
--

DROP TABLE IF EXISTS `cua_kho_vat_tu`;
CREATE TABLE IF NOT EXISTS `cua_kho_vat_tu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_vat_tu` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `id_nhom_vat_tu` int(11) DEFAULT NULL,
  `thuong_hieu` int(11) DEFAULT NULL,
  `model` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `xuat_xu` int(11) DEFAULT NULL,
  `nha_cung_cap` int(11) DEFAULT NULL,
  `la_phu_kien` tinyint(1) DEFAULT NULL,
  `so_luong` float DEFAULT NULL,
  `dvt` int(11) NOT NULL,
  `don_gia` double DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_nhom_vat_tu` (`id_nhom_vat_tu`),
  KEY `xuat_xu` (`xuat_xu`)
) ENGINE=InnoDB AUTO_INCREMENT=998 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_kho_vat_tu`
--

INSERT INTO `cua_kho_vat_tu` (`id`, `code`, `ten_vat_tu`, `id_nhom_vat_tu`, `thuong_hieu`, `model`, `xuat_xu`, `nha_cung_cap`, `la_phu_kien`, `so_luong`, `dvt`, `don_gia`, `ghi_chu`, `date_created`, `user_created`) VALUES
(990, '1wsg1', 'Lõi khóa 1 đầu chìa núm xoay mở trong - DRAHO TT', 1, 1, NULL, 1, NULL, 1, 0, 225, 0, NULL, '2024-06-15 13:54:22', 1),
(992, '46FPf', 'Ke vĩnh cữu 14x25 (cánh cửa lùa hệ 55)', 1, 1, NULL, 1, NULL, 1, 0, 225, 0, NULL, '2024-06-15 13:54:23', 1),
(993, '5z0r3', 'Bản lề chữ A mở quay 10 in - DRAHO', 1, 1, NULL, 1, NULL, 1, 0, 225, 0, NULL, '2024-06-15 13:54:23', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_kho_vat_tu_lich_su`
--

DROP TABLE IF EXISTS `cua_kho_vat_tu_lich_su`;
CREATE TABLE IF NOT EXISTS `cua_kho_vat_tu_lich_su` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_kho_vat_tu` int(11) NOT NULL,
  `id_nha_cung_cap` int(11) DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `so_luong` float DEFAULT NULL,
  `so_luong_cu` float DEFAULT NULL,
  `so_luong_moi` float DEFAULT NULL,
  `id_mau_cua` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_kho_vat_tu` (`id_kho_vat_tu`),
  KEY `id_nha_cung_cap` (`id_nha_cung_cap`)
) ENGINE=InnoDB AUTO_INCREMENT=1833 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_kho_vat_tu_lich_su`
--

INSERT INTO `cua_kho_vat_tu_lich_su` (`id`, `id_kho_vat_tu`, `id_nha_cung_cap`, `ghi_chu`, `so_luong`, `so_luong_cu`, `so_luong_moi`, `id_mau_cua`, `date_created`, `user_created`) VALUES
(1825, 990, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2024-06-15 13:54:22', 1),
(1827, 992, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2024-06-15 13:54:23', 1),
(1828, 993, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2024-06-15 13:54:23', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_kho_vat_tu_nha_cung_cap`
--

DROP TABLE IF EXISTS `cua_kho_vat_tu_nha_cung_cap`;
CREATE TABLE IF NOT EXISTS `cua_kho_vat_tu_nha_cung_cap` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_nha_cung_cap` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dia_chi` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_kho_vat_tu_nha_cung_cap`
--

INSERT INTO `cua_kho_vat_tu_nha_cung_cap` (`id`, `code`, `ten_nha_cung_cap`, `dia_chi`, `date_created`, `user_created`) VALUES
(1, 'abcd', 'Chưa phân loại', 'Thành phố Trà Vinh, tỉnh Trà Vinh', NULL, NULL),
(2, 'NCC01', 'Công ty TNHH ABCD', 'thành phố Trà Vinh\r\n', '2023-12-05 08:20:45', 1),
(3, 'NCC02', 'Công ty NVT', 'Trà VINH', '2023-12-05 08:41:01', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_loai_bao_gia`
--

DROP TABLE IF EXISTS `cua_loai_bao_gia`;
CREATE TABLE IF NOT EXISTS `cua_loai_bao_gia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_loai_bao_gia` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nhom_bao_gia` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_loai_bao_gia`
--

INSERT INTO `cua_loai_bao_gia` (`id`, `code`, `ten_loai_bao_gia`, `nhom_bao_gia`, `ghi_chu`) VALUES
(1, 'nhom-mac-dinh', 'Báo giá nhôm', 'NHOM', NULL),
(2, 'vat-tu-mac-dinh', 'Báo giá vật tư', 'VATTU', NULL),
(3, 'vach-mac-dinh', 'Báo giá vách', 'VACH', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cua_loai_cua`
--

DROP TABLE IF EXISTS `cua_loai_cua`;
CREATE TABLE IF NOT EXISTS `cua_loai_cua` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_loai_cua` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua`
--

DROP TABLE IF EXISTS `cua_mau_cua`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_cua` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `kich_thuoc` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ngang` float DEFAULT NULL,
  `cao` float DEFAULT NULL,
  `id_he_nhom` int(11) DEFAULT NULL,
  `id_loai_cua` int(11) NOT NULL,
  `id_parent` int(11) DEFAULT NULL,
  `id_du_an` int(11) NOT NULL,
  `so_luong` int(11) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `id_he_nhom` (`id_he_nhom`),
  KEY `id_parent` (`id_parent`),
  KEY `id_loai_cua` (`id_loai_cua`),
  KEY `id_du_an` (`id_du_an`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua_nhom`
--

DROP TABLE IF EXISTS `cua_mau_cua_nhom`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua_nhom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mau_cua` int(11) NOT NULL,
  `id_cay_nhom` int(11) NOT NULL,
  `chieu_dai` float DEFAULT NULL,
  `so_luong` int(11) DEFAULT NULL,
  `kieu_cat` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `khoi_luong` float DEFAULT NULL,
  `don_gia` double DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_mau_cua` (`id_mau_cua`),
  KEY `id_cay_nhom` (`id_cay_nhom`)
) ENGINE=InnoDB AUTO_INCREMENT=1217 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua_nhom_su_dung`
--

DROP TABLE IF EXISTS `cua_mau_cua_nhom_su_dung`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua_nhom_su_dung` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mau_cua` int(11) DEFAULT NULL,
  `id_du_an` int(11) DEFAULT NULL,
  `id_kho_nhom` int(11) NOT NULL,
  `chieu_dai_ban_dau` float NOT NULL,
  `chieu_dai_con_lai` float NOT NULL,
  `chieu_dai_nhap_lai` float DEFAULT NULL,
  `ghi_chu_nhap_lai` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_mau_cua` (`id_mau_cua`),
  KEY `id_kho_nhom` (`id_kho_nhom`),
  KEY `id_du_an` (`id_du_an`)
) ENGINE=InnoDB AUTO_INCREMENT=3485 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua_nhom_su_dung_chi_tiet`
--

DROP TABLE IF EXISTS `cua_mau_cua_nhom_su_dung_chi_tiet`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua_nhom_su_dung_chi_tiet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_nhom_su_dung` int(11) NOT NULL,
  `id_nhom_toi_uu` int(11) NOT NULL,
  `date_created` int(11) DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_nhom_su_dung` (`id_nhom_su_dung`),
  KEY `id_nhom_toi_uu` (`id_nhom_toi_uu`)
) ENGINE=InnoDB AUTO_INCREMENT=15251 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua_settings`
--

DROP TABLE IF EXISTS `cua_mau_cua_settings`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mau_cua` int(11) DEFAULT NULL,
  `vet_cat` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_mau_cua` (`id_mau_cua`)
) ENGINE=InnoDB AUTO_INCREMENT=152 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua_vach`
--

DROP TABLE IF EXISTS `cua_mau_cua_vach`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua_vach` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mau_cua` int(11) NOT NULL,
  `id_vach` int(11) NOT NULL,
  `rong` float DEFAULT NULL,
  `cao` float DEFAULT NULL,
  `so_luong` float DEFAULT NULL,
  `dien_tich` float DEFAULT NULL,
  `don_gia` double NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) NOT NULL,
  `so_luong_xuat` float DEFAULT NULL,
  `ghi_chu_xuat` text COLLATE utf8_unicode_ci,
  `so_luong_nhap_lai` float DEFAULT NULL,
  `ghi_chu_nhap_lai` text COLLATE utf8_unicode_ci,
  `code_bao_gia` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_mau_cua` (`id_mau_cua`),
  KEY `id_vach` (`id_vach`)
) ENGINE=InnoDB AUTO_INCREMENT=221 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua_vat_tu`
--

DROP TABLE IF EXISTS `cua_mau_cua_vat_tu`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua_vat_tu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mau_cua` int(11) NOT NULL,
  `id_kho_vat_tu` int(11) NOT NULL,
  `so_luong` float NOT NULL,
  `dvt` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `don_gia` double DEFAULT NULL,
  `la_phu_kien` tinyint(4) DEFAULT NULL,
  `so_luong_xuat` float DEFAULT NULL,
  `ghi_chu_xuat` text COLLATE utf8_unicode_ci,
  `so_luong_nhap_lai` float DEFAULT NULL,
  `ghi_chu_nhap_lai` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  `code_bao_gia` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_mau_cua` (`id_mau_cua`),
  KEY `id_kho_vat_tu` (`id_kho_vat_tu`)
) ENGINE=InnoDB AUTO_INCREMENT=1279 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_settings`
--

DROP TABLE IF EXISTS `cua_settings`;
CREATE TABLE IF NOT EXISTS `cua_settings` (
  `id` int(11) NOT NULL,
  `cho_phep_nhap_kho_am` tinyint(1) DEFAULT NULL,
  `an_kho_nhom_bang_khong` tinyint(1) DEFAULT NULL,
  `vet_cat` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_settings`
--

INSERT INTO `cua_settings` (`id`, `cho_phep_nhap_kho_am`, `an_kho_nhom_bang_khong`, `vet_cat`) VALUES
(1, 1, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `cua_thuong_hieu`
--

DROP TABLE IF EXISTS `cua_thuong_hieu`;
CREATE TABLE IF NOT EXISTS `cua_thuong_hieu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_thuong_hieu` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_thuong_hieu`
--

INSERT INTO `cua_thuong_hieu` (`id`, `code`, `ten_thuong_hieu`, `ghi_chu`) VALUES
(1, 'chua-phan-loai', 'Mặc định', ''),
(2, '9AM1y', 'Thương hiệu 1', ''),
(3, '6FYOl', 'Thương hiệu 2', '');

-- --------------------------------------------------------

--
-- Table structure for table `cua_toi_uu`
--

DROP TABLE IF EXISTS `cua_toi_uu`;
CREATE TABLE IF NOT EXISTS `cua_toi_uu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mau_cua` int(11) NOT NULL,
  `id_mau_cua_nhom` int(11) NOT NULL,
  `id_ton_kho_nhom` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_mau_cua` (`id_mau_cua`),
  KEY `id_mau_cua_nhom` (`id_mau_cua_nhom`),
  KEY `id_ton_kho_nhom` (`id_ton_kho_nhom`)
) ENGINE=InnoDB AUTO_INCREMENT=21926 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_xuat_xu`
--

DROP TABLE IF EXISTS `cua_xuat_xu`;
CREATE TABLE IF NOT EXISTS `cua_xuat_xu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_xuat_xu` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_xuat_xu`
--

INSERT INTO `cua_xuat_xu` (`id`, `code`, `ten_xuat_xu`, `ghi_chu`) VALUES
(1, 'chua-phan-loai', 'Chưa phân loại', ''),
(2, 'VN', 'Việt Nam', '');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

DROP TABLE IF EXISTS `history`;
CREATE TABLE IF NOT EXISTS `history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loai` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `id_tham_chieu` int(11) NOT NULL,
  `noi_dung` text COLLATE utf8_unicode_ci NOT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`id`, `loai`, `id_tham_chieu`, `noi_dung`, `thoi_gian_tao`, `nguoi_tao`) VALUES
(9, 'hoadonbanle', 5, 'Đạn inox cho ke: Thay đổi Số lượng từ 1 -> 2', '2024-05-15 09:26:29', 1),
(10, 'hoadonbanle', 5, 'Bản lề 4D KC: Thay đổi Số lượng từ 1 -> 10', '2024-05-15 10:02:49', 1),
(11, 'hoadonbanle', 5, 'VTP ô vách (gioăng - nêm - keo - vít): Thay đổi Đơn giá từ 0 -> 50000', '2024-05-17 09:40:32', 1);

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

DROP TABLE IF EXISTS `migration`;
CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1695691639),
('m140608_173539_create_user_table', 1695691642),
('m140611_133903_init_rbac', 1695691642),
('m140808_073114_create_auth_item_group_table', 1695691642),
('m140809_072112_insert_superadmin_to_user', 1695691643),
('m140809_073114_insert_common_permisison_to_auth_item', 1695691643),
('m141023_141535_create_user_visit_log', 1695691643),
('m141116_115804_add_bind_to_ip_and_registration_ip_to_user', 1695691643),
('m141121_194858_split_browser_and_os_column', 1695691643),
('m141201_220516_add_email_and_email_confirmed_to_user', 1695691644),
('m141207_001649_create_basic_user_permissions', 1695691644);

-- --------------------------------------------------------

--
-- Table structure for table `technologies`
--

DROP TABLE IF EXISTS `technologies`;
CREATE TABLE IF NOT EXISTS `technologies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `summary` text COLLATE utf8_unicode_ci,
  `datetime_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `template`
--

DROP TABLE IF EXISTS `template`;
CREATE TABLE IF NOT EXISTS `template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `summary` text COLLATE utf8_unicode_ci,
  `user_created` int(11) DEFAULT NULL,
  `datetime_created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `template`
--

INSERT INTO `template` (`id`, `code`, `name`, `summary`, `user_created`, `datetime_created`) VALUES
(6, '67817125f52ebc64d623ca038038bc27', 'Template 1', '', NULL, '2023-09-11 15:42:47');

-- --------------------------------------------------------

--
-- Table structure for table `template_blocks`
--

DROP TABLE IF EXISTS `template_blocks`;
CREATE TABLE IF NOT EXISTS `template_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_template` int(11) NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `user_created` int(11) DEFAULT NULL,
  `datetime_created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_template` (`id_template`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `template_blocks`
--

INSERT INTO `template_blocks` (`id`, `id_template`, `code`, `name`, `content`, `user_created`, `datetime_created`) VALUES
(2, 6, 'd1942f189c31983ed21a8aa7c9589fa9', 'Block info', 'Công ty TNHH An Thịnh', NULL, '2023-09-11 15:48:05');

-- --------------------------------------------------------

--
-- Table structure for table `template_pages`
--

DROP TABLE IF EXISTS `template_pages`;
CREATE TABLE IF NOT EXISTS `template_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_template` int(11) NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `is_dynamic` tinyint(1) NOT NULL,
  `user_created` int(11) DEFAULT NULL,
  `datetime_created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_template` (`id_template`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `template_pages`
--

INSERT INTO `template_pages` (`id`, `id_template`, `code`, `name`, `file`, `is_dynamic`, `user_created`, `datetime_created`) VALUES
(7, 6, 'd874eb9923d3b481764a924017ce29ff', 'Trang chủ', 'index.php', 0, NULL, '2023-09-11 15:46:18'),
(8, 6, 'f6e8a5b10c8d2c9f24cd31a23ce3ad65', 'Giới thiệu', 'about.php', 0, NULL, '2023-09-11 15:46:32');

-- --------------------------------------------------------

--
-- Table structure for table `template_technologies`
--

DROP TABLE IF EXISTS `template_technologies`;
CREATE TABLE IF NOT EXISTS `template_technologies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_template` int(11) NOT NULL,
  `id_technologie` int(11) NOT NULL,
  `datetime_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_template` (`id_template`),
  KEY `id_technologie` (`id_technologie`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `template_varibles`
--

DROP TABLE IF EXISTS `template_varibles`;
CREATE TABLE IF NOT EXISTS `template_varibles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_template` int(11) NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `varible_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_created` int(11) DEFAULT NULL,
  `datetime_created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_template` (`id_template`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `template_varibles`
--

INSERT INTO `template_varibles` (`id`, `id_template`, `code`, `name`, `varible_type`, `value`, `user_created`, `datetime_created`) VALUES
(3, 6, 'e5a03b101c9278dee5b30f8de11887ef', 'var1', 'text', 'Nguyễn Văn Tý An', NULL, '2023-09-11 15:47:42'),
(4, 6, '59b147ddf73d528f3100ad37d99a6a1d', 'var2', 'int', '100', NULL, '2023-09-11 15:47:51');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8 NOT NULL,
  `auth_key` varchar(32) CHARACTER SET utf8 NOT NULL,
  `password_hash` varchar(255) CHARACTER SET utf8 NOT NULL,
  `confirmation_token` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `superadmin` smallint(6) DEFAULT '0',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `registration_ip` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
  `bind_to_ip` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(128) CHARACTER SET utf8 DEFAULT NULL,
  `email_confirmed` smallint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `confirmation_token`, `status`, `superadmin`, `created_at`, `updated_at`, `registration_ip`, `bind_to_ip`, `email`, `email_confirmed`) VALUES
(1, 'superadmin', 'MDvwUlYvBDOYlfwXEkNhRChWr2utQ3xU', '$2y$13$.82.TmKU5VxndDwYIY8KOeQFIn7WJ6tZinx6mz0MGdkqmpYC0wmHK', NULL, 1, 1, 1695691643, 1695691643, NULL, NULL, NULL, 0),
(2, 'admin', 'Hch1yqSEXM8MbzZLQqQ0J30xv47Y6QO0', '$2y$13$OaXrxEFYubo0F1g5yRqmJOuxbmzqaFPeh9tPjcZ/aY4wjpBtspgyO', NULL, 1, 1, 1702256795, 1702256795, '::1', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_visit_log`
--

DROP TABLE IF EXISTS `user_visit_log`;
CREATE TABLE IF NOT EXISTS `user_visit_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` varchar(255) CHARACTER SET utf8 NOT NULL,
  `ip` varchar(15) CHARACTER SET utf8 NOT NULL,
  `language` char(2) CHARACTER SET utf8 NOT NULL,
  `user_agent` varchar(255) CHARACTER SET utf8 NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `visit_time` int(11) NOT NULL,
  `browser` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `os` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_visit_log`
--

INSERT INTO `user_visit_log` (`id`, `token`, `ip`, `language`, `user_agent`, `user_id`, `visit_time`, `browser`, `os`) VALUES
(1, '651233ac68058', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695691692, 'Chrome', 'Windows'),
(2, '651236d4e41f3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695692500, 'Chrome', 'Windows'),
(3, '6512462aa9eb3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695696426, 'Chrome', 'Windows'),
(4, '65137e1b21d83', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695776283, 'Chrome', 'Windows'),
(5, '65152884d18a2', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695885444, 'Chrome', 'Windows'),
(6, '65167bc86b56f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695972296, 'Chrome', 'Windows'),
(7, '651fc82504a1f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1696581669, 'Chrome', 'Windows'),
(8, '65294c755aebb', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1697205365, 'Chrome', 'Windows'),
(9, '65295a386d589', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1697208888, 'Chrome', 'Windows'),
(10, '652d5011ee601', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1697468434, 'Chrome', 'Windows'),
(11, '652e4ad038376', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1697532624, 'Chrome', 'Windows'),
(12, '652e4b0664a5e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1697532678, 'Chrome', 'Windows'),
(13, '6535c66babd70', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1698023019, 'Chrome', 'Windows'),
(14, '653f6657106a4', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1698653783, 'Chrome', 'Windows'),
(15, '65449a2cbcaff', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1698994732, 'Chrome', 'Windows'),
(16, '65449a409b40e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1698994752, 'Chrome', 'Windows'),
(17, '654839f01d33e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1699232240, 'Chrome', 'Windows'),
(18, '65498b0e1a435', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1699318542, 'Chrome', 'Windows'),
(19, '654c30af3f6b2', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1699492015, 'Chrome', 'Windows'),
(20, '654d8251ec3db', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1699578449, 'Chrome', 'Windows'),
(21, '6552c5c3166bb', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1699923395, 'Chrome', 'Windows'),
(22, '65556baa09cc4', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1700096938, 'Chrome', 'Windows'),
(23, '6556ba7927cfa', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1700182649, 'Chrome', 'Windows'),
(24, '655ea55da9335', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1700701533, 'Chrome', 'Windows'),
(25, '655ff4cb95ae2', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1700787403, 'Chrome', 'Windows'),
(26, '6563f2c74ad32', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701049031, 'Chrome', 'Windows'),
(27, '65668958eaae0', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701218648, 'Chrome', 'Windows'),
(28, '656696bf09e09', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701222079, 'Chrome', 'Windows'),
(29, '656990dc9d085', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701417180, 'Chrome', 'Windows'),
(30, '656d21257611e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701650725, 'Chrome', 'Windows'),
(31, '656d774245afa', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701672770, 'Chrome', 'Windows'),
(32, '656e743392498', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701737523, 'Chrome', 'Windows'),
(33, '656ed00f1ba53', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701761039, 'Chrome', 'Windows'),
(34, '656fc4e0009c2', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701823712, 'Chrome', 'Windows'),
(35, '657114ef13fe3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701909743, 'Chrome', 'Windows'),
(36, '6573c4d291c4d', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1702085842, 'Chrome', 'Windows'),
(37, '6573cc0e3eb38', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1702087694, 'Chrome', 'Windows'),
(38, '6573cc35bc770', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1702087733, 'Chrome', 'Windows'),
(39, '6576608310f74', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1702256771, 'Chrome', 'Windows'),
(40, '657660c3ae9e3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 2, 1702256835, 'Chrome', 'Windows'),
(41, '65796d9e815a9', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1702456734, 'Chrome', 'Windows'),
(42, '657aa2e74b599', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1702535911, 'Chrome', 'Windows'),
(43, '657d510622e04', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1702711558, 'Chrome', 'Windows'),
(44, '65810b57b2f61', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1702955863, 'Chrome', 'Windows'),
(45, '6582468034135', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1703036544, 'Chrome', 'Windows'),
(46, '6582491abea69', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1703037210, 'Chrome', 'Windows'),
(47, '65839ed9a5f36', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1703124697, 'Chrome', 'Windows'),
(48, '6584e95dbe283', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1703209309, 'Chrome', 'Windows'),
(49, '658535af6d642', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 2, 1703228847, 'Chrome', 'Windows'),
(50, '65869dcc6e44b', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1703321036, 'Chrome', 'Windows'),
(51, '6590d3d4a581c', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 2, 1703990228, 'Chrome', 'Windows'),
(52, '65920c8cabb6f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 2, 1704070284, 'Chrome', 'Windows'),
(53, '65937af25d400', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1704164082, 'Chrome', 'Windows'),
(54, '6597b3f56be13', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1704440821, 'Chrome', 'Windows'),
(55, '6598c2c65b204', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1704510150, 'Chrome', 'Windows'),
(56, '65a9d9fcf3381', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1705630205, 'Chrome', 'Windows'),
(57, '65dffd9ae2235', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 1, 1709178266, 'Chrome', 'Windows'),
(58, '661f1e67032e3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36', 1, 1713315431, 'Chrome', 'Windows'),
(59, '66289d637b30a', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36', 1, 1713937763, 'Chrome', 'Windows'),
(60, '6639dc619ad26', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36', 1, 1715068001, 'Chrome', 'Windows'),
(61, '663b3f0b24c2e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36', 1, 1715158795, 'Chrome', 'Windows'),
(62, '66417d1cbda0e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36', 1, 1715567900, 'Chrome', 'Windows'),
(63, '6645bb7c30896', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36', 1, 1715846012, 'Chrome', 'Windows'),
(64, '6646c35433573', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1715913556, 'Chrome', 'Windows'),
(65, '6648542336357', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1716016163, 'Chrome', 'Windows'),
(66, '664bf20e94cfc', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1716253198, 'Chrome', 'Windows'),
(67, '66541d2094eb0', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1716788512, 'Chrome', 'Windows'),
(68, '66553a56ab953', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1716861526, 'Chrome', 'Windows'),
(69, '66569e3c0c02f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1716952636, 'Chrome', 'Windows'),
(70, '6659459bc84b0', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1717126555, 'Chrome', 'Windows'),
(71, '665d74a793765', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1717400743, 'Chrome', 'Windows'),
(72, '66625b5d80cb4', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1717721949, 'Chrome', 'Windows'),
(73, '666652f49f33a', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1717981940, 'Chrome', 'Windows'),
(74, '666907579d104', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1718159191, 'Chrome', 'Windows'),
(75, '666aa5e531457', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1718265317, 'Chrome', 'Windows');

-- --------------------------------------------------------

--
-- Table structure for table `website`
--

DROP TABLE IF EXISTS `website`;
CREATE TABLE IF NOT EXISTS `website` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_template` int(11) NOT NULL,
  `user_created` int(11) DEFAULT NULL,
  `datetime_created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_template` (`id_template`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `website`
--

INSERT INTO `website` (`id`, `id_template`, `user_created`, `datetime_created`) VALUES
(13, 6, NULL, '2023-09-11 16:10:55'),
(14, 6, NULL, '2023-09-12 07:46:33'),
(15, 6, NULL, '2023-09-13 08:10:08');

-- --------------------------------------------------------

--
-- Table structure for table `website_blocks`
--

DROP TABLE IF EXISTS `website_blocks`;
CREATE TABLE IF NOT EXISTS `website_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_website` int(11) NOT NULL,
  `id_template_block` int(11) NOT NULL,
  `content` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `id_website` (`id_website`),
  KEY `id_template_block` (`id_template_block`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `website_blocks`
--

INSERT INTO `website_blocks` (`id`, `id_website`, `id_template_block`, `content`) VALUES
(3, 13, 2, '<p>Công ty TNHH An <b>Thịnh </b>nnnn</p><ul><li>fdsfsaf</li><li>gfdsgsdg</li><li>gdsgag</li></ul><p><img src=\"/uploads/images/8f53295a73878494e9bc8dd6c3c7104f.jpg\" style=\"width: 100%;\"><br></p><p>\r\n</p>'),
(4, 14, 2, 'Công ty TNHH An Thịnh'),
(5, 15, 2, 'Công ty TNHH An Thịnh');

-- --------------------------------------------------------

--
-- Table structure for table `website_pages`
--

DROP TABLE IF EXISTS `website_pages`;
CREATE TABLE IF NOT EXISTS `website_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_website` int(11) NOT NULL,
  `id_template_page` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_website` (`id_website`),
  KEY `id_templage_page` (`id_template_page`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `website_pages`
--

INSERT INTO `website_pages` (`id`, `id_website`, `id_template_page`) VALUES
(25, 13, 7),
(26, 13, 8),
(27, 14, 7),
(28, 14, 8),
(29, 15, 7),
(30, 15, 8);

-- --------------------------------------------------------

--
-- Table structure for table `website_varibles`
--

DROP TABLE IF EXISTS `website_varibles`;
CREATE TABLE IF NOT EXISTS `website_varibles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_website` int(11) NOT NULL,
  `id_template_varible` int(11) NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_website` (`id_website`),
  KEY `id_templage_varible` (`id_template_varible`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `website_varibles`
--

INSERT INTO `website_varibles` (`id`, `id_website`, `id_template_varible`, `value`) VALUES
(7, 13, 3, 'Nguyễn Văn Tý An 123'),
(8, 13, 4, '1012'),
(9, 14, 3, 'Nguyễn Văn Tý An'),
(10, 14, 4, '100'),
(11, 15, 3, 'Nguyễn Văn Tý An'),
(12, 15, 4, '100');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_assignment`
--
ALTER TABLE `auth_assignment`
  ADD CONSTRAINT `auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_assignment_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `auth_item`
--
ALTER TABLE `auth_item`
  ADD CONSTRAINT `auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_auth_item_group_code` FOREIGN KEY (`group_code`) REFERENCES `auth_item_group` (`code`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `banle_hoa_don`
--
ALTER TABLE `banle_hoa_don`
  ADD CONSTRAINT `banle_hoa_don_ibfk_1` FOREIGN KEY (`id_khach_hang`) REFERENCES `banle_khach_hang` (`id`);

--
-- Constraints for table `banle_hoa_don_chi_tiet`
--
ALTER TABLE `banle_hoa_don_chi_tiet`
  ADD CONSTRAINT `banle_hoa_don_chi_tiet_ibfk_1` FOREIGN KEY (`id_hoa_don`) REFERENCES `banle_hoa_don` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `banle_khach_hang`
--
ALTER TABLE `banle_khach_hang`
  ADD CONSTRAINT `banle_khach_hang_ibfk_1` FOREIGN KEY (`id_loai_khach_hang`) REFERENCES `banle_loai_khach_hang` (`id`);

--
-- Constraints for table `cua_cay_nhom`
--
ALTER TABLE `cua_cay_nhom`
  ADD CONSTRAINT `cua_cay_nhom_ibfk_1` FOREIGN KEY (`id_he_nhom`) REFERENCES `cua_he_nhom` (`id`);

--
-- Constraints for table `cua_du_an_chi_tiet`
--
ALTER TABLE `cua_du_an_chi_tiet`
  ADD CONSTRAINT `cua_du_an_chi_tiet_ibfk_1` FOREIGN KEY (`id_du_an`) REFERENCES `cua_du_an` (`id`),
  ADD CONSTRAINT `cua_du_an_chi_tiet_ibfk_2` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`);

--
-- Constraints for table `cua_du_an_settings`
--
ALTER TABLE `cua_du_an_settings`
  ADD CONSTRAINT `cua_du_an_settings_ibfk_1` FOREIGN KEY (`id_du_an`) REFERENCES `cua_du_an` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_kho_nhom`
--
ALTER TABLE `cua_kho_nhom`
  ADD CONSTRAINT `cua_kho_nhom_ibfk_1` FOREIGN KEY (`id_cay_nhom`) REFERENCES `cua_cay_nhom` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_kho_nhom_lich_su`
--
ALTER TABLE `cua_kho_nhom_lich_su`
  ADD CONSTRAINT `cua_kho_nhom_lich_su_ibfk_1` FOREIGN KEY (`id_kho_nhom`) REFERENCES `cua_kho_nhom` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_kho_vat_tu`
--
ALTER TABLE `cua_kho_vat_tu`
  ADD CONSTRAINT `cua_kho_vat_tu_ibfk_1` FOREIGN KEY (`xuat_xu`) REFERENCES `cua_xuat_xu` (`id`);

--
-- Constraints for table `cua_kho_vat_tu_lich_su`
--
ALTER TABLE `cua_kho_vat_tu_lich_su`
  ADD CONSTRAINT `cua_kho_vat_tu_lich_su_ibfk_1` FOREIGN KEY (`id_kho_vat_tu`) REFERENCES `cua_kho_vat_tu` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_mau_cua`
--
ALTER TABLE `cua_mau_cua`
  ADD CONSTRAINT `cua_mau_cua_ibfk_1` FOREIGN KEY (`id_he_nhom`) REFERENCES `cua_he_nhom` (`id`),
  ADD CONSTRAINT `cua_mau_cua_ibfk_2` FOREIGN KEY (`id_loai_cua`) REFERENCES `cua_loai_cua` (`id`),
  ADD CONSTRAINT `cua_mau_cua_ibfk_3` FOREIGN KEY (`id_du_an`) REFERENCES `cua_du_an` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_mau_cua_nhom`
--
ALTER TABLE `cua_mau_cua_nhom`
  ADD CONSTRAINT `cua_mau_cua_nhom_ibfk_1` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cua_mau_cua_nhom_ibfk_2` FOREIGN KEY (`id_cay_nhom`) REFERENCES `cua_cay_nhom` (`id`);

--
-- Constraints for table `cua_mau_cua_nhom_su_dung`
--
ALTER TABLE `cua_mau_cua_nhom_su_dung`
  ADD CONSTRAINT `cua_mau_cua_nhom_su_dung_ibfk_1` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cua_mau_cua_nhom_su_dung_ibfk_2` FOREIGN KEY (`id_kho_nhom`) REFERENCES `cua_kho_nhom` (`id`),
  ADD CONSTRAINT `cua_mau_cua_nhom_su_dung_ibfk_3` FOREIGN KEY (`id_du_an`) REFERENCES `cua_du_an` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_mau_cua_nhom_su_dung_chi_tiet`
--
ALTER TABLE `cua_mau_cua_nhom_su_dung_chi_tiet`
  ADD CONSTRAINT `cua_mau_cua_nhom_su_dung_chi_tiet_ibfk_1` FOREIGN KEY (`id_nhom_su_dung`) REFERENCES `cua_mau_cua_nhom_su_dung` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cua_mau_cua_nhom_su_dung_chi_tiet_ibfk_2` FOREIGN KEY (`id_nhom_toi_uu`) REFERENCES `cua_toi_uu` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_mau_cua_settings`
--
ALTER TABLE `cua_mau_cua_settings`
  ADD CONSTRAINT `cua_mau_cua_settings_ibfk_1` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_mau_cua_vach`
--
ALTER TABLE `cua_mau_cua_vach`
  ADD CONSTRAINT `cua_mau_cua_vach_ibfk_1` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cua_mau_cua_vach_ibfk_2` FOREIGN KEY (`id_vach`) REFERENCES `cua_he_vach` (`id`);

--
-- Constraints for table `cua_mau_cua_vat_tu`
--
ALTER TABLE `cua_mau_cua_vat_tu`
  ADD CONSTRAINT `cua_mau_cua_vat_tu_ibfk_1` FOREIGN KEY (`id_kho_vat_tu`) REFERENCES `cua_kho_vat_tu` (`id`),
  ADD CONSTRAINT `cua_mau_cua_vat_tu_ibfk_2` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_toi_uu`
--
ALTER TABLE `cua_toi_uu`
  ADD CONSTRAINT `cua_toi_uu_ibfk_1` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`),
  ADD CONSTRAINT `cua_toi_uu_ibfk_2` FOREIGN KEY (`id_mau_cua_nhom`) REFERENCES `cua_mau_cua_nhom` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cua_toi_uu_ibfk_3` FOREIGN KEY (`id_ton_kho_nhom`) REFERENCES `cua_kho_nhom` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `template_blocks`
--
ALTER TABLE `template_blocks`
  ADD CONSTRAINT `template_blocks_ibfk_1` FOREIGN KEY (`id_template`) REFERENCES `template` (`id`);

--
-- Constraints for table `template_pages`
--
ALTER TABLE `template_pages`
  ADD CONSTRAINT `template_pages_ibfk_1` FOREIGN KEY (`id_template`) REFERENCES `template` (`id`);

--
-- Constraints for table `template_technologies`
--
ALTER TABLE `template_technologies`
  ADD CONSTRAINT `template_technologies_ibfk_1` FOREIGN KEY (`id_technologie`) REFERENCES `technologies` (`id`),
  ADD CONSTRAINT `template_technologies_ibfk_2` FOREIGN KEY (`id_template`) REFERENCES `template` (`id`);

--
-- Constraints for table `template_varibles`
--
ALTER TABLE `template_varibles`
  ADD CONSTRAINT `template_varibles_ibfk_1` FOREIGN KEY (`id_template`) REFERENCES `template` (`id`);

--
-- Constraints for table `user_visit_log`
--
ALTER TABLE `user_visit_log`
  ADD CONSTRAINT `user_visit_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `website`
--
ALTER TABLE `website`
  ADD CONSTRAINT `website_ibfk_1` FOREIGN KEY (`id_template`) REFERENCES `template` (`id`);

--
-- Constraints for table `website_blocks`
--
ALTER TABLE `website_blocks`
  ADD CONSTRAINT `website_blocks_ibfk_1` FOREIGN KEY (`id_template_block`) REFERENCES `template_blocks` (`id`),
  ADD CONSTRAINT `website_blocks_ibfk_2` FOREIGN KEY (`id_website`) REFERENCES `website` (`id`);

--
-- Constraints for table `website_pages`
--
ALTER TABLE `website_pages`
  ADD CONSTRAINT `website_pages_ibfk_1` FOREIGN KEY (`id_template_page`) REFERENCES `template_pages` (`id`),
  ADD CONSTRAINT `website_pages_ibfk_2` FOREIGN KEY (`id_website`) REFERENCES `website` (`id`);

--
-- Constraints for table `website_varibles`
--
ALTER TABLE `website_varibles`
  ADD CONSTRAINT `website_varibles_ibfk_1` FOREIGN KEY (`id_website`) REFERENCES `website` (`id`),
  ADD CONSTRAINT `website_varibles_ibfk_2` FOREIGN KEY (`id_template_varible`) REFERENCES `template_varibles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
