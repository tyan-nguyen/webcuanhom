-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 07, 2024 at 07:47 AM
-- Server version: 5.7.40
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webcuanhom`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_assignment`
--

DROP TABLE IF EXISTS `auth_assignment`;
CREATE TABLE IF NOT EXISTS `auth_assignment` (
  `item_name` varchar(64) CHARACTER SET utf8 NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_item`
--

DROP TABLE IF EXISTS `auth_item`;
CREATE TABLE IF NOT EXISTS `auth_item` (
  `name` varchar(64) CHARACTER SET utf8 NOT NULL,
  `type` int(11) NOT NULL,
  `description` text CHARACTER SET utf8,
  `rule_name` varchar(64) CHARACTER SET utf8 DEFAULT NULL,
  `data` text CHARACTER SET utf8,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `group_code` varchar(64) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `idx-auth_item-type` (`type`),
  KEY `fk_auth_item_group_code` (`group_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item`
--

INSERT INTO `auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`, `group_code`) VALUES
('/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//ajaxcrud', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//controller', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//crud', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//extension', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//form', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//model', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//module', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/asset/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/asset/compress', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/asset/template', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/cache/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/cache/flush', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/cache/flush-all', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/cache/flush-schema', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/cache/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/db-explain', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/download-mail', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/toolbar', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/view', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/user/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/user/reset-identity', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/user/set-identity', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/fixture/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/fixture/load', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/fixture/unload', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/action', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/diff', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/preview', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/view', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/hello/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/hello/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/help/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/help/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/help/list', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/help/list-action-options', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/help/usage', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/message/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/message/config', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/message/config-template', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/message/extract', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/create', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/down', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/fresh', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/history', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/mark', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/new', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/redo', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/to', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/up', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/serve/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/serve/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/auth/change-own-password', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user-permission/set', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user-permission/set-roles', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/bulk-activate', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/bulk-deactivate', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/bulk-delete', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/change-password', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/create', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/delete', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/grid-page-size', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/update', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/view', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('Admin', 1, 'Admin', NULL, NULL, 1695691644, 1695691644, NULL),
('assignRolesToUsers', 2, 'Assign roles to users', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('bindUserToIp', 2, 'Bind user to IP', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('changeOwnPassword', 2, 'Change own password', NULL, NULL, 1695691644, 1695691644, 'userCommonPermissions'),
('changeUserPassword', 2, 'Change user password', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('commonPermission', 2, 'Common permission', NULL, NULL, 1695691643, 1695691643, NULL),
('createUsers', 2, 'Create users', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('deleteUsers', 2, 'Delete users', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('editUserEmail', 2, 'Edit user email', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('editUsers', 2, 'Edit users', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('viewRegistrationIp', 2, 'View registration IP', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('viewUserEmail', 2, 'View user email', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('viewUserRoles', 2, 'View user roles', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('viewUsers', 2, 'View users', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('viewVisitLog', 2, 'View visit log', NULL, NULL, 1695691644, 1695691644, 'userManagement');

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_child`
--

DROP TABLE IF EXISTS `auth_item_child`;
CREATE TABLE IF NOT EXISTS `auth_item_child` (
  `parent` varchar(64) CHARACTER SET utf8 NOT NULL,
  `child` varchar(64) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item_child`
--

INSERT INTO `auth_item_child` (`parent`, `child`) VALUES
('changeOwnPassword', '/user-management/auth/change-own-password'),
('assignRolesToUsers', '/user-management/user-permission/set'),
('assignRolesToUsers', '/user-management/user-permission/set-roles'),
('editUsers', '/user-management/user/bulk-activate'),
('editUsers', '/user-management/user/bulk-deactivate'),
('deleteUsers', '/user-management/user/bulk-delete'),
('changeUserPassword', '/user-management/user/change-password'),
('createUsers', '/user-management/user/create'),
('deleteUsers', '/user-management/user/delete'),
('viewUsers', '/user-management/user/grid-page-size'),
('viewUsers', '/user-management/user/index'),
('editUsers', '/user-management/user/update'),
('viewUsers', '/user-management/user/view'),
('Admin', 'assignRolesToUsers'),
('Admin', 'changeOwnPassword'),
('Admin', 'changeUserPassword'),
('Admin', 'createUsers'),
('Admin', 'deleteUsers'),
('Admin', 'editUsers'),
('editUserEmail', 'viewUserEmail'),
('assignRolesToUsers', 'viewUserRoles'),
('Admin', 'viewUsers'),
('assignRolesToUsers', 'viewUsers'),
('changeUserPassword', 'viewUsers'),
('createUsers', 'viewUsers'),
('deleteUsers', 'viewUsers'),
('editUsers', 'viewUsers');

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_group`
--

DROP TABLE IF EXISTS `auth_item_group`;
CREATE TABLE IF NOT EXISTS `auth_item_group` (
  `code` varchar(64) CHARACTER SET utf8 NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item_group`
--

INSERT INTO `auth_item_group` (`code`, `name`, `created_at`, `updated_at`) VALUES
('userCommonPermissions', 'User common permission', 1695691644, 1695691644),
('userManagement', 'User management', 1695691644, 1695691644);

-- --------------------------------------------------------

--
-- Table structure for table `auth_rule`
--

DROP TABLE IF EXISTS `auth_rule`;
CREATE TABLE IF NOT EXISTS `auth_rule` (
  `name` varchar(64) CHARACTER SET utf8 NOT NULL,
  `data` text CHARACTER SET utf8,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_cay_nhom`
--

DROP TABLE IF EXISTS `cua_cay_nhom`;
CREATE TABLE IF NOT EXISTS `cua_cay_nhom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_he_nhom` int(11) NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ten_cay_nhom` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `so_luong` int(11) DEFAULT NULL,
  `don_gia` double DEFAULT NULL,
  `khoi_luong` float DEFAULT NULL,
  `chieu_dai` float DEFAULT NULL,
  `for_cua_so` tinyint(1) DEFAULT NULL,
  `for_cua_di` tinyint(1) DEFAULT NULL,
  `min_allow_cut` float DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_he_nhom` (`id_he_nhom`)
) ENGINE=InnoDB AUTO_INCREMENT=162 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_cay_nhom`
--

INSERT INTO `cua_cay_nhom` (`id`, `id_he_nhom`, `code`, `ten_cay_nhom`, `so_luong`, `don_gia`, `khoi_luong`, `chieu_dai`, `for_cua_so`, `for_cua_di`, `min_allow_cut`, `date_created`, `user_created`) VALUES
(123, 1, 'Rinoxt', 'Ray Inox lù xếp trượt', 1, 215000, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(124, 1, 'SD0415', 'Xingfa PMI sữa ', 0, 352200, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(125, 1, 'SD3295', 'Xingfa PMI sữa ', 0, 385680, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(126, 1, 'SD3328', 'Xingfa PMI sữa', 0, 1712160, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(127, 1, 'SD3332', 'Xingfa PMI sữa ', 0, 2015520, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(128, 1, 'XD0312', 'Xingfa PMI Xám', 3, 2603040, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(129, 1, 'XD0415', 'Xingfa PMI Xám  (55)', 0, 352200, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(130, 1, 'XD22903', 'Xingfa PMI Xám ', 0, 1201200, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(131, 1, 'XD3203', 'Xingfa PMI Xám ', 0, 1375200, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(132, 1, 'XD3209', 'Xingfa PMI Xám ', 4, 5610000, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(133, 1, 'XD3295', 'Xingfa PMI Xám (55)', 5, 4435320, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(134, 1, 'XD3296', 'Xingfa PMI Xám ', 0, 385680, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(135, 1, 'XD3300', 'Xingfa PMI Xám ', 0, 476160, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(136, 1, 'XD3303mr', 'Xingfa PMI Xám (mở ra)', 3, 6046560, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(137, 1, 'XD3313', 'Xingfa PMI Xám P55', 0, 789960, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(138, 1, 'XD3318', 'Xingfa PMI Xám', 0, 1230480, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(139, 1, 'XD3328', 'Xingfa PMI Xám(55)', 2, 8560800, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(140, 1, 'XD8092', 'Xingfa PMI Xám', 1, 2257200, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(141, 1, 'XL100F0712', 'Xingfa PMI Xám ', 2, 745920, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(142, 1, 'XL100F1012', 'Xingfa PMI Xám ', 3, 1491840, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(143, 1, 'XL100F1109', 'Xingfa PMI Xám', 10, 514800, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(144, 1, 'XL550112', 'Xingfa PMI Xám (55)', 8, 10909920, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(145, 1, 'XL550212', 'Xingfa PMI Xám (55)', 8, 15395520, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(146, 1, 'XL55D0412', 'Xingfa PMI Xám', 11, 1599840, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(147, 1, 'XL55D0512', 'Xingfa PMI Xám ', 2, 374400, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(148, 1, 'XP3332', 'Xingfa PMI Xám  (mở vô)', 3, 14108640, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(149, 1, 'XP550415', 'Xingfa PMI Xám(22900)', 1, 704400, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(150, 1, 'XP55D3203', 'Xingfa PMI Xám (đố chia Ô)', 3, 2062800, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(151, 1, 'XP55D5108', 'Xingfa PMI Xám', 1, 114000, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(152, 1, 'XP55D5314', 'Xingfa PMI Xám', 2, 787200, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(153, 1, 'XP55D5414', 'Xingfa PMI Xám', 1, 309600, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(154, 1, 'XP55D5514', 'Xingfa PMI Xám', 1, 289200, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(155, 1, 'XP65D027112', 'Xingfa PMI Xám', 3, 589800, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(156, 1, 'XP65D0720', 'Xingfa PMI Xám', 1, 844795, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(157, 1, 'XP65D1210', 'Xingfa PMI Xám', 1, 205800, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(158, 1, 'XP65D2020', 'Xingfa PMI Xám', 4, 5139200, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(159, 1, 'XPMI007', 'Xingfa PMI Xám', 0, 932533, 0, 5900, 0, 0, 0, '2023-12-29 16:24:23', 1),
(160, 4, 'C3300', 'Nẹp nối khung', 0, 0, 0, 5900, 0, 0, 0, '2023-12-31 10:56:26', 2),
(161, 4, 'C3328', 'Khung bao cửa đi mở quay', 0, 0, 0, 5900, 0, 0, 0, '2023-12-31 10:56:26', 2);

-- --------------------------------------------------------

--
-- Table structure for table `cua_don_vi_tinh`
--

DROP TABLE IF EXISTS `cua_don_vi_tinh`;
CREATE TABLE IF NOT EXISTS `cua_don_vi_tinh` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_dvt` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=225 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_don_vi_tinh`
--

INSERT INTO `cua_don_vi_tinh` (`id`, `code`, `ten_dvt`, `date_created`, `user_created`) VALUES
(1, 'chua-phan-loai', 'Chưa phân loại', NULL, NULL),
(2, '', 'Tạ', NULL, NULL),
(3, '', 'Yến', NULL, NULL),
(4, '', 'Kilogram', NULL, NULL),
(5, '', 'gram', NULL, NULL),
(6, '', 'Miligram', NULL, NULL),
(7, '', 'Cái', NULL, NULL),
(8, '', 'Hộp', NULL, NULL),
(9, '', 'Cái', NULL, NULL),
(10, '', 'Cái', NULL, NULL),
(11, '', 'Cái', NULL, NULL),
(12, '', 'test', NULL, NULL),
(14, NULL, 'cặp', NULL, NULL),
(15, NULL, 'm2', NULL, NULL),
(212, NULL, 'Bộ', NULL, NULL),
(213, NULL, 'Chiếc', NULL, NULL),
(214, NULL, 'Thanh', NULL, NULL),
(220, NULL, 'Chai', NULL, NULL),
(221, NULL, 'con', NULL, NULL),
(222, NULL, 'cuộn', NULL, NULL),
(223, NULL, 'kg', NULL, NULL),
(224, NULL, 'mét tới', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cua_du_an`
--

DROP TABLE IF EXISTS `cua_du_an`;
CREATE TABLE IF NOT EXISTS `cua_du_an` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_du_an` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ten_khach_hang` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dia_chi` text COLLATE utf8_unicode_ci,
  `so_dien_thoai` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trang_thai` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ngay_bat_dau_thuc_hien` date DEFAULT NULL,
  `ngay_hoan_thanh_du_an` date DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `code_mau_thiet_ke` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_du_an`
--

INSERT INTO `cua_du_an` (`id`, `code`, `ten_du_an`, `ten_khach_hang`, `dia_chi`, `so_dien_thoai`, `email`, `trang_thai`, `ngay_bat_dau_thuc_hien`, `ngay_hoan_thanh_du_an`, `ghi_chu`, `code_mau_thiet_ke`, `date_created`, `user_created`) VALUES
(9, '83jZV', 'Dự án 1', 'Nguyễn Văn A', '', '', '', 'KHOI_TAO', NULL, NULL, '', 'VER.230928', '2023-12-16 14:37:02', 1),
(10, '5W4wV', 'Dự án Phường 9', 'Nguyễn Văn AAA', '', '', '', 'KHOI_TAO', NULL, NULL, '<p>x</p>', 'VER.230928', '2023-12-21 11:08:03', 1),
(11, '4BsEN', 'sdssss', 'sss', '', '', '', 'HOAN_THANH', NULL, NULL, '', 'VER.230928', '2023-12-31 23:11:18', 2),
(12, '7ap27', 'Tên dự án', 'Khách hàng A', '', '', '', 'KHOI_TAO', '2024-01-01', '2024-01-30', '<p>info</p>', 'VER.230928', '2024-01-24 10:32:03', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_du_an_chi_tiet`
--

DROP TABLE IF EXISTS `cua_du_an_chi_tiet`;
CREATE TABLE IF NOT EXISTS `cua_du_an_chi_tiet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_du_an` int(11) NOT NULL,
  `id_mau_cua` int(11) NOT NULL,
  `so_luong` int(11) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_du_an` (`id_du_an`),
  KEY `id_mau_cua` (`id_mau_cua`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_he_nhom`
--

DROP TABLE IF EXISTS `cua_he_nhom`;
CREATE TABLE IF NOT EXISTS `cua_he_nhom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_he_nhom` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_he_nhom`
--

INSERT INTO `cua_he_nhom` (`id`, `code`, `ten_he_nhom`, `ghi_chu`, `date_created`, `user_created`) VALUES
(1, 'xf55', 'Nhôm Xingfa hệ 55', '', '2023-09-26 09:36:12', 1),
(2, 'xf65', 'Nhôm Xingfa hệ 65', '', '2023-09-26 09:40:02', 1),
(3, '6uQoU', 'PMI hệ 45', NULL, '2023-09-29 15:11:45', 1),
(4, '4k0Eb', 'Xingfa Quảng Đông hệ 55', NULL, '2023-10-03 10:07:27', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_he_vach`
--

DROP TABLE IF EXISTS `cua_he_vach`;
CREATE TABLE IF NOT EXISTS `cua_he_vach` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_he_vach` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_he_vach`
--

INSERT INTO `cua_he_vach` (`id`, `code`, `ten_he_vach`, `ghi_chu`, `date_created`, `user_created`) VALUES
(1, '6YDyH', 'Vách kính', 'abc', '2023-12-07 14:04:37', 1),
(2, '4oS4u', 'Vách nhôm', '', '2023-12-07 14:09:14', 1),
(3, 'CL6', 'Kính trắng CL 6ly', 'Thêm từ import file #mau 1Lw3r', '2023-12-11 10:56:30', 2);

-- --------------------------------------------------------

--
-- Table structure for table `cua_hinh_anh`
--

DROP TABLE IF EXISTS `cua_hinh_anh`;
CREATE TABLE IF NOT EXISTS `cua_hinh_anh` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loai` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `id_tham_chieu` int(11) NOT NULL,
  `ten_hien_thi` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `duong_dan` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_file_luu` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `img_extension` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `img_size` float DEFAULT NULL,
  `img_wh` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_hinh_anh`
--

INSERT INTO `cua_hinh_anh` (`id`, `loai`, `id_tham_chieu`, `ten_hien_thi`, `duong_dan`, `ten_file_luu`, `img_extension`, `img_size`, `img_wh`, `ghi_chu`, `thoi_gian_tao`, `nguoi_tao`) VALUES
(27, 'mau-cua', 19, NULL, '143709-MmU9.jpeg', '143709-MmU9.jpeg', 'jpeg', NULL, NULL, NULL, '2023-12-16 14:37:09', 1),
(28, 'mau-cua', 20, NULL, '105439-4F6E.jpeg', '105439-4F6E.jpeg', 'jpeg', NULL, NULL, NULL, '2023-12-21 10:54:39', 1),
(29, 'mau-cua', 21, NULL, '110919-89Li.jpeg', '110919-89Li.jpeg', 'jpeg', NULL, NULL, NULL, '2023-12-21 11:09:19', 1),
(30, 'mau-cua', 22, NULL, '105626-flaI.jpeg', '105626-flaI.jpeg', 'jpeg', NULL, NULL, NULL, '2023-12-31 10:56:26', 2),
(31, 'mau-cua', 23, NULL, '231135-Csqd.jpeg', '231135-Csqd.jpeg', 'jpeg', NULL, NULL, NULL, '2023-12-31 23:11:35', 2),
(32, 'mau-cua', 24, NULL, '232416-voZg.jpeg', '232416-voZg.jpeg', 'jpeg', NULL, NULL, NULL, '2023-12-31 23:24:16', 2),
(33, 'mau-cua', 26, NULL, '103300-b8X7.jpeg', '103300-b8X7.jpeg', 'jpeg', NULL, NULL, NULL, '2024-01-24 10:33:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_kho_nhom`
--

DROP TABLE IF EXISTS `cua_kho_nhom`;
CREATE TABLE IF NOT EXISTS `cua_kho_nhom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_cay_nhom` int(11) NOT NULL,
  `chieu_dai` float NOT NULL,
  `so_luong` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_cay_nhom` (`id_cay_nhom`)
) ENGINE=InnoDB AUTO_INCREMENT=184 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_kho_nhom`
--

INSERT INTO `cua_kho_nhom` (`id`, `id_cay_nhom`, `chieu_dai`, `so_luong`, `date_created`, `user_created`) VALUES
(138, 123, 5900, 1, '2023-12-29 16:24:23', 1),
(139, 123, 5500, 10, '2023-12-29 16:24:23', 1),
(140, 124, 5900, 0, '2023-12-29 16:24:23', 1),
(141, 124, 1000, 5, '2023-12-29 16:24:23', 1),
(142, 124, 1500, 20, '2023-12-29 16:24:23', 1),
(143, 125, 5900, 0, '2023-12-29 16:24:23', 1),
(144, 126, 5900, 0, '2023-12-29 16:24:23', 1),
(145, 127, 5900, 0, '2023-12-29 16:24:23', 1),
(146, 128, 5900, 3, '2023-12-29 16:24:23', 1),
(147, 129, 5900, 0, '2023-12-29 16:24:23', 1),
(148, 130, 5900, 0, '2023-12-29 16:24:23', 1),
(149, 131, 5900, 0, '2023-12-29 16:24:23', 1),
(150, 132, 5900, 4, '2023-12-29 16:24:23', 1),
(151, 133, 5900, 5, '2023-12-29 16:24:23', 1),
(152, 134, 5900, 0, '2023-12-29 16:24:23', 1),
(153, 135, 5900, 0, '2023-12-29 16:24:23', 1),
(154, 136, 5900, 3, '2023-12-29 16:24:23', 1),
(155, 137, 5900, 0, '2023-12-29 16:24:23', 1),
(156, 138, 5900, 0, '2023-12-29 16:24:23', 1),
(157, 139, 5900, 2, '2023-12-29 16:24:23', 1),
(158, 140, 5900, 1, '2023-12-29 16:24:23', 1),
(159, 141, 5900, 2, '2023-12-29 16:24:23', 1),
(160, 142, 5900, 3, '2023-12-29 16:24:23', 1),
(161, 143, 5900, 10, '2023-12-29 16:24:23', 1),
(162, 144, 5900, 8, '2023-12-29 16:24:23', 1),
(163, 145, 5900, 8, '2023-12-29 16:24:23', 1),
(164, 146, 5900, 11, '2023-12-29 16:24:23', 1),
(165, 147, 5900, 2, '2023-12-29 16:24:23', 1),
(166, 148, 5900, 3, '2023-12-29 16:24:23', 1),
(167, 149, 5900, 1, '2023-12-29 16:24:23', 1),
(168, 150, 5900, 3, '2023-12-29 16:24:23', 1),
(169, 151, 5900, 1, '2023-12-29 16:24:23', 1),
(170, 152, 5900, 2, '2023-12-29 16:24:23', 1),
(171, 153, 5900, 1, '2023-12-29 16:24:23', 1),
(172, 154, 5900, 1, '2023-12-29 16:24:23', 1),
(173, 155, 5900, 3, '2023-12-29 16:24:23', 1),
(174, 156, 5900, 1, '2023-12-29 16:24:23', 1),
(175, 157, 5900, 1, '2023-12-29 16:24:23', 1),
(176, 158, 5900, 4, '2023-12-29 16:24:23', 1),
(177, 159, 5900, 0, '2023-12-29 16:24:23', 1),
(178, 160, 0, 0, '2023-12-31 10:56:26', 2),
(179, 161, 0, 0, '2023-12-31 10:56:26', 2),
(180, 160, 5900, -5, '2023-12-31 10:57:34', 2),
(181, 161, 5900, 40, '2023-12-31 10:57:56', 2),
(182, 160, 10, 5900, '2023-12-31 15:16:14', 2),
(183, 161, 3000, 7, '2023-12-31 15:16:31', 2);

-- --------------------------------------------------------

--
-- Table structure for table `cua_kho_nhom_lich_su`
--

DROP TABLE IF EXISTS `cua_kho_nhom_lich_su`;
CREATE TABLE IF NOT EXISTS `cua_kho_nhom_lich_su` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_kho_nhom` int(11) NOT NULL,
  `so_luong` int(11) NOT NULL,
  `so_luong_cu` int(11) DEFAULT NULL,
  `so_luong_moi` int(11) DEFAULT NULL,
  `noi_dung` text COLLATE utf8_unicode_ci NOT NULL,
  `id_mau_cua` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_kho_nhom` (`id_kho_nhom`)
) ENGINE=InnoDB AUTO_INCREMENT=279 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_kho_nhom_lich_su`
--

INSERT INTO `cua_kho_nhom_lich_su` (`id`, `id_kho_nhom`, `so_luong`, `so_luong_cu`, `so_luong_moi`, `noi_dung`, `id_mau_cua`, `date_created`, `user_created`) VALUES
(157, 138, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(158, 139, 10, 0, 10, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm ', NULL, '2023-12-29 16:24:23', 1),
(159, 140, 0, 0, 0, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(160, 141, 5, 0, 5, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm ', NULL, '2023-12-29 16:24:23', 1),
(161, 142, 20, 0, 20, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm ', NULL, '2023-12-29 16:24:23', 1),
(162, 143, 0, 0, 0, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(163, 144, 0, 0, 0, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(164, 145, 0, 0, 0, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(165, 146, 3, 0, 3, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(166, 147, 0, 0, 0, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(167, 148, 0, 0, 0, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(168, 149, 0, 0, 0, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(169, 150, 4, 0, 4, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(170, 151, 5, 0, 5, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(171, 152, 0, 0, 0, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(172, 153, 0, 0, 0, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(173, 154, 3, 0, 3, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(174, 155, 0, 0, 0, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(175, 156, 0, 0, 0, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(176, 157, 2, 0, 2, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(177, 158, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(178, 159, 2, 0, 2, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(179, 160, 3, 0, 3, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(180, 161, 10, 0, 10, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(181, 162, 8, 0, 8, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(182, 163, 8, 0, 8, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(183, 164, 11, 0, 11, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(184, 165, 2, 0, 2, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(185, 166, 3, 0, 3, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(186, 167, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(187, 168, 3, 0, 3, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(188, 169, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(189, 170, 2, 0, 2, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(190, 171, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(191, 172, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(192, 173, 3, 0, 3, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(193, 174, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(194, 175, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(195, 176, 4, 0, 4, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(196, 177, 0, 0, 0, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-29 16:24:23', 1),
(197, 138, 19, 1, 20, 'Cập nhật tồn kho do sửa dữ liệu kho nhôm #Rinoxt (5900) <br/>xx', NULL, '2023-12-29 16:25:02', 1),
(198, 143, 100, 0, 100, 'Cập nhật tồn kho do sửa dữ liệu kho nhôm #SD3295 (5900) <br/>xx', NULL, '2023-12-29 16:25:26', 1),
(199, 138, 1, 20, 21, 'Cập nhật tồn kho do cập nhật dữ liệu kho nhôm #Rinoxt (5900) từ file exel', NULL, '2023-12-29 16:25:38', 1),
(200, 139, 10, 10, 20, 'Cập nhật tồn kho do cập nhật dữ liệu kho nhôm #Rinoxt (5500) từ file exel', NULL, '2023-12-29 16:25:38', 1),
(201, 141, 5, 5, 10, 'Cập nhật tồn kho do cập nhật dữ liệu kho nhôm #SD0415 (1000) từ file exel', NULL, '2023-12-29 16:25:38', 1),
(202, 142, 20, 20, 40, 'Cập nhật tồn kho do cập nhật dữ liệu kho nhôm #SD0415 (1500) từ file exel', NULL, '2023-12-29 16:25:38', 1),
(203, 146, 3, 3, 6, 'Cập nhật tồn kho do cập nhật dữ liệu kho nhôm #XD0312 (5900) từ file exel', NULL, '2023-12-29 16:25:38', 1),
(204, 150, 4, 4, 8, 'Cập nhật tồn kho do cập nhật dữ liệu kho nhôm #XD3209 (5900) từ file exel', NULL, '2023-12-29 16:25:38', 1),
(205, 151, 5, 5, 10, 'Cập nhật tồn kho do cập nhật dữ liệu kho nhôm #XD3295 (5900) từ file exel', NULL, '2023-12-29 16:25:38', 1),
(206, 154, 3, 3, 6, 'Cập nhật tồn kho do cập nhật dữ liệu kho nhôm #XD3303mr (5900) từ file exel', NULL, '2023-12-29 16:25:38', 1),
(207, 157, 2, 2, 4, 'Cập nhật tồn kho do cập nhật dữ liệu kho nhôm #XD3328 (5900) từ file exel', NULL, '2023-12-29 16:25:38', 1),
(208, 158, 1, 1, 2, 'Cập nhật tồn kho do cập nhật dữ liệu kho nhôm #XD8092 (5900) từ file exel', NULL, '2023-12-29 16:25:38', 1),
(209, 159, 2, 2, 4, 'Cập nhật tồn kho do cập nhật dữ liệu kho nhôm #XL100F0712 (5900) từ file exel', NULL, '2023-12-29 16:25:38', 1),
(210, 160, 3, 3, 6, 'Cập nhật tồn kho do cập nhật dữ liệu kho nhôm #XL100F1012 (5900) từ file exel', NULL, '2023-12-29 16:25:38', 1),
(211, 161, 10, 10, 20, 'Cập nhật tồn kho do cập nhật dữ liệu kho nhôm #XL100F1109 (5900) từ file exel', NULL, '2023-12-29 16:25:38', 1),
(212, 162, 8, 8, 16, 'Cập nhật tồn kho do cập nhật dữ liệu kho nhôm #XL550112 (5900) từ file exel', NULL, '2023-12-29 16:25:38', 1),
(213, 163, 8, 8, 16, 'Cập nhật tồn kho do cập nhật dữ liệu kho nhôm #XL550212 (5900) từ file exel', NULL, '2023-12-29 16:25:38', 1),
(214, 164, 11, 11, 22, 'Cập nhật tồn kho do cập nhật dữ liệu kho nhôm #XL55D0412 (5900) từ file exel', NULL, '2023-12-29 16:25:38', 1),
(215, 165, 2, 2, 4, 'Cập nhật tồn kho do cập nhật dữ liệu kho nhôm #XL55D0512 (5900) từ file exel', NULL, '2023-12-29 16:25:38', 1),
(216, 166, 3, 3, 6, 'Cập nhật tồn kho do cập nhật dữ liệu kho nhôm #XP3332 (5900) từ file exel', NULL, '2023-12-29 16:25:39', 1),
(217, 167, 1, 1, 2, 'Cập nhật tồn kho do cập nhật dữ liệu kho nhôm #XP550415 (5900) từ file exel', NULL, '2023-12-29 16:25:39', 1),
(218, 168, 3, 3, 6, 'Cập nhật tồn kho do cập nhật dữ liệu kho nhôm #XP55D3203 (5900) từ file exel', NULL, '2023-12-29 16:25:39', 1),
(219, 169, 1, 1, 2, 'Cập nhật tồn kho do cập nhật dữ liệu kho nhôm #XP55D5108 (5900) từ file exel', NULL, '2023-12-29 16:25:39', 1),
(220, 170, 2, 2, 4, 'Cập nhật tồn kho do cập nhật dữ liệu kho nhôm #XP55D5314 (5900) từ file exel', NULL, '2023-12-29 16:25:39', 1),
(221, 171, 1, 1, 2, 'Cập nhật tồn kho do cập nhật dữ liệu kho nhôm #XP55D5414 (5900) từ file exel', NULL, '2023-12-29 16:25:39', 1),
(222, 172, 1, 1, 2, 'Cập nhật tồn kho do cập nhật dữ liệu kho nhôm #XP55D5514 (5900) từ file exel', NULL, '2023-12-29 16:25:39', 1),
(223, 173, 3, 3, 6, 'Cập nhật tồn kho do cập nhật dữ liệu kho nhôm #XP65D027112 (5900) từ file exel', NULL, '2023-12-29 16:25:39', 1),
(224, 174, 1, 1, 2, 'Cập nhật tồn kho do cập nhật dữ liệu kho nhôm #XP65D0720 (5900) từ file exel', NULL, '2023-12-29 16:25:39', 1),
(225, 175, 1, 1, 2, 'Cập nhật tồn kho do cập nhật dữ liệu kho nhôm #XP65D1210 (5900) từ file exel', NULL, '2023-12-29 16:25:39', 1),
(226, 176, 4, 4, 8, 'Cập nhật tồn kho do cập nhật dữ liệu kho nhôm #XP65D2020 (5900) từ file exel', NULL, '2023-12-29 16:25:39', 1),
(227, 138, 20, 21, 1, 'Cập nhật tồn kho do cập nhật đè dữ liệu kho nhôm #Rinoxt (5900) từ file excel', NULL, '2023-12-29 16:25:48', 1),
(228, 139, 10, 20, 10, 'Cập nhật tồn kho do cập nhật đè dữ liệu kho nhôm #Rinoxt (5500) từ file excel', NULL, '2023-12-29 16:25:48', 1),
(229, 141, 5, 10, 5, 'Cập nhật tồn kho do cập nhật đè dữ liệu kho nhôm #SD0415 (1000) từ file excel', NULL, '2023-12-29 16:25:48', 1),
(230, 142, 20, 40, 20, 'Cập nhật tồn kho do cập nhật đè dữ liệu kho nhôm #SD0415 (1500) từ file excel', NULL, '2023-12-29 16:25:48', 1),
(231, 143, 100, 100, 0, 'Cập nhật tồn kho do cập nhật đè dữ liệu kho nhôm #SD3295 (5900) từ file excel', NULL, '2023-12-29 16:25:48', 1),
(232, 146, 3, 6, 3, 'Cập nhật tồn kho do cập nhật đè dữ liệu kho nhôm #XD0312 (5900) từ file excel', NULL, '2023-12-29 16:25:48', 1),
(233, 150, 4, 8, 4, 'Cập nhật tồn kho do cập nhật đè dữ liệu kho nhôm #XD3209 (5900) từ file excel', NULL, '2023-12-29 16:25:48', 1),
(234, 151, 5, 10, 5, 'Cập nhật tồn kho do cập nhật đè dữ liệu kho nhôm #XD3295 (5900) từ file excel', NULL, '2023-12-29 16:25:48', 1),
(235, 154, 3, 6, 3, 'Cập nhật tồn kho do cập nhật đè dữ liệu kho nhôm #XD3303mr (5900) từ file excel', NULL, '2023-12-29 16:25:48', 1),
(236, 157, 2, 4, 2, 'Cập nhật tồn kho do cập nhật đè dữ liệu kho nhôm #XD3328 (5900) từ file excel', NULL, '2023-12-29 16:25:48', 1),
(237, 158, 1, 2, 1, 'Cập nhật tồn kho do cập nhật đè dữ liệu kho nhôm #XD8092 (5900) từ file excel', NULL, '2023-12-29 16:25:48', 1),
(238, 159, 2, 4, 2, 'Cập nhật tồn kho do cập nhật đè dữ liệu kho nhôm #XL100F0712 (5900) từ file excel', NULL, '2023-12-29 16:25:48', 1),
(239, 160, 3, 6, 3, 'Cập nhật tồn kho do cập nhật đè dữ liệu kho nhôm #XL100F1012 (5900) từ file excel', NULL, '2023-12-29 16:25:48', 1),
(240, 161, 10, 20, 10, 'Cập nhật tồn kho do cập nhật đè dữ liệu kho nhôm #XL100F1109 (5900) từ file excel', NULL, '2023-12-29 16:25:48', 1),
(241, 162, 8, 16, 8, 'Cập nhật tồn kho do cập nhật đè dữ liệu kho nhôm #XL550112 (5900) từ file excel', NULL, '2023-12-29 16:25:48', 1),
(242, 163, 8, 16, 8, 'Cập nhật tồn kho do cập nhật đè dữ liệu kho nhôm #XL550212 (5900) từ file excel', NULL, '2023-12-29 16:25:48', 1),
(243, 164, 11, 22, 11, 'Cập nhật tồn kho do cập nhật đè dữ liệu kho nhôm #XL55D0412 (5900) từ file excel', NULL, '2023-12-29 16:25:48', 1),
(244, 165, 2, 4, 2, 'Cập nhật tồn kho do cập nhật đè dữ liệu kho nhôm #XL55D0512 (5900) từ file excel', NULL, '2023-12-29 16:25:48', 1),
(245, 166, 3, 6, 3, 'Cập nhật tồn kho do cập nhật đè dữ liệu kho nhôm #XP3332 (5900) từ file excel', NULL, '2023-12-29 16:25:48', 1),
(246, 167, 1, 2, 1, 'Cập nhật tồn kho do cập nhật đè dữ liệu kho nhôm #XP550415 (5900) từ file excel', NULL, '2023-12-29 16:25:48', 1),
(247, 168, 3, 6, 3, 'Cập nhật tồn kho do cập nhật đè dữ liệu kho nhôm #XP55D3203 (5900) từ file excel', NULL, '2023-12-29 16:25:48', 1),
(248, 169, 1, 2, 1, 'Cập nhật tồn kho do cập nhật đè dữ liệu kho nhôm #XP55D5108 (5900) từ file excel', NULL, '2023-12-29 16:25:48', 1),
(249, 170, 2, 4, 2, 'Cập nhật tồn kho do cập nhật đè dữ liệu kho nhôm #XP55D5314 (5900) từ file excel', NULL, '2023-12-29 16:25:48', 1),
(250, 171, 1, 2, 1, 'Cập nhật tồn kho do cập nhật đè dữ liệu kho nhôm #XP55D5414 (5900) từ file excel', NULL, '2023-12-29 16:25:48', 1),
(251, 172, 1, 2, 1, 'Cập nhật tồn kho do cập nhật đè dữ liệu kho nhôm #XP55D5514 (5900) từ file excel', NULL, '2023-12-29 16:25:48', 1),
(252, 173, 3, 6, 3, 'Cập nhật tồn kho do cập nhật đè dữ liệu kho nhôm #XP65D027112 (5900) từ file excel', NULL, '2023-12-29 16:25:48', 1),
(253, 174, 1, 2, 1, 'Cập nhật tồn kho do cập nhật đè dữ liệu kho nhôm #XP65D0720 (5900) từ file excel', NULL, '2023-12-29 16:25:48', 1),
(254, 175, 1, 2, 1, 'Cập nhật tồn kho do cập nhật đè dữ liệu kho nhôm #XP65D1210 (5900) từ file excel', NULL, '2023-12-29 16:25:48', 1),
(255, 176, 4, 8, 4, 'Cập nhật tồn kho do cập nhật đè dữ liệu kho nhôm #XP65D2020 (5900) từ file excel', NULL, '2023-12-29 16:25:48', 1),
(256, 178, 0, 0, 0, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-31 10:56:26', 2),
(257, 179, 0, 0, 0, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2023-12-31 10:56:26', 2),
(258, 180, 100, 0, 100, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm ', NULL, '2023-12-31 10:57:34', 2),
(259, 181, 50, 0, 50, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm ', NULL, '2023-12-31 10:57:56', 2),
(260, 180, -100, 100, 0, 'Cập nhật tồn kho do sửa dữ liệu kho nhôm #C3300 (5900) <br/>x', NULL, '2023-12-31 12:46:34', 2),
(261, 182, 5900, 0, 5900, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm ', NULL, '2023-12-31 15:16:14', 2),
(262, 183, 10, 0, 10, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm ', NULL, '2023-12-31 15:16:31', 2),
(263, 180, 1, -2, -3, 'Xuất kho mẫu cửa #4bMWw', 23, '2023-12-31 23:21:14', 2),
(264, 181, 1, 50, 49, 'Xuất kho mẫu cửa #4bMWw', 23, '2023-12-31 23:21:14', 2),
(265, 181, 1, 49, 48, 'Xuất kho mẫu cửa #4bMWw', 23, '2023-12-31 23:21:14', 2),
(266, 181, 1, 48, 47, 'Xuất kho mẫu cửa #4bMWw', 23, '2023-12-31 23:21:14', 2),
(267, 181, 1, 47, 46, 'Xuất kho mẫu cửa #4bMWw', 23, '2023-12-31 23:21:14', 2),
(268, 180, 1, -3, -4, 'Xuất kho mẫu cửa #4bMWw', 23, '2023-12-31 23:21:31', 2),
(269, 181, 1, 46, 45, 'Xuất kho mẫu cửa #4bMWw', 23, '2023-12-31 23:21:31', 2),
(270, 181, 1, 45, 44, 'Xuất kho mẫu cửa #4bMWw', 23, '2023-12-31 23:21:31', 2),
(271, 181, 1, 44, 43, 'Xuất kho mẫu cửa #4bMWw', 23, '2023-12-31 23:21:31', 2),
(272, 181, 1, 43, 42, 'Xuất kho mẫu cửa #4bMWw', 23, '2023-12-31 23:21:31', 2),
(273, 180, 1, -4, -5, 'Xuất kho mẫu cửa #47YJr', 24, '2023-12-31 23:24:37', 2),
(274, 183, 1, 10, 9, 'Xuất kho mẫu cửa #47YJr', 24, '2023-12-31 23:24:37', 2),
(275, 183, 1, 9, 8, 'Xuất kho mẫu cửa #47YJr', 24, '2023-12-31 23:24:37', 2),
(276, 183, 1, 8, 7, 'Xuất kho mẫu cửa #47YJr', 24, '2023-12-31 23:24:37', 2),
(277, 181, 1, 42, 41, 'Xuất kho mẫu cửa #47YJr', 24, '2023-12-31 23:24:37', 2),
(278, 181, 1, 41, 40, 'Xuất kho mẫu cửa #47YJr', 24, '2023-12-31 23:24:37', 2);

-- --------------------------------------------------------

--
-- Table structure for table `cua_kho_vat_tu`
--

DROP TABLE IF EXISTS `cua_kho_vat_tu`;
CREATE TABLE IF NOT EXISTS `cua_kho_vat_tu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_vat_tu` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `id_nhom_vat_tu` int(11) DEFAULT NULL,
  `thuong_hieu` int(11) DEFAULT NULL,
  `model` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `xuat_xu` int(11) DEFAULT NULL,
  `nha_cung_cap` int(11) DEFAULT NULL,
  `la_phu_kien` tinyint(1) DEFAULT NULL,
  `so_luong` float DEFAULT NULL,
  `dvt` int(11) NOT NULL,
  `don_gia` double DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_nhom_vat_tu` (`id_nhom_vat_tu`),
  KEY `xuat_xu` (`xuat_xu`)
) ENGINE=InnoDB AUTO_INCREMENT=925 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_kho_vat_tu`
--

INSERT INTO `cua_kho_vat_tu` (`id`, `code`, `ten_vat_tu`, `id_nhom_vat_tu`, `thuong_hieu`, `model`, `xuat_xu`, `nha_cung_cap`, `la_phu_kien`, `so_luong`, `dvt`, `don_gia`, `ghi_chu`, `date_created`, `user_created`) VALUES
(643, 'BkbSA1965Bogo', 'Bộ khóa biến - vân chốt hàm dùng cho cửa 1 cánh', 1, 1, NULL, 1, 2, 1, 100, 212, 76400, NULL, '2023-12-24 22:45:59', 1),
(644, 'Bl20w17 ETCBogo', 'Tay nắm cửa đi - Màu champagne', 1, 1, NULL, 1, 3, 1, 100, 212, 11030400, NULL, '2023-12-24 22:45:59', 1),
(645, 'blkxt 75', 'Bản lề kéo xếp trượt  75', 1, 1, NULL, 1, 3, 1, 100, 212, 520000, NULL, '2023-12-24 22:45:59', 1),
(646, 'BLS Dra', 'Bản Lề Sàn', 1, 1, NULL, 1, NULL, 1, 100, 212, 2742080, NULL, '2023-12-24 22:45:59', 1),
(647, 'blxt 75', 'Bản lề thường xếp trượt  75', 1, 1, NULL, 1, NULL, 1, 100, 212, 3456000, NULL, '2023-12-24 22:45:59', 1),
(648, 'bxxt 75', 'Bộ bánh xe xếp trượt PMI 75', 1, 1, NULL, 1, NULL, 1, 100, 212, 2600000, NULL, '2023-12-24 22:45:59', 1),
(649, 'CbBogo', 'Chốt bật Bogo', 1, 1, NULL, 1, NULL, 1, 100, 212, 3168000, NULL, '2023-12-24 22:45:59', 1),
(650, 'HcxtPMI.bac', 'Hộp chốt xếp trượt PMI - Màu bạc', 1, 1, NULL, 1, NULL, 1, 100, 212, 377600, NULL, '2023-12-24 22:45:59', 1),
(651, 'Lk90.75', 'Lỗi khóa 90mm hệ75', 1, 1, NULL, 1, NULL, 1, 100, 212, 304000, NULL, '2023-12-24 22:45:59', 1),
(652, 'Mccscđ.RCBogo', 'Miệng chốt cửa sổ , cửa đi cho nhôm hệ  rảnh C', 1, 1, NULL, 1, NULL, 1, 100, 212, 885600, NULL, '2023-12-24 22:45:59', 1),
(653, 'Mđk 75', 'Miệng đơn khóa 75', 1, 1, NULL, 1, NULL, 1, 100, 212, 58400, NULL, '2023-12-24 22:45:59', 1),
(654, 'Mkl inoxBogo', 'Miệng khóa lùa dùng cho ray Inox', 1, 1, NULL, 1, NULL, 1, 100, 212, 0, NULL, '2023-12-24 22:45:59', 1),
(655, 'Ncr', 'Nhựa Chống Rung', 1, 1, NULL, 1, NULL, 1, 100, 212, 97920, NULL, '2023-12-24 22:45:59', 1),
(656, 'PK E2c8b', 'Bộ phụ kiện E chống tự động dùng giảm chắn 2 chiều 8 bánh', 1, 1, NULL, 1, NULL, 1, 100, 212, 4700000, NULL, '2023-12-24 22:45:59', 1),
(657, 'RTKS.20A', 'Rèm trong kính S- 20A-Cơ tay', 1, 1, NULL, 1, NULL, 1, 100, 212, 3634875, NULL, '2023-12-24 22:45:59', 1),
(658, 'SA -1964Bogo', 'Bộ khóa biên + vấu chốt hàm dùng cho cửa 2 cánh', 1, 1, NULL, 1, NULL, 1, 100, 212, 651700, NULL, '2023-12-24 22:45:59', 1),
(659, 'Shbđn', 'Súng hơn bắn đạn nhôm', 1, 1, NULL, 1, NULL, 1, 100, 212, 1200000, NULL, '2023-12-24 22:45:59', 1),
(660, 'Sh.phi5', 'Súng hơi đột lỗ ke đạn phi 5 dùng cho tất cả hệ nhôm', 1, 1, NULL, 1, NULL, 1, 100, 212, 3450000, NULL, '2023-12-24 22:45:59', 1),
(661, 'TCCP.acb04', 'Thanh Chốt Cánh Phụ', 1, 1, NULL, 1, NULL, 1, 100, 212, 200000, NULL, '2023-12-24 22:45:59', 1),
(662, 'Tcđ-bogo', 'Tay Cửa đi BoGo', 1, 1, NULL, 1, NULL, 1, 100, 212, 2696320, NULL, '2023-12-24 22:45:59', 1),
(663, 'Tkđđxt 75', 'Thân khóa đơn điểm xếp trượt  75', 1, 1, NULL, 1, NULL, 1, 100, 212, 352000, NULL, '2023-12-24 22:45:59', 1),
(664, 'tnbh 75.bạc', 'Tay nắm bẹt hệ 75- Bạc', 1, 1, NULL, 1, NULL, 1, 100, 212, 296000, NULL, '2023-12-24 22:45:59', 1),
(665, 'tncđ.bacBogo', 'Tay nắm cửa đi màu bạc', 1, 1, NULL, 1, NULL, 1, 100, 212, 3830000, NULL, '2023-12-24 22:45:59', 1),
(666, 'Tncđxt 75.Bạc', 'Tay nắm cửa đi xếp trượt 75. Bạc', 1, 1, NULL, 1, NULL, 1, 100, 212, 472000, NULL, '2023-12-24 22:45:59', 1),
(667, 'TnPM23.Dra', 'Tay nắm PM-23(L8*90.M5*70)', 1, 1, NULL, 1, NULL, 1, 100, 212, 564908, NULL, '2023-12-24 22:45:59', 1),
(668, 'TNPM27.92Dra', 'Tay nắm PM-27 L8*90,M5*70', 1, 1, NULL, 1, NULL, 1, 100, 212, 4256968, NULL, '2023-12-24 22:45:59', 1),
(669, 'TNPM27ABDra', 'Tay nắm PM-27 đen AB', 1, 1, NULL, 1, NULL, 1, 100, 212, 2741776, NULL, '2023-12-24 22:45:59', 1),
(670, 'TNPM27Dra', 'Tay nắm PM-27 L8*90', 1, 1, NULL, 1, NULL, 1, 100, 212, 2741776, NULL, '2023-12-24 22:45:59', 1),
(671, 'Vcđđ.L100Bogo', 'Bộ vấu chốt đa điểm - L100 PMI', 1, 1, NULL, 1, NULL, 1, 100, 212, 345800, NULL, '2023-12-24 22:45:59', 1),
(672, 'Z06TBogo', 'Đầu chìa chữ T cho cửa sổ mở quay', 1, 1, NULL, 1, NULL, 1, 100, 212, 217600, NULL, '2023-12-24 22:45:59', 1),
(673, 'Z76B.xfBogo', 'Miệng chốt cửa sổ , cửa đi cho nhôm hệ Xingfa', 1, 1, NULL, 1, NULL, 1, 100, 212, 350400, NULL, '2023-12-24 22:45:59', 1),
(674, 'Bl4D', 'Bản lề 4D KC', 1, 1, NULL, 1, NULL, 1, 100, 7, 1075000, NULL, '2023-12-24 22:45:59', 1),
(675, 'BLR1591', 'Bản lề rảnh C', 1, 1, NULL, 1, NULL, 1, 100, 7, 6020000, NULL, '2023-12-24 22:45:59', 1),
(676, 'bxel.55xf', 'Bánh xe lùa hệ 55 Xinfa', 1, 1, NULL, 1, NULL, 1, 100, 7, 5700000, NULL, '2023-12-24 22:45:59', 1),
(677, 'Caosu', 'Cao su chống va đập cánh', 1, 1, NULL, 1, NULL, 1, 100, 7, 69000, NULL, '2023-12-24 22:45:59', 1),
(678, 'cbcp150', 'Chốt bật cánh phụ', 1, 1, NULL, 1, NULL, 1, 100, 7, 1080000, NULL, '2023-12-24 22:45:59', 1),
(679, 'Cbtr', 'Cảm biến trong', 1, 1, NULL, 1, NULL, 1, 100, 7, 880000, NULL, '2023-12-24 22:45:59', 1),
(680, 'ccp 10B', 'Chốt cánh phụ', 1, 1, NULL, 1, NULL, 1, 100, 7, 240000, NULL, '2023-12-24 22:45:59', 1),
(681, 'ccp 2A16A', 'Đế Chốt cánh phụ', 1, 1, NULL, 1, NULL, 1, 100, 7, 30000, NULL, '2023-12-24 22:45:59', 1),
(682, 'CĐR', 'Cây đi ron', 1, 1, NULL, 1, NULL, 1, 100, 7, 250000, NULL, '2023-12-24 22:45:59', 1),
(683, 'Chancanh', 'Chặn cánh FKD ( màu đen)', 1, 1, NULL, 1, NULL, 1, 100, 7, 287500, NULL, '2023-12-24 22:45:59', 1),
(684, 'contruot', 'Con trượt bằng thép,model SBR30UU', 1, 1, NULL, 1, NULL, 1, 100, 7, 1160000, NULL, '2023-12-24 22:45:59', 1),
(685, 'đcrC', 'Đế chốt rảnh C', 1, 1, NULL, 1, NULL, 1, 100, 7, 60000, NULL, '2023-12-24 22:45:59', 1),
(686, 'ĐNĐĐ.PJ063B', 'Đầu Nối Đa Điểm L=130mm', 1, 1, NULL, 1, NULL, 1, 100, 7, 100000, NULL, '2023-12-24 22:45:59', 1),
(687, 'DRTN', 'Dao rọc tem nhôm', 1, 1, NULL, 1, NULL, 1, 100, 7, 720000, NULL, '2023-12-24 22:45:59', 1),
(688, 'ĐTL', 'Đai thủy lực', 1, 1, NULL, 1, NULL, 1, 100, 7, 100000, NULL, '2023-12-24 22:45:59', 1),
(689, 'FC3008Bogo', 'Hố chốt âm chống bụi', 1, 1, NULL, 1, NULL, 1, 100, 7, 665000, NULL, '2023-12-24 22:45:59', 1),
(690, 'GCC', 'Góc Cá Chép', 1, 1, NULL, 1, NULL, 1, 100, 7, 1980000, NULL, '2023-12-24 22:45:59', 1),
(691, 'HKCĐĐĐ 35', 'Hộp khóa cửa đi đa điểm 35mm- Rảnh C', 1, 1, NULL, 1, NULL, 1, 100, 7, 660000, NULL, '2023-12-24 22:45:59', 1),
(692, 'Kbghck', 'Kiềm bấm gân hàm chốt khóa', 1, 1, NULL, 1, NULL, 1, 100, 7, 1700000, NULL, '2023-12-24 22:45:59', 1),
(693, 'Kbhe55', 'Kiềm bấm thoát nước ray lùa hệ 55', 1, 1, NULL, 1, NULL, 1, 100, 7, 1700000, NULL, '2023-12-24 22:45:59', 1),
(694, 'KC-4T5', 'Kẹp chữ C - 4T5', 1, 1, NULL, 1, NULL, 1, 100, 7, 800000, NULL, '2023-12-24 22:45:59', 1),
(695, 'KCCĐ', 'Ke cánh cửa đi', 1, 1, NULL, 1, NULL, 1, 100, 7, 400000, NULL, '2023-12-24 22:45:59', 1),
(696, 'KCCS', 'Ke cách cửa sổ', 1, 1, NULL, 1, NULL, 1, 100, 7, 500000, NULL, '2023-12-24 22:45:59', 1),
(697, 'KCR', 'Kéo cắt ron', 1, 1, NULL, 1, NULL, 1, 100, 7, 675000, NULL, '2023-12-24 22:45:59', 1),
(698, 'KCTL', 'Ke cánh thủy lực', 1, 1, NULL, 1, NULL, 1, 100, 7, 500000, NULL, '2023-12-24 22:45:59', 1),
(699, 'KE14x35', 'KVC cánh lùa 55', 1, 1, NULL, 1, NULL, 1, 100, 7, 1463000, NULL, '2023-12-24 22:45:59', 1),
(700, 'KE14x51', 'KVC Khung bao vách kính', 1, 1, NULL, 1, NULL, 1, 100, 7, 2362500, NULL, '2023-12-24 22:45:59', 1),
(701, 'KE25x41', 'KVC  Cánh cửa đi', 1, 1, NULL, 1, NULL, 1, 100, 7, 1856000, NULL, '2023-12-24 22:45:59', 1),
(702, 'KE31x41', 'KVC Khung Cánh cửa đi', 1, 1, NULL, 1, NULL, 1, 100, 7, 6384000, NULL, '2023-12-24 22:45:59', 1),
(703, 'Kecxt', 'Ke cánh xếp trượt', 1, 1, NULL, 1, NULL, 1, 100, 7, 880000, NULL, '2023-12-24 22:45:59', 1),
(704, 'Keđkbcđ.65', 'Ke đạn khung bao cửa đi hệ 65', 1, 1, NULL, 1, NULL, 1, 100, 7, 108000, NULL, '2023-12-24 22:45:59', 1),
(705, 'Kegxt63', 'Ke ép góc xếp trượt hệ 63', 1, 1, NULL, 1, NULL, 1, 100, 7, 690000, NULL, '2023-12-24 22:45:59', 1),
(706, 'Kepcđ.9kg', 'Ke ép góc và bán đạn (KBCĐ)(9kg)', 1, 1, NULL, 1, NULL, 1, 100, 7, 915600, NULL, '2023-12-24 22:45:59', 1),
(707, 'KKCĐ', 'Ke khung cửa đi', 1, 1, NULL, 1, NULL, 1, 100, 7, 400000, NULL, '2023-12-24 22:45:59', 1),
(708, 'KKCĐ.65', 'Ke khung cửa đi hệ R65', 1, 1, NULL, 1, NULL, 1, 100, 7, 2180000, NULL, '2023-12-24 22:45:59', 1),
(709, 'Ktcn', 'Khung Test cửa nhôm', 1, 1, NULL, 1, NULL, 1, 100, 7, 35750000, NULL, '2023-12-24 22:45:59', 1),
(710, 'KVC32.41CRGCL', 'Ke Vĩnh Cửu 32*41 CRom (GCL)', 1, 1, NULL, 1, NULL, 1, 100, 7, 3000000, NULL, '2023-12-24 22:45:59', 1),
(711, 'Kvctq', 'Ke vĩnh cửu trượt quay', 1, 1, NULL, 1, NULL, 1, 100, 7, 768000, NULL, '2023-12-24 22:45:59', 1),
(712, 'Kvctq.4', 'Ke vĩnh cửu D&T V31*29 loại 4 dành cho hệ trượt quay', 1, 1, NULL, 1, NULL, 1, 100, 7, 415000, NULL, '2023-12-24 22:45:59', 1),
(713, 'lk2đc100', 'Lỗi khoái 2 đầu chìa 10067.5s/32.5s- Rảnh C', 1, 1, NULL, 1, NULL, 1, 100, 7, 310000, NULL, '2023-12-24 22:45:59', 1),
(714, 'LK2ĐC 100', 'Lỗi khóa 2 đầu chìa 100 67.55/32.5S-Rảnh C', 1, 1, NULL, 1, NULL, 1, 100, 7, 310000, NULL, '2023-12-24 22:45:59', 1),
(715, 'mđkc2C', 'Miệng đón khóa cửa rảnh C (1-2 cánh xài chung)', 1, 1, NULL, 1, NULL, 1, 100, 7, 120000, NULL, '2023-12-24 22:45:59', 1),
(716, 'mlccn.500', 'Mài lưỡi cưa cắt nhôm đường kính 500', 1, 1, NULL, 1, NULL, 1, 100, 7, 240000, NULL, '2023-12-24 22:45:59', 1),
(717, 'NHT8', 'Nối hơi T 8', 1, 1, NULL, 1, NULL, 1, 100, 7, 12000, NULL, '2023-12-24 22:45:59', 1),
(718, 'NNo8', 'Nối nhanh ống 8', 1, 1, NULL, 1, NULL, 1, 100, 7, 24000, NULL, '2023-12-24 22:45:59', 1),
(719, 'Ntn', 'Nắp thoát nước', 1, 1, NULL, 1, NULL, 1, 100, 7, 60000, NULL, '2023-12-24 22:45:59', 1),
(720, 'Rk1cmv', 'Ruột khóa 1 chìa mở vào', 1, 1, NULL, 1, NULL, 1, 100, 7, 1052480, NULL, '2023-12-24 22:45:59', 1),
(721, 'Tkcđđđ.35Bogo', 'Thân khóa cửa đi đa điểm 35mm Bogo', 1, 1, NULL, 1, NULL, 1, 100, 7, 6360000, NULL, '2023-12-24 22:45:59', 1),
(722, 'TkcđđđBogo', 'Thân khóa cửa đi đơn điểm Bogo', 1, 1, NULL, 1, NULL, 1, 100, 7, 1258400, NULL, '2023-12-24 22:45:59', 1),
(723, 'ValiMau', 'VaLi Mẫu ( Trung Quân)', 1, 1, NULL, 1, NULL, 1, 100, 7, 3800000, NULL, '2023-12-24 22:45:59', 1),
(724, 'ValiTesla', 'Vali đầy đủ phụ kiện Tesla', 1, 1, NULL, 1, NULL, 1, 100, 7, 2500000, NULL, '2023-12-24 22:45:59', 1),
(725, 'Van C2000', 'Van điều áp C2000', 1, 1, NULL, 1, NULL, 1, 100, 7, 250000, NULL, '2023-12-24 22:45:59', 1),
(726, 'Vangat', 'Van Gạt', 1, 1, NULL, 1, NULL, 1, 100, 7, 135000, NULL, '2023-12-24 22:45:59', 1),
(727, 'VC1Ke1Bogo', 'Cánh cửa số 1 ke', 1, 1, NULL, 1, NULL, 1, 100, 7, 3057600, NULL, '2023-12-24 22:45:59', 1),
(728, 'Xilanh 32', 'Xilanh Mal 32*100-1 đầu', 1, 1, NULL, 1, NULL, 1, 100, 7, 960000, NULL, '2023-12-24 22:45:59', 1),
(729, 'BCCCN', 'Bịt chân cánh có ngưỡng', 1, 1, NULL, 1, NULL, 1, 100, 14, 300000, NULL, '2023-12-24 22:45:59', 1),
(730, 'BCCKN', 'Bịt chân cánh không ngưỡng', 1, 1, NULL, 1, NULL, 1, 100, 14, 300000, NULL, '2023-12-24 22:45:59', 1),
(731, 'BĐĐ.TP', 'Bịt đổ động ( Trái, phải)', 1, 1, NULL, 1, NULL, 1, 100, 14, 400000, NULL, '2023-12-24 22:45:59', 1),
(732, 'Dcnhom', 'Dao Cắt Nhôm', 1, 1, NULL, 1, NULL, 1, 100, 14, 12800000, NULL, '2023-12-24 22:45:59', 1),
(733, 'tncđkc P027', 'Tay nắm cửa đi kim cương', 1, 1, NULL, 1, NULL, 1, 100, 14, 1040000, NULL, '2023-12-24 22:45:59', 1),
(734, 'TnTL.800.400', 'Tay nắm Thủy lực 800- tim 400', 1, 1, NULL, 1, NULL, 1, 100, 14, 1300000, NULL, '2023-12-24 22:45:59', 1),
(735, 'BC3285C1Dra', 'Bụng Cửa', 1, 1, NULL, 1, NULL, 1, 100, 213, 190781, NULL, '2023-12-24 22:45:59', 1),
(736, 'BCĐ2285C1Dra', 'Bụng Cửa Đa', 1, 1, NULL, 1, NULL, 1, 100, 213, 1890860, NULL, '2023-12-24 22:45:59', 1),
(737, 'BCĐ2885CDra', 'Bụng Cửa Đa 2885', 1, 1, NULL, 1, NULL, 1, 100, 213, 2066896, NULL, '2023-12-24 22:45:59', 1),
(738, 'BCĐ3285C1Dra', 'Bụng Cửa Đa', 1, 1, NULL, 1, NULL, 1, 100, 213, 381561, NULL, '2023-12-24 22:45:59', 1),
(739, 'BCĐ3285CDra', 'Bụng Cửa Đơn', 1, 1, NULL, 1, NULL, 1, 100, 213, 1763237, NULL, '2023-12-24 22:46:00', 1),
(740, 'BCĐF12GDra', 'Bộ Chuyển động 12G', 1, 1, NULL, 1, NULL, 1, 100, 213, 130307, NULL, '2023-12-24 22:46:00', 1),
(741, 'BG180ABogo', 'Miệng khóa', 1, 1, NULL, 1, NULL, 1, 100, 213, 0, NULL, '2023-12-24 22:46:00', 1),
(742, 'BLB3 Dra', 'Bản lề biên', 1, 1, NULL, 1, NULL, 1, 100, 213, 1528497, NULL, '2023-12-24 22:46:00', 1),
(743, 'blc4DBogo', 'Bản lề cửa 4D khung - cánh (không phân biệt trái , phải)', 1, 1, NULL, 1, NULL, 1, 100, 213, 7878000, NULL, '2023-12-24 22:46:00', 1),
(744, 'blc4DcBogo', 'Bản lề cửa 4D cánh - cánh (không phân biệt trái , phải)', 1, 1, NULL, 1, NULL, 1, 100, 213, 6372000, NULL, '2023-12-24 22:46:00', 1),
(745, 'BL-ET20B Bogo', 'Khóa đi lùa đa điểm 02 mặt', 1, 1, NULL, 1, NULL, 1, 100, 213, 1936800, NULL, '2023-12-24 22:46:00', 1),
(746, 'BL-ET20C Bogo', 'Khóa đi lùa đa điểm 02 mặt', 1, 1, NULL, 1, NULL, 1, 100, 213, 860800, NULL, '2023-12-24 22:46:00', 1),
(747, 'BLP917BBogo', 'Tay cầm cửa sổ đa điểm - Màu Bạc', 1, 1, NULL, 1, NULL, 1, 100, 213, 676800, NULL, '2023-12-24 22:46:00', 1),
(748, 'BLP9217C.Bogo', 'Tay cầm cửa sổ đa điểm - Màu Champagne', 1, 1, NULL, 1, NULL, 1, 100, 213, 827200, NULL, '2023-12-24 22:46:00', 1),
(749, 'BLP9217DBogo', 'Tay cầm cửa sổ đa điểm - Màu Đen', 1, 1, NULL, 1, NULL, 1, 100, 213, 676800, NULL, '2023-12-24 22:46:00', 1),
(750, 'BLX0759-PCBogo', 'Tay cầm cửa sổ đơn điểm - Phải Champagne', 1, 1, NULL, 1, NULL, 1, 100, 213, 3008000, NULL, '2023-12-24 22:46:00', 1),
(751, 'BLZH-083 PDra', 'Bản Lề Xám', 1, 1, NULL, 1, NULL, 1, 100, 213, 3257990, NULL, '2023-12-24 22:46:00', 1),
(752, 'BLZH-085 PDra', 'Bản Lề ZH 085 - phải', 1, 1, NULL, 1, NULL, 1, 100, 213, 257684, NULL, '2023-12-24 22:46:00', 1),
(753, 'BLZH-085 T Dra', 'Bản Lề ZH 085 - Trái', 1, 1, NULL, 1, NULL, 1, 100, 213, 257684, NULL, '2023-12-24 22:46:00', 1),
(754, 'BLZH-168 4D ABDra', 'Bản Lề 4D C-K', 1, 1, NULL, 1, NULL, 1, 100, 213, 7509504, NULL, '2023-12-24 22:46:00', 1),
(755, 'BLZH168JA671 Dra', 'Bản lề 168 (JA671)', 1, 1, NULL, 1, NULL, 1, 100, 213, 3327432, NULL, '2023-12-24 22:46:00', 1),
(756, 'BLZH168T Dra', 'Bản lề 168 trắng', 1, 1, NULL, 1, NULL, 1, 100, 213, 1109144, NULL, '2023-12-24 22:46:00', 1),
(757, 'BLZH-169 4D ABDra', 'Bản Lề 4D C-C', 1, 1, NULL, 1, NULL, 1, 100, 213, 1952148, NULL, '2023-12-24 22:46:00', 1),
(758, 'BLZH-169 4D JADra', 'Bản Lề 4D C-C', 1, 1, NULL, 1, NULL, 1, 100, 213, 1952145, NULL, '2023-12-24 22:46:00', 1),
(759, 'BLZH169 Dra', 'Bản lề 169-1', 1, 1, NULL, 1, NULL, 1, 100, 213, 1729979, NULL, '2023-12-24 22:46:00', 1),
(760, 'BW-171Bogo', 'Bánh xe 2 bánh (dành cho nhôm Rolan)', 1, 1, NULL, 1, NULL, 1, 100, 213, 10440000, NULL, '2023-12-24 22:46:00', 1),
(761, 'Bx2brinoxBogo', 'Bánh xe 2 bánh - Ray inox ( hệ lùa 100F, hệ 115...)', 1, 1, NULL, 1, NULL, 1, 100, 213, 1073000, NULL, '2023-12-24 22:46:00', 1),
(762, 'bxe.55Dra', 'Bánh xe 55', 1, 1, NULL, 1, NULL, 1, 100, 213, 4864213, NULL, '2023-12-24 22:46:00', 1),
(763, 'BXRD2Dra', 'Bánh xe ray dưới', 1, 1, NULL, 1, NULL, 1, 100, 213, 494349, NULL, '2023-12-24 22:46:00', 1),
(764, 'BXRT1Dra', 'Bánh xe ray trên', 1, 1, NULL, 1, NULL, 1, 100, 213, 604612, NULL, '2023-12-24 22:46:00', 1),
(765, 'ByBQ120ACBogo', 'Chốt sập tự động đơn điểm có khóa - Champagne', 1, 1, NULL, 1, NULL, 1, 100, 213, 4636800, NULL, '2023-12-24 22:46:00', 1),
(766, 'BYBQ422AC Bogo', 'Chốt sập tự động đa điểm có khóa', 1, 1, NULL, 1, NULL, 1, 100, 213, 486200, NULL, '2023-12-24 22:46:00', 1),
(767, 'Cđay.517Dra', 'Cần đẩy FB517', 1, 1, NULL, 1, NULL, 1, 100, 213, 731498, NULL, '2023-12-24 22:46:00', 1),
(768, 'CĐZ6Dra', 'Cốt đinh', 1, 1, NULL, 1, NULL, 1, 100, 213, 63960, NULL, '2023-12-24 22:46:00', 1),
(769, 'chotso.phai Dra', 'Chốt sò phải', 1, 1, NULL, 1, NULL, 1, 100, 213, 3444468, NULL, '2023-12-24 22:46:00', 1),
(770, 'chotso.phai.trangDra', 'Chốt sò phải (màu trắng)', 1, 1, NULL, 1, NULL, 1, 100, 213, 62426, NULL, '2023-12-24 22:46:00', 1),
(771, 'chotso.trái Dra', 'Chốt sò trái', 1, 1, NULL, 1, NULL, 1, 100, 213, 3858708, NULL, '2023-12-24 22:46:00', 1),
(772, 'ĐCĐĐ.FB3HDra', 'Đầu Chia đa điểm FB3H', 1, 1, NULL, 1, NULL, 1, 100, 213, 191617, NULL, '2023-12-24 22:46:00', 1),
(773, 'ĐC.FBit Dra', 'Đầu chốt', 1, 1, NULL, 1, NULL, 1, 100, 213, 2691705, NULL, '2023-12-24 22:46:00', 1),
(774, 'DK80.48/32T Bogo', 'Lõi khóa 1 đầu chìa núm vặn mở ngoài ( nhôm hệ Xingfa 55)', 1, 1, NULL, 1, NULL, 1, 100, 213, 239200, NULL, '2023-12-24 22:46:00', 1),
(775, 'ĐNĐĐ.FB6IDra', 'Đầu Nối Đa Điểm', 1, 1, NULL, 1, NULL, 1, 100, 213, 300813, NULL, '2023-12-24 22:46:00', 1),
(776, 'ĐpgbxBogo', 'Đệm pas gần bánh xe ', 1, 1, NULL, 1, NULL, 1, 100, 213, 700000, NULL, '2023-12-24 22:46:00', 1),
(777, 'Đpgbx L45Bogo', 'Đệm pas gắn bánh xe L=145mm PMI55', 1, 1, NULL, 1, NULL, 1, 100, 213, 560000, NULL, '2023-12-24 22:46:00', 1),
(778, 'FH12CKBogo', 'Bản lề A 12inch( dành cho nhôm cầu,hệ rảnh C, châu Âu)', 1, 1, NULL, 1, NULL, 1, 100, 213, 289600, NULL, '2023-12-24 22:46:00', 1),
(779, 'JL12-300Bogo', 'Bản lề chữ A 12inch', 1, 1, NULL, 1, NULL, 1, 100, 213, 176000, NULL, '2023-12-24 22:46:00', 1),
(780, 'JL14-350Bogo', 'Bản lề chữ A 14inch', 1, 1, NULL, 1, NULL, 1, 100, 213, 193600, NULL, '2023-12-24 22:46:00', 1),
(781, 'KDX2Dra', 'Kẹp dưới', 1, 1, NULL, 1, NULL, 1, 100, 213, 278800, NULL, '2023-12-24 22:46:00', 1),
(782, 'KSS3Dra', 'Khóa Sàn', 1, 1, NULL, 1, NULL, 1, 100, 213, 519880, NULL, '2023-12-24 22:46:00', 1),
(783, 'KTS2Dra', 'Kẹp trên', 1, 1, NULL, 1, NULL, 1, 100, 213, 278800, NULL, '2023-12-24 22:46:00', 1),
(784, 'Lk1đcmn.topalBogo', 'Lõi khóa 1 đầu chìa núm vặn mở ngoài ( nhôm hệ Topal, Maxpro)', 1, 1, NULL, 1, NULL, 1, 100, 213, 744000, NULL, '2023-12-24 22:46:00', 1),
(785, 'Lk1đcmt.DK92Bogo', 'Lõi khóa 1 đầu chìa núm vặn mở trong ( nhôm hệ Topal, Maxpro)', 1, 1, NULL, 1, NULL, 1, 100, 213, 992000, NULL, '2023-12-24 22:46:00', 1),
(786, 'Lk1đcmt.XF55Bogo', 'Lõi khóa 1 đầu chìa núm vặn mở trong ( nhôm hệ Xingfa 55)', 1, 1, NULL, 1, NULL, 1, 100, 213, 956800, NULL, '2023-12-24 22:46:00', 1),
(787, 'Lk2đc79.Dra', 'Lõi khóa 2 đầu chìa 79#47/32B', 1, 1, NULL, 1, NULL, 1, 100, 213, 432440, NULL, '2023-12-24 22:46:00', 1),
(788, 'Lk2đc.topalBogo', 'Lõi khóa 2 đầu chìa ( nhôm hệ Topal, Maxpro)', 1, 1, NULL, 1, NULL, 1, 100, 213, 2652900, NULL, '2023-12-24 22:46:00', 1),
(789, 'Lk2đc.xf 55Bogo', 'Lõi khóa 2 đầu chìa ( nhôm hệ Xingfa 55)', 1, 1, NULL, 1, NULL, 1, 100, 213, 834000, NULL, '2023-12-24 22:46:00', 1),
(790, 'LK72.36Dra', 'Lỗi Khóa', 1, 1, NULL, 1, NULL, 1, 100, 213, 214470, NULL, '2023-12-24 22:46:00', 1),
(791, 'LK84.52', 'Lỗi Khóa', 1, 1, NULL, 1, NULL, 1, 100, 213, 298713, NULL, '2023-12-24 22:46:00', 1),
(792, 'LKN79.47Dra', 'Lỗi Khóa (ngoài)', 1, 1, NULL, 1, NULL, 1, 100, 213, 1134506, NULL, '2023-12-24 22:46:00', 1),
(793, 'Lkn79.Dra', 'Lõi khóa ngoài 79#47/32T', 1, 1, NULL, 1, NULL, 1, 100, 213, 432440, NULL, '2023-12-24 22:46:00', 1),
(794, 'LKT79.32Dra', 'Lỗi Khóa (trong)', 1, 1, NULL, 1, NULL, 1, 100, 213, 1134506, NULL, '2023-12-24 22:46:00', 1),
(795, 'Lkt79.Dra', 'Lõi khóa ngoài 79#32/47T', 1, 1, NULL, 1, NULL, 1, 100, 213, 432440, NULL, '2023-12-24 22:46:00', 1),
(796, 'LMH.22B-10Dra', 'Lề A Mở Hất', 1, 1, NULL, 1, NULL, 1, 100, 213, 927917, NULL, '2023-12-24 22:46:00', 1),
(797, 'LMH.22B-12Dra', 'Lề A Mở Hất', 1, 1, NULL, 1, NULL, 1, 100, 213, 1147248, NULL, '2023-12-24 22:46:00', 1),
(798, 'LMQ.211-10Dra', 'Lề A Mở Quay', 1, 1, NULL, 1, NULL, 1, 100, 213, 1048891, NULL, '2023-12-24 22:46:00', 1),
(799, 'LMQ.211-12Dra', 'Lề A Mở Quay', 1, 1, NULL, 1, NULL, 1, 100, 213, 1167782, NULL, '2023-12-24 22:46:00', 1),
(800, 'LMQ.211-14Dra', 'Lề A Mở Quay', 1, 1, NULL, 1, NULL, 1, 100, 213, 1245456, NULL, '2023-12-24 22:46:00', 1),
(801, 'MCFB8DDra', 'Miệng chốt', 1, 1, NULL, 1, NULL, 1, 100, 213, 360461, NULL, '2023-12-24 22:46:00', 1),
(802, 'miengsapDra', 'Miệng sập', 1, 1, NULL, 1, NULL, 1, 100, 213, 442680, NULL, '2023-12-24 22:46:00', 1),
(803, 'MOKB18Dra', 'Miệng Ốp 2 Cánh', 1, 1, NULL, 1, NULL, 1, 100, 213, 235616, NULL, '2023-12-24 22:46:00', 1),
(804, 'MOKB19Dra', 'Miệng Ốp 1 Cánh', 1, 1, NULL, 1, NULL, 1, 100, 213, 505518, NULL, '2023-12-24 22:46:00', 1),
(805, 'MS41.25Dra', 'Miệng Sò', 1, 1, NULL, 1, NULL, 1, 100, 213, 28454, NULL, '2023-12-24 22:46:00', 1),
(806, 'P40Bogo', 'Lưỡi gà  tay nắm cửa sổ 40', 1, 1, NULL, 1, NULL, 1, 100, 213, 0, NULL, '2023-12-24 22:46:00', 1),
(807, 'P65Bogo', 'Lưỡi gà dùng cho tay cầm cửa sổ - Topal, PMI ', 1, 1, NULL, 1, NULL, 1, 100, 213, 0, NULL, '2023-12-24 22:46:00', 1),
(808, 'tccp.Fb517 Dra', 'Thanh Chốt cánh phụ FB517', 1, 1, NULL, 1, NULL, 1, 100, 213, 3871440, NULL, '2023-12-24 22:46:00', 1),
(809, 'tccp.Fb518 Dra', 'Thanh Chốt cánh phụ FB518', 1, 1, NULL, 1, NULL, 1, 100, 213, -157360, NULL, '2023-12-24 22:46:00', 1),
(810, 'TCCP.L250.ABDra', 'Thanh Chốt Cánh Phụ đen AB', 1, 1, NULL, 1, NULL, 1, 100, 213, 454138, NULL, '2023-12-24 22:46:00', 1),
(811, 'TCCP.L250Dra', 'Thanh Chốt Cánh Phụ', 1, 1, NULL, 1, NULL, 1, 100, 213, 194731, NULL, '2023-12-24 22:46:00', 1),
(812, 'TCCP.L250.Xam Dra', 'Thanh Chốt Cánh Phụ Xám', 1, 1, NULL, 1, NULL, 1, 100, 213, 454138, NULL, '2023-12-24 22:46:00', 1),
(813, 'TCCP.L500', 'Thanh Chốt Cánh Phụ', 1, 1, NULL, 1, NULL, 1, 100, 213, 177214, NULL, '2023-12-24 22:46:00', 1),
(814, 'TCĐL38Bogo', 'Thanh Chuyển động nối đầu nối đa điểm - L= 38cm', 1, 1, NULL, 1, NULL, 1, 100, 213, 98800, NULL, '2023-12-24 22:46:00', 1),
(815, 'TCĐLG12-400Dra', 'Thanh Chuyển động', 1, 1, NULL, 1, NULL, 1, 100, 213, 456624, NULL, '2023-12-24 22:46:00', 1),
(816, 'TcđLG22Dra', 'Thanh chuyển động', 1, 1, NULL, 1, NULL, 1, 100, 213, 162848, NULL, '2023-12-24 22:46:00', 1),
(817, 'TCĐLG36-1400Dra', 'Thanh Chuyển động 36', 1, 1, NULL, 1, NULL, 1, 100, 213, 78924, NULL, '2023-12-24 22:46:00', 1),
(818, 'tcg.10Bogo', 'Thanh Chống gió 10inch', 1, 1, NULL, 1, NULL, 1, 100, 213, 140800, NULL, '2023-12-24 22:46:00', 1),
(819, 'TCH.29A-8Dra', 'Tay chống C Hất', 1, 1, NULL, 1, NULL, 1, 100, 213, 638798, NULL, '2023-12-24 22:46:00', 1),
(820, 'TCMS C221-10Dra', 'Tay Chống Ma Sát', 1, 1, NULL, 1, NULL, 1, 100, 213, 2248784, NULL, '2023-12-24 22:46:00', 1),
(821, 'TCMS C221-12Dra', 'Tay Chống Ma Sát', 1, 1, NULL, 1, NULL, 1, 100, 213, 2503636, NULL, '2023-12-24 22:46:00', 1),
(822, 'TK 7003Dra', 'Tay Kéo', 1, 1, NULL, 1, NULL, 1, 100, 213, 870840, NULL, '2023-12-24 22:46:00', 1),
(823, 'TKC-DDra', 'Tay kéo chữ D', 1, 1, NULL, 1, NULL, 1, 100, 213, 253948, NULL, '2023-12-24 22:46:00', 1),
(824, 'TN27AB', 'Tay Nắm', 1, 1, NULL, 1, NULL, 1, 100, 213, 1438610, NULL, '2023-12-24 22:46:00', 1),
(825, 'TN27JA', 'Tay Nắm', 1, 1, NULL, 1, NULL, 1, 100, 213, 1870193, NULL, '2023-12-24 22:46:00', 1),
(826, 'TNĐ.411.Le Dra', 'Tay nắm Đơn 411-Left -đen AB', 1, 1, NULL, 1, NULL, 1, 100, 213, 572880, NULL, '2023-12-24 22:46:00', 1),
(827, 'TNĐ.411.Lef Dra', 'Tay nắm Đơn 411-Left - Xám', 1, 1, NULL, 1, NULL, 1, 100, 213, 286440, NULL, '2023-12-24 22:46:00', 1),
(828, 'TNĐ.411.Ri Dra', 'Tay nắm Đơn 411-Right-xám', 1, 1, NULL, 1, NULL, 1, 100, 213, 572880, NULL, '2023-12-24 22:46:00', 1),
(829, 'TNĐ.411.Rig Dra', 'Tay nắm Đơn 411-Right- đen AB', 1, 1, NULL, 1, NULL, 1, 100, 213, 286440, NULL, '2023-12-24 22:46:00', 1),
(830, 'TNĐ F58A.đenDra', 'Tay nắm Đa F58A - đen AB', 1, 1, NULL, 1, NULL, 1, 100, 213, 1205875, NULL, '2023-12-24 22:46:00', 1),
(831, 'TNĐ F58ADra', 'Tay nắm Đa F58A - Xám', 1, 1, NULL, 1, NULL, 1, 100, 213, 1205875, NULL, '2023-12-24 22:46:00', 1),
(832, 'TNF58ADra', 'Tay nắm F58', 1, 1, NULL, 1, NULL, 1, 100, 213, 318605, NULL, '2023-12-24 22:46:00', 1),
(833, 'TNF62ADra', 'Tay nắm F62A', 1, 1, NULL, 1, NULL, 1, 100, 213, 148912, NULL, '2023-12-24 22:46:00', 1),
(834, 'tnlDY290BBogo', 'Tay nắm lùa', 1, 1, NULL, 1, NULL, 1, 100, 213, 3016000, NULL, '2023-12-24 22:46:00', 1),
(835, 'VHF13CI.1Dra', 'Vẫu hãm 1 cánh', 1, 1, NULL, 1, NULL, 1, 100, 213, 75776, NULL, '2023-12-24 22:46:00', 1),
(836, 'VHF13CIDra', 'Vẫu hãm', 1, 1, NULL, 1, NULL, 1, 100, 213, 610191, NULL, '2023-12-24 22:46:00', 1),
(837, 'VHF14CI.2Dra', 'Vẫu hãm 2 cánh', 1, 1, NULL, 1, NULL, 1, 100, 213, 92070, NULL, '2023-12-24 22:46:00', 1),
(838, 'VHF14CIDra', 'Vẫu hãm', 1, 1, NULL, 1, NULL, 1, 100, 213, 758595, NULL, '2023-12-24 22:46:00', 1),
(839, 'WD12BBogo', 'Bản lề cửa 4D - Bạc ( dành cho hệ rảnh C, châu Âu) không phân biệt trái - phải', 1, 1, NULL, 1, NULL, 1, 100, 213, 5520000, NULL, '2023-12-24 22:46:00', 1),
(840, 'WD12CBogo', 'Bản lề cửa 4D - Champagne( dành cho hệ rảnh C, châu Âu) không phân biệt trái - phải', 1, 1, NULL, 1, NULL, 1, 100, 213, 18528000, NULL, '2023-12-24 22:46:00', 1),
(841, 'WD25CBogo', 'Bản lề cửa 4D khung - cánh (không phân biệt trái , phải) - Champagne', 1, 1, NULL, 1, NULL, 1, 100, 213, 3960000, NULL, '2023-12-24 22:46:00', 1),
(842, 'ZY3085Bogo', 'Thân khóa cửa đi đơn điểm Bogo Luxxury', 1, 1, NULL, 1, NULL, 1, 100, 213, 286000, NULL, '2023-12-24 22:46:00', 1),
(843, 'ZY88530Bogo', 'Thân khóa cửa đi đa điểm thông minh Bogo', 1, 1, NULL, 1, NULL, 1, 100, 213, 4257000, NULL, '2023-12-24 22:46:00', 1),
(844, 'JLA250', 'Bản lề chữ A 250mm 10\'\'(22)', 1, 1, NULL, 1, NULL, 1, 14, 214, 378000, NULL, '2023-12-24 22:46:00', 1),
(873, 'KEG PU88', 'Keo ép góc PU 88', 2, 1, NULL, 1, NULL, 0, 1, 220, 2880000, NULL, '2023-12-24 23:03:56', 1),
(874, 'SL7-40924', 'Keo Silicon-Sealant-Màu xám nhạt (chai)', 2, 1, NULL, 1, NULL, 0, 1, 220, 4320000, NULL, '2023-12-24 23:03:56', 1),
(875, 'Đinox', 'Đạn inox cho ke', 2, 1, NULL, 1, NULL, 0, 1, 221, 0, NULL, '2023-12-24 23:03:56', 1),
(876, 'Gioang', 'Gioãng (1 cuộn - 5 kg)', 2, 1, NULL, 1, NULL, 0, 1, 222, 450000, NULL, '2023-12-24 23:03:56', 1),
(877, 'Gioang đt5', 'Ni 5*9 dùng thay gioãng dt5 ( chân cánh)', 2, 1, NULL, 1, NULL, 0, 1, 222, 200000, NULL, '2023-12-24 23:03:56', 1),
(878, 'Gioang.cđđ E', 'Gioãng cánh đối đầu dùng cho bộ E', 2, 1, NULL, 1, NULL, 0, 1, 223, 550000, NULL, '2023-12-24 23:03:56', 1),
(879, 'Gioangc.PMI', 'Gioãng cách xếp trượt PMI', 2, 1, NULL, 1, NULL, 0, 1, 223, 450000, NULL, '2023-12-24 23:03:56', 1),
(880, 'Gioang.E', 'Gioãng khung bộ E', 2, 1, NULL, 1, NULL, 0, 1, 223, 550000, NULL, '2023-12-24 23:03:56', 1),
(881, 'Gioang.PMI', 'Gioãng khung xếp trượt PMI', 2, 1, NULL, 1, NULL, 0, 1, 223, 450000, NULL, '2023-12-24 23:03:56', 1),
(882, 'Keg', 'Ke ép góc', 2, 1, NULL, 1, NULL, 0, 1, 223, 3700000, NULL, '2023-12-24 23:03:56', 1),
(883, 'KEGCK', 'Ke ép góc cánh +khung', 2, 1, NULL, 1, NULL, 0, 1, 223, 200000, NULL, '2023-12-24 23:03:56', 1),
(884, 'Ketc', 'Ke tăng cứng', 2, 1, NULL, 1, NULL, 0, 1, 223, 420000, NULL, '2023-12-24 23:03:56', 1),
(885, 'Ketc.55', 'Ke tăng cứng H55', 2, 1, NULL, 1, NULL, 0, 1, 223, 1728000, NULL, '2023-12-24 23:03:56', 1),
(886, 'Ketc63', 'Ke tăng cứng xếp trượt 63', 2, 1, NULL, 1, NULL, 0, 1, 223, 1050000, NULL, '2023-12-24 23:03:56', 1),
(887, 'NK3ly', 'Nêm kính 3 ly', 2, 1, NULL, 1, NULL, 0, 1, 223, 50000, NULL, '2023-12-24 23:03:56', 1),
(888, 'NK5ly', 'Nêm kính 5 ly', 2, 1, NULL, 1, NULL, 0, 1, 223, 50000, NULL, '2023-12-24 23:03:56', 1),
(889, 'RCK', 'Ron cánh khung', 2, 1, NULL, 1, NULL, 0, 1, 223, 750000, NULL, '2023-12-24 23:03:56', 1),
(890, 'RonC', 'Ron Cánh', 2, 1, NULL, 1, NULL, 0, 1, 223, 375000, NULL, '2023-12-24 23:03:56', 1),
(891, 'RonK', 'Ron Khung', 2, 1, NULL, 1, NULL, 0, 1, 223, 375000, NULL, '2023-12-24 23:03:56', 1),
(892, 'RonTPE', 'Ron TPE nẹp kính 8mm', 2, 1, NULL, 1, NULL, 0, 1, 223, 17000000, NULL, '2023-12-24 23:03:56', 1),
(893, 'VINb.2F', 'Vít Inox đầu bằng 2F', 2, 1, NULL, 1, NULL, 0, 1, 223, 95000, NULL, '2023-12-24 23:03:56', 1),
(894, 'VINd.2F', 'Vít Inox đầu dù 2F', 2, 1, NULL, 1, NULL, 0, 1, 223, 95000, NULL, '2023-12-24 23:03:56', 1),
(895, 'Vit', 'Kít', 2, 1, NULL, 1, NULL, 0, 1, 223, 200000, NULL, '2023-12-24 23:03:56', 1),
(896, 'Khhvy4', 'Kính hộp hoa văn ý - vàng đồng ( Y-9-4)', 2, 1, NULL, 1, NULL, 0, 1, 15, 920000, NULL, '2023-12-24 23:03:56', 1),
(897, 'Khhvy8', 'Kính hộp hoa văn ý - vàng đồng ( Y-9-8)', 2, 1, NULL, 1, NULL, 0, 1, 15, 4608720, NULL, '2023-12-24 23:03:56', 1),
(898, 'ktcl10ly', 'Kiếng trắng 10ly cường lực', 2, 1, NULL, 1, NULL, 0, 1, 15, 312532, NULL, '2023-12-24 23:03:56', 1),
(899, 'ktcl8ly', 'Kiếng trắng 8ly cường lực', 2, 1, NULL, 1, NULL, 0, 1, 15, 2503860, NULL, '2023-12-24 23:03:56', 1),
(900, 'thanhtruot', 'Thanh trượt bằng thép,model SBR30', 2, 1, NULL, 1, NULL, 0, 1, 224, 5040000, NULL, '2023-12-24 23:03:56', 1),
(901, 'TB001', 'Thiết bị 1', 3, 1, NULL, 1, NULL, 0, 10, 7, 1000000, NULL, '2023-12-24 23:23:24', 1),
(902, 'TB002', 'Thiết bị 2', 3, 1, NULL, 1, NULL, 0, 10, 7, 0, NULL, '2023-12-24 23:23:24', 1),
(907, '5CeuP', 'Ke tăng cứng', 1, 1, NULL, 1, NULL, 1, -220, 7, 0, NULL, '2023-12-31 10:56:26', 2),
(908, '7T5le', 'Ke vĩnh cữu 31x41 (cửa đi mở quay XF55)', 1, 1, NULL, 1, NULL, 1, -100, 7, 0, NULL, '2023-12-31 10:56:26', 2),
(909, '77uxg', 'Tay nắm gạt đa điểm cửa đi', 1, 1, NULL, 1, NULL, 1, -10, 14, 0, NULL, '2023-12-31 10:56:26', 2),
(910, '3FUDr', 'Miệng khóa', 1, 1, NULL, 1, NULL, 1, -10, 7, 0, NULL, '2023-12-31 10:56:26', 2),
(911, '6YRPQ', 'Thân khóa đa điểm', 1, 1, NULL, 1, NULL, 1, -10, 7, 0, NULL, '2023-12-31 10:56:26', 2),
(912, '7ecIZ', 'Lõi khóa 1 đầu chìa núm xoay mở ngoài', 1, 1, NULL, 1, NULL, 1, -10, 7, 0, NULL, '2023-12-31 10:56:26', 2),
(913, '1fXpK', 'Đầu khóa biên thấp', 1, 1, NULL, 1, NULL, 1, -20, 7, 0, NULL, '2023-12-31 10:56:26', 2),
(914, '3pwIj', 'Vấu hãm 2-4 cánh', 1, 1, NULL, 1, NULL, 1, -20, 7, 0, NULL, '2023-12-31 10:56:26', 2),
(915, '5MFjD', 'Chốt rút dài 220', 1, 1, NULL, 1, NULL, 1, -10, 7, 0, NULL, '2023-12-31 10:56:26', 2),
(916, '7BFfD', 'Chốt rút dài 500', 1, 1, NULL, 1, NULL, 1, -10, 7, 0, NULL, '2023-12-31 10:56:26', 2),
(917, '2UNax', 'Đệm chốt', 1, 1, NULL, 1, NULL, 1, -10, 7, 0, NULL, '2023-12-31 10:56:26', 2),
(918, '7RV2F', 'Hố chốt', 1, 1, NULL, 1, NULL, 1, -10, 7, 0, NULL, '2023-12-31 10:56:26', 2),
(919, '8wvx0', 'Bản lề lá 4D (khung và cánh)', 1, 1, NULL, 1, NULL, 1, -60, 7, 0, NULL, '2023-12-31 10:56:26', 2),
(920, '7GZdm', 'Ke vĩnh cữu 14x51 2 vít (khung vách - khung cửa lùa XF55)', 1, 1, NULL, 1, NULL, 1, -40, 7, 0, NULL, '2023-12-31 10:56:26', 2),
(921, '57hZc', 'Nắp bịt đố động cửa đi (các loại)', 2, 1, NULL, 1, NULL, 0, -9, 7, 0, NULL, '2023-12-31 10:56:26', 2),
(922, '9ijZ4', 'Nắp bịt ốp chân cánh (các loại)', 2, 1, NULL, 1, NULL, 0, -27, 7, 0, NULL, '2023-12-31 10:56:26', 2),
(923, '1uraT', 'VTP Cửa đi mở quay 2 cánh (gioăng - nêm - keo - vít)', 2, 1, NULL, 1, NULL, 0, -25.83, 15, 0, NULL, '2023-12-31 10:56:26', 2),
(924, '4FW1C', 'VTP ô vách (gioăng - nêm - keo - vít)', 2, 1, NULL, 1, NULL, 0, -5.22, 15, 0, NULL, '2023-12-31 10:56:26', 2);

-- --------------------------------------------------------

--
-- Table structure for table `cua_kho_vat_tu_lich_su`
--

DROP TABLE IF EXISTS `cua_kho_vat_tu_lich_su`;
CREATE TABLE IF NOT EXISTS `cua_kho_vat_tu_lich_su` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_kho_vat_tu` int(11) NOT NULL,
  `id_nha_cung_cap` int(11) DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `so_luong` float DEFAULT NULL,
  `so_luong_cu` float DEFAULT NULL,
  `so_luong_moi` float DEFAULT NULL,
  `id_mau_cua` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_kho_vat_tu` (`id_kho_vat_tu`),
  KEY `id_nha_cung_cap` (`id_nha_cung_cap`)
) ENGINE=InnoDB AUTO_INCREMENT=1309 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_kho_vat_tu_lich_su`
--

INSERT INTO `cua_kho_vat_tu_lich_su` (`id`, `id_kho_vat_tu`, `id_nha_cung_cap`, `ghi_chu`, `so_luong`, `so_luong_cu`, `so_luong_moi`, `id_mau_cua`, `date_created`, `user_created`) VALUES
(629, 643, 2, 'Nhập số lượng khi thêm mới vào kho', 1, 0, 1, NULL, '2023-12-24 22:45:59', 1),
(630, 644, 3, 'Nhập số lượng khi thêm mới vào kho', 18, 0, 18, NULL, '2023-12-24 22:45:59', 1),
(631, 645, 3, 'Nhập số lượng khi thêm mới vào kho', 1, 0, 1, NULL, '2023-12-24 22:45:59', 1),
(632, 646, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 22:45:59', 1),
(633, 647, 1, 'Nhập số lượng khi thêm mới vào kho', 9, 0, 9, NULL, '2023-12-24 22:45:59', 1),
(634, 648, 1, 'Nhập số lượng khi thêm mới vào kho', 1, 0, 1, NULL, '2023-12-24 22:45:59', 1),
(635, 649, 1, 'Nhập số lượng khi thêm mới vào kho', 72, 0, 72, NULL, '2023-12-24 22:45:59', 1),
(636, 650, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 22:45:59', 1),
(637, 651, 1, 'Nhập số lượng khi thêm mới vào kho', 1, 0, 1, NULL, '2023-12-24 22:45:59', 1),
(638, 652, 1, 'Nhập số lượng khi thêm mới vào kho', 30, 0, 30, NULL, '2023-12-24 22:45:59', 1),
(639, 653, 1, 'Nhập số lượng khi thêm mới vào kho', 1, 0, 1, NULL, '2023-12-24 22:45:59', 1),
(640, 654, 1, 'Nhập số lượng khi thêm mới vào kho', 26, 0, 26, NULL, '2023-12-24 22:45:59', 1),
(641, 655, 1, 'Nhập số lượng khi thêm mới vào kho', 8, 0, 8, NULL, '2023-12-24 22:45:59', 1),
(642, 656, 1, 'Nhập số lượng khi thêm mới vào kho', 1, 0, 1, NULL, '2023-12-24 22:45:59', 1),
(643, 657, 1, 'Nhập số lượng khi thêm mới vào kho', 1.85, 0, 1.85, NULL, '2023-12-24 22:45:59', 1),
(644, 658, 1, 'Nhập số lượng khi thêm mới vào kho', 12, 0, 12, NULL, '2023-12-24 22:45:59', 1),
(645, 659, 1, 'Nhập số lượng khi thêm mới vào kho', 1, 0, 1, NULL, '2023-12-24 22:45:59', 1),
(646, 660, 1, 'Nhập số lượng khi thêm mới vào kho', 1, 0, 1, NULL, '2023-12-24 22:45:59', 1),
(647, 661, 1, 'Nhập số lượng khi thêm mới vào kho', 4, 0, 4, NULL, '2023-12-24 22:45:59', 1),
(648, 662, 1, 'Nhập số lượng khi thêm mới vào kho', 4, 0, 4, NULL, '2023-12-24 22:45:59', 1),
(649, 663, 1, 'Nhập số lượng khi thêm mới vào kho', 1, 0, 1, NULL, '2023-12-24 22:45:59', 1),
(650, 664, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 22:45:59', 1),
(651, 665, 1, 'Nhập số lượng khi thêm mới vào kho', 6, 0, 6, NULL, '2023-12-24 22:45:59', 1),
(652, 666, 1, 'Nhập số lượng khi thêm mới vào kho', 1, 0, 1, NULL, '2023-12-24 22:45:59', 1),
(653, 667, 1, 'Nhập số lượng khi thêm mới vào kho', 5, 0, 5, NULL, '2023-12-24 22:45:59', 1),
(654, 668, 1, 'Nhập số lượng khi thêm mới vào kho', 31, 0, 31, NULL, '2023-12-24 22:45:59', 1),
(655, 669, 1, 'Nhập số lượng khi thêm mới vào kho', 20, 0, 20, NULL, '2023-12-24 22:45:59', 1),
(656, 670, 1, 'Nhập số lượng khi thêm mới vào kho', 20, 0, 20, NULL, '2023-12-24 22:45:59', 1),
(657, 671, 1, 'Nhập số lượng khi thêm mới vào kho', 3, 0, 3, NULL, '2023-12-24 22:45:59', 1),
(658, 672, 1, 'Nhập số lượng khi thêm mới vào kho', 8, 0, 8, NULL, '2023-12-24 22:45:59', 1),
(659, 673, 1, 'Nhập số lượng khi thêm mới vào kho', 12, 0, 12, NULL, '2023-12-24 22:45:59', 1),
(660, 674, 1, 'Nhập số lượng khi thêm mới vào kho', 5, 0, 5, NULL, '2023-12-24 22:45:59', 1),
(661, 675, 1, 'Nhập số lượng khi thêm mới vào kho', 28, 0, 28, NULL, '2023-12-24 22:45:59', 1),
(662, 676, 1, 'Nhập số lượng khi thêm mới vào kho', 380, 0, 380, NULL, '2023-12-24 22:45:59', 1),
(663, 677, 1, 'Nhập số lượng khi thêm mới vào kho', 200, 0, 200, NULL, '2023-12-24 22:45:59', 1),
(664, 678, 1, 'Nhập số lượng khi thêm mới vào kho', 12, 0, 12, NULL, '2023-12-24 22:45:59', 1),
(665, 679, 1, 'Nhập số lượng khi thêm mới vào kho', 4, 0, 4, NULL, '2023-12-24 22:45:59', 1),
(666, 680, 1, 'Nhập số lượng khi thêm mới vào kho', 12, 0, 12, NULL, '2023-12-24 22:45:59', 1),
(667, 681, 1, 'Nhập số lượng khi thêm mới vào kho', 3, 0, 3, NULL, '2023-12-24 22:45:59', 1),
(668, 682, 1, 'Nhập số lượng khi thêm mới vào kho', 5, 0, 5, NULL, '2023-12-24 22:45:59', 1),
(669, 683, 1, 'Nhập số lượng khi thêm mới vào kho', 100, 0, 100, NULL, '2023-12-24 22:45:59', 1),
(670, 684, 1, 'Nhập số lượng khi thêm mới vào kho', 8, 0, 8, NULL, '2023-12-24 22:45:59', 1),
(671, 685, 1, 'Nhập số lượng khi thêm mới vào kho', 3, 0, 3, NULL, '2023-12-24 22:45:59', 1),
(672, 686, 1, 'Nhập số lượng khi thêm mới vào kho', 4, 0, 4, NULL, '2023-12-24 22:45:59', 1),
(673, 687, 1, 'Nhập số lượng khi thêm mới vào kho', 4, 0, 4, NULL, '2023-12-24 22:45:59', 1),
(674, 688, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 22:45:59', 1),
(675, 689, 1, 'Nhập số lượng khi thêm mới vào kho', 70, 0, 70, NULL, '2023-12-24 22:45:59', 1),
(676, 690, 1, 'Nhập số lượng khi thêm mới vào kho', 140, 0, 140, NULL, '2023-12-24 22:45:59', 1),
(677, 691, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 22:45:59', 1),
(678, 692, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 22:45:59', 1),
(679, 693, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 22:45:59', 1),
(680, 694, 1, 'Nhập số lượng khi thêm mới vào kho', 4, 0, 4, NULL, '2023-12-24 22:45:59', 1),
(681, 695, 1, 'Nhập số lượng khi thêm mới vào kho', 4, 0, 4, NULL, '2023-12-24 22:45:59', 1),
(682, 696, 1, 'Nhập số lượng khi thêm mới vào kho', 5, 0, 5, NULL, '2023-12-24 22:45:59', 1),
(683, 697, 1, 'Nhập số lượng khi thêm mới vào kho', 5, 0, 5, NULL, '2023-12-24 22:45:59', 1),
(684, 698, 1, 'Nhập số lượng khi thêm mới vào kho', 5, 0, 5, NULL, '2023-12-24 22:45:59', 1),
(685, 699, 1, 'Nhập số lượng khi thêm mới vào kho', 385, 0, 385, NULL, '2023-12-24 22:45:59', 1),
(686, 700, 1, 'Nhập số lượng khi thêm mới vào kho', 315, 0, 315, NULL, '2023-12-24 22:45:59', 1),
(687, 701, 1, 'Nhập số lượng khi thêm mới vào kho', 320, 0, 320, NULL, '2023-12-24 22:45:59', 1),
(688, 702, 1, 'Nhập số lượng khi thêm mới vào kho', 532, 0, 532, NULL, '2023-12-24 22:45:59', 1),
(689, 703, 1, 'Nhập số lượng khi thêm mới vào kho', 100, 0, 100, NULL, '2023-12-24 22:45:59', 1),
(690, 704, 1, 'Nhập số lượng khi thêm mới vào kho', 5, 0, 5, NULL, '2023-12-24 22:45:59', 1),
(691, 705, 1, 'Nhập số lượng khi thêm mới vào kho', 30, 0, 30, NULL, '2023-12-24 22:45:59', 1),
(692, 706, 1, 'Nhập số lượng khi thêm mới vào kho', 42, 0, 42, NULL, '2023-12-24 22:45:59', 1),
(693, 707, 1, 'Nhập số lượng khi thêm mới vào kho', 4, 0, 4, NULL, '2023-12-24 22:45:59', 1),
(694, 708, 1, 'Nhập số lượng khi thêm mới vào kho', 100, 0, 100, NULL, '2023-12-24 22:45:59', 1),
(695, 709, 1, 'Nhập số lượng khi thêm mới vào kho', 1, 0, 1, NULL, '2023-12-24 22:45:59', 1),
(696, 710, 1, 'Nhập số lượng khi thêm mới vào kho', 250, 0, 250, NULL, '2023-12-24 22:45:59', 1),
(697, 711, 1, 'Nhập số lượng khi thêm mới vào kho', 64, 0, 64, NULL, '2023-12-24 22:45:59', 1),
(698, 712, 1, 'Nhập số lượng khi thêm mới vào kho', 50, 0, 50, NULL, '2023-12-24 22:45:59', 1),
(699, 713, 1, 'Nhập số lượng khi thêm mới vào kho', 1, 0, 1, NULL, '2023-12-24 22:45:59', 1),
(700, 714, 1, 'Nhập số lượng khi thêm mới vào kho', 1, 0, 1, NULL, '2023-12-24 22:45:59', 1),
(701, 715, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 22:45:59', 1),
(702, 716, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 22:45:59', 1),
(703, 717, 1, 'Nhập số lượng khi thêm mới vào kho', 4, 0, 4, NULL, '2023-12-24 22:45:59', 1),
(704, 718, 1, 'Nhập số lượng khi thêm mới vào kho', 8, 0, 8, NULL, '2023-12-24 22:45:59', 1),
(705, 719, 1, 'Nhập số lượng khi thêm mới vào kho', 100, 0, 100, NULL, '2023-12-24 22:45:59', 1),
(706, 720, 1, 'Nhập số lượng khi thêm mới vào kho', 4, 0, 4, NULL, '2023-12-24 22:45:59', 1),
(707, 721, 1, 'Nhập số lượng khi thêm mới vào kho', 15, 0, 15, NULL, '2023-12-24 22:45:59', 1),
(708, 722, 1, 'Nhập số lượng khi thêm mới vào kho', 4, 0, 4, NULL, '2023-12-24 22:45:59', 1),
(709, 723, 1, 'Nhập số lượng khi thêm mới vào kho', 1, 0, 1, NULL, '2023-12-24 22:45:59', 1),
(710, 724, 1, 'Nhập số lượng khi thêm mới vào kho', 1, 0, 1, NULL, '2023-12-24 22:45:59', 1),
(711, 725, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 22:45:59', 1),
(712, 726, 1, 'Nhập số lượng khi thêm mới vào kho', 1, 0, 1, NULL, '2023-12-24 22:45:59', 1),
(713, 727, 1, 'Nhập số lượng khi thêm mới vào kho', 336, 0, 336, NULL, '2023-12-24 22:45:59', 1),
(714, 728, 1, 'Nhập số lượng khi thêm mới vào kho', 8, 0, 8, NULL, '2023-12-24 22:45:59', 1),
(715, 729, 1, 'Nhập số lượng khi thêm mới vào kho', 50, 0, 50, NULL, '2023-12-24 22:45:59', 1),
(716, 730, 1, 'Nhập số lượng khi thêm mới vào kho', 50, 0, 50, NULL, '2023-12-24 22:45:59', 1),
(717, 731, 1, 'Nhập số lượng khi thêm mới vào kho', 50, 0, 50, NULL, '2023-12-24 22:45:59', 1),
(718, 732, 1, 'Nhập số lượng khi thêm mới vào kho', 1, 0, 1, NULL, '2023-12-24 22:45:59', 1),
(719, 733, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 22:45:59', 1),
(720, 734, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 22:45:59', 1),
(721, 735, 1, 'Nhập số lượng khi thêm mới vào kho', 1, 0, 1, NULL, '2023-12-24 22:45:59', 1),
(722, 736, 1, 'Nhập số lượng khi thêm mới vào kho', 11, 0, 11, NULL, '2023-12-24 22:45:59', 1),
(723, 737, 1, 'Nhập số lượng khi thêm mới vào kho', 15, 0, 15, NULL, '2023-12-24 22:45:59', 1),
(724, 738, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 22:45:59', 1),
(725, 739, 1, 'Nhập số lượng khi thêm mới vào kho', 13, 0, 13, NULL, '2023-12-24 22:46:00', 1),
(726, 740, 1, 'Nhập số lượng khi thêm mới vào kho', 3, 0, 3, NULL, '2023-12-24 22:46:00', 1),
(727, 741, 1, 'Nhập số lượng khi thêm mới vào kho', 21, 0, 21, NULL, '2023-12-24 22:46:00', 1),
(728, 742, 1, 'Nhập số lượng khi thêm mới vào kho', 27, 0, 27, NULL, '2023-12-24 22:46:00', 1),
(729, 743, 1, 'Nhập số lượng khi thêm mới vào kho', 60, 0, 60, NULL, '2023-12-24 22:46:00', 1),
(730, 744, 1, 'Nhập số lượng khi thêm mới vào kho', 36, 0, 36, NULL, '2023-12-24 22:46:00', 1),
(731, 745, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 22:46:00', 1),
(732, 746, 1, 'Nhập số lượng khi thêm mới vào kho', 1, 0, 1, NULL, '2023-12-24 22:46:00', 1),
(733, 747, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 22:46:00', 1),
(734, 748, 1, 'Nhập số lượng khi thêm mới vào kho', 3, 0, 3, NULL, '2023-12-24 22:46:00', 1),
(735, 749, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 22:46:00', 1),
(736, 750, 1, 'Nhập số lượng khi thêm mới vào kho', 20, 0, 20, NULL, '2023-12-24 22:46:00', 1),
(737, 751, 1, 'Nhập số lượng khi thêm mới vào kho', 34, 0, 34, NULL, '2023-12-24 22:46:00', 1),
(738, 752, 1, 'Nhập số lượng khi thêm mới vào kho', 5, 0, 5, NULL, '2023-12-24 22:46:00', 1),
(739, 753, 1, 'Nhập số lượng khi thêm mới vào kho', 5, 0, 5, NULL, '2023-12-24 22:46:00', 1),
(740, 754, 1, 'Nhập số lượng khi thêm mới vào kho', 60, 0, 60, NULL, '2023-12-24 22:46:00', 1),
(741, 755, 1, 'Nhập số lượng khi thêm mới vào kho', 30, 0, 30, NULL, '2023-12-24 22:46:00', 1),
(742, 756, 1, 'Nhập số lượng khi thêm mới vào kho', 10, 0, 10, NULL, '2023-12-24 22:46:00', 1),
(743, 757, 1, 'Nhập số lượng khi thêm mới vào kho', 15, 0, 15, NULL, '2023-12-24 22:46:00', 1),
(744, 758, 1, 'Nhập số lượng khi thêm mới vào kho', 15, 0, 15, NULL, '2023-12-24 22:46:00', 1),
(745, 759, 1, 'Nhập số lượng khi thêm mới vào kho', 15, 0, 15, NULL, '2023-12-24 22:46:00', 1),
(746, 760, 1, 'Nhập số lượng khi thêm mới vào kho', 90, 0, 90, NULL, '2023-12-24 22:46:00', 1),
(747, 761, 1, 'Nhập số lượng khi thêm mới vào kho', 9, 0, 9, NULL, '2023-12-24 22:46:00', 1),
(748, 762, 1, 'Nhập số lượng khi thêm mới vào kho', 276, 0, 276, NULL, '2023-12-24 22:46:00', 1),
(749, 763, 1, 'Nhập số lượng khi thêm mới vào kho', 3, 0, 3, NULL, '2023-12-24 22:46:00', 1),
(750, 764, 1, 'Nhập số lượng khi thêm mới vào kho', 3, 0, 3, NULL, '2023-12-24 22:46:00', 1),
(751, 765, 1, 'Nhập số lượng khi thêm mới vào kho', 42, 0, 42, NULL, '2023-12-24 22:46:00', 1),
(752, 766, 1, 'Nhập số lượng khi thêm mới vào kho', 3, 0, 3, NULL, '2023-12-24 22:46:00', 1),
(753, 767, 1, 'Nhập số lượng khi thêm mới vào kho', 11, 0, 11, NULL, '2023-12-24 22:46:00', 1),
(754, 768, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 22:46:00', 1),
(755, 769, 1, 'Nhập số lượng khi thêm mới vào kho', 125, 0, 125, NULL, '2023-12-24 22:46:00', 1),
(756, 770, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 22:46:00', 1),
(757, 771, 1, 'Nhập số lượng khi thêm mới vào kho', 165, 0, 165, NULL, '2023-12-24 22:46:00', 1),
(758, 772, 1, 'Nhập số lượng khi thêm mới vào kho', 15, 0, 15, NULL, '2023-12-24 22:46:00', 1),
(759, 773, 1, 'Nhập số lượng khi thêm mới vào kho', 211, 0, 211, NULL, '2023-12-24 22:46:00', 1),
(760, 774, 1, 'Nhập số lượng khi thêm mới vào kho', 1, 0, 1, NULL, '2023-12-24 22:46:00', 1),
(761, 775, 1, 'Nhập số lượng khi thêm mới vào kho', 23, 0, 23, NULL, '2023-12-24 22:46:00', 1),
(762, 776, 1, 'Nhập số lượng khi thêm mới vào kho', 76, 0, 76, NULL, '2023-12-24 22:46:00', 1),
(763, 777, 1, 'Nhập số lượng khi thêm mới vào kho', 40, 0, 40, NULL, '2023-12-24 22:46:00', 1),
(764, 778, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 22:46:00', 1),
(765, 779, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 22:46:00', 1),
(766, 780, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 22:46:00', 1),
(767, 781, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 22:46:00', 1),
(768, 782, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 22:46:00', 1),
(769, 783, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 22:46:00', 1),
(770, 784, 1, 'Nhập số lượng khi thêm mới vào kho', 3, 0, 3, NULL, '2023-12-24 22:46:00', 1),
(771, 785, 1, 'Nhập số lượng khi thêm mới vào kho', 4, 0, 4, NULL, '2023-12-24 22:46:00', 1),
(772, 786, 1, 'Nhập số lượng khi thêm mới vào kho', 4, 0, 4, NULL, '2023-12-24 22:46:00', 1),
(773, 787, 1, 'Nhập số lượng khi thêm mới vào kho', 4, 0, 4, NULL, '2023-12-24 22:46:00', 1),
(774, 788, 1, 'Nhập số lượng khi thêm mới vào kho', 9, 0, 9, NULL, '2023-12-24 22:46:00', 1),
(775, 789, 1, 'Nhập số lượng khi thêm mới vào kho', 3, 0, 3, NULL, '2023-12-24 22:46:00', 1),
(776, 790, 1, 'Nhập số lượng khi thêm mới vào kho', 1, 0, 1, NULL, '2023-12-24 22:46:00', 1),
(777, 791, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 22:46:00', 1),
(778, 792, 1, 'Nhập số lượng khi thêm mới vào kho', 10, 0, 10, NULL, '2023-12-24 22:46:00', 1),
(779, 793, 1, 'Nhập số lượng khi thêm mới vào kho', 4, 0, 4, NULL, '2023-12-24 22:46:00', 1),
(780, 794, 1, 'Nhập số lượng khi thêm mới vào kho', 10, 0, 10, NULL, '2023-12-24 22:46:00', 1),
(781, 795, 1, 'Nhập số lượng khi thêm mới vào kho', 4, 0, 4, NULL, '2023-12-24 22:46:00', 1),
(782, 796, 1, 'Nhập số lượng khi thêm mới vào kho', 20, 0, 20, NULL, '2023-12-24 22:46:00', 1),
(783, 797, 1, 'Nhập số lượng khi thêm mới vào kho', 20, 0, 20, NULL, '2023-12-24 22:46:00', 1),
(784, 798, 1, 'Nhập số lượng khi thêm mới vào kho', 20, 0, 20, NULL, '2023-12-24 22:46:00', 1),
(785, 799, 1, 'Nhập số lượng khi thêm mới vào kho', 20, 0, 20, NULL, '2023-12-24 22:46:00', 1),
(786, 800, 1, 'Nhập số lượng khi thêm mới vào kho', 20, 0, 20, NULL, '2023-12-24 22:46:00', 1),
(787, 801, 1, 'Nhập số lượng khi thêm mới vào kho', 42, 0, 42, NULL, '2023-12-24 22:46:00', 1),
(788, 802, 1, 'Nhập số lượng khi thêm mới vào kho', 172, 0, 172, NULL, '2023-12-24 22:46:00', 1),
(789, 803, 1, 'Nhập số lượng khi thêm mới vào kho', 15, 0, 15, NULL, '2023-12-24 22:46:00', 1),
(790, 804, 1, 'Nhập số lượng khi thêm mới vào kho', 35, 0, 35, NULL, '2023-12-24 22:46:00', 1),
(791, 805, 1, 'Nhập số lượng khi thêm mới vào kho', 12, 0, 12, NULL, '2023-12-24 22:46:00', 1),
(792, 806, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 22:46:00', 1),
(793, 807, 1, 'Nhập số lượng khi thêm mới vào kho', 4, 0, 4, NULL, '2023-12-24 22:46:00', 1),
(794, 808, 1, 'Nhập số lượng khi thêm mới vào kho', 100, 0, 100, NULL, '2023-12-24 22:46:00', 1),
(795, 809, 1, 'Nhập số lượng khi thêm mới vào kho', 200, 0, 200, NULL, '2023-12-24 22:46:00', 1),
(796, 810, 1, 'Nhập số lượng khi thêm mới vào kho', 20, 0, 20, NULL, '2023-12-24 22:46:00', 1),
(797, 811, 1, 'Nhập số lượng khi thêm mới vào kho', 8, 0, 8, NULL, '2023-12-24 22:46:00', 1),
(798, 812, 1, 'Nhập số lượng khi thêm mới vào kho', 20, 0, 20, NULL, '2023-12-24 22:46:00', 1),
(799, 813, 1, 'Nhập số lượng khi thêm mới vào kho', 4, 0, 4, NULL, '2023-12-24 22:46:00', 1),
(800, 814, 1, 'Nhập số lượng khi thêm mới vào kho', 6, 0, 6, NULL, '2023-12-24 22:46:00', 1),
(801, 815, 1, 'Nhập số lượng khi thêm mới vào kho', 19, 0, 19, NULL, '2023-12-24 22:46:00', 1),
(802, 816, 1, 'Nhập số lượng khi thêm mới vào kho', 4, 0, 4, NULL, '2023-12-24 22:46:00', 1),
(803, 817, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 22:46:00', 1),
(804, 818, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 22:46:00', 1),
(805, 819, 1, 'Nhập số lượng khi thêm mới vào kho', 20, 0, 20, NULL, '2023-12-24 22:46:00', 1),
(806, 820, 1, 'Nhập số lượng khi thêm mới vào kho', 40, 0, 40, NULL, '2023-12-24 22:46:00', 1),
(807, 821, 1, 'Nhập số lượng khi thêm mới vào kho', 40, 0, 40, NULL, '2023-12-24 22:46:00', 1),
(808, 822, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 22:46:00', 1),
(809, 823, 1, 'Nhập số lượng khi thêm mới vào kho', 3, 0, 3, NULL, '2023-12-24 22:46:00', 1),
(810, 824, 1, 'Nhập số lượng khi thêm mới vào kho', 10, 0, 10, NULL, '2023-12-24 22:46:00', 1),
(811, 825, 1, 'Nhập số lượng khi thêm mới vào kho', 13, 0, 13, NULL, '2023-12-24 22:46:00', 1),
(812, 826, 1, 'Nhập số lượng khi thêm mới vào kho', 10, 0, 10, NULL, '2023-12-24 22:46:00', 1),
(813, 827, 1, 'Nhập số lượng khi thêm mới vào kho', 5, 0, 5, NULL, '2023-12-24 22:46:00', 1),
(814, 828, 1, 'Nhập số lượng khi thêm mới vào kho', 10, 0, 10, NULL, '2023-12-24 22:46:00', 1),
(815, 829, 1, 'Nhập số lượng khi thêm mới vào kho', 5, 0, 5, NULL, '2023-12-24 22:46:00', 1),
(816, 830, 1, 'Nhập số lượng khi thêm mới vào kho', 20, 0, 20, NULL, '2023-12-24 22:46:00', 1),
(817, 831, 1, 'Nhập số lượng khi thêm mới vào kho', 20, 0, 20, NULL, '2023-12-24 22:46:00', 1),
(818, 832, 1, 'Nhập số lượng khi thêm mới vào kho', 5, 0, 5, NULL, '2023-12-24 22:46:00', 1),
(819, 833, 1, 'Nhập số lượng khi thêm mới vào kho', 3, 0, 3, NULL, '2023-12-24 22:46:00', 1),
(820, 834, 1, 'Nhập số lượng khi thêm mới vào kho', 6, 0, 6, NULL, '2023-12-24 22:46:00', 1),
(821, 835, 1, 'Nhập số lượng khi thêm mới vào kho', 15, 0, 15, NULL, '2023-12-24 22:46:00', 1),
(822, 836, 1, 'Nhập số lượng khi thêm mới vào kho', 114, 0, 114, NULL, '2023-12-24 22:46:00', 1),
(823, 837, 1, 'Nhập số lượng khi thêm mới vào kho', 15, 0, 15, NULL, '2023-12-24 22:46:00', 1),
(824, 838, 1, 'Nhập số lượng khi thêm mới vào kho', 118, 0, 118, NULL, '2023-12-24 22:46:00', 1),
(825, 839, 1, 'Nhập số lượng khi thêm mới vào kho', 30, 0, 30, NULL, '2023-12-24 22:46:00', 1),
(826, 840, 1, 'Nhập số lượng khi thêm mới vào kho', 96, 0, 96, NULL, '2023-12-24 22:46:00', 1),
(827, 841, 1, 'Nhập số lượng khi thêm mới vào kho', 44, 0, 44, NULL, '2023-12-24 22:46:00', 1),
(828, 842, 1, 'Nhập số lượng khi thêm mới vào kho', 1, 0, 1, NULL, '2023-12-24 22:46:00', 1),
(829, 843, 1, 'Nhập số lượng khi thêm mới vào kho', 8, 0, 8, NULL, '2023-12-24 22:46:00', 1),
(830, 844, 1, 'Nhập số lượng khi thêm mới vào kho', 14, 0, 14, NULL, '2023-12-24 22:46:00', 1),
(859, 873, 1, 'Nhập số lượng khi thêm mới vào kho', 24, 0, 24, NULL, '2023-12-24 23:03:56', 1),
(860, 874, 1, 'Nhập số lượng khi thêm mới vào kho', 120, 0, 120, NULL, '2023-12-24 23:03:56', 1),
(861, 875, 1, 'Nhập số lượng khi thêm mới vào kho', 100, 0, 100, NULL, '2023-12-24 23:03:56', 1),
(862, 876, 1, 'Nhập số lượng khi thêm mới vào kho', 5, 0, 5, NULL, '2023-12-24 23:03:56', 1),
(863, 877, 1, 'Nhập số lượng khi thêm mới vào kho', 1, 0, 1, NULL, '2023-12-24 23:03:56', 1),
(864, 878, 1, 'Nhập số lượng khi thêm mới vào kho', 10, 0, 10, NULL, '2023-12-24 23:03:56', 1),
(865, 879, 1, 'Nhập số lượng khi thêm mới vào kho', 5, 0, 5, NULL, '2023-12-24 23:03:56', 1),
(866, 880, 1, 'Nhập số lượng khi thêm mới vào kho', 10, 0, 10, NULL, '2023-12-24 23:03:56', 1),
(867, 881, 1, 'Nhập số lượng khi thêm mới vào kho', 5, 0, 5, NULL, '2023-12-24 23:03:56', 1),
(868, 882, 1, 'Nhập số lượng khi thêm mới vào kho', 37, 0, 37, NULL, '2023-12-24 23:03:56', 1),
(869, 883, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 23:03:56', 1),
(870, 884, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2023-12-24 23:03:56', 1),
(871, 885, 1, 'Nhập số lượng khi thêm mới vào kho', 24, 0, 24, NULL, '2023-12-24 23:03:56', 1),
(872, 886, 1, 'Nhập số lượng khi thêm mới vào kho', 5, 0, 5, NULL, '2023-12-24 23:03:56', 1),
(873, 887, 1, 'Nhập số lượng khi thêm mới vào kho', 0.5, 0, 0.5, NULL, '2023-12-24 23:03:56', 1),
(874, 888, 1, 'Nhập số lượng khi thêm mới vào kho', 0.5, 0, 0.5, NULL, '2023-12-24 23:03:56', 1),
(875, 889, 1, 'Nhập số lượng khi thêm mới vào kho', 10, 0, 10, NULL, '2023-12-24 23:03:56', 1),
(876, 890, 1, 'Nhập số lượng khi thêm mới vào kho', 5, 0, 5, NULL, '2023-12-24 23:03:56', 1),
(877, 891, 1, 'Nhập số lượng khi thêm mới vào kho', 5, 0, 5, NULL, '2023-12-24 23:03:56', 1),
(878, 892, 1, 'Nhập số lượng khi thêm mới vào kho', 200, 0, 200, NULL, '2023-12-24 23:03:56', 1),
(879, 893, 1, 'Nhập số lượng khi thêm mới vào kho', 1, 0, 1, NULL, '2023-12-24 23:03:56', 1),
(880, 894, 1, 'Nhập số lượng khi thêm mới vào kho', 1, 0, 1, NULL, '2023-12-24 23:03:56', 1),
(881, 895, 1, 'Nhập số lượng khi thêm mới vào kho', 1, 0, 1, NULL, '2023-12-24 23:03:56', 1),
(882, 896, 1, 'Nhập số lượng khi thêm mới vào kho', 1, 0, 1, NULL, '2023-12-24 23:03:56', 1),
(883, 897, 1, 'Nhập số lượng khi thêm mới vào kho', 3.84, 0, 3.84, NULL, '2023-12-24 23:03:56', 1),
(884, 898, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2023-12-24 23:03:56', 1),
(885, 899, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2023-12-24 23:03:56', 1),
(886, 900, 1, 'Nhập số lượng khi thêm mới vào kho', 12, 0, 12, NULL, '2023-12-24 23:03:56', 1),
(887, 901, 1, 'Nhập số lượng khi thêm mới vào kho', 4, 0, 4, NULL, '2023-12-24 23:23:24', 1),
(888, 902, 1, 'Nhập số lượng khi thêm mới vào kho', 1, 0, 1, NULL, '2023-12-24 23:23:24', 1),
(889, 873, 1, 'xx', -100, 24, -76, NULL, '2023-12-29 15:35:49', 1),
(892, 901, NULL, 'Ghi đè tồn kho khi nhập excel', 6, 4, 10, NULL, '2023-12-31 10:33:31', 2),
(893, 902, NULL, 'Ghi đè tồn kho khi nhập excel', 9, 1, 10, NULL, '2023-12-31 10:33:31', 2),
(896, 873, NULL, 'Ghi đè tồn kho khi nhập excel', 77, -76, 1, NULL, '2023-12-31 10:41:08', 2),
(897, 874, NULL, 'Ghi đè tồn kho khi nhập excel', -119, 120, 1, NULL, '2023-12-31 10:41:08', 2),
(898, 875, NULL, 'Ghi đè tồn kho khi nhập excel', -99, 100, 1, NULL, '2023-12-31 10:41:08', 2),
(899, 876, NULL, 'Ghi đè tồn kho khi nhập excel', -4, 5, 1, NULL, '2023-12-31 10:41:08', 2),
(900, 878, NULL, 'Ghi đè tồn kho khi nhập excel', -9, 10, 1, NULL, '2023-12-31 10:41:08', 2),
(901, 879, NULL, 'Ghi đè tồn kho khi nhập excel', -4, 5, 1, NULL, '2023-12-31 10:41:08', 2),
(902, 880, NULL, 'Ghi đè tồn kho khi nhập excel', -9, 10, 1, NULL, '2023-12-31 10:41:08', 2),
(903, 881, NULL, 'Ghi đè tồn kho khi nhập excel', -4, 5, 1, NULL, '2023-12-31 10:41:08', 2),
(904, 882, NULL, 'Ghi đè tồn kho khi nhập excel', -36, 37, 1, NULL, '2023-12-31 10:41:08', 2),
(905, 883, NULL, 'Ghi đè tồn kho khi nhập excel', -1, 2, 1, NULL, '2023-12-31 10:41:08', 2),
(906, 884, NULL, 'Ghi đè tồn kho khi nhập excel', -1, 2, 1, NULL, '2023-12-31 10:41:08', 2),
(907, 885, NULL, 'Ghi đè tồn kho khi nhập excel', -23, 24, 1, NULL, '2023-12-31 10:41:08', 2),
(908, 886, NULL, 'Ghi đè tồn kho khi nhập excel', -4, 5, 1, NULL, '2023-12-31 10:41:08', 2),
(909, 887, NULL, 'Ghi đè tồn kho khi nhập excel', 0.5, 0.5, 1, NULL, '2023-12-31 10:41:08', 2),
(910, 888, NULL, 'Ghi đè tồn kho khi nhập excel', 0.5, 0.5, 1, NULL, '2023-12-31 10:41:08', 2),
(911, 889, NULL, 'Ghi đè tồn kho khi nhập excel', -9, 10, 1, NULL, '2023-12-31 10:41:08', 2),
(912, 890, NULL, 'Ghi đè tồn kho khi nhập excel', -4, 5, 1, NULL, '2023-12-31 10:41:08', 2),
(913, 891, NULL, 'Ghi đè tồn kho khi nhập excel', -4, 5, 1, NULL, '2023-12-31 10:41:08', 2),
(914, 892, NULL, 'Ghi đè tồn kho khi nhập excel', -199, 200, 1, NULL, '2023-12-31 10:41:08', 2),
(915, 897, NULL, 'Ghi đè tồn kho khi nhập excel', -2.84, 3.84, 1, NULL, '2023-12-31 10:41:08', 2),
(916, 898, NULL, 'Ghi đè tồn kho khi nhập excel', 1, 0, 1, NULL, '2023-12-31 10:41:08', 2),
(917, 899, NULL, 'Ghi đè tồn kho khi nhập excel', 1, 0, 1, NULL, '2023-12-31 10:41:08', 2),
(918, 900, NULL, 'Ghi đè tồn kho khi nhập excel', -11, 12, 1, NULL, '2023-12-31 10:41:08', 2),
(919, 643, 2, 'Ghi đè tồn kho khi nhập excel', 99, 1, 100, NULL, '2023-12-31 10:51:38', 2),
(920, 644, 3, 'Ghi đè tồn kho khi nhập excel', 82, 18, 100, NULL, '2023-12-31 10:51:38', 2),
(921, 645, 3, 'Ghi đè tồn kho khi nhập excel', 99, 1, 100, NULL, '2023-12-31 10:51:38', 2),
(922, 646, NULL, 'Ghi đè tồn kho khi nhập excel', 98, 2, 100, NULL, '2023-12-31 10:51:38', 2),
(923, 647, NULL, 'Ghi đè tồn kho khi nhập excel', 91, 9, 100, NULL, '2023-12-31 10:51:38', 2),
(924, 648, NULL, 'Ghi đè tồn kho khi nhập excel', 99, 1, 100, NULL, '2023-12-31 10:51:38', 2),
(925, 649, NULL, 'Ghi đè tồn kho khi nhập excel', 28, 72, 100, NULL, '2023-12-31 10:51:38', 2),
(926, 650, NULL, 'Ghi đè tồn kho khi nhập excel', 98, 2, 100, NULL, '2023-12-31 10:51:38', 2),
(927, 651, NULL, 'Ghi đè tồn kho khi nhập excel', 99, 1, 100, NULL, '2023-12-31 10:51:38', 2),
(928, 652, NULL, 'Ghi đè tồn kho khi nhập excel', 70, 30, 100, NULL, '2023-12-31 10:51:38', 2),
(929, 653, NULL, 'Ghi đè tồn kho khi nhập excel', 99, 1, 100, NULL, '2023-12-31 10:51:38', 2),
(930, 654, NULL, 'Ghi đè tồn kho khi nhập excel', 74, 26, 100, NULL, '2023-12-31 10:51:38', 2),
(931, 655, NULL, 'Ghi đè tồn kho khi nhập excel', 92, 8, 100, NULL, '2023-12-31 10:51:38', 2),
(932, 656, NULL, 'Ghi đè tồn kho khi nhập excel', 99, 1, 100, NULL, '2023-12-31 10:51:38', 2),
(933, 657, NULL, 'Ghi đè tồn kho khi nhập excel', 98.15, 1.85, 100, NULL, '2023-12-31 10:51:38', 2),
(934, 658, NULL, 'Ghi đè tồn kho khi nhập excel', 88, 12, 100, NULL, '2023-12-31 10:51:38', 2),
(935, 659, NULL, 'Ghi đè tồn kho khi nhập excel', 99, 1, 100, NULL, '2023-12-31 10:51:38', 2),
(936, 660, NULL, 'Ghi đè tồn kho khi nhập excel', 99, 1, 100, NULL, '2023-12-31 10:51:38', 2),
(937, 661, NULL, 'Ghi đè tồn kho khi nhập excel', 96, 4, 100, NULL, '2023-12-31 10:51:38', 2),
(938, 662, NULL, 'Ghi đè tồn kho khi nhập excel', 96, 4, 100, NULL, '2023-12-31 10:51:38', 2),
(939, 663, NULL, 'Ghi đè tồn kho khi nhập excel', 99, 1, 100, NULL, '2023-12-31 10:51:38', 2),
(940, 664, NULL, 'Ghi đè tồn kho khi nhập excel', 98, 2, 100, NULL, '2023-12-31 10:51:38', 2),
(941, 665, NULL, 'Ghi đè tồn kho khi nhập excel', 94, 6, 100, NULL, '2023-12-31 10:51:38', 2),
(942, 666, NULL, 'Ghi đè tồn kho khi nhập excel', 99, 1, 100, NULL, '2023-12-31 10:51:38', 2),
(943, 667, NULL, 'Ghi đè tồn kho khi nhập excel', 95, 5, 100, NULL, '2023-12-31 10:51:38', 2),
(944, 668, NULL, 'Ghi đè tồn kho khi nhập excel', 69, 31, 100, NULL, '2023-12-31 10:51:38', 2),
(945, 669, NULL, 'Ghi đè tồn kho khi nhập excel', 80, 20, 100, NULL, '2023-12-31 10:51:38', 2),
(946, 670, NULL, 'Ghi đè tồn kho khi nhập excel', 80, 20, 100, NULL, '2023-12-31 10:51:38', 2),
(947, 671, NULL, 'Ghi đè tồn kho khi nhập excel', 97, 3, 100, NULL, '2023-12-31 10:51:38', 2),
(948, 672, NULL, 'Ghi đè tồn kho khi nhập excel', 92, 8, 100, NULL, '2023-12-31 10:51:38', 2),
(949, 673, NULL, 'Ghi đè tồn kho khi nhập excel', 88, 12, 100, NULL, '2023-12-31 10:51:38', 2),
(950, 674, NULL, 'Ghi đè tồn kho khi nhập excel', 95, 5, 100, NULL, '2023-12-31 10:51:38', 2),
(951, 675, NULL, 'Ghi đè tồn kho khi nhập excel', 72, 28, 100, NULL, '2023-12-31 10:51:38', 2),
(952, 676, NULL, 'Ghi đè tồn kho khi nhập excel', -280, 380, 100, NULL, '2023-12-31 10:51:38', 2),
(953, 677, NULL, 'Ghi đè tồn kho khi nhập excel', -100, 200, 100, NULL, '2023-12-31 10:51:38', 2),
(954, 678, NULL, 'Ghi đè tồn kho khi nhập excel', 88, 12, 100, NULL, '2023-12-31 10:51:38', 2),
(955, 679, NULL, 'Ghi đè tồn kho khi nhập excel', 96, 4, 100, NULL, '2023-12-31 10:51:38', 2),
(956, 680, NULL, 'Ghi đè tồn kho khi nhập excel', 88, 12, 100, NULL, '2023-12-31 10:51:38', 2),
(957, 681, NULL, 'Ghi đè tồn kho khi nhập excel', 97, 3, 100, NULL, '2023-12-31 10:51:38', 2),
(958, 682, NULL, 'Ghi đè tồn kho khi nhập excel', 95, 5, 100, NULL, '2023-12-31 10:51:38', 2),
(959, 684, NULL, 'Ghi đè tồn kho khi nhập excel', 92, 8, 100, NULL, '2023-12-31 10:51:38', 2),
(960, 685, NULL, 'Ghi đè tồn kho khi nhập excel', 97, 3, 100, NULL, '2023-12-31 10:51:38', 2),
(961, 686, NULL, 'Ghi đè tồn kho khi nhập excel', 96, 4, 100, NULL, '2023-12-31 10:51:38', 2),
(962, 687, NULL, 'Ghi đè tồn kho khi nhập excel', 96, 4, 100, NULL, '2023-12-31 10:51:38', 2),
(963, 688, NULL, 'Ghi đè tồn kho khi nhập excel', 98, 2, 100, NULL, '2023-12-31 10:51:38', 2),
(964, 689, NULL, 'Ghi đè tồn kho khi nhập excel', 30, 70, 100, NULL, '2023-12-31 10:51:38', 2),
(965, 690, NULL, 'Ghi đè tồn kho khi nhập excel', -40, 140, 100, NULL, '2023-12-31 10:51:38', 2),
(966, 691, NULL, 'Ghi đè tồn kho khi nhập excel', 98, 2, 100, NULL, '2023-12-31 10:51:38', 2),
(967, 692, NULL, 'Ghi đè tồn kho khi nhập excel', 98, 2, 100, NULL, '2023-12-31 10:51:38', 2),
(968, 693, NULL, 'Ghi đè tồn kho khi nhập excel', 98, 2, 100, NULL, '2023-12-31 10:51:38', 2),
(969, 694, NULL, 'Ghi đè tồn kho khi nhập excel', 96, 4, 100, NULL, '2023-12-31 10:51:38', 2),
(970, 695, NULL, 'Ghi đè tồn kho khi nhập excel', 96, 4, 100, NULL, '2023-12-31 10:51:38', 2),
(971, 696, NULL, 'Ghi đè tồn kho khi nhập excel', 95, 5, 100, NULL, '2023-12-31 10:51:38', 2),
(972, 697, NULL, 'Ghi đè tồn kho khi nhập excel', 95, 5, 100, NULL, '2023-12-31 10:51:38', 2),
(973, 698, NULL, 'Ghi đè tồn kho khi nhập excel', 95, 5, 100, NULL, '2023-12-31 10:51:38', 2),
(974, 699, NULL, 'Ghi đè tồn kho khi nhập excel', -285, 385, 100, NULL, '2023-12-31 10:51:38', 2),
(975, 700, NULL, 'Ghi đè tồn kho khi nhập excel', -215, 315, 100, NULL, '2023-12-31 10:51:38', 2),
(976, 701, NULL, 'Ghi đè tồn kho khi nhập excel', -220, 320, 100, NULL, '2023-12-31 10:51:38', 2),
(977, 702, NULL, 'Ghi đè tồn kho khi nhập excel', -432, 532, 100, NULL, '2023-12-31 10:51:38', 2),
(978, 704, NULL, 'Ghi đè tồn kho khi nhập excel', 95, 5, 100, NULL, '2023-12-31 10:51:38', 2),
(979, 705, NULL, 'Ghi đè tồn kho khi nhập excel', 70, 30, 100, NULL, '2023-12-31 10:51:38', 2),
(980, 706, NULL, 'Ghi đè tồn kho khi nhập excel', 58, 42, 100, NULL, '2023-12-31 10:51:38', 2),
(981, 707, NULL, 'Ghi đè tồn kho khi nhập excel', 96, 4, 100, NULL, '2023-12-31 10:51:38', 2),
(982, 709, NULL, 'Ghi đè tồn kho khi nhập excel', 99, 1, 100, NULL, '2023-12-31 10:51:38', 2),
(983, 710, NULL, 'Ghi đè tồn kho khi nhập excel', -150, 250, 100, NULL, '2023-12-31 10:51:38', 2),
(984, 711, NULL, 'Ghi đè tồn kho khi nhập excel', 36, 64, 100, NULL, '2023-12-31 10:51:38', 2),
(985, 712, NULL, 'Ghi đè tồn kho khi nhập excel', 50, 50, 100, NULL, '2023-12-31 10:51:38', 2),
(986, 713, NULL, 'Ghi đè tồn kho khi nhập excel', 99, 1, 100, NULL, '2023-12-31 10:51:38', 2),
(987, 714, NULL, 'Ghi đè tồn kho khi nhập excel', 99, 1, 100, NULL, '2023-12-31 10:51:38', 2),
(988, 715, NULL, 'Ghi đè tồn kho khi nhập excel', 98, 2, 100, NULL, '2023-12-31 10:51:38', 2),
(989, 716, NULL, 'Ghi đè tồn kho khi nhập excel', 98, 2, 100, NULL, '2023-12-31 10:51:38', 2),
(990, 717, NULL, 'Ghi đè tồn kho khi nhập excel', 96, 4, 100, NULL, '2023-12-31 10:51:38', 2),
(991, 718, NULL, 'Ghi đè tồn kho khi nhập excel', 92, 8, 100, NULL, '2023-12-31 10:51:38', 2),
(992, 720, NULL, 'Ghi đè tồn kho khi nhập excel', 96, 4, 100, NULL, '2023-12-31 10:51:38', 2),
(993, 721, NULL, 'Ghi đè tồn kho khi nhập excel', 85, 15, 100, NULL, '2023-12-31 10:51:38', 2),
(994, 722, NULL, 'Ghi đè tồn kho khi nhập excel', 96, 4, 100, NULL, '2023-12-31 10:51:38', 2),
(995, 723, NULL, 'Ghi đè tồn kho khi nhập excel', 99, 1, 100, NULL, '2023-12-31 10:51:38', 2),
(996, 724, NULL, 'Ghi đè tồn kho khi nhập excel', 99, 1, 100, NULL, '2023-12-31 10:51:38', 2),
(997, 725, NULL, 'Ghi đè tồn kho khi nhập excel', 98, 2, 100, NULL, '2023-12-31 10:51:38', 2),
(998, 726, NULL, 'Ghi đè tồn kho khi nhập excel', 99, 1, 100, NULL, '2023-12-31 10:51:38', 2),
(999, 727, NULL, 'Ghi đè tồn kho khi nhập excel', -236, 336, 100, NULL, '2023-12-31 10:51:38', 2),
(1000, 728, NULL, 'Ghi đè tồn kho khi nhập excel', 92, 8, 100, NULL, '2023-12-31 10:51:38', 2),
(1001, 729, NULL, 'Ghi đè tồn kho khi nhập excel', 50, 50, 100, NULL, '2023-12-31 10:51:38', 2),
(1002, 730, NULL, 'Ghi đè tồn kho khi nhập excel', 50, 50, 100, NULL, '2023-12-31 10:51:38', 2),
(1003, 731, NULL, 'Ghi đè tồn kho khi nhập excel', 50, 50, 100, NULL, '2023-12-31 10:51:38', 2),
(1004, 732, NULL, 'Ghi đè tồn kho khi nhập excel', 99, 1, 100, NULL, '2023-12-31 10:51:38', 2),
(1005, 733, NULL, 'Ghi đè tồn kho khi nhập excel', 98, 2, 100, NULL, '2023-12-31 10:51:38', 2),
(1006, 734, NULL, 'Ghi đè tồn kho khi nhập excel', 98, 2, 100, NULL, '2023-12-31 10:51:38', 2),
(1007, 735, NULL, 'Ghi đè tồn kho khi nhập excel', 99, 1, 100, NULL, '2023-12-31 10:51:38', 2),
(1008, 736, NULL, 'Ghi đè tồn kho khi nhập excel', 89, 11, 100, NULL, '2023-12-31 10:51:38', 2),
(1009, 737, NULL, 'Ghi đè tồn kho khi nhập excel', 85, 15, 100, NULL, '2023-12-31 10:51:38', 2),
(1010, 738, NULL, 'Ghi đè tồn kho khi nhập excel', 98, 2, 100, NULL, '2023-12-31 10:51:38', 2),
(1011, 739, NULL, 'Ghi đè tồn kho khi nhập excel', 87, 13, 100, NULL, '2023-12-31 10:51:38', 2),
(1012, 740, NULL, 'Ghi đè tồn kho khi nhập excel', 97, 3, 100, NULL, '2023-12-31 10:51:38', 2),
(1013, 741, NULL, 'Ghi đè tồn kho khi nhập excel', 79, 21, 100, NULL, '2023-12-31 10:51:38', 2),
(1014, 742, NULL, 'Ghi đè tồn kho khi nhập excel', 73, 27, 100, NULL, '2023-12-31 10:51:38', 2),
(1015, 743, NULL, 'Ghi đè tồn kho khi nhập excel', 40, 60, 100, NULL, '2023-12-31 10:51:38', 2),
(1016, 744, NULL, 'Ghi đè tồn kho khi nhập excel', 64, 36, 100, NULL, '2023-12-31 10:51:38', 2),
(1017, 745, NULL, 'Ghi đè tồn kho khi nhập excel', 98, 2, 100, NULL, '2023-12-31 10:51:38', 2),
(1018, 746, NULL, 'Ghi đè tồn kho khi nhập excel', 99, 1, 100, NULL, '2023-12-31 10:51:38', 2),
(1019, 747, NULL, 'Ghi đè tồn kho khi nhập excel', 98, 2, 100, NULL, '2023-12-31 10:51:38', 2),
(1020, 748, NULL, 'Ghi đè tồn kho khi nhập excel', 97, 3, 100, NULL, '2023-12-31 10:51:38', 2),
(1021, 749, NULL, 'Ghi đè tồn kho khi nhập excel', 98, 2, 100, NULL, '2023-12-31 10:51:38', 2),
(1022, 750, NULL, 'Ghi đè tồn kho khi nhập excel', 80, 20, 100, NULL, '2023-12-31 10:51:38', 2),
(1023, 751, NULL, 'Ghi đè tồn kho khi nhập excel', 66, 34, 100, NULL, '2023-12-31 10:51:38', 2),
(1024, 752, NULL, 'Ghi đè tồn kho khi nhập excel', 95, 5, 100, NULL, '2023-12-31 10:51:38', 2),
(1025, 753, NULL, 'Ghi đè tồn kho khi nhập excel', 95, 5, 100, NULL, '2023-12-31 10:51:38', 2),
(1026, 754, NULL, 'Ghi đè tồn kho khi nhập excel', 40, 60, 100, NULL, '2023-12-31 10:51:38', 2),
(1027, 755, NULL, 'Ghi đè tồn kho khi nhập excel', 70, 30, 100, NULL, '2023-12-31 10:51:38', 2),
(1028, 756, NULL, 'Ghi đè tồn kho khi nhập excel', 90, 10, 100, NULL, '2023-12-31 10:51:38', 2),
(1029, 757, NULL, 'Ghi đè tồn kho khi nhập excel', 85, 15, 100, NULL, '2023-12-31 10:51:38', 2),
(1030, 758, NULL, 'Ghi đè tồn kho khi nhập excel', 85, 15, 100, NULL, '2023-12-31 10:51:38', 2),
(1031, 759, NULL, 'Ghi đè tồn kho khi nhập excel', 85, 15, 100, NULL, '2023-12-31 10:51:38', 2),
(1032, 760, NULL, 'Ghi đè tồn kho khi nhập excel', 10, 90, 100, NULL, '2023-12-31 10:51:38', 2),
(1033, 761, NULL, 'Ghi đè tồn kho khi nhập excel', 91, 9, 100, NULL, '2023-12-31 10:51:38', 2),
(1034, 762, NULL, 'Ghi đè tồn kho khi nhập excel', -176, 276, 100, NULL, '2023-12-31 10:51:38', 2),
(1035, 763, NULL, 'Ghi đè tồn kho khi nhập excel', 97, 3, 100, NULL, '2023-12-31 10:51:38', 2),
(1036, 764, NULL, 'Ghi đè tồn kho khi nhập excel', 97, 3, 100, NULL, '2023-12-31 10:51:38', 2),
(1037, 765, NULL, 'Ghi đè tồn kho khi nhập excel', 58, 42, 100, NULL, '2023-12-31 10:51:38', 2),
(1038, 766, NULL, 'Ghi đè tồn kho khi nhập excel', 97, 3, 100, NULL, '2023-12-31 10:51:38', 2),
(1039, 767, NULL, 'Ghi đè tồn kho khi nhập excel', 89, 11, 100, NULL, '2023-12-31 10:51:38', 2),
(1040, 768, NULL, 'Ghi đè tồn kho khi nhập excel', 98, 2, 100, NULL, '2023-12-31 10:51:38', 2),
(1041, 769, NULL, 'Ghi đè tồn kho khi nhập excel', -25, 125, 100, NULL, '2023-12-31 10:51:38', 2),
(1042, 770, NULL, 'Ghi đè tồn kho khi nhập excel', 98, 2, 100, NULL, '2023-12-31 10:51:38', 2),
(1043, 771, NULL, 'Ghi đè tồn kho khi nhập excel', -65, 165, 100, NULL, '2023-12-31 10:51:38', 2),
(1044, 772, NULL, 'Ghi đè tồn kho khi nhập excel', 85, 15, 100, NULL, '2023-12-31 10:51:38', 2),
(1045, 773, NULL, 'Ghi đè tồn kho khi nhập excel', -111, 211, 100, NULL, '2023-12-31 10:51:38', 2),
(1046, 774, NULL, 'Ghi đè tồn kho khi nhập excel', 99, 1, 100, NULL, '2023-12-31 10:51:38', 2),
(1047, 775, NULL, 'Ghi đè tồn kho khi nhập excel', 77, 23, 100, NULL, '2023-12-31 10:51:38', 2),
(1048, 776, NULL, 'Ghi đè tồn kho khi nhập excel', 24, 76, 100, NULL, '2023-12-31 10:51:38', 2),
(1049, 777, NULL, 'Ghi đè tồn kho khi nhập excel', 60, 40, 100, NULL, '2023-12-31 10:51:38', 2),
(1050, 778, NULL, 'Ghi đè tồn kho khi nhập excel', 98, 2, 100, NULL, '2023-12-31 10:51:38', 2),
(1051, 779, NULL, 'Ghi đè tồn kho khi nhập excel', 98, 2, 100, NULL, '2023-12-31 10:51:38', 2),
(1052, 780, NULL, 'Ghi đè tồn kho khi nhập excel', 98, 2, 100, NULL, '2023-12-31 10:51:38', 2),
(1053, 781, NULL, 'Ghi đè tồn kho khi nhập excel', 98, 2, 100, NULL, '2023-12-31 10:51:38', 2),
(1054, 782, NULL, 'Ghi đè tồn kho khi nhập excel', 98, 2, 100, NULL, '2023-12-31 10:51:38', 2),
(1055, 783, NULL, 'Ghi đè tồn kho khi nhập excel', 98, 2, 100, NULL, '2023-12-31 10:51:38', 2),
(1056, 784, NULL, 'Ghi đè tồn kho khi nhập excel', 97, 3, 100, NULL, '2023-12-31 10:51:38', 2),
(1057, 785, NULL, 'Ghi đè tồn kho khi nhập excel', 96, 4, 100, NULL, '2023-12-31 10:51:38', 2),
(1058, 786, NULL, 'Ghi đè tồn kho khi nhập excel', 96, 4, 100, NULL, '2023-12-31 10:51:38', 2),
(1059, 787, NULL, 'Ghi đè tồn kho khi nhập excel', 96, 4, 100, NULL, '2023-12-31 10:51:38', 2),
(1060, 788, NULL, 'Ghi đè tồn kho khi nhập excel', 91, 9, 100, NULL, '2023-12-31 10:51:38', 2),
(1061, 789, NULL, 'Ghi đè tồn kho khi nhập excel', 97, 3, 100, NULL, '2023-12-31 10:51:38', 2),
(1062, 790, NULL, 'Ghi đè tồn kho khi nhập excel', 99, 1, 100, NULL, '2023-12-31 10:51:38', 2),
(1063, 791, NULL, 'Ghi đè tồn kho khi nhập excel', 98, 2, 100, NULL, '2023-12-31 10:51:38', 2),
(1064, 792, NULL, 'Ghi đè tồn kho khi nhập excel', 90, 10, 100, NULL, '2023-12-31 10:51:38', 2),
(1065, 793, NULL, 'Ghi đè tồn kho khi nhập excel', 96, 4, 100, NULL, '2023-12-31 10:51:38', 2),
(1066, 794, NULL, 'Ghi đè tồn kho khi nhập excel', 90, 10, 100, NULL, '2023-12-31 10:51:38', 2),
(1067, 795, NULL, 'Ghi đè tồn kho khi nhập excel', 96, 4, 100, NULL, '2023-12-31 10:51:38', 2),
(1068, 796, NULL, 'Ghi đè tồn kho khi nhập excel', 80, 20, 100, NULL, '2023-12-31 10:51:38', 2),
(1069, 797, NULL, 'Ghi đè tồn kho khi nhập excel', 80, 20, 100, NULL, '2023-12-31 10:51:39', 2),
(1070, 798, NULL, 'Ghi đè tồn kho khi nhập excel', 80, 20, 100, NULL, '2023-12-31 10:51:39', 2),
(1071, 799, NULL, 'Ghi đè tồn kho khi nhập excel', 80, 20, 100, NULL, '2023-12-31 10:51:39', 2),
(1072, 800, NULL, 'Ghi đè tồn kho khi nhập excel', 80, 20, 100, NULL, '2023-12-31 10:51:39', 2),
(1073, 801, NULL, 'Ghi đè tồn kho khi nhập excel', 58, 42, 100, NULL, '2023-12-31 10:51:39', 2),
(1074, 802, NULL, 'Ghi đè tồn kho khi nhập excel', -72, 172, 100, NULL, '2023-12-31 10:51:39', 2),
(1075, 803, NULL, 'Ghi đè tồn kho khi nhập excel', 85, 15, 100, NULL, '2023-12-31 10:51:39', 2),
(1076, 804, NULL, 'Ghi đè tồn kho khi nhập excel', 65, 35, 100, NULL, '2023-12-31 10:51:39', 2),
(1077, 805, NULL, 'Ghi đè tồn kho khi nhập excel', 88, 12, 100, NULL, '2023-12-31 10:51:39', 2),
(1078, 806, NULL, 'Ghi đè tồn kho khi nhập excel', 98, 2, 100, NULL, '2023-12-31 10:51:39', 2),
(1079, 807, NULL, 'Ghi đè tồn kho khi nhập excel', 96, 4, 100, NULL, '2023-12-31 10:51:39', 2),
(1080, 809, NULL, 'Ghi đè tồn kho khi nhập excel', -100, 200, 100, NULL, '2023-12-31 10:51:39', 2),
(1081, 810, NULL, 'Ghi đè tồn kho khi nhập excel', 80, 20, 100, NULL, '2023-12-31 10:51:39', 2),
(1082, 811, NULL, 'Ghi đè tồn kho khi nhập excel', 92, 8, 100, NULL, '2023-12-31 10:51:39', 2),
(1083, 812, NULL, 'Ghi đè tồn kho khi nhập excel', 80, 20, 100, NULL, '2023-12-31 10:51:39', 2),
(1084, 813, NULL, 'Ghi đè tồn kho khi nhập excel', 96, 4, 100, NULL, '2023-12-31 10:51:39', 2),
(1085, 814, NULL, 'Ghi đè tồn kho khi nhập excel', 94, 6, 100, NULL, '2023-12-31 10:51:39', 2),
(1086, 815, NULL, 'Ghi đè tồn kho khi nhập excel', 81, 19, 100, NULL, '2023-12-31 10:51:39', 2),
(1087, 816, NULL, 'Ghi đè tồn kho khi nhập excel', 96, 4, 100, NULL, '2023-12-31 10:51:39', 2),
(1088, 817, NULL, 'Ghi đè tồn kho khi nhập excel', 98, 2, 100, NULL, '2023-12-31 10:51:39', 2),
(1089, 818, NULL, 'Ghi đè tồn kho khi nhập excel', 98, 2, 100, NULL, '2023-12-31 10:51:39', 2),
(1090, 819, NULL, 'Ghi đè tồn kho khi nhập excel', 80, 20, 100, NULL, '2023-12-31 10:51:39', 2),
(1091, 820, NULL, 'Ghi đè tồn kho khi nhập excel', 60, 40, 100, NULL, '2023-12-31 10:51:39', 2),
(1092, 821, NULL, 'Ghi đè tồn kho khi nhập excel', 60, 40, 100, NULL, '2023-12-31 10:51:39', 2),
(1093, 822, NULL, 'Ghi đè tồn kho khi nhập excel', 98, 2, 100, NULL, '2023-12-31 10:51:39', 2),
(1094, 823, NULL, 'Ghi đè tồn kho khi nhập excel', 97, 3, 100, NULL, '2023-12-31 10:51:39', 2),
(1095, 824, NULL, 'Ghi đè tồn kho khi nhập excel', 90, 10, 100, NULL, '2023-12-31 10:51:39', 2),
(1096, 825, NULL, 'Ghi đè tồn kho khi nhập excel', 87, 13, 100, NULL, '2023-12-31 10:51:39', 2),
(1097, 826, NULL, 'Ghi đè tồn kho khi nhập excel', 90, 10, 100, NULL, '2023-12-31 10:51:39', 2),
(1098, 827, NULL, 'Ghi đè tồn kho khi nhập excel', 95, 5, 100, NULL, '2023-12-31 10:51:39', 2),
(1099, 828, NULL, 'Ghi đè tồn kho khi nhập excel', 90, 10, 100, NULL, '2023-12-31 10:51:39', 2),
(1100, 829, NULL, 'Ghi đè tồn kho khi nhập excel', 95, 5, 100, NULL, '2023-12-31 10:51:39', 2),
(1101, 830, NULL, 'Ghi đè tồn kho khi nhập excel', 80, 20, 100, NULL, '2023-12-31 10:51:39', 2),
(1102, 831, NULL, 'Ghi đè tồn kho khi nhập excel', 80, 20, 100, NULL, '2023-12-31 10:51:39', 2),
(1103, 832, NULL, 'Ghi đè tồn kho khi nhập excel', 95, 5, 100, NULL, '2023-12-31 10:51:39', 2),
(1104, 833, NULL, 'Ghi đè tồn kho khi nhập excel', 97, 3, 100, NULL, '2023-12-31 10:51:39', 2),
(1105, 834, NULL, 'Ghi đè tồn kho khi nhập excel', 94, 6, 100, NULL, '2023-12-31 10:51:39', 2),
(1106, 835, NULL, 'Ghi đè tồn kho khi nhập excel', 85, 15, 100, NULL, '2023-12-31 10:51:39', 2),
(1107, 836, NULL, 'Ghi đè tồn kho khi nhập excel', -14, 114, 100, NULL, '2023-12-31 10:51:39', 2),
(1108, 837, NULL, 'Ghi đè tồn kho khi nhập excel', 85, 15, 100, NULL, '2023-12-31 10:51:39', 2),
(1109, 838, NULL, 'Ghi đè tồn kho khi nhập excel', -18, 118, 100, NULL, '2023-12-31 10:51:39', 2),
(1110, 839, NULL, 'Ghi đè tồn kho khi nhập excel', 70, 30, 100, NULL, '2023-12-31 10:51:39', 2),
(1111, 840, NULL, 'Ghi đè tồn kho khi nhập excel', 4, 96, 100, NULL, '2023-12-31 10:51:39', 2),
(1112, 841, NULL, 'Ghi đè tồn kho khi nhập excel', 56, 44, 100, NULL, '2023-12-31 10:51:39', 2),
(1113, 842, NULL, 'Ghi đè tồn kho khi nhập excel', 99, 1, 100, NULL, '2023-12-31 10:51:39', 2),
(1114, 843, NULL, 'Ghi đè tồn kho khi nhập excel', 92, 8, 100, NULL, '2023-12-31 10:51:39', 2),
(1115, 907, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2023-12-31 10:56:26', 2),
(1116, 908, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2023-12-31 10:56:26', 2),
(1117, 909, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2023-12-31 10:56:26', 2),
(1118, 910, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2023-12-31 10:56:26', 2),
(1119, 911, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2023-12-31 10:56:26', 2),
(1120, 912, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2023-12-31 10:56:26', 2),
(1121, 913, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2023-12-31 10:56:26', 2),
(1122, 914, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2023-12-31 10:56:26', 2),
(1123, 915, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2023-12-31 10:56:26', 2),
(1124, 916, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2023-12-31 10:56:26', 2),
(1125, 917, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2023-12-31 10:56:26', 2),
(1126, 918, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2023-12-31 10:56:26', 2),
(1127, 919, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2023-12-31 10:56:26', 2),
(1128, 920, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2023-12-31 10:56:26', 2),
(1129, 921, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2023-12-31 10:56:26', 2),
(1130, 922, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2023-12-31 10:56:26', 2),
(1131, 923, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2023-12-31 10:56:26', 2),
(1132, 924, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2023-12-31 10:56:26', 2),
(1133, 907, 1, 'Xuất kho mẫu cửa #4bMWw', 22, 0, -22, 23, '2023-12-31 23:13:39', 2),
(1134, 908, 1, 'Xuất kho mẫu cửa #4bMWw', 10, 0, -10, 23, '2023-12-31 23:13:39', 2),
(1135, 909, 1, 'Xuất kho mẫu cửa #4bMWw', 1, 0, -1, 23, '2023-12-31 23:13:39', 2),
(1136, 910, 1, 'Xuất kho mẫu cửa #4bMWw', 1, 0, -1, 23, '2023-12-31 23:13:39', 2),
(1137, 911, 1, 'Xuất kho mẫu cửa #4bMWw', 1, 0, -1, 23, '2023-12-31 23:13:39', 2),
(1138, 912, 1, 'Xuất kho mẫu cửa #4bMWw', 1, 0, -1, 23, '2023-12-31 23:13:39', 2),
(1139, 913, 1, 'Xuất kho mẫu cửa #4bMWw', 2, 0, -2, 23, '2023-12-31 23:13:39', 2),
(1140, 914, 1, 'Xuất kho mẫu cửa #4bMWw', 2, 0, -2, 23, '2023-12-31 23:13:39', 2),
(1141, 915, 1, 'Xuất kho mẫu cửa #4bMWw', 1, 0, -1, 23, '2023-12-31 23:13:39', 2),
(1142, 916, 1, 'Xuất kho mẫu cửa #4bMWw', 1, 0, -1, 23, '2023-12-31 23:13:39', 2),
(1143, 917, 1, 'Xuất kho mẫu cửa #4bMWw', 1, 0, -1, 23, '2023-12-31 23:13:39', 2),
(1144, 918, 1, 'Xuất kho mẫu cửa #4bMWw', 1, 0, -1, 23, '2023-12-31 23:13:39', 2),
(1145, 919, 1, 'Xuất kho mẫu cửa #4bMWw', 6, 0, -6, 23, '2023-12-31 23:13:39', 2),
(1146, 920, 1, 'Xuất kho mẫu cửa #4bMWw', 4, 0, -4, 23, '2023-12-31 23:13:39', 2),
(1147, 907, 1, 'Xuất kho mẫu cửa #4bMWw', 22, -22, -44, 23, '2023-12-31 23:14:13', 2),
(1148, 908, 1, 'Xuất kho mẫu cửa #4bMWw', 10, -10, -20, 23, '2023-12-31 23:14:13', 2),
(1149, 909, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -1, -2, 23, '2023-12-31 23:14:13', 2),
(1150, 910, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -1, -2, 23, '2023-12-31 23:14:13', 2),
(1151, 911, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -1, -2, 23, '2023-12-31 23:14:13', 2),
(1152, 912, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -1, -2, 23, '2023-12-31 23:14:13', 2),
(1153, 913, 1, 'Xuất kho mẫu cửa #4bMWw', 2, -2, -4, 23, '2023-12-31 23:14:13', 2),
(1154, 914, 1, 'Xuất kho mẫu cửa #4bMWw', 2, -2, -4, 23, '2023-12-31 23:14:13', 2),
(1155, 915, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -1, -2, 23, '2023-12-31 23:14:13', 2),
(1156, 916, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -1, -2, 23, '2023-12-31 23:14:13', 2),
(1157, 917, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -1, -2, 23, '2023-12-31 23:14:13', 2),
(1158, 918, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -1, -2, 23, '2023-12-31 23:14:13', 2),
(1159, 919, 1, 'Xuất kho mẫu cửa #4bMWw', 6, -6, -12, 23, '2023-12-31 23:14:13', 2),
(1160, 920, 1, 'Xuất kho mẫu cửa #4bMWw', 4, -4, -8, 23, '2023-12-31 23:14:13', 2),
(1161, 921, 1, 'Xuất kho mẫu cửa #4bMWw', 1, 0, -1, 23, '2023-12-31 23:14:13', 2),
(1162, 922, 1, 'Xuất kho mẫu cửa #4bMWw', 3, 0, -3, 23, '2023-12-31 23:14:13', 2),
(1163, 923, 1, 'Xuất kho mẫu cửa #4bMWw', 2.87, 0, -2.87, 23, '2023-12-31 23:14:13', 2),
(1164, 924, 1, 'Xuất kho mẫu cửa #4bMWw', 0.58, 0, -0.58, 23, '2023-12-31 23:14:13', 2),
(1165, 907, 1, 'Xuất kho mẫu cửa #4bMWw', 22, -44, -66, 23, '2023-12-31 23:15:35', 2),
(1166, 908, 1, 'Xuất kho mẫu cửa #4bMWw', 10, -20, -30, 23, '2023-12-31 23:15:35', 2),
(1167, 909, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -2, -3, 23, '2023-12-31 23:15:35', 2),
(1168, 910, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -2, -3, 23, '2023-12-31 23:15:35', 2),
(1169, 911, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -2, -3, 23, '2023-12-31 23:15:35', 2),
(1170, 912, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -2, -3, 23, '2023-12-31 23:15:35', 2),
(1171, 913, 1, 'Xuất kho mẫu cửa #4bMWw', 2, -4, -6, 23, '2023-12-31 23:15:35', 2),
(1172, 914, 1, 'Xuất kho mẫu cửa #4bMWw', 2, -4, -6, 23, '2023-12-31 23:15:35', 2),
(1173, 915, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -2, -3, 23, '2023-12-31 23:15:35', 2),
(1174, 916, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -2, -3, 23, '2023-12-31 23:15:35', 2),
(1175, 917, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -2, -3, 23, '2023-12-31 23:15:35', 2),
(1176, 918, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -2, -3, 23, '2023-12-31 23:15:35', 2),
(1177, 919, 1, 'Xuất kho mẫu cửa #4bMWw', 6, -12, -18, 23, '2023-12-31 23:15:35', 2),
(1178, 920, 1, 'Xuất kho mẫu cửa #4bMWw', 4, -8, -12, 23, '2023-12-31 23:15:35', 2),
(1179, 921, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -1, -2, 23, '2023-12-31 23:15:35', 2),
(1180, 922, 1, 'Xuất kho mẫu cửa #4bMWw', 3, -3, -6, 23, '2023-12-31 23:15:35', 2),
(1181, 923, 1, 'Xuất kho mẫu cửa #4bMWw', 2.87, -2.87, -5.74, 23, '2023-12-31 23:15:35', 2),
(1182, 924, 1, 'Xuất kho mẫu cửa #4bMWw', 0.58, -0.58, -1.16, 23, '2023-12-31 23:15:35', 2),
(1183, 907, 1, 'Xuất kho mẫu cửa #4bMWw', 22, -66, -88, 23, '2023-12-31 23:17:07', 2),
(1184, 908, 1, 'Xuất kho mẫu cửa #4bMWw', 10, -30, -40, 23, '2023-12-31 23:17:07', 2),
(1185, 909, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -3, -4, 23, '2023-12-31 23:17:07', 2),
(1186, 910, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -3, -4, 23, '2023-12-31 23:17:07', 2),
(1187, 911, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -3, -4, 23, '2023-12-31 23:17:07', 2),
(1188, 912, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -3, -4, 23, '2023-12-31 23:17:07', 2),
(1189, 913, 1, 'Xuất kho mẫu cửa #4bMWw', 2, -6, -8, 23, '2023-12-31 23:17:07', 2),
(1190, 914, 1, 'Xuất kho mẫu cửa #4bMWw', 2, -6, -8, 23, '2023-12-31 23:17:07', 2),
(1191, 915, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -3, -4, 23, '2023-12-31 23:17:07', 2),
(1192, 916, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -3, -4, 23, '2023-12-31 23:17:07', 2),
(1193, 917, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -3, -4, 23, '2023-12-31 23:17:07', 2),
(1194, 918, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -3, -4, 23, '2023-12-31 23:17:07', 2),
(1195, 919, 1, 'Xuất kho mẫu cửa #4bMWw', 6, -18, -24, 23, '2023-12-31 23:17:07', 2),
(1196, 920, 1, 'Xuất kho mẫu cửa #4bMWw', 4, -12, -16, 23, '2023-12-31 23:17:07', 2),
(1197, 921, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -2, -3, 23, '2023-12-31 23:17:07', 2),
(1198, 922, 1, 'Xuất kho mẫu cửa #4bMWw', 3, -6, -9, 23, '2023-12-31 23:17:07', 2),
(1199, 923, 1, 'Xuất kho mẫu cửa #4bMWw', 2.87, -5.74, -8.61, 23, '2023-12-31 23:17:07', 2),
(1200, 924, 1, 'Xuất kho mẫu cửa #4bMWw', 0.58, -1.16, -1.74, 23, '2023-12-31 23:17:07', 2);
INSERT INTO `cua_kho_vat_tu_lich_su` (`id`, `id_kho_vat_tu`, `id_nha_cung_cap`, `ghi_chu`, `so_luong`, `so_luong_cu`, `so_luong_moi`, `id_mau_cua`, `date_created`, `user_created`) VALUES
(1201, 907, 1, 'Xuất kho mẫu cửa #4bMWw', 22, -88, -110, 23, '2023-12-31 23:18:44', 2),
(1202, 908, 1, 'Xuất kho mẫu cửa #4bMWw', 10, -40, -50, 23, '2023-12-31 23:18:44', 2),
(1203, 909, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -4, -5, 23, '2023-12-31 23:18:44', 2),
(1204, 910, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -4, -5, 23, '2023-12-31 23:18:44', 2),
(1205, 911, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -4, -5, 23, '2023-12-31 23:18:45', 2),
(1206, 912, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -4, -5, 23, '2023-12-31 23:18:45', 2),
(1207, 913, 1, 'Xuất kho mẫu cửa #4bMWw', 2, -8, -10, 23, '2023-12-31 23:18:45', 2),
(1208, 914, 1, 'Xuất kho mẫu cửa #4bMWw', 2, -8, -10, 23, '2023-12-31 23:18:45', 2),
(1209, 915, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -4, -5, 23, '2023-12-31 23:18:45', 2),
(1210, 916, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -4, -5, 23, '2023-12-31 23:18:45', 2),
(1211, 917, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -4, -5, 23, '2023-12-31 23:18:45', 2),
(1212, 918, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -4, -5, 23, '2023-12-31 23:18:45', 2),
(1213, 919, 1, 'Xuất kho mẫu cửa #4bMWw', 6, -24, -30, 23, '2023-12-31 23:18:45', 2),
(1214, 920, 1, 'Xuất kho mẫu cửa #4bMWw', 4, -16, -20, 23, '2023-12-31 23:18:45', 2),
(1215, 921, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -3, -4, 23, '2023-12-31 23:18:45', 2),
(1216, 922, 1, 'Xuất kho mẫu cửa #4bMWw', 3, -9, -12, 23, '2023-12-31 23:18:45', 2),
(1217, 923, 1, 'Xuất kho mẫu cửa #4bMWw', 2.87, -8.61, -11.48, 23, '2023-12-31 23:18:45', 2),
(1218, 924, 1, 'Xuất kho mẫu cửa #4bMWw', 0.58, -1.74, -2.32, 23, '2023-12-31 23:18:45', 2),
(1219, 907, 1, 'Xuất kho mẫu cửa #4bMWw', 22, -110, -132, 23, '2023-12-31 23:19:57', 2),
(1220, 908, 1, 'Xuất kho mẫu cửa #4bMWw', 10, -50, -60, 23, '2023-12-31 23:19:57', 2),
(1221, 909, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -5, -6, 23, '2023-12-31 23:19:57', 2),
(1222, 910, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -5, -6, 23, '2023-12-31 23:19:57', 2),
(1223, 911, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -5, -6, 23, '2023-12-31 23:19:57', 2),
(1224, 912, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -5, -6, 23, '2023-12-31 23:19:57', 2),
(1225, 913, 1, 'Xuất kho mẫu cửa #4bMWw', 2, -10, -12, 23, '2023-12-31 23:19:57', 2),
(1226, 914, 1, 'Xuất kho mẫu cửa #4bMWw', 2, -10, -12, 23, '2023-12-31 23:19:57', 2),
(1227, 915, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -5, -6, 23, '2023-12-31 23:19:57', 2),
(1228, 916, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -5, -6, 23, '2023-12-31 23:19:57', 2),
(1229, 917, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -5, -6, 23, '2023-12-31 23:19:57', 2),
(1230, 918, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -5, -6, 23, '2023-12-31 23:19:57', 2),
(1231, 919, 1, 'Xuất kho mẫu cửa #4bMWw', 6, -30, -36, 23, '2023-12-31 23:19:57', 2),
(1232, 920, 1, 'Xuất kho mẫu cửa #4bMWw', 4, -20, -24, 23, '2023-12-31 23:19:57', 2),
(1233, 921, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -4, -5, 23, '2023-12-31 23:19:57', 2),
(1234, 922, 1, 'Xuất kho mẫu cửa #4bMWw', 3, -12, -15, 23, '2023-12-31 23:19:57', 2),
(1235, 923, 1, 'Xuất kho mẫu cửa #4bMWw', 2.87, -11.48, -14.35, 23, '2023-12-31 23:19:57', 2),
(1236, 924, 1, 'Xuất kho mẫu cửa #4bMWw', 0.58, -2.32, -2.9, 23, '2023-12-31 23:19:57', 2),
(1237, 907, 1, 'Xuất kho mẫu cửa #4bMWw', 22, -132, -154, 23, '2023-12-31 23:20:30', 2),
(1238, 908, 1, 'Xuất kho mẫu cửa #4bMWw', 10, -60, -70, 23, '2023-12-31 23:20:30', 2),
(1239, 909, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -6, -7, 23, '2023-12-31 23:20:30', 2),
(1240, 910, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -6, -7, 23, '2023-12-31 23:20:30', 2),
(1241, 911, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -6, -7, 23, '2023-12-31 23:20:30', 2),
(1242, 912, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -6, -7, 23, '2023-12-31 23:20:30', 2),
(1243, 913, 1, 'Xuất kho mẫu cửa #4bMWw', 2, -12, -14, 23, '2023-12-31 23:20:30', 2),
(1244, 914, 1, 'Xuất kho mẫu cửa #4bMWw', 2, -12, -14, 23, '2023-12-31 23:20:30', 2),
(1245, 915, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -6, -7, 23, '2023-12-31 23:20:30', 2),
(1246, 916, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -6, -7, 23, '2023-12-31 23:20:30', 2),
(1247, 917, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -6, -7, 23, '2023-12-31 23:20:30', 2),
(1248, 918, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -6, -7, 23, '2023-12-31 23:20:30', 2),
(1249, 919, 1, 'Xuất kho mẫu cửa #4bMWw', 6, -36, -42, 23, '2023-12-31 23:20:30', 2),
(1250, 920, 1, 'Xuất kho mẫu cửa #4bMWw', 4, -24, -28, 23, '2023-12-31 23:20:30', 2),
(1251, 921, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -5, -6, 23, '2023-12-31 23:20:30', 2),
(1252, 922, 1, 'Xuất kho mẫu cửa #4bMWw', 3, -15, -18, 23, '2023-12-31 23:20:30', 2),
(1253, 923, 1, 'Xuất kho mẫu cửa #4bMWw', 2.87, -14.35, -17.22, 23, '2023-12-31 23:20:30', 2),
(1254, 924, 1, 'Xuất kho mẫu cửa #4bMWw', 0.58, -2.9, -3.48, 23, '2023-12-31 23:20:30', 2),
(1255, 907, 1, 'Xuất kho mẫu cửa #4bMWw', 22, -154, -176, 23, '2023-12-31 23:21:14', 2),
(1256, 908, 1, 'Xuất kho mẫu cửa #4bMWw', 10, -70, -80, 23, '2023-12-31 23:21:14', 2),
(1257, 909, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -7, -8, 23, '2023-12-31 23:21:14', 2),
(1258, 910, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -7, -8, 23, '2023-12-31 23:21:14', 2),
(1259, 911, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -7, -8, 23, '2023-12-31 23:21:14', 2),
(1260, 912, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -7, -8, 23, '2023-12-31 23:21:14', 2),
(1261, 913, 1, 'Xuất kho mẫu cửa #4bMWw', 2, -14, -16, 23, '2023-12-31 23:21:14', 2),
(1262, 914, 1, 'Xuất kho mẫu cửa #4bMWw', 2, -14, -16, 23, '2023-12-31 23:21:14', 2),
(1263, 915, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -7, -8, 23, '2023-12-31 23:21:14', 2),
(1264, 916, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -7, -8, 23, '2023-12-31 23:21:14', 2),
(1265, 917, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -7, -8, 23, '2023-12-31 23:21:14', 2),
(1266, 918, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -7, -8, 23, '2023-12-31 23:21:14', 2),
(1267, 919, 1, 'Xuất kho mẫu cửa #4bMWw', 6, -42, -48, 23, '2023-12-31 23:21:14', 2),
(1268, 920, 1, 'Xuất kho mẫu cửa #4bMWw', 4, -28, -32, 23, '2023-12-31 23:21:14', 2),
(1269, 921, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -6, -7, 23, '2023-12-31 23:21:14', 2),
(1270, 922, 1, 'Xuất kho mẫu cửa #4bMWw', 3, -18, -21, 23, '2023-12-31 23:21:14', 2),
(1271, 923, 1, 'Xuất kho mẫu cửa #4bMWw', 2.87, -17.22, -20.09, 23, '2023-12-31 23:21:14', 2),
(1272, 924, 1, 'Xuất kho mẫu cửa #4bMWw', 0.58, -3.48, -4.06, 23, '2023-12-31 23:21:14', 2),
(1273, 907, 1, 'Xuất kho mẫu cửa #4bMWw', 22, -176, -198, 23, '2023-12-31 23:21:31', 2),
(1274, 908, 1, 'Xuất kho mẫu cửa #4bMWw', 10, -80, -90, 23, '2023-12-31 23:21:31', 2),
(1275, 909, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -8, -9, 23, '2023-12-31 23:21:31', 2),
(1276, 910, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -8, -9, 23, '2023-12-31 23:21:31', 2),
(1277, 911, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -8, -9, 23, '2023-12-31 23:21:31', 2),
(1278, 912, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -8, -9, 23, '2023-12-31 23:21:31', 2),
(1279, 913, 1, 'Xuất kho mẫu cửa #4bMWw', 2, -16, -18, 23, '2023-12-31 23:21:31', 2),
(1280, 914, 1, 'Xuất kho mẫu cửa #4bMWw', 2, -16, -18, 23, '2023-12-31 23:21:31', 2),
(1281, 915, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -8, -9, 23, '2023-12-31 23:21:31', 2),
(1282, 916, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -8, -9, 23, '2023-12-31 23:21:31', 2),
(1283, 917, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -8, -9, 23, '2023-12-31 23:21:31', 2),
(1284, 918, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -8, -9, 23, '2023-12-31 23:21:31', 2),
(1285, 919, 1, 'Xuất kho mẫu cửa #4bMWw', 6, -48, -54, 23, '2023-12-31 23:21:31', 2),
(1286, 920, 1, 'Xuất kho mẫu cửa #4bMWw', 4, -32, -36, 23, '2023-12-31 23:21:31', 2),
(1287, 921, 1, 'Xuất kho mẫu cửa #4bMWw', 1, -7, -8, 23, '2023-12-31 23:21:31', 2),
(1288, 922, 1, 'Xuất kho mẫu cửa #4bMWw', 3, -21, -24, 23, '2023-12-31 23:21:31', 2),
(1289, 923, 1, 'Xuất kho mẫu cửa #4bMWw', 2.87, -20.09, -22.96, 23, '2023-12-31 23:21:31', 2),
(1290, 924, 1, 'Xuất kho mẫu cửa #4bMWw', 0.58, -4.06, -4.64, 23, '2023-12-31 23:21:31', 2),
(1291, 907, 1, 'Xuất kho mẫu cửa #47YJr', 22, -198, -220, 24, '2023-12-31 23:24:37', 2),
(1292, 908, 1, 'Xuất kho mẫu cửa #47YJr', 10, -90, -100, 24, '2023-12-31 23:24:37', 2),
(1293, 909, 1, 'Xuất kho mẫu cửa #47YJr', 1, -9, -10, 24, '2023-12-31 23:24:37', 2),
(1294, 910, 1, 'Xuất kho mẫu cửa #47YJr', 1, -9, -10, 24, '2023-12-31 23:24:37', 2),
(1295, 911, 1, 'Xuất kho mẫu cửa #47YJr', 1, -9, -10, 24, '2023-12-31 23:24:37', 2),
(1296, 912, 1, 'Xuất kho mẫu cửa #47YJr', 1, -9, -10, 24, '2023-12-31 23:24:37', 2),
(1297, 913, 1, 'Xuất kho mẫu cửa #47YJr', 2, -18, -20, 24, '2023-12-31 23:24:37', 2),
(1298, 914, 1, 'Xuất kho mẫu cửa #47YJr', 2, -18, -20, 24, '2023-12-31 23:24:37', 2),
(1299, 915, 1, 'Xuất kho mẫu cửa #47YJr', 1, -9, -10, 24, '2023-12-31 23:24:37', 2),
(1300, 916, 1, 'Xuất kho mẫu cửa #47YJr', 1, -9, -10, 24, '2023-12-31 23:24:37', 2),
(1301, 917, 1, 'Xuất kho mẫu cửa #47YJr', 1, -9, -10, 24, '2023-12-31 23:24:37', 2),
(1302, 918, 1, 'Xuất kho mẫu cửa #47YJr', 1, -9, -10, 24, '2023-12-31 23:24:37', 2),
(1303, 919, 1, 'Xuất kho mẫu cửa #47YJr', 6, -54, -60, 24, '2023-12-31 23:24:37', 2),
(1304, 920, 1, 'Xuất kho mẫu cửa #47YJr', 4, -36, -40, 24, '2023-12-31 23:24:37', 2),
(1305, 921, 1, 'Xuất kho mẫu cửa #47YJr', 1, -8, -9, 24, '2023-12-31 23:24:37', 2),
(1306, 922, 1, 'Xuất kho mẫu cửa #47YJr', 3, -24, -27, 24, '2023-12-31 23:24:37', 2),
(1307, 923, 1, 'Xuất kho mẫu cửa #47YJr', 2.87, -22.96, -25.83, 24, '2023-12-31 23:24:37', 2),
(1308, 924, 1, 'Xuất kho mẫu cửa #47YJr', 0.58, -4.64, -5.22, 24, '2023-12-31 23:24:37', 2);

-- --------------------------------------------------------

--
-- Table structure for table `cua_kho_vat_tu_nha_cung_cap`
--

DROP TABLE IF EXISTS `cua_kho_vat_tu_nha_cung_cap`;
CREATE TABLE IF NOT EXISTS `cua_kho_vat_tu_nha_cung_cap` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_nha_cung_cap` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dia_chi` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_kho_vat_tu_nha_cung_cap`
--

INSERT INTO `cua_kho_vat_tu_nha_cung_cap` (`id`, `code`, `ten_nha_cung_cap`, `dia_chi`, `date_created`, `user_created`) VALUES
(1, 'abcd', 'Chưa phân loại', 'Thành phố Trà Vinh, tỉnh Trà Vinh', NULL, NULL),
(2, 'NCC01', 'Công ty TNHH ABCD', 'thành phố Trà Vinh\r\n', '2023-12-05 08:20:45', 1),
(3, 'NCC02', 'Công ty NVT', 'Trà VINH', '2023-12-05 08:41:01', 1),
(4, 'NCC03', 'Công ty DEF', 'Vĩnh Long', '2023-12-05 08:41:25', 1),
(5, 'NCC04', 'Nhà cung cấp 04', 'Long An', '2023-12-05 08:41:48', 1),
(6, 'fsadfas', 'fdsaf', 'fasdf', '2023-12-05 08:44:55', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_loai_bao_gia`
--

DROP TABLE IF EXISTS `cua_loai_bao_gia`;
CREATE TABLE IF NOT EXISTS `cua_loai_bao_gia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_loai_bao_gia` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nhom_bao_gia` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_loai_bao_gia`
--

INSERT INTO `cua_loai_bao_gia` (`id`, `code`, `ten_loai_bao_gia`, `nhom_bao_gia`, `ghi_chu`) VALUES
(1, 'nhom-mac-dinh', 'Báo giá nhôm', 'NHOM', NULL),
(2, 'vat-tu-mac-dinh', 'Báo giá vật tư', 'VATTU', NULL),
(3, 'vach-mac-dinh', 'Báo giá vách', 'VACH', NULL),
(4, '3wk68', 'Loại 1', 'VATTU', 'x');

-- --------------------------------------------------------

--
-- Table structure for table `cua_loai_cua`
--

DROP TABLE IF EXISTS `cua_loai_cua`;
CREATE TABLE IF NOT EXISTS `cua_loai_cua` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_loai_cua` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_loai_cua`
--

INSERT INTO `cua_loai_cua` (`id`, `code`, `ten_loai_cua`, `ghi_chu`, `date_created`, `user_created`) VALUES
(1, 'cua1canh', 'Cửa đi một cánh', '', '2023-09-26 08:39:38', 1),
(2, 'cua2canh', 'Cửa đi hai cánh', 'ghi chú', '2023-09-26 09:40:46', 1),
(3, '4cQDZ', 'CĐ 2 CÁNH', NULL, '2023-09-29 15:12:32', 1),
(4, '8BNY3', 'CỬA ĐI 2 CÁNH FIX RỜI', NULL, '2023-10-03 10:07:27', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua`
--

DROP TABLE IF EXISTS `cua_mau_cua`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_cua` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `kich_thuoc` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ngang` float DEFAULT NULL,
  `cao` float DEFAULT NULL,
  `id_he_nhom` int(11) DEFAULT NULL,
  `id_loai_cua` int(11) NOT NULL,
  `id_parent` int(11) DEFAULT NULL,
  `id_du_an` int(11) NOT NULL,
  `so_luong` int(11) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `id_he_nhom` (`id_he_nhom`),
  KEY `id_parent` (`id_parent`),
  KEY `id_loai_cua` (`id_loai_cua`),
  KEY `id_du_an` (`id_du_an`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_mau_cua`
--

INSERT INTO `cua_mau_cua` (`id`, `code`, `ten_cua`, `kich_thuoc`, `ngang`, `cao`, `id_he_nhom`, `id_loai_cua`, `id_parent`, `id_du_an`, `so_luong`, `status`, `date_created`, `user_created`) VALUES
(19, '7eudB', 'CỬA ĐI 2 CÁNH FIX RỜI', '1400x2700 (mm)', NULL, NULL, 4, 4, 0, 9, 1, 'KHOI_TAO', '2023-12-16 14:37:09', 1),
(20, '8kVAn', 'CỬA ĐI 2 CÁNH FIX RỜI', '1400x2700 (mm)', NULL, NULL, 4, 4, 0, 9, 1, 'KHOI_TAO', '2023-12-21 10:54:39', 1),
(21, '7t2r1', 'CỬA ĐI 2 CÁNH FIX RỜI', '1400x2700 (mm)', NULL, NULL, 4, 4, 0, 10, 1, 'KHOI_TAO', '2023-12-21 11:09:19', 1),
(22, '5MF9Z', 'CỬA ĐI 2 CÁNH FIX RỜI', '1400x2700 (mm)', NULL, NULL, 4, 4, 0, 10, 1, 'KHOI_TAO', '2023-12-31 10:56:26', 2),
(23, '4bMWw', 'CỬA ĐI 2 CÁNH FIX RỜI', '1400x2700 (mm)', NULL, NULL, 4, 4, 0, 11, 1, 'DA_XUAT_KHO', '2023-12-31 23:11:35', 2),
(24, '47YJr', 'CỬA ĐI 2 CÁNH FIX RỜI', '1400x2700 (mm)', NULL, NULL, 4, 4, 0, 11, 1, 'DA_XUAT_KHO', '2023-12-31 23:24:16', 2),
(26, '3zUSy', 'CỬA ĐI 2 CÁNH FIX RỜI', '1400x2700 (mm)', NULL, NULL, 4, 4, 0, 12, 1, 'KHOI_TAO', '2024-01-24 10:33:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua_nhom`
--

DROP TABLE IF EXISTS `cua_mau_cua_nhom`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua_nhom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mau_cua` int(11) NOT NULL,
  `id_cay_nhom` int(11) NOT NULL,
  `chieu_dai` float DEFAULT NULL,
  `so_luong` int(11) DEFAULT NULL,
  `kieu_cat` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `khoi_luong` float DEFAULT NULL,
  `don_gia` double DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_mau_cua` (`id_mau_cua`),
  KEY `id_cay_nhom` (`id_cay_nhom`)
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_mau_cua_nhom`
--

INSERT INTO `cua_mau_cua_nhom` (`id`, `id_mau_cua`, `id_cay_nhom`, `chieu_dai`, `so_luong`, `kieu_cat`, `khoi_luong`, `don_gia`, `date_created`, `user_created`) VALUES
(87, 22, 160, 1400, 1, '|===|', 0.49, 0, '2023-12-31 10:56:26', 2),
(88, 22, 161, 2000, 1, '/===\\', 1.76, 0, '2023-12-31 10:56:26', 2),
(89, 22, 161, 1000, 2, '/===\\', 1.76, 0, '2023-12-31 10:56:26', 2),
(90, 22, 161, 500, 1, '/===\\', 1.76, 0, '2023-12-31 10:56:26', 2),
(91, 22, 161, 2500, 1, '/===\\', 1.76, 0, '2023-12-31 10:56:26', 2),
(92, 22, 161, 5800, 1, '/===\\', 1.76, 0, '2023-12-31 10:56:26', 2),
(93, 22, 161, 5000, 1, '/===\\', 1.76, 0, '2023-12-31 10:56:26', 2),
(94, 22, 161, 1700, 1, '/===\\', 1.76, 0, '2023-12-31 10:56:26', 2),
(95, 22, 161, 300, 1, '/===\\', 1.76, 0, '2023-12-31 10:56:26', 2),
(96, 22, 160, 200, 5, '|===|', 0.49, 0, '2023-12-31 10:56:26', 2),
(97, 22, 160, 1700, 2, '|===|', 0.49, 0, '2023-12-31 10:56:26', 2),
(98, 23, 160, 1400, 1, '|===|', 0.49, 0, '2023-12-31 23:11:35', 2),
(99, 23, 161, 2000, 1, '/===\\', 1.76, 0, '2023-12-31 23:11:35', 2),
(100, 23, 161, 1000, 2, '/===\\', 1.76, 0, '2023-12-31 23:11:35', 2),
(101, 23, 161, 500, 1, '/===\\', 1.76, 0, '2023-12-31 23:11:35', 2),
(102, 23, 161, 2500, 1, '/===\\', 1.76, 0, '2023-12-31 23:11:35', 2),
(103, 23, 161, 5800, 1, '/===\\', 1.76, 0, '2023-12-31 23:11:35', 2),
(104, 23, 161, 5000, 1, '/===\\', 1.76, 0, '2023-12-31 23:11:35', 2),
(105, 23, 161, 1700, 1, '/===\\', 1.76, 0, '2023-12-31 23:11:35', 2),
(106, 23, 161, 300, 1, '/===\\', 1.76, 0, '2023-12-31 23:11:35', 2),
(107, 23, 160, 200, 5, '|===|', 0.49, 0, '2023-12-31 23:11:35', 2),
(108, 23, 160, 1700, 2, '|===|', 0.49, 0, '2023-12-31 23:11:35', 2),
(109, 24, 160, 1400, 1, '|===|', 0.49, 0, '2023-12-31 23:24:16', 2),
(110, 24, 161, 2000, 1, '/===\\', 1.76, 0, '2023-12-31 23:24:16', 2),
(111, 24, 161, 1000, 2, '/===\\', 1.76, 0, '2023-12-31 23:24:16', 2),
(112, 24, 161, 500, 1, '/===\\', 1.76, 0, '2023-12-31 23:24:16', 2),
(113, 24, 161, 2500, 1, '/===\\', 1.76, 0, '2023-12-31 23:24:16', 2),
(114, 24, 161, 5800, 1, '/===\\', 1.76, 0, '2023-12-31 23:24:16', 2),
(115, 24, 161, 5000, 1, '/===\\', 1.76, 0, '2023-12-31 23:24:16', 2),
(116, 24, 161, 1700, 1, '/===\\', 1.76, 0, '2023-12-31 23:24:16', 2),
(117, 24, 161, 300, 1, '/===\\', 1.76, 0, '2023-12-31 23:24:16', 2),
(118, 24, 160, 200, 5, '/===\\', 0.49, 0, '2023-12-31 23:24:16', 2),
(119, 24, 160, 1700, 2, '|===\\', 0.49, 0, '2023-12-31 23:24:16', 2),
(120, 26, 160, 1400, 1, '|===|', 0.49, 0, '2024-01-24 10:33:00', 1),
(121, 26, 161, 2000, 1, '/===\\', 1.76, 0, '2024-01-24 10:33:00', 1),
(122, 26, 161, 1000, 2, '/===\\', 1.76, 0, '2024-01-24 10:33:00', 1),
(123, 26, 161, 500, 1, '/===\\', 1.76, 0, '2024-01-24 10:33:00', 1),
(124, 26, 161, 2500, 1, '/===\\', 1.76, 0, '2024-01-24 10:33:00', 1),
(125, 26, 161, 5800, 1, '/===\\', 1.76, 0, '2024-01-24 10:33:00', 1),
(126, 26, 161, 5000, 1, '/===\\', 1.76, 0, '2024-01-24 10:33:00', 1),
(127, 26, 161, 1700, 1, '/===\\', 1.76, 0, '2024-01-24 10:33:00', 1),
(128, 26, 161, 300, 1, '/===\\', 1.76, 0, '2024-01-24 10:33:00', 1),
(129, 26, 160, 200, 5, '|===|', 0.49, 0, '2024-01-24 10:33:00', 1),
(130, 26, 160, 1700, 2, '|===|', 0.49, 0, '2024-01-24 10:33:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua_nhom_su_dung`
--

DROP TABLE IF EXISTS `cua_mau_cua_nhom_su_dung`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua_nhom_su_dung` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mau_cua` int(11) NOT NULL,
  `id_kho_nhom` int(11) NOT NULL,
  `chieu_dai_ban_dau` float NOT NULL,
  `chieu_dai_con_lai` float NOT NULL,
  `chieu_dai_nhap_lai` float DEFAULT NULL,
  `ghi_chu_nhap_lai` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_mau_cua` (`id_mau_cua`),
  KEY `id_kho_nhom` (`id_kho_nhom`)
) ENGINE=InnoDB AUTO_INCREMENT=206 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_mau_cua_nhom_su_dung`
--

INSERT INTO `cua_mau_cua_nhom_su_dung` (`id`, `id_mau_cua`, `id_kho_nhom`, `chieu_dai_ban_dau`, `chieu_dai_con_lai`, `chieu_dai_nhap_lai`, `ghi_chu_nhap_lai`, `date_created`, `user_created`) VALUES
(92, 23, 180, 5900, 100, NULL, NULL, '2023-12-31 23:11:41', 2),
(93, 23, 181, 5900, 100, NULL, NULL, '2023-12-31 23:11:41', 2),
(94, 23, 181, 5900, 100, NULL, NULL, '2023-12-31 23:11:41', 2),
(95, 23, 181, 5900, 400, NULL, NULL, '2023-12-31 23:11:41', 2),
(96, 23, 181, 5900, 3200, NULL, NULL, '2023-12-31 23:11:41', 2),
(97, 24, 180, 5900, 100, NULL, NULL, '2023-12-31 23:24:23', 2),
(98, 24, 183, 3000, 0, NULL, NULL, '2023-12-31 23:24:24', 2),
(99, 24, 183, 3000, 0, NULL, NULL, '2023-12-31 23:24:24', 2),
(100, 24, 183, 3000, 0, NULL, NULL, '2023-12-31 23:24:24', 2),
(101, 24, 181, 5900, 100, NULL, NULL, '2023-12-31 23:24:24', 2),
(102, 24, 181, 5900, 900, NULL, NULL, '2023-12-31 23:24:24', 2),
(141, 22, 180, 5900, 100, NULL, NULL, '2024-01-22 08:00:17', 1),
(142, 22, 181, 5900, 100, NULL, NULL, '2024-01-22 08:00:17', 1),
(143, 22, 181, 5900, 100, NULL, NULL, '2024-01-22 08:00:17', 1),
(144, 22, 181, 5900, 400, NULL, NULL, '2024-01-22 08:00:18', 1),
(145, 22, 181, 5900, 3200, NULL, NULL, '2024-01-22 08:00:18', 1),
(201, 26, 180, 5900, 100, NULL, NULL, '2024-04-24 13:39:46', 1),
(202, 26, 181, 5900, 100, NULL, NULL, '2024-04-24 13:39:46', 1),
(203, 26, 181, 5900, 100, NULL, NULL, '2024-04-24 13:39:46', 1),
(204, 26, 181, 5900, 400, NULL, NULL, '2024-04-24 13:39:46', 1),
(205, 26, 181, 5900, 3200, NULL, NULL, '2024-04-24 13:39:46', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua_nhom_su_dung_chi_tiet`
--

DROP TABLE IF EXISTS `cua_mau_cua_nhom_su_dung_chi_tiet`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua_nhom_su_dung_chi_tiet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_nhom_su_dung` int(11) NOT NULL,
  `id_nhom_toi_uu` int(11) NOT NULL,
  `date_created` int(11) DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_nhom_su_dung` (`id_nhom_su_dung`),
  KEY `id_nhom_toi_uu` (`id_nhom_toi_uu`)
) ENGINE=InnoDB AUTO_INCREMENT=479 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_mau_cua_nhom_su_dung_chi_tiet`
--

INSERT INTO `cua_mau_cua_nhom_su_dung_chi_tiet` (`id`, `id_nhom_su_dung`, `id_nhom_toi_uu`, `date_created`, `user_created`) VALUES
(122, 92, 800, 2023, 2),
(123, 92, 810, 2023, 2),
(124, 92, 811, 2023, 2),
(125, 92, 812, 2023, 2),
(126, 92, 813, 2023, 2),
(127, 92, 814, 2023, 2),
(128, 92, 815, 2023, 2),
(129, 92, 816, 2023, 2),
(130, 93, 806, 2023, 2),
(131, 94, 801, 2023, 2),
(132, 94, 802, 2023, 2),
(133, 94, 805, 2023, 2),
(134, 94, 809, 2023, 2),
(135, 95, 804, 2023, 2),
(136, 95, 807, 2023, 2),
(137, 96, 803, 2023, 2),
(138, 96, 808, 2023, 2),
(139, 97, 817, 2023, 2),
(140, 97, 827, 2023, 2),
(141, 97, 828, 2023, 2),
(142, 97, 829, 2023, 2),
(143, 97, 830, 2023, 2),
(144, 97, 831, 2023, 2),
(145, 97, 832, 2023, 2),
(146, 97, 833, 2023, 2),
(147, 98, 818, 2023, 2),
(148, 98, 819, 2023, 2),
(149, 99, 821, 2023, 2),
(150, 99, 822, 2023, 2),
(151, 100, 820, 2023, 2),
(152, 100, 825, 2023, 2),
(153, 100, 826, 2023, 2),
(154, 101, 823, 2023, 2),
(155, 102, 824, 2023, 2),
(275, 141, 953, 2024, 1),
(276, 141, 963, 2024, 1),
(277, 141, 964, 2024, 1),
(278, 141, 965, 2024, 1),
(279, 141, 966, 2024, 1),
(280, 141, 967, 2024, 1),
(281, 141, 968, 2024, 1),
(282, 141, 969, 2024, 1),
(283, 142, 959, 2024, 1),
(284, 143, 954, 2024, 1),
(285, 143, 955, 2024, 1),
(286, 143, 958, 2024, 1),
(287, 143, 962, 2024, 1),
(288, 144, 957, 2024, 1),
(289, 144, 960, 2024, 1),
(290, 145, 956, 2024, 1),
(291, 145, 961, 2024, 1),
(462, 201, 1140, 2024, 1),
(463, 201, 1150, 2024, 1),
(464, 201, 1151, 2024, 1),
(465, 201, 1152, 2024, 1),
(466, 201, 1153, 2024, 1),
(467, 201, 1154, 2024, 1),
(468, 201, 1155, 2024, 1),
(469, 201, 1156, 2024, 1),
(470, 202, 1146, 2024, 1),
(471, 203, 1141, 2024, 1),
(472, 203, 1142, 2024, 1),
(473, 203, 1145, 2024, 1),
(474, 203, 1149, 2024, 1),
(475, 204, 1144, 2024, 1),
(476, 204, 1147, 2024, 1),
(477, 205, 1143, 2024, 1),
(478, 205, 1148, 2024, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua_settings`
--

DROP TABLE IF EXISTS `cua_mau_cua_settings`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mau_cua` int(11) DEFAULT NULL,
  `vet_cat` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_mau_cua_settings`
--

INSERT INTO `cua_mau_cua_settings` (`id`, `id_mau_cua`, `vet_cat`) VALUES
(1, 24, 5),
(2, 25, 2.5),
(3, 19, 2.5),
(4, 25, 2.5),
(5, 23, 1),
(6, 26, 3);

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua_vach`
--

DROP TABLE IF EXISTS `cua_mau_cua_vach`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua_vach` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mau_cua` int(11) NOT NULL,
  `id_vach` int(11) NOT NULL,
  `rong` float DEFAULT NULL,
  `cao` float DEFAULT NULL,
  `so_luong` float DEFAULT NULL,
  `dien_tich` float DEFAULT NULL,
  `don_gia` double NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) NOT NULL,
  `so_luong_xuat` float DEFAULT NULL,
  `ghi_chu_xuat` text COLLATE utf8_unicode_ci,
  `so_luong_nhap_lai` float DEFAULT NULL,
  `ghi_chu_nhap_lai` text COLLATE utf8_unicode_ci,
  `code_bao_gia` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_mau_cua` (`id_mau_cua`),
  KEY `id_vach` (`id_vach`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_mau_cua_vach`
--

INSERT INTO `cua_mau_cua_vach` (`id`, `id_mau_cua`, `id_vach`, `rong`, `cao`, `so_luong`, `dien_tich`, `don_gia`, `date_created`, `user_created`, `so_luong_xuat`, `ghi_chu_xuat`, `so_luong_nhap_lai`, `ghi_chu_nhap_lai`, `code_bao_gia`) VALUES
(5, 19, 3, 514, 2008, 2, 2.06, 0, '2023-12-16 14:37:09', 1, 0, '', 0, '', NULL),
(6, 19, 3, 1330, 429, 1, 0.57, 0, '2023-12-16 14:37:09', 1, 0, '', 0, '', NULL),
(7, 20, 3, 514, 2008, 2, 2.06, 0, '2023-12-21 10:54:39', 1, 0, '', 0, '', NULL),
(8, 20, 3, 1330, 429, 1, 0.57, 0, '2023-12-21 10:54:39', 1, 0, '', 0, '', NULL),
(9, 21, 3, 514, 2008, 2, 2.06, 0, '2023-12-21 11:09:19', 1, 0, '', 0, '', NULL),
(10, 21, 3, 1330, 429, 1, 0.57, 0, '2023-12-21 11:09:19', 1, 0, '', 0, '', NULL),
(11, 22, 3, 514, 2008, 2, 2.06, 0, '2023-12-31 10:56:26', 2, 0, '', 0, '', NULL),
(12, 22, 3, 1330, 429, 1, 0.57, 0, '2023-12-31 10:56:26', 2, 0, '', 0, '', NULL),
(13, 23, 3, 514, 2008, 2, 2.06, 0, '2023-12-31 23:11:35', 2, 0, '', 0, '', NULL),
(14, 23, 3, 1330, 429, 1, 0.57, 0, '2023-12-31 23:11:35', 2, 0, '', 0, '', NULL),
(15, 24, 3, 514, 2008, 2, 2.06, 0, '2023-12-31 23:24:16', 2, 0, '', 0, '', NULL),
(16, 24, 3, 1330, 429, 1, 0.57, 0, '2023-12-31 23:24:16', 2, 0, '', 0, '', NULL),
(17, 26, 3, 514, 2008, 2, 2.06, 0, '2024-01-24 10:33:00', 1, 0, '', 0, '', NULL),
(18, 26, 3, 1330, 429, 1, 0.57, 0, '2024-01-24 10:33:00', 1, 0, '', 0, '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua_vat_tu`
--

DROP TABLE IF EXISTS `cua_mau_cua_vat_tu`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua_vat_tu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mau_cua` int(11) NOT NULL,
  `id_kho_vat_tu` int(11) NOT NULL,
  `so_luong` float NOT NULL,
  `dvt` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `don_gia` double DEFAULT NULL,
  `la_phu_kien` tinyint(4) DEFAULT NULL,
  `so_luong_xuat` float DEFAULT NULL,
  `ghi_chu_xuat` text COLLATE utf8_unicode_ci,
  `so_luong_nhap_lai` float DEFAULT NULL,
  `ghi_chu_nhap_lai` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  `code_bao_gia` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_mau_cua` (`id_mau_cua`),
  KEY `id_kho_vat_tu` (`id_kho_vat_tu`)
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_mau_cua_vat_tu`
--

INSERT INTO `cua_mau_cua_vat_tu` (`id`, `id_mau_cua`, `id_kho_vat_tu`, `so_luong`, `dvt`, `don_gia`, `la_phu_kien`, `so_luong_xuat`, `ghi_chu_xuat`, `so_luong_nhap_lai`, `ghi_chu_nhap_lai`, `date_created`, `user_created`, `code_bao_gia`) VALUES
(73, 22, 907, 22, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(74, 22, 908, 10, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(75, 22, 909, 1, 'cặp', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(76, 22, 910, 1, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(77, 22, 911, 1, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(78, 22, 912, 1, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(79, 22, 913, 2, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(80, 22, 914, 2, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(81, 22, 915, 1, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(82, 22, 916, 1, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(83, 22, 917, 1, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(84, 22, 918, 1, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(85, 22, 919, 6, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(86, 22, 920, 4, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(87, 22, 921, 1, 'cái', 0, 0, 0, '', 0, '', NULL, NULL, NULL),
(88, 22, 922, 3, 'cái', 0, 0, 0, '', 0, '', NULL, NULL, NULL),
(89, 22, 923, 2.87, 'm2', 0, 0, 0, '', 0, '', NULL, NULL, NULL),
(90, 22, 924, 0.58, 'm2', 0, 0, 0, '', 0, '', NULL, NULL, NULL),
(92, 23, 908, 15, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(93, 23, 909, 1, 'cặp', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(94, 23, 910, 1, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(95, 23, 911, 1, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(96, 23, 912, 1, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(97, 23, 913, 2, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(98, 23, 914, 2, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(99, 23, 915, 1, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(100, 23, 916, 1, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(101, 23, 917, 1, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(102, 23, 918, 1, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(103, 23, 919, 6, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(104, 23, 920, 4, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(105, 23, 921, 11, 'cái', 0, 0, 0, '', 0, '', NULL, NULL, NULL),
(106, 23, 922, 3, 'cái', 0, 0, 0, '', 0, '', NULL, NULL, NULL),
(107, 23, 923, 2.87, 'm2', 0, 0, 0, '', 0, '', NULL, NULL, NULL),
(108, 23, 924, 0.58, 'm2', 0, 0, 0, '', 0, '', NULL, NULL, NULL),
(115, 24, 913, 2, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(116, 24, 914, 2, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(117, 24, 915, 1, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(118, 24, 916, 1, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(119, 24, 917, 1, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(120, 24, 918, 1, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(121, 24, 919, 6, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(122, 24, 920, 4, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(123, 24, 921, 1, 'cái', 0, 0, 0, '', 0, '', NULL, NULL, NULL),
(124, 24, 922, 3, 'cái', 0, 0, 0, '', 0, '', NULL, NULL, NULL),
(125, 24, 923, 2.87, 'm2', 0, 0, 0, '', 0, '', NULL, NULL, NULL),
(126, 24, 924, 0.58, 'm2', 0, 0, 0, '', 0, '', NULL, NULL, NULL),
(127, 26, 907, 100, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(128, 26, 908, 10, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(129, 26, 909, 1, 'cặp', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(130, 26, 910, 1, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(131, 26, 911, 1, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(132, 26, 912, 2, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(133, 26, 913, 2, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(134, 26, 914, 2, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(135, 26, 915, 1, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(136, 26, 916, 1, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(137, 26, 917, 1, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(138, 26, 918, 1, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(139, 26, 919, 6, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(140, 26, 920, 4, 'cái', 0, 1, 0, '', 0, '', NULL, NULL, NULL),
(141, 26, 921, 1, 'cái', 0, 0, 0, '', 0, '', NULL, NULL, NULL),
(142, 26, 922, 3, 'cái', 0, 0, 0, '', 0, '', NULL, NULL, NULL),
(143, 26, 923, 2.87, 'm2', 0, 0, 0, '', 0, '', NULL, NULL, NULL),
(144, 26, 924, 0.58, 'm2', 0, 0, 0, '', 0, '', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cua_settings`
--

DROP TABLE IF EXISTS `cua_settings`;
CREATE TABLE IF NOT EXISTS `cua_settings` (
  `id` int(11) NOT NULL,
  `cho_phep_nhap_kho_am` tinyint(1) DEFAULT NULL,
  `an_kho_nhom_bang_khong` tinyint(1) DEFAULT NULL,
  `vet_cat` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_settings`
--

INSERT INTO `cua_settings` (`id`, `cho_phep_nhap_kho_am`, `an_kho_nhom_bang_khong`, `vet_cat`) VALUES
(1, 1, 1, 2.5);

-- --------------------------------------------------------

--
-- Table structure for table `cua_thuong_hieu`
--

DROP TABLE IF EXISTS `cua_thuong_hieu`;
CREATE TABLE IF NOT EXISTS `cua_thuong_hieu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_thuong_hieu` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_thuong_hieu`
--

INSERT INTO `cua_thuong_hieu` (`id`, `code`, `ten_thuong_hieu`, `ghi_chu`) VALUES
(1, 'chua-phan-loai', 'Mặc định', ''),
(2, '9AM1y', 'Thương hiệu 1', ''),
(3, '6FYOl', 'Thương hiệu 2', '');

-- --------------------------------------------------------

--
-- Table structure for table `cua_toi_uu`
--

DROP TABLE IF EXISTS `cua_toi_uu`;
CREATE TABLE IF NOT EXISTS `cua_toi_uu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mau_cua` int(11) NOT NULL,
  `id_mau_cua_nhom` int(11) NOT NULL,
  `id_ton_kho_nhom` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_mau_cua` (`id_mau_cua`),
  KEY `id_mau_cua_nhom` (`id_mau_cua_nhom`),
  KEY `id_ton_kho_nhom` (`id_ton_kho_nhom`)
) ENGINE=InnoDB AUTO_INCREMENT=1157 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_toi_uu`
--

INSERT INTO `cua_toi_uu` (`id`, `id_mau_cua`, `id_mau_cua_nhom`, `id_ton_kho_nhom`, `date_created`, `user_created`) VALUES
(800, 23, 98, 180, '2023-12-31 23:11:41', 2),
(801, 23, 99, 181, '2023-12-31 23:11:41', 2),
(802, 23, 100, 181, '2023-12-31 23:11:41', 2),
(803, 23, 100, 181, '2023-12-31 23:11:41', 2),
(804, 23, 101, 181, '2023-12-31 23:11:41', 2),
(805, 23, 102, 181, '2023-12-31 23:11:41', 2),
(806, 23, 103, 181, '2023-12-31 23:11:41', 2),
(807, 23, 104, 181, '2023-12-31 23:11:41', 2),
(808, 23, 105, 181, '2023-12-31 23:11:41', 2),
(809, 23, 106, 181, '2023-12-31 23:11:41', 2),
(810, 23, 107, 180, '2023-12-31 23:11:41', 2),
(811, 23, 107, 180, '2023-12-31 23:11:41', 2),
(812, 23, 107, 180, '2023-12-31 23:11:41', 2),
(813, 23, 107, 180, '2023-12-31 23:11:41', 2),
(814, 23, 107, 180, '2023-12-31 23:11:41', 2),
(815, 23, 108, 180, '2023-12-31 23:11:41', 2),
(816, 23, 108, 180, '2023-12-31 23:11:41', 2),
(817, 24, 109, 180, '2023-12-31 23:24:23', 2),
(818, 24, 110, 183, '2023-12-31 23:24:23', 2),
(819, 24, 111, 183, '2023-12-31 23:24:23', 2),
(820, 24, 111, 183, '2023-12-31 23:24:23', 2),
(821, 24, 112, 183, '2023-12-31 23:24:23', 2),
(822, 24, 113, 183, '2023-12-31 23:24:23', 2),
(823, 24, 114, 181, '2023-12-31 23:24:23', 2),
(824, 24, 115, 181, '2023-12-31 23:24:23', 2),
(825, 24, 116, 183, '2023-12-31 23:24:23', 2),
(826, 24, 117, 183, '2023-12-31 23:24:23', 2),
(827, 24, 118, 180, '2023-12-31 23:24:23', 2),
(828, 24, 118, 180, '2023-12-31 23:24:23', 2),
(829, 24, 118, 180, '2023-12-31 23:24:23', 2),
(830, 24, 118, 180, '2023-12-31 23:24:23', 2),
(831, 24, 118, 180, '2023-12-31 23:24:23', 2),
(832, 24, 119, 180, '2023-12-31 23:24:23', 2),
(833, 24, 119, 180, '2023-12-31 23:24:23', 2),
(953, 22, 87, 180, '2024-01-22 08:00:17', 1),
(954, 22, 88, 181, '2024-01-22 08:00:17', 1),
(955, 22, 89, 181, '2024-01-22 08:00:17', 1),
(956, 22, 89, 181, '2024-01-22 08:00:17', 1),
(957, 22, 90, 181, '2024-01-22 08:00:17', 1),
(958, 22, 91, 181, '2024-01-22 08:00:17', 1),
(959, 22, 92, 181, '2024-01-22 08:00:17', 1),
(960, 22, 93, 181, '2024-01-22 08:00:17', 1),
(961, 22, 94, 181, '2024-01-22 08:00:17', 1),
(962, 22, 95, 181, '2024-01-22 08:00:17', 1),
(963, 22, 96, 180, '2024-01-22 08:00:17', 1),
(964, 22, 96, 180, '2024-01-22 08:00:17', 1),
(965, 22, 96, 180, '2024-01-22 08:00:17', 1),
(966, 22, 96, 180, '2024-01-22 08:00:17', 1),
(967, 22, 96, 180, '2024-01-22 08:00:17', 1),
(968, 22, 97, 180, '2024-01-22 08:00:17', 1),
(969, 22, 97, 180, '2024-01-22 08:00:17', 1),
(1140, 26, 120, 180, '2024-04-24 13:39:46', 1),
(1141, 26, 121, 181, '2024-04-24 13:39:46', 1),
(1142, 26, 122, 181, '2024-04-24 13:39:46', 1),
(1143, 26, 122, 181, '2024-04-24 13:39:46', 1),
(1144, 26, 123, 181, '2024-04-24 13:39:46', 1),
(1145, 26, 124, 181, '2024-04-24 13:39:46', 1),
(1146, 26, 125, 181, '2024-04-24 13:39:46', 1),
(1147, 26, 126, 181, '2024-04-24 13:39:46', 1),
(1148, 26, 127, 181, '2024-04-24 13:39:46', 1),
(1149, 26, 128, 181, '2024-04-24 13:39:46', 1),
(1150, 26, 129, 180, '2024-04-24 13:39:46', 1),
(1151, 26, 129, 180, '2024-04-24 13:39:46', 1),
(1152, 26, 129, 180, '2024-04-24 13:39:46', 1),
(1153, 26, 129, 180, '2024-04-24 13:39:46', 1),
(1154, 26, 129, 180, '2024-04-24 13:39:46', 1),
(1155, 26, 130, 180, '2024-04-24 13:39:46', 1),
(1156, 26, 130, 180, '2024-04-24 13:39:46', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_xuat_xu`
--

DROP TABLE IF EXISTS `cua_xuat_xu`;
CREATE TABLE IF NOT EXISTS `cua_xuat_xu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_xuat_xu` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_xuat_xu`
--

INSERT INTO `cua_xuat_xu` (`id`, `code`, `ten_xuat_xu`, `ghi_chu`) VALUES
(1, 'chua-phan-loai', 'Chưa phân loại', ''),
(2, 'VN', 'Việt Nam', '');

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

DROP TABLE IF EXISTS `migration`;
CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1695691639),
('m140608_173539_create_user_table', 1695691642),
('m140611_133903_init_rbac', 1695691642),
('m140808_073114_create_auth_item_group_table', 1695691642),
('m140809_072112_insert_superadmin_to_user', 1695691643),
('m140809_073114_insert_common_permisison_to_auth_item', 1695691643),
('m141023_141535_create_user_visit_log', 1695691643),
('m141116_115804_add_bind_to_ip_and_registration_ip_to_user', 1695691643),
('m141121_194858_split_browser_and_os_column', 1695691643),
('m141201_220516_add_email_and_email_confirmed_to_user', 1695691644),
('m141207_001649_create_basic_user_permissions', 1695691644);

-- --------------------------------------------------------

--
-- Table structure for table `technologies`
--

DROP TABLE IF EXISTS `technologies`;
CREATE TABLE IF NOT EXISTS `technologies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `summary` text COLLATE utf8_unicode_ci,
  `datetime_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `template`
--

DROP TABLE IF EXISTS `template`;
CREATE TABLE IF NOT EXISTS `template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `summary` text COLLATE utf8_unicode_ci,
  `user_created` int(11) DEFAULT NULL,
  `datetime_created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `template`
--

INSERT INTO `template` (`id`, `code`, `name`, `summary`, `user_created`, `datetime_created`) VALUES
(6, '67817125f52ebc64d623ca038038bc27', 'Template 1', '', NULL, '2023-09-11 15:42:47');

-- --------------------------------------------------------

--
-- Table structure for table `template_blocks`
--

DROP TABLE IF EXISTS `template_blocks`;
CREATE TABLE IF NOT EXISTS `template_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_template` int(11) NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `user_created` int(11) DEFAULT NULL,
  `datetime_created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_template` (`id_template`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `template_blocks`
--

INSERT INTO `template_blocks` (`id`, `id_template`, `code`, `name`, `content`, `user_created`, `datetime_created`) VALUES
(2, 6, 'd1942f189c31983ed21a8aa7c9589fa9', 'Block info', 'Công ty TNHH An Thịnh', NULL, '2023-09-11 15:48:05');

-- --------------------------------------------------------

--
-- Table structure for table `template_pages`
--

DROP TABLE IF EXISTS `template_pages`;
CREATE TABLE IF NOT EXISTS `template_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_template` int(11) NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `is_dynamic` tinyint(1) NOT NULL,
  `user_created` int(11) DEFAULT NULL,
  `datetime_created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_template` (`id_template`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `template_pages`
--

INSERT INTO `template_pages` (`id`, `id_template`, `code`, `name`, `file`, `is_dynamic`, `user_created`, `datetime_created`) VALUES
(7, 6, 'd874eb9923d3b481764a924017ce29ff', 'Trang chủ', 'index.php', 0, NULL, '2023-09-11 15:46:18'),
(8, 6, 'f6e8a5b10c8d2c9f24cd31a23ce3ad65', 'Giới thiệu', 'about.php', 0, NULL, '2023-09-11 15:46:32');

-- --------------------------------------------------------

--
-- Table structure for table `template_technologies`
--

DROP TABLE IF EXISTS `template_technologies`;
CREATE TABLE IF NOT EXISTS `template_technologies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_template` int(11) NOT NULL,
  `id_technologie` int(11) NOT NULL,
  `datetime_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_template` (`id_template`),
  KEY `id_technologie` (`id_technologie`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `template_varibles`
--

DROP TABLE IF EXISTS `template_varibles`;
CREATE TABLE IF NOT EXISTS `template_varibles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_template` int(11) NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `varible_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_created` int(11) DEFAULT NULL,
  `datetime_created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_template` (`id_template`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `template_varibles`
--

INSERT INTO `template_varibles` (`id`, `id_template`, `code`, `name`, `varible_type`, `value`, `user_created`, `datetime_created`) VALUES
(3, 6, 'e5a03b101c9278dee5b30f8de11887ef', 'var1', 'text', 'Nguyễn Văn Tý An', NULL, '2023-09-11 15:47:42'),
(4, 6, '59b147ddf73d528f3100ad37d99a6a1d', 'var2', 'int', '100', NULL, '2023-09-11 15:47:51');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8 NOT NULL,
  `auth_key` varchar(32) CHARACTER SET utf8 NOT NULL,
  `password_hash` varchar(255) CHARACTER SET utf8 NOT NULL,
  `confirmation_token` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `superadmin` smallint(6) DEFAULT '0',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `registration_ip` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
  `bind_to_ip` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(128) CHARACTER SET utf8 DEFAULT NULL,
  `email_confirmed` smallint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `confirmation_token`, `status`, `superadmin`, `created_at`, `updated_at`, `registration_ip`, `bind_to_ip`, `email`, `email_confirmed`) VALUES
(1, 'superadmin', 'MDvwUlYvBDOYlfwXEkNhRChWr2utQ3xU', '$2y$13$.82.TmKU5VxndDwYIY8KOeQFIn7WJ6tZinx6mz0MGdkqmpYC0wmHK', NULL, 1, 1, 1695691643, 1695691643, NULL, NULL, NULL, 0),
(2, 'admin', 'Hch1yqSEXM8MbzZLQqQ0J30xv47Y6QO0', '$2y$13$OaXrxEFYubo0F1g5yRqmJOuxbmzqaFPeh9tPjcZ/aY4wjpBtspgyO', NULL, 1, 1, 1702256795, 1702256795, '::1', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_visit_log`
--

DROP TABLE IF EXISTS `user_visit_log`;
CREATE TABLE IF NOT EXISTS `user_visit_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` varchar(255) CHARACTER SET utf8 NOT NULL,
  `ip` varchar(15) CHARACTER SET utf8 NOT NULL,
  `language` char(2) CHARACTER SET utf8 NOT NULL,
  `user_agent` varchar(255) CHARACTER SET utf8 NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `visit_time` int(11) NOT NULL,
  `browser` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `os` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_visit_log`
--

INSERT INTO `user_visit_log` (`id`, `token`, `ip`, `language`, `user_agent`, `user_id`, `visit_time`, `browser`, `os`) VALUES
(1, '651233ac68058', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695691692, 'Chrome', 'Windows'),
(2, '651236d4e41f3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695692500, 'Chrome', 'Windows'),
(3, '6512462aa9eb3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695696426, 'Chrome', 'Windows'),
(4, '65137e1b21d83', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695776283, 'Chrome', 'Windows'),
(5, '65152884d18a2', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695885444, 'Chrome', 'Windows'),
(6, '65167bc86b56f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695972296, 'Chrome', 'Windows'),
(7, '651fc82504a1f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1696581669, 'Chrome', 'Windows'),
(8, '65294c755aebb', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1697205365, 'Chrome', 'Windows'),
(9, '65295a386d589', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1697208888, 'Chrome', 'Windows'),
(10, '652d5011ee601', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1697468434, 'Chrome', 'Windows'),
(11, '652e4ad038376', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1697532624, 'Chrome', 'Windows'),
(12, '652e4b0664a5e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1697532678, 'Chrome', 'Windows'),
(13, '6535c66babd70', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1698023019, 'Chrome', 'Windows'),
(14, '653f6657106a4', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1698653783, 'Chrome', 'Windows'),
(15, '65449a2cbcaff', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1698994732, 'Chrome', 'Windows'),
(16, '65449a409b40e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1698994752, 'Chrome', 'Windows'),
(17, '654839f01d33e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1699232240, 'Chrome', 'Windows'),
(18, '65498b0e1a435', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1699318542, 'Chrome', 'Windows'),
(19, '654c30af3f6b2', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1699492015, 'Chrome', 'Windows'),
(20, '654d8251ec3db', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1699578449, 'Chrome', 'Windows'),
(21, '6552c5c3166bb', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1699923395, 'Chrome', 'Windows'),
(22, '65556baa09cc4', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1700096938, 'Chrome', 'Windows'),
(23, '6556ba7927cfa', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1700182649, 'Chrome', 'Windows'),
(24, '655ea55da9335', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1700701533, 'Chrome', 'Windows'),
(25, '655ff4cb95ae2', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1700787403, 'Chrome', 'Windows'),
(26, '6563f2c74ad32', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701049031, 'Chrome', 'Windows'),
(27, '65668958eaae0', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701218648, 'Chrome', 'Windows'),
(28, '656696bf09e09', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701222079, 'Chrome', 'Windows'),
(29, '656990dc9d085', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701417180, 'Chrome', 'Windows'),
(30, '656d21257611e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701650725, 'Chrome', 'Windows'),
(31, '656d774245afa', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701672770, 'Chrome', 'Windows'),
(32, '656e743392498', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701737523, 'Chrome', 'Windows'),
(33, '656ed00f1ba53', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701761039, 'Chrome', 'Windows'),
(34, '656fc4e0009c2', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701823712, 'Chrome', 'Windows'),
(35, '657114ef13fe3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701909743, 'Chrome', 'Windows'),
(36, '6573c4d291c4d', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1702085842, 'Chrome', 'Windows'),
(37, '6573cc0e3eb38', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1702087694, 'Chrome', 'Windows'),
(38, '6573cc35bc770', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1702087733, 'Chrome', 'Windows'),
(39, '6576608310f74', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1702256771, 'Chrome', 'Windows'),
(40, '657660c3ae9e3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 2, 1702256835, 'Chrome', 'Windows'),
(41, '65796d9e815a9', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1702456734, 'Chrome', 'Windows'),
(42, '657aa2e74b599', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1702535911, 'Chrome', 'Windows'),
(43, '657d510622e04', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1702711558, 'Chrome', 'Windows'),
(44, '65810b57b2f61', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1702955863, 'Chrome', 'Windows'),
(45, '6582468034135', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1703036544, 'Chrome', 'Windows'),
(46, '6582491abea69', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1703037210, 'Chrome', 'Windows'),
(47, '65839ed9a5f36', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1703124697, 'Chrome', 'Windows'),
(48, '6584e95dbe283', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1703209309, 'Chrome', 'Windows'),
(49, '658535af6d642', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 2, 1703228847, 'Chrome', 'Windows'),
(50, '65869dcc6e44b', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1703321036, 'Chrome', 'Windows'),
(51, '6590d3d4a581c', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 2, 1703990228, 'Chrome', 'Windows'),
(52, '65920c8cabb6f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 2, 1704070284, 'Chrome', 'Windows'),
(53, '65937af25d400', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1704164082, 'Chrome', 'Windows'),
(54, '6597b3f56be13', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1704440821, 'Chrome', 'Windows'),
(55, '6598c2c65b204', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1704510150, 'Chrome', 'Windows'),
(56, '65a9d9fcf3381', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1705630205, 'Chrome', 'Windows'),
(57, '65dffd9ae2235', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 1, 1709178266, 'Chrome', 'Windows'),
(58, '661f1e67032e3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36', 1, 1713315431, 'Chrome', 'Windows'),
(59, '66289d637b30a', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36', 1, 1713937763, 'Chrome', 'Windows'),
(60, '6639dc619ad26', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36', 1, 1715068001, 'Chrome', 'Windows');

-- --------------------------------------------------------

--
-- Table structure for table `website`
--

DROP TABLE IF EXISTS `website`;
CREATE TABLE IF NOT EXISTS `website` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_template` int(11) NOT NULL,
  `user_created` int(11) DEFAULT NULL,
  `datetime_created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_template` (`id_template`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `website`
--

INSERT INTO `website` (`id`, `id_template`, `user_created`, `datetime_created`) VALUES
(13, 6, NULL, '2023-09-11 16:10:55'),
(14, 6, NULL, '2023-09-12 07:46:33'),
(15, 6, NULL, '2023-09-13 08:10:08');

-- --------------------------------------------------------

--
-- Table structure for table `website_blocks`
--

DROP TABLE IF EXISTS `website_blocks`;
CREATE TABLE IF NOT EXISTS `website_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_website` int(11) NOT NULL,
  `id_template_block` int(11) NOT NULL,
  `content` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `id_website` (`id_website`),
  KEY `id_template_block` (`id_template_block`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `website_blocks`
--

INSERT INTO `website_blocks` (`id`, `id_website`, `id_template_block`, `content`) VALUES
(3, 13, 2, '<p>Công ty TNHH An <b>Thịnh </b>nnnn</p><ul><li>fdsfsaf</li><li>gfdsgsdg</li><li>gdsgag</li></ul><p><img src=\"/uploads/images/8f53295a73878494e9bc8dd6c3c7104f.jpg\" style=\"width: 100%;\"><br></p><p>\r\n</p>'),
(4, 14, 2, 'Công ty TNHH An Thịnh'),
(5, 15, 2, 'Công ty TNHH An Thịnh');

-- --------------------------------------------------------

--
-- Table structure for table `website_pages`
--

DROP TABLE IF EXISTS `website_pages`;
CREATE TABLE IF NOT EXISTS `website_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_website` int(11) NOT NULL,
  `id_template_page` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_website` (`id_website`),
  KEY `id_templage_page` (`id_template_page`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `website_pages`
--

INSERT INTO `website_pages` (`id`, `id_website`, `id_template_page`) VALUES
(25, 13, 7),
(26, 13, 8),
(27, 14, 7),
(28, 14, 8),
(29, 15, 7),
(30, 15, 8);

-- --------------------------------------------------------

--
-- Table structure for table `website_varibles`
--

DROP TABLE IF EXISTS `website_varibles`;
CREATE TABLE IF NOT EXISTS `website_varibles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_website` int(11) NOT NULL,
  `id_template_varible` int(11) NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_website` (`id_website`),
  KEY `id_templage_varible` (`id_template_varible`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `website_varibles`
--

INSERT INTO `website_varibles` (`id`, `id_website`, `id_template_varible`, `value`) VALUES
(7, 13, 3, 'Nguyễn Văn Tý An 123'),
(8, 13, 4, '1012'),
(9, 14, 3, 'Nguyễn Văn Tý An'),
(10, 14, 4, '100'),
(11, 15, 3, 'Nguyễn Văn Tý An'),
(12, 15, 4, '100');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_assignment`
--
ALTER TABLE `auth_assignment`
  ADD CONSTRAINT `auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_assignment_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `auth_item`
--
ALTER TABLE `auth_item`
  ADD CONSTRAINT `auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_auth_item_group_code` FOREIGN KEY (`group_code`) REFERENCES `auth_item_group` (`code`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_cay_nhom`
--
ALTER TABLE `cua_cay_nhom`
  ADD CONSTRAINT `cua_cay_nhom_ibfk_1` FOREIGN KEY (`id_he_nhom`) REFERENCES `cua_he_nhom` (`id`);

--
-- Constraints for table `cua_du_an_chi_tiet`
--
ALTER TABLE `cua_du_an_chi_tiet`
  ADD CONSTRAINT `cua_du_an_chi_tiet_ibfk_1` FOREIGN KEY (`id_du_an`) REFERENCES `cua_du_an` (`id`),
  ADD CONSTRAINT `cua_du_an_chi_tiet_ibfk_2` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`);

--
-- Constraints for table `cua_kho_nhom`
--
ALTER TABLE `cua_kho_nhom`
  ADD CONSTRAINT `cua_kho_nhom_ibfk_1` FOREIGN KEY (`id_cay_nhom`) REFERENCES `cua_cay_nhom` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_kho_nhom_lich_su`
--
ALTER TABLE `cua_kho_nhom_lich_su`
  ADD CONSTRAINT `cua_kho_nhom_lich_su_ibfk_1` FOREIGN KEY (`id_kho_nhom`) REFERENCES `cua_kho_nhom` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_kho_vat_tu`
--
ALTER TABLE `cua_kho_vat_tu`
  ADD CONSTRAINT `cua_kho_vat_tu_ibfk_1` FOREIGN KEY (`xuat_xu`) REFERENCES `cua_xuat_xu` (`id`);

--
-- Constraints for table `cua_kho_vat_tu_lich_su`
--
ALTER TABLE `cua_kho_vat_tu_lich_su`
  ADD CONSTRAINT `cua_kho_vat_tu_lich_su_ibfk_1` FOREIGN KEY (`id_kho_vat_tu`) REFERENCES `cua_kho_vat_tu` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_mau_cua`
--
ALTER TABLE `cua_mau_cua`
  ADD CONSTRAINT `cua_mau_cua_ibfk_1` FOREIGN KEY (`id_he_nhom`) REFERENCES `cua_he_nhom` (`id`),
  ADD CONSTRAINT `cua_mau_cua_ibfk_2` FOREIGN KEY (`id_loai_cua`) REFERENCES `cua_loai_cua` (`id`),
  ADD CONSTRAINT `cua_mau_cua_ibfk_3` FOREIGN KEY (`id_du_an`) REFERENCES `cua_du_an` (`id`);

--
-- Constraints for table `cua_mau_cua_nhom`
--
ALTER TABLE `cua_mau_cua_nhom`
  ADD CONSTRAINT `cua_mau_cua_nhom_ibfk_1` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`),
  ADD CONSTRAINT `cua_mau_cua_nhom_ibfk_2` FOREIGN KEY (`id_cay_nhom`) REFERENCES `cua_cay_nhom` (`id`);

--
-- Constraints for table `cua_mau_cua_nhom_su_dung`
--
ALTER TABLE `cua_mau_cua_nhom_su_dung`
  ADD CONSTRAINT `cua_mau_cua_nhom_su_dung_ibfk_1` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`),
  ADD CONSTRAINT `cua_mau_cua_nhom_su_dung_ibfk_2` FOREIGN KEY (`id_kho_nhom`) REFERENCES `cua_kho_nhom` (`id`);

--
-- Constraints for table `cua_mau_cua_nhom_su_dung_chi_tiet`
--
ALTER TABLE `cua_mau_cua_nhom_su_dung_chi_tiet`
  ADD CONSTRAINT `cua_mau_cua_nhom_su_dung_chi_tiet_ibfk_1` FOREIGN KEY (`id_nhom_su_dung`) REFERENCES `cua_mau_cua_nhom_su_dung` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cua_mau_cua_nhom_su_dung_chi_tiet_ibfk_2` FOREIGN KEY (`id_nhom_toi_uu`) REFERENCES `cua_toi_uu` (`id`);

--
-- Constraints for table `cua_mau_cua_vach`
--
ALTER TABLE `cua_mau_cua_vach`
  ADD CONSTRAINT `cua_mau_cua_vach_ibfk_1` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`),
  ADD CONSTRAINT `cua_mau_cua_vach_ibfk_2` FOREIGN KEY (`id_vach`) REFERENCES `cua_he_vach` (`id`);

--
-- Constraints for table `cua_mau_cua_vat_tu`
--
ALTER TABLE `cua_mau_cua_vat_tu`
  ADD CONSTRAINT `cua_mau_cua_vat_tu_ibfk_1` FOREIGN KEY (`id_kho_vat_tu`) REFERENCES `cua_kho_vat_tu` (`id`),
  ADD CONSTRAINT `cua_mau_cua_vat_tu_ibfk_2` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`);

--
-- Constraints for table `cua_toi_uu`
--
ALTER TABLE `cua_toi_uu`
  ADD CONSTRAINT `cua_toi_uu_ibfk_1` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`),
  ADD CONSTRAINT `cua_toi_uu_ibfk_2` FOREIGN KEY (`id_mau_cua_nhom`) REFERENCES `cua_mau_cua_nhom` (`id`),
  ADD CONSTRAINT `cua_toi_uu_ibfk_3` FOREIGN KEY (`id_ton_kho_nhom`) REFERENCES `cua_kho_nhom` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `template_blocks`
--
ALTER TABLE `template_blocks`
  ADD CONSTRAINT `template_blocks_ibfk_1` FOREIGN KEY (`id_template`) REFERENCES `template` (`id`);

--
-- Constraints for table `template_pages`
--
ALTER TABLE `template_pages`
  ADD CONSTRAINT `template_pages_ibfk_1` FOREIGN KEY (`id_template`) REFERENCES `template` (`id`);

--
-- Constraints for table `template_technologies`
--
ALTER TABLE `template_technologies`
  ADD CONSTRAINT `template_technologies_ibfk_1` FOREIGN KEY (`id_technologie`) REFERENCES `technologies` (`id`),
  ADD CONSTRAINT `template_technologies_ibfk_2` FOREIGN KEY (`id_template`) REFERENCES `template` (`id`);

--
-- Constraints for table `template_varibles`
--
ALTER TABLE `template_varibles`
  ADD CONSTRAINT `template_varibles_ibfk_1` FOREIGN KEY (`id_template`) REFERENCES `template` (`id`);

--
-- Constraints for table `user_visit_log`
--
ALTER TABLE `user_visit_log`
  ADD CONSTRAINT `user_visit_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `website`
--
ALTER TABLE `website`
  ADD CONSTRAINT `website_ibfk_1` FOREIGN KEY (`id_template`) REFERENCES `template` (`id`);

--
-- Constraints for table `website_blocks`
--
ALTER TABLE `website_blocks`
  ADD CONSTRAINT `website_blocks_ibfk_1` FOREIGN KEY (`id_template_block`) REFERENCES `template_blocks` (`id`),
  ADD CONSTRAINT `website_blocks_ibfk_2` FOREIGN KEY (`id_website`) REFERENCES `website` (`id`);

--
-- Constraints for table `website_pages`
--
ALTER TABLE `website_pages`
  ADD CONSTRAINT `website_pages_ibfk_1` FOREIGN KEY (`id_template_page`) REFERENCES `template_pages` (`id`),
  ADD CONSTRAINT `website_pages_ibfk_2` FOREIGN KEY (`id_website`) REFERENCES `website` (`id`);

--
-- Constraints for table `website_varibles`
--
ALTER TABLE `website_varibles`
  ADD CONSTRAINT `website_varibles_ibfk_1` FOREIGN KEY (`id_website`) REFERENCES `website` (`id`),
  ADD CONSTRAINT `website_varibles_ibfk_2` FOREIGN KEY (`id_template_varible`) REFERENCES `template_varibles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
