-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 14, 2026 at 03:27 AM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webcuanhom3`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_assignment`
--

DROP TABLE IF EXISTS `auth_assignment`;
CREATE TABLE IF NOT EXISTS `auth_assignment` (
  `item_name` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `user_id` int NOT NULL,
  `created_at` int DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_item`
--

DROP TABLE IF EXISTS `auth_item`;
CREATE TABLE IF NOT EXISTS `auth_item` (
  `name` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `type` int NOT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `rule_name` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `data` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `created_at` int DEFAULT NULL,
  `updated_at` int DEFAULT NULL,
  `group_code` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `idx-auth_item-type` (`type`),
  KEY `fk_auth_item_group_code` (`group_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `auth_item`
--

INSERT INTO `auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`, `group_code`) VALUES
('/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//ajaxcrud', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//controller', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//crud', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//extension', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//form', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//model', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//module', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/asset/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/asset/compress', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/asset/template', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/cache/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/cache/flush', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/cache/flush-all', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/cache/flush-schema', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/cache/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/db-explain', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/download-mail', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/toolbar', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/view', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/user/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/user/reset-identity', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/user/set-identity', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/fixture/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/fixture/load', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/fixture/unload', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/action', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/diff', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/preview', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/view', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/hello/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/hello/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/help/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/help/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/help/list', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/help/list-action-options', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/help/usage', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/message/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/message/config', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/message/config-template', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/message/extract', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/create', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/down', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/fresh', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/history', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/mark', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/new', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/redo', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/to', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/up', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/serve/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/serve/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/auth/change-own-password', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user-permission/set', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user-permission/set-roles', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/bulk-activate', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/bulk-deactivate', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/bulk-delete', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/change-password', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/create', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/delete', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/grid-page-size', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/update', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/view', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('Admin', 1, 'Admin', NULL, NULL, 1695691644, 1695691644, NULL),
('assignRolesToUsers', 2, 'Assign roles to users', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('bindUserToIp', 2, 'Bind user to IP', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('changeOwnPassword', 2, 'Change own password', NULL, NULL, 1695691644, 1695691644, 'userCommonPermissions'),
('changeUserPassword', 2, 'Change user password', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('commonPermission', 2, 'Common permission', NULL, NULL, 1695691643, 1695691643, NULL),
('createUsers', 2, 'Create users', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('deleteUsers', 2, 'Delete users', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('editUserEmail', 2, 'Edit user email', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('editUsers', 2, 'Edit users', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('viewRegistrationIp', 2, 'View registration IP', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('viewUserEmail', 2, 'View user email', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('viewUserRoles', 2, 'View user roles', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('viewUsers', 2, 'View users', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('viewVisitLog', 2, 'View visit log', NULL, NULL, 1695691644, 1695691644, 'userManagement');

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_child`
--

DROP TABLE IF EXISTS `auth_item_child`;
CREATE TABLE IF NOT EXISTS `auth_item_child` (
  `parent` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `child` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `auth_item_child`
--

INSERT INTO `auth_item_child` (`parent`, `child`) VALUES
('changeOwnPassword', '/user-management/auth/change-own-password'),
('assignRolesToUsers', '/user-management/user-permission/set'),
('assignRolesToUsers', '/user-management/user-permission/set-roles'),
('editUsers', '/user-management/user/bulk-activate'),
('editUsers', '/user-management/user/bulk-deactivate'),
('deleteUsers', '/user-management/user/bulk-delete'),
('changeUserPassword', '/user-management/user/change-password'),
('createUsers', '/user-management/user/create'),
('deleteUsers', '/user-management/user/delete'),
('viewUsers', '/user-management/user/grid-page-size'),
('viewUsers', '/user-management/user/index'),
('editUsers', '/user-management/user/update'),
('viewUsers', '/user-management/user/view'),
('Admin', 'assignRolesToUsers'),
('Admin', 'changeOwnPassword'),
('Admin', 'changeUserPassword'),
('Admin', 'createUsers'),
('Admin', 'deleteUsers'),
('Admin', 'editUsers'),
('editUserEmail', 'viewUserEmail'),
('assignRolesToUsers', 'viewUserRoles'),
('Admin', 'viewUsers'),
('assignRolesToUsers', 'viewUsers'),
('changeUserPassword', 'viewUsers'),
('createUsers', 'viewUsers'),
('deleteUsers', 'viewUsers'),
('editUsers', 'viewUsers');

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_group`
--

DROP TABLE IF EXISTS `auth_item_group`;
CREATE TABLE IF NOT EXISTS `auth_item_group` (
  `code` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `created_at` int DEFAULT NULL,
  `updated_at` int DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `auth_item_group`
--

INSERT INTO `auth_item_group` (`code`, `name`, `created_at`, `updated_at`) VALUES
('userCommonPermissions', 'User common permission', 1695691644, 1695691644),
('userManagement', 'User management', 1695691644, 1695691644);

-- --------------------------------------------------------

--
-- Table structure for table `auth_rule`
--

DROP TABLE IF EXISTS `auth_rule`;
CREATE TABLE IF NOT EXISTS `auth_rule` (
  `name` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `data` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `created_at` int DEFAULT NULL,
  `updated_at` int DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `banle_hoa_don`
--

DROP TABLE IF EXISTS `banle_hoa_don`;
CREATE TABLE IF NOT EXISTS `banle_hoa_don` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ma_hoa_don` int DEFAULT NULL,
  `so_vao_so` int DEFAULT NULL,
  `nam` int DEFAULT NULL,
  `ghi_chu` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `id_nguoi_ban` int DEFAULT NULL,
  `ngay_ban` date DEFAULT NULL,
  `id_nguoi_lap` int DEFAULT NULL,
  `ngay_lap` date DEFAULT NULL,
  `trang_thai` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `edit_mode` tinyint(1) DEFAULT NULL,
  `id_khach_hang` int DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_khach_hang` (`id_khach_hang`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `banle_hoa_don`
--

INSERT INTO `banle_hoa_don` (`id`, `ma_hoa_don`, `so_vao_so`, `nam`, `ghi_chu`, `id_nguoi_ban`, `ngay_ban`, `id_nguoi_lap`, `ngay_lap`, `trang_thai`, `edit_mode`, `id_khach_hang`, `date_created`, `user_created`) VALUES
(1, NULL, 1, 2025, NULL, NULL, NULL, NULL, NULL, 'DA_THANH_TOAN', 0, 3, '2025-07-28 20:33:55', 6),
(2, NULL, NULL, 2025, NULL, NULL, NULL, NULL, NULL, 'BAN_NHAP', 0, NULL, '2025-07-29 09:30:21', 6),
(3, NULL, NULL, 2025, NULL, NULL, NULL, NULL, NULL, 'BAN_NHAP', 1, 5, '2025-07-29 09:40:33', 6),
(4, NULL, NULL, 2025, NULL, NULL, NULL, NULL, NULL, 'BAN_NHAP', 0, NULL, '2025-08-01 16:09:12', 1),
(5, NULL, NULL, 2025, NULL, NULL, NULL, NULL, NULL, 'BAN_NHAP', 0, NULL, '2025-08-11 13:39:52', 1),
(6, NULL, NULL, 2025, NULL, NULL, NULL, NULL, NULL, 'BAN_NHAP', 0, NULL, '2025-09-06 16:46:27', 6),
(7, NULL, NULL, 2025, NULL, NULL, NULL, NULL, NULL, 'BAN_NHAP', 0, NULL, '2025-10-03 22:07:51', 6),
(8, NULL, NULL, 2025, NULL, NULL, NULL, NULL, NULL, 'BAN_NHAP', 0, NULL, '2025-10-03 22:07:57', 6),
(9, NULL, 2, 2025, NULL, NULL, NULL, NULL, NULL, 'DA_THANH_TOAN', 0, NULL, '2025-10-03 22:09:13', 6),
(10, NULL, NULL, 2025, NULL, NULL, NULL, NULL, NULL, 'BAN_NHAP', 0, NULL, '2025-10-03 22:14:54', 6),
(11, NULL, NULL, 2025, NULL, NULL, NULL, NULL, NULL, 'BAN_NHAP', 0, NULL, '2025-10-05 21:06:40', 6),
(12, NULL, NULL, 2025, NULL, NULL, NULL, NULL, NULL, 'BAN_NHAP', 0, NULL, '2025-10-05 21:08:05', 6),
(13, NULL, 3, 2025, NULL, NULL, NULL, NULL, NULL, 'DA_THANH_TOAN', 1, 8, '2025-10-05 21:08:09', 6),
(14, NULL, 4, 2025, NULL, NULL, NULL, NULL, NULL, 'DA_THANH_TOAN', 1, 7, '2025-10-05 21:12:26', 6),
(15, NULL, NULL, 2025, NULL, NULL, NULL, NULL, NULL, 'BAN_NHAP', 0, NULL, '2025-10-06 15:52:59', 6),
(16, NULL, NULL, 2025, NULL, NULL, NULL, NULL, NULL, 'BAN_NHAP', 0, NULL, '2025-10-09 09:51:54', 6),
(17, NULL, 5, 2025, NULL, NULL, NULL, NULL, NULL, 'DA_THANH_TOAN', 1, 9, '2025-10-09 09:53:05', 6),
(18, NULL, NULL, 2025, NULL, NULL, NULL, NULL, NULL, 'BAN_NHAP', 0, NULL, '2025-10-15 23:07:33', 6),
(19, NULL, 6, 2025, NULL, NULL, NULL, NULL, NULL, 'DA_THANH_TOAN', 0, 3, '2025-10-23 21:05:16', 6),
(20, NULL, 7, 2025, NULL, NULL, NULL, NULL, NULL, 'DA_THANH_TOAN', 0, 3, '2025-10-23 21:10:52', 6),
(21, NULL, 8, 2025, NULL, NULL, NULL, NULL, NULL, 'DA_THANH_TOAN', 0, 3, '2025-10-29 14:02:29', 6),
(22, NULL, NULL, 2025, NULL, NULL, NULL, NULL, NULL, 'BAN_NHAP', 0, NULL, '2025-11-13 09:33:04', 6),
(23, NULL, 9, 2025, NULL, NULL, NULL, NULL, NULL, 'DA_THANH_TOAN', 0, 10, '2025-11-13 09:34:02', 6),
(24, NULL, 10, 2025, NULL, NULL, NULL, NULL, NULL, 'DA_THANH_TOAN', 0, 11, '2025-11-13 09:39:36', 6),
(25, NULL, 11, 2025, NULL, NULL, NULL, NULL, NULL, 'DA_THANH_TOAN', 0, 12, '2025-11-13 09:47:34', 6),
(26, NULL, 12, 2025, NULL, NULL, NULL, NULL, NULL, 'DA_THANH_TOAN', 0, 13, '2025-11-13 09:52:08', 6),
(27, NULL, 13, 2025, NULL, NULL, NULL, NULL, NULL, 'DA_THANH_TOAN', 0, 14, '2025-11-13 10:01:20', 6),
(28, NULL, 14, 2025, NULL, NULL, NULL, NULL, NULL, 'DA_THANH_TOAN', 0, 15, '2025-11-16 21:13:38', 6),
(29, NULL, NULL, 2025, NULL, NULL, NULL, NULL, NULL, 'BAN_NHAP', 0, 16, '2025-11-16 21:18:46', 6),
(30, NULL, 15, 2025, NULL, NULL, NULL, NULL, NULL, 'DA_THANH_TOAN', 0, 7, '2025-11-16 21:23:05', 6),
(31, NULL, NULL, 2025, NULL, NULL, NULL, NULL, NULL, 'BAN_NHAP', 0, 3, '2025-11-23 12:02:53', 6),
(32, NULL, NULL, 2025, NULL, NULL, NULL, NULL, NULL, 'BAN_NHAP', 0, 17, '2025-11-23 13:55:08', 6),
(33, NULL, NULL, 2025, NULL, NULL, NULL, NULL, NULL, 'BAN_NHAP', 0, 18, '2025-11-23 14:47:47', 6);

-- --------------------------------------------------------

--
-- Table structure for table `banle_hoa_don_chi_tiet`
--

DROP TABLE IF EXISTS `banle_hoa_don_chi_tiet`;
CREATE TABLE IF NOT EXISTS `banle_hoa_don_chi_tiet` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_hoa_don` int NOT NULL,
  `id_vat_tu` int DEFAULT NULL,
  `loai_vat_tu` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `don_gia` int DEFAULT NULL,
  `so_luong` double DEFAULT NULL,
  `ghi_chu` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_hoa_don` (`id_hoa_don`)
) ENGINE=InnoDB AUTO_INCREMENT=189 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `banle_hoa_don_chi_tiet`
--

INSERT INTO `banle_hoa_don_chi_tiet` (`id`, `id_hoa_don`, `id_vat_tu`, `loai_vat_tu`, `don_gia`, `so_luong`, `ghi_chu`, `date_created`, `user_created`) VALUES
(1, 1, 14, 'Phụ kiện', 21500, 40, '', '2025-07-29 09:16:29', 6),
(3, 1, 6, 'Phụ kiện', 2500, 40, '', '2025-07-29 09:26:18', 6),
(4, 1, 32, 'Phụ kiện', 55000, 20, '', '2025-07-29 09:28:02', 6),
(5, 3, 19, 'Phụ kiện', 105000, 8, '', '2025-07-29 09:43:21', 6),
(6, 3, 20, 'Phụ kiện', 108000, 8, '', '2025-07-29 09:44:28', 6),
(7, 3, 25, 'Phụ kiện', 105000, 1, '', '2025-07-29 09:44:48', 6),
(8, 3, 17, 'Phụ kiện', 140000, 1, '', '2025-07-29 09:45:36', 6),
(9, 3, 2, 'Phụ kiện', 102000, 1, '', '2025-07-29 09:47:32', 6),
(10, 3, 7, 'Phụ kiện', 6000, 2, '', '2025-07-29 09:56:17', 6),
(11, 3, 4, 'Phụ kiện', 11600, 6, '', '2025-07-29 10:07:50', 6),
(12, 3, 11, 'Phụ kiện', 37000, 6, '', '2025-07-29 10:08:10', 6),
(13, 3, 8, 'Phụ kiện', 10000, 3, '', '2025-07-29 10:08:24', 6),
(14, 3, 9, 'Phụ kiện', 0, 3, '', '2025-07-29 10:08:43', 6),
(15, 9, 32, 'Phụ kiện', 0, 2, '', '2025-10-03 22:10:17', 6),
(16, 9, 35, 'Phụ kiện', 0, 4, '', '2025-10-03 22:10:39', 6),
(17, 9, 34, 'Phụ kiện', 0, 2, '', '2025-10-03 22:11:36', 6),
(18, 9, 11, 'Phụ kiện', 0, 2, '', '2025-10-03 22:12:23', 6),
(19, 9, 19, 'Phụ kiện', 0, 4, '', '2025-10-03 22:13:08', 6),
(29, 13, 63, 'Phụ kiện', 0, 18, '', '2025-10-05 21:28:53', 6),
(30, 13, 11, 'Phụ kiện', 0, 2, '', '2025-10-05 21:29:28', 6),
(31, 13, 68, 'Phụ kiện', 0, 2, '', '2025-10-05 21:29:46', 6),
(32, 13, 47, 'Phụ kiện', 0, 2, '', '2025-10-05 21:30:08', 6),
(33, 13, 67, 'Phụ kiện', 0, 4, '', '2025-10-05 21:30:34', 6),
(34, 13, 22, 'Phụ kiện', 0, 2, '', '2025-10-05 21:30:45', 6),
(35, 13, 36, 'Phụ kiện', 0, 9, '', '2025-10-05 21:31:20', 6),
(36, 13, 59, 'Phụ kiện', 0, 3, '', '2025-10-05 21:31:51', 6),
(37, 13, 53, 'Phụ kiện', 0, 3, '', '2025-10-05 21:33:19', 6),
(38, 13, 66, 'Phụ kiện', 0, 3, '', '2025-10-05 21:34:12', 6),
(39, 13, 64, 'Phụ kiện', 0, 8, '', '2025-10-05 21:34:53', 6),
(40, 13, 49, 'Phụ kiện', 0, 4, '', '2025-10-05 21:36:26', 6),
(41, 14, 36, 'Phụ kiện', 0, 16, '', '2025-10-05 21:50:51', 6),
(42, 14, 60, 'Phụ kiện', 0, 2, '', '2025-10-05 21:51:53', 6),
(43, 14, 65, 'Phụ kiện', 0, 2, '', '2025-10-05 21:52:20', 6),
(44, 14, 57, 'Phụ kiện', 0, 2, '', '2025-10-05 21:52:42', 6),
(45, 14, 47, 'Phụ kiện', 0, 2, '', '2025-10-05 21:53:25', 6),
(46, 14, 67, 'Phụ kiện', 0, 4, '', '2025-10-05 21:54:07', 6),
(48, 14, 23, 'Phụ kiện', 0, 2, '', '2025-10-05 21:54:50', 6),
(49, 14, 45, 'Phụ kiện', 0, 1, '', '2025-10-05 21:55:46', 6),
(50, 14, 46, 'Phụ kiện', 0, 2, '', '2025-10-05 21:56:20', 6),
(51, 13, 72, 'Phụ kiện', 0, 3, '', '2025-10-06 21:39:35', 6),
(52, 17, 1, 'Phụ kiện', 0, 9, '', '2025-10-09 09:53:22', 6),
(53, 17, 16, 'Phụ kiện', 0, 3, '', '2025-10-09 09:53:41', 6),
(54, 17, 8, 'Phụ kiện', 0, 3, '', '2025-10-09 09:53:52', 6),
(55, 17, 28, 'Phụ kiện', 0, 3, '', '2025-10-09 09:54:02', 6),
(56, 17, 6, 'Phụ kiện', 0, 3, '', '2025-10-09 09:54:13', 6),
(57, 17, 32, 'Phụ kiện', 0, 5, '', '2025-10-09 09:54:56', 6),
(58, 17, 35, 'Phụ kiện', 0, 10, '', '2025-10-09 09:55:19', 6),
(59, 17, 12, 'Phụ kiện', 0, 6, '', '2025-10-09 09:56:15', 6),
(60, 17, 11, 'Phụ kiện', 0, 1, '', '2025-10-09 10:00:28', 6),
(61, 17, 21, 'Phụ kiện', 0, 12, '', '2025-10-09 10:02:37', 6),
(62, 17, 27, 'Phụ kiện', 0, 2, '', '2025-10-09 10:03:30', 6),
(63, 17, 26, 'Phụ kiện', 0, 2, '', '2025-10-09 10:03:41', 6),
(64, 17, 24, 'Phụ kiện', 0, 2, '', '2025-10-09 10:03:59', 6),
(65, 17, 25, 'Phụ kiện', 0, 2, '', '2025-10-09 10:04:20', 6),
(66, 17, 22, 'Phụ kiện', 0, 1, '', '2025-10-09 10:04:38', 6),
(67, 17, 23, 'Phụ kiện', 0, 1, '', '2025-10-09 10:04:50', 6),
(68, 19, 1, 'Phụ kiện', 0, 120, '', '2025-10-23 21:06:15', 6),
(69, 19, 28, 'Phụ kiện', 0, 30, '', '2025-10-23 21:06:36', 6),
(70, 19, 30, 'Phụ kiện', 0, 10, '', '2025-10-23 21:07:08', 6),
(71, 19, 34, 'Phụ kiện', 0, 10, '', '2025-10-23 21:07:38', 6),
(72, 19, 16, 'Phụ kiện', 0, 10, '', '2025-10-23 21:07:53', 6),
(73, 19, 17, 'Phụ kiện', 0, 10, '', '2025-10-23 21:08:07', 6),
(74, 19, 8, 'Phụ kiện', 0, 20, '', '2025-10-23 21:08:36', 6),
(75, 19, 24, 'Phụ kiện', 0, 30, '', '2025-10-23 21:08:58', 6),
(76, 19, 25, 'Phụ kiện', 0, 30, '', '2025-10-23 21:09:14', 6),
(77, 20, 6, 'Phụ kiện', 0, 15, '', '2025-10-23 21:11:35', 6),
(78, 21, 3, 'Phụ kiện', 0, 150, '', '2025-10-29 14:04:07', 6),
(79, 21, 9, 'Phụ kiện', 0, 5, '', '2025-10-29 14:04:31', 6),
(80, 21, 8, 'Phụ kiện', 0, 30, '', '2025-10-29 14:04:56', 6),
(81, 21, 7, 'Phụ kiện', 0, 15, '', '2025-10-29 14:05:18', 6),
(82, 21, 25, 'Phụ kiện', 0, 30, '', '2025-10-29 14:05:40', 6),
(83, 21, 24, 'Phụ kiện', 0, 30, '', '2025-10-29 14:06:01', 6),
(84, 21, 28, 'Phụ kiện', 0, 30, '', '2025-10-29 14:06:25', 6),
(85, 21, 29, 'Phụ kiện', 0, 10, '', '2025-10-29 14:06:48', 6),
(86, 21, 16, 'Phụ kiện', 0, 20, '', '2025-10-29 14:07:16', 6),
(87, 21, 17, 'Phụ kiện', 0, 10, '', '2025-10-29 14:07:36', 6),
(88, 21, 31, 'Phụ kiện', 0, 30, '', '2025-10-29 14:08:01', 6),
(89, 21, 34, 'Phụ kiện', 0, 30, '', '2025-10-29 14:08:23', 6),
(90, 23, 3, 'Phụ kiện', 0, 9, '', '2025-11-13 09:34:34', 6),
(91, 23, 6, 'Phụ kiện', 0, 3, '', '2025-11-13 09:34:45', 6),
(92, 23, 8, 'Phụ kiện', 0, 3, '', '2025-11-13 09:34:57', 6),
(93, 23, 16, 'Phụ kiện', 0, 3, '', '2025-11-13 09:35:13', 6),
(94, 23, 28, 'Phụ kiện', 0, 3, '', '2025-11-13 09:35:28', 6),
(95, 24, 1, 'Phụ kiện', 0, 11, '', '2025-11-13 09:41:24', 6),
(96, 24, 4, 'Phụ kiện', 0, 8, '', '2025-11-13 09:41:34', 6),
(97, 24, 6, 'Phụ kiện', 0, 2, '', '2025-11-13 09:41:46', 6),
(98, 24, 9, 'Phụ kiện', 0, 1, '', '2025-11-13 09:41:59', 6),
(99, 24, 18, 'Phụ kiện', 0, 1, '', '2025-11-13 09:42:07', 6),
(100, 24, 29, 'Phụ kiện', 0, 1, '', '2025-11-13 09:42:15', 6),
(101, 24, 27, 'Phụ kiện', 0, 2, '', '2025-11-13 09:42:27', 6),
(102, 24, 26, 'Phụ kiện', 0, 2, '', '2025-11-13 09:42:34', 6),
(103, 24, 24, 'Phụ kiện', 0, 6, '', '2025-11-13 09:43:09', 6),
(104, 24, 25, 'Phụ kiện', 0, 6, '', '2025-11-13 09:43:41', 6),
(105, 24, 22, 'Phụ kiện', 0, 3, '', '2025-11-13 09:43:53', 6),
(106, 24, 23, 'Phụ kiện', 0, 3, '', '2025-11-13 09:44:00', 6),
(107, 24, 16, 'Phụ kiện', 0, 1, '', '2025-11-13 09:45:28', 6),
(108, 24, 28, 'Phụ kiện', 0, 1, '', '2025-11-13 09:45:34', 6),
(109, 24, 8, 'Phụ kiện', 0, 1, '', '2025-11-13 09:45:51', 6),
(110, 25, 5, 'Phụ kiện', 0, 1, '', '2025-11-13 09:48:43', 6),
(111, 25, 9, 'Phụ kiện', 0, 1, '', '2025-11-13 09:48:51', 6),
(112, 25, 18, 'Phụ kiện', 0, 1, '', '2025-11-13 09:49:00', 6),
(113, 25, 29, 'Phụ kiện', 0, 1, '', '2025-11-13 09:49:08', 6),
(114, 25, 27, 'Phụ kiện', 0, 2, '', '2025-11-13 09:49:22', 6),
(115, 25, 26, 'Phụ kiện', 0, 2, '', '2025-11-13 09:49:34', 6),
(116, 25, 24, 'Phụ kiện', 0, 6, '', '2025-11-13 09:49:44', 6),
(117, 25, 25, 'Phụ kiện', 0, 6, '', '2025-11-13 09:49:53', 6),
(118, 25, 22, 'Phụ kiện', 0, 3, '', '2025-11-13 09:50:05', 6),
(119, 25, 23, 'Phụ kiện', 0, 3, '', '2025-11-13 09:50:14', 6),
(120, 25, 35, 'Phụ kiện', 0, 4, '', '2025-11-13 09:50:46', 6),
(121, 25, 32, 'Phụ kiện', 0, 1, '', '2025-11-13 09:50:57', 6),
(122, 25, 34, 'Phụ kiện', 0, 1, '', '2025-11-13 09:51:28', 6),
(123, 26, 4, 'Phụ kiện', 0, 9, '', '2025-11-13 09:53:38', 6),
(124, 26, 5, 'Phụ kiện', 0, 3, '', '2025-11-13 09:58:17', 6),
(125, 26, 8, 'Phụ kiện', 0, 3, '', '2025-11-13 09:58:27', 6),
(126, 26, 16, 'Phụ kiện', 0, 1, '', '2025-11-13 09:58:53', 6),
(127, 26, 17, 'Phụ kiện', 0, 2, '', '2025-11-13 09:59:04', 6),
(128, 26, 28, 'Phụ kiện', 0, 3, '', '2025-11-13 09:59:20', 6),
(129, 27, 3, 'Phụ kiện', 0, 9, '', '2025-11-13 10:04:25', 6),
(130, 27, 6, 'Phụ kiện', 0, 2, '', '2025-11-13 10:04:36', 6),
(131, 27, 9, 'Phụ kiện', 0, 1, '', '2025-11-13 10:04:46', 6),
(132, 27, 8, 'Phụ kiện', 0, 1, '', '2025-11-13 10:04:53', 6),
(133, 27, 18, 'Phụ kiện', 0, 1, '', '2025-11-13 10:05:05', 6),
(134, 27, 16, 'Phụ kiện', 0, 1, '', '2025-11-13 10:05:26', 6),
(135, 27, 28, 'Phụ kiện', 0, 1, '', '2025-11-13 10:05:36', 6),
(136, 27, 29, 'Phụ kiện', 0, 1, '', '2025-11-13 10:05:43', 6),
(137, 27, 27, 'Phụ kiện', 0, 2, '', '2025-11-13 10:06:27', 6),
(138, 27, 26, 'Phụ kiện', 0, 2, '', '2025-11-13 10:06:37', 6),
(139, 27, 24, 'Phụ kiện', 0, 2, '', '2025-11-13 10:06:52', 6),
(140, 27, 25, 'Phụ kiện', 0, 2, '', '2025-11-13 10:07:02', 6),
(141, 27, 22, 'Phụ kiện', 0, 1, '', '2025-11-13 10:07:16', 6),
(142, 27, 23, 'Phụ kiện', 0, 1, '', '2025-11-13 10:07:24', 6),
(143, 27, 35, 'Phụ kiện', 0, 8, '', '2025-11-13 10:07:57', 6),
(144, 27, 31, 'Phụ kiện', 0, 2, '', '2025-11-13 10:08:10', 6),
(145, 27, 34, 'Phụ kiện', 0, 2, '', '2025-11-13 10:08:29', 6),
(146, 28, 30, 'Phụ kiện', 0, 4, '', '2025-11-16 21:14:51', 6),
(147, 28, 34, 'Phụ kiện', 0, 4, '', '2025-11-16 21:15:03', 6),
(148, 28, 35, 'Phụ kiện', 0, 16, '', '2025-11-16 21:16:20', 6),
(149, 28, 2, 'Phụ kiện', 0, 6, '', '2025-11-16 21:17:01', 6),
(150, 28, 5, 'Phụ kiện', 0, 2, '', '2025-11-16 21:17:09', 6),
(151, 28, 8, 'Phụ kiện', 0, 2, '', '2025-11-16 21:17:22', 6),
(152, 28, 28, 'Phụ kiện', 0, 2, '', '2025-11-16 21:17:32', 6),
(153, 28, 16, 'Phụ kiện', 0, 2, '', '2025-11-16 21:17:45', 6),
(154, 29, 1, 'Phụ kiện', 0, 9, '', '2025-11-16 21:20:16', 6),
(155, 29, 6, 'Phụ kiện', 0, 2, '', '2025-11-16 21:20:25', 6),
(156, 29, 9, 'Phụ kiện', 0, 1, '', '2025-11-16 21:20:45', 6),
(157, 29, 59, 'Phụ kiện', 0, 1, '', '2025-11-16 21:20:50', 6),
(158, 29, 28, 'Phụ kiện', 0, 1, '', '2025-11-16 21:20:59', 6),
(159, 29, 29, 'Phụ kiện', 0, 1, '', '2025-11-16 21:21:05', 6),
(160, 29, 18, 'Phụ kiện', 0, 1, '', '2025-11-16 21:21:14', 6),
(161, 29, 16, 'Phụ kiện', 0, 1, '', '2025-11-16 21:21:26', 6),
(162, 29, 24, 'Phụ kiện', 0, 2, '', '2025-11-16 21:21:44', 6),
(163, 29, 25, 'Phụ kiện', 0, 2, '', '2025-11-16 21:21:55', 6),
(164, 29, 27, 'Phụ kiện', 0, 2, '', '2025-11-16 21:22:05', 6),
(165, 29, 26, 'Phụ kiện', 0, 2, '', '2025-11-16 21:22:12', 6),
(166, 29, 22, 'Phụ kiện', 0, 1, '', '2025-11-16 21:22:20', 6),
(167, 29, 23, 'Phụ kiện', 0, 1, '', '2025-11-16 21:22:27', 6),
(168, 30, 36, 'Phụ kiện', 0, 3, '', '2025-11-16 21:23:29', 6),
(170, 30, 72, 'Phụ kiện', 111, 1, '', '2025-11-16 21:25:46', 6),
(171, 30, 1, 'Phụ kiện', 0, 3, '', '2025-11-16 21:29:25', 6),
(172, 30, 53, 'Phụ kiện', 0, 1, '', '2025-11-16 21:30:27', 6),
(173, 30, 8, 'Phụ kiện', 0, 1, '', '2025-11-16 21:31:10', 6),
(175, 30, 6, 'Phụ kiện', 0, 1, '', '2025-11-16 21:31:42', 6),
(176, 30, 28, 'Phụ kiện', 0, 1, '', '2025-11-16 21:31:58', 6),
(177, 30, 16, 'Phụ kiện', 0, 1, '', '2025-11-16 21:32:22', 6),
(178, 31, 3, 'Phụ kiện', 0, 150, '', '2025-11-23 12:03:58', 6),
(179, 31, 8, 'Phụ kiện', 0, 30, '', '2025-11-23 12:04:15', 6),
(180, 31, 7, 'Phụ kiện', 0, 30, '', '2025-11-23 12:04:33', 6),
(181, 31, 28, 'Phụ kiện', 0, 30, '', '2025-11-23 12:04:47', 6),
(182, 31, 16, 'Phụ kiện', 0, 29, '', '2025-11-23 12:05:01', 6),
(183, 31, 17, 'Phụ kiện', 0, 10, '', '2025-11-23 12:05:14', 6),
(184, 31, 21, 'Phụ kiện', 0, 30, '', '2025-11-23 12:05:57', 6),
(185, 31, 19, 'Phụ kiện', 0, 30, '', '2025-11-23 12:06:18', 6),
(186, 32, 69, 'Phụ kiện', 0, 8, '', '2025-11-23 13:56:29', 6),
(187, 32, 2, 'Phụ kiện', 0, 16, '', '2025-11-23 13:56:45', 6),
(188, 32, 25, 'Phụ kiện', 0, 8, '', '2025-11-23 13:57:00', 6);

-- --------------------------------------------------------

--
-- Table structure for table `banle_khach_hang`
--

DROP TABLE IF EXISTS `banle_khach_hang`;
CREATE TABLE IF NOT EXISTS `banle_khach_hang` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_loai_khach_hang` int NOT NULL,
  `ten_khach_hang` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `dia_chi` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `so_dien_thoai` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `email` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `ghi_chu` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_loai_khach_hang` (`id_loai_khach_hang`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `banle_khach_hang`
--

INSERT INTO `banle_khach_hang` (`id`, `id_loai_khach_hang`, `ten_khach_hang`, `dia_chi`, `so_dien_thoai`, `email`, `ghi_chu`, `date_created`, `user_created`) VALUES
(1, 2, 'Chú Út Cao', 'Cầu Quan', '', '', '', '2024-09-09 16:14:49', 2),
(2, 2, 'a. Nam', 'D5', '', '', '', '2024-09-12 09:19:20', 2),
(3, 1, 'CTY HƯNG KỶ', 'ABC', '', '', '', '2025-07-28 20:35:54', 6),
(4, 2, 'ANH CẢNH CẦU KÈ', 'chợ ninh thới cầu kè ', '0358282527', '', '', '2025-07-29 09:38:36', 6),
(5, 2, 'CHÚ HỮU PHƯỚC TẬP SƠN', 'TẬP SƠN TRÀ CÚ', '0973717668', '', '', '2025-07-29 09:42:10', 6),
(6, 2, 'CHÚ PHÚ DUYÊN HẢI', 'TX DUYÊN HẢI\r\n', '0919608444', '', '', '2025-10-03 22:09:08', 6),
(7, 2, 'CHỊ MỘNG CÀNG LONG', 'ĐỐI DIỆN CA XÃ CÀNG LONG', '0362591486', '', '', '2025-10-05 21:09:34', 6),
(8, 2, 'ANH ĐỈNH TIỂU CẦN', 'PHÚ CẦN TIỂU CẦN ĐƯỜNG 6T', '0855817979', '', '', '2025-10-05 21:13:54', 6),
(9, 2, 'ANH NHÂN HÒA MINH', 'HÒA MINH ', '0378800097', '', '', '2025-10-09 09:52:56', 6),
(10, 1, 'grara sửa xe Đồng Khởi', 'đồng khởi', '', '', '', '2025-11-13 09:33:55', 6),
(11, 2, 'ANH GIANG P7', 'ĐƯỜNG VÀNH ĐAI', '0976814162', '', '', '2025-11-13 09:41:06', 6),
(12, 2, 'THẦU SƠN ĐỒNG DIỀU', 'ĐỒNG DIỀU KCN', '0363362723', '', '', '2025-11-13 09:48:16', 6),
(13, 2, 'CHỊ BÍCH NGOAN', 'KHÁCH SẠN BÍCH NGOAN ĐƯỜNG 19/5', '0989047799', '', '', '2025-11-13 09:53:00', 6),
(14, 1, 'TRƯỜNG LÁI', 'GIỒNG LỨC', '', '', '', '2025-11-13 10:03:44', 6),
(15, 2, 'ANH CƯỜNG CHÂU THÀNH', 'TIỆM A CƯỜNG CHÂU THÀNH', '0915126944', '', '', '2025-11-16 21:14:15', 6),
(16, 2, 'CHỊ LY TIỂU CẦN', 'HIẾU TRUNG TIỂU CẦN', '0352633034', '', '', '2025-11-16 21:19:45', 6),
(17, 2, 'ANH TIẾN TRÀ CÚ', 'TRÀ CÚ\r\n', '', '', '', '2025-11-23 13:55:24', 6),
(18, 2, 'ANH TRUNG MỸ LONG', 'MỸ LONG-CẦU NGANG', '039666050', '', '', '2025-11-23 14:48:59', 6),
(19, 2, 'anh An', 'trà vinh', '', '', '', '2026-03-13 08:19:06', 2),
(20, 2, 'CHÚ ĐẦY', 'TRÀ VINH', '', '', '', '2026-03-14 09:57:33', 2);

-- --------------------------------------------------------

--
-- Table structure for table `banle_loai_khach_hang`
--

DROP TABLE IF EXISTS `banle_loai_khach_hang`;
CREATE TABLE IF NOT EXISTS `banle_loai_khach_hang` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ten_loai_khach_hang` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `ghi_chu` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `banle_loai_khach_hang`
--

INSERT INTO `banle_loai_khach_hang` (`id`, `ten_loai_khach_hang`, `ghi_chu`, `date_created`, `user_created`) VALUES
(1, 'Doanh nghiệp', NULL, NULL, NULL),
(2, 'Cá nhân', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cua_cay_nhom`
--

DROP TABLE IF EXISTS `cua_cay_nhom`;
CREATE TABLE IF NOT EXISTS `cua_cay_nhom` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_he_nhom` int NOT NULL,
  `code` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `id_he_mau` int DEFAULT NULL,
  `ten_cay_nhom` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `so_luong` int DEFAULT NULL,
  `don_gia` double DEFAULT NULL,
  `khoi_luong` float DEFAULT NULL,
  `chieu_dai` float DEFAULT NULL,
  `do_day` float DEFAULT NULL,
  `for_cua_so` tinyint(1) DEFAULT NULL,
  `for_cua_di` tinyint(1) DEFAULT NULL,
  `min_allow_cut` float DEFAULT NULL,
  `min_allow_cut_under` float DEFAULT NULL,
  `dung_cho_nhieu_he_nhom` tinyint(1) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_he_nhom` (`id_he_nhom`),
  KEY `id_mau` (`id_he_mau`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `cua_cay_nhom`
--

INSERT INTO `cua_cay_nhom` (`id`, `id_he_nhom`, `code`, `id_he_mau`, `ten_cay_nhom`, `so_luong`, `don_gia`, `khoi_luong`, `chieu_dai`, `do_day`, `for_cua_so`, `for_cua_di`, `min_allow_cut`, `min_allow_cut_under`, `dung_cho_nhieu_he_nhom`, `date_created`, `user_created`) VALUES
(1, 1, 'P55D0120', 1, 'khung bao cửa đi', 41, 0, 0, 5800, 2, 0, 1, 0, 0, 0, '2025-08-29 13:25:35', 6),
(2, 1, 'P55D0220', 1, 'cánh cửa đi mở ngoài', 17, 0, 0, 5800, 2, 0, 1, 0, 0, 0, '2025-08-29 13:27:20', 6),
(3, 1, 'P55D2120', 1, 'cánh cửa đi mở trong', 23, 0, 0, 5800, 2, 0, 1, 0, 0, 0, '2025-08-29 13:28:07', 6),
(4, 1, 'P55D0320', 1, 'ngang dưới cửa đi ', 10, 0, 0, 5800, 2, 0, 1, 0, 0, 0, '2025-08-29 13:28:58', 6),
(5, 1, 'P55D3329', 1, 'che chân', 20, 0, 0, 5800, 1.5, 0, 1, 0, 0, 0, '2025-08-29 13:29:35', 6),
(6, 1, 'P55D3318', 1, 'khung bao cửa sổ', 41, 0, 0, 5800, 1.5, 1, 0, 0, 0, 0, '2025-08-29 13:30:22', 6),
(7, 1, 'P55D8092', 1, 'cánh cửa sổ ', 10, 0, 0, 5800, 1.4, 1, 0, 0, 0, 0, '2025-08-29 13:31:25', 6),
(8, 1, 'P55D3313', 1, 'T chia cửa ', 21, 0, 0, 5800, 1.4, 0, 0, 0, 0, 1, '2025-08-29 14:08:06', 6),
(9, 1, 'P55D3203', 1, 'T chia vách', 19, 0, 0, 5800, 2, 0, 0, 0, 0, 1, '2025-08-29 14:08:46', 6),
(10, 1, 'p55d0316', 1, 'đố chia', 1, 0, 0, 5800, 2, 0, 0, 0, 0, 1, '2025-08-29 14:09:25', 6),
(11, 1, 'P55D22903', 1, 'đố động', 21, 0, 0, 5800, 1.4, 0, 0, 0, 0, 1, '2025-08-29 14:10:16', 6),
(12, 1, 'P55D3300', 1, 'I nối', 1, 0, 0, 5800, 2, 0, 0, 0, 0, 1, '2025-08-29 14:11:02', 6),
(13, 1, 'P55D3209', 1, 'khung bao vách', 38, 0, 0, 5800, 1.4, 0, 0, 0, 0, 1, '2025-08-29 14:11:48', 6),
(14, 1, '3296', 1, 'sập kính thường', 59, 0, 0, 5800, 2, 0, 0, 0, 0, 1, '2025-08-29 14:12:33', 6),
(15, 1, 'P55D0415', 1, 'ốp chân cánh cửa đi ', 32, 0, 0, 5800, 1.5, 0, 1, 0, 0, 0, '2025-08-29 14:13:14', 6),
(16, 1, 'P55D5108', 1, 'chân ốp che tường', 12, 0, 0, 5800, 2, 0, 0, 0, 0, 1, '2025-08-29 14:14:04', 6),
(17, 1, 'PMI007', 1, 'Lá Hộp 8.9 x 93', 27, 0, 0, 5800, 0.8, 0, 0, 0, 0, 1, '2025-08-29 14:15:25', 6),
(18, 1, 'P55D459', 1, 'Thanh truyền động 4.2 x 19.2', 80, 0, 0, 5800, 2, 0, 0, 0, 0, 1, '2025-08-29 14:21:31', 6),
(19, 1, 'p55d459', NULL, 'thanh chuyền', 80, 0, 0, 5800, 2, 0, 0, 0, 0, 1, '2025-09-01 21:18:01', 6),
(20, 1, 'L550112', 1, 'Khung bao lùa 44.8 x 55', 17, 0, 0, 5800, 1.2, 0, 0, 0, 0, 1, '2025-09-01 21:18:53', 6),
(21, 1, 'L550212', 1, 'Cánh lùa 30.3 x 70', 5, 0, 0, 5800, 1.2, 1, 0, 0, 0, 0, '2025-09-01 21:19:26', 6),
(22, 1, 'L550412', 1, 'Hèm chắn nước 24.4 x 40.8', 9, 0, 0, 5800, 1.2, 1, 0, 0, 0, 0, '2025-09-01 21:20:13', 6),
(23, 1, 'L100F0813', 1, 'Dẫn hướng trên 24.2 x 17.1', 14, 0, 0, 5800, 1.3, 0, 0, 0, 0, 1, '2025-09-01 21:20:50', 6),
(24, 5, 'MP60D0420', 1, 'Cánh bản 60 x 120', 2, 0, 0, 5800, 1.4, 0, 1, 0, 0, 0, '2025-09-01 21:21:24', 6),
(25, 3, 'MD651', 1, 'thanh đứng', 2, 0, 0, 6000, 2.5, 0, 0, 0, 0, 1, '2025-09-01 21:26:34', 6),
(26, 3, 'MD652', 1, 'Ngang Nhỏ', 35, 0, 0, 6000, 2.5, 0, 0, 0, 0, 1, '2025-09-04 15:49:36', 6),
(27, 3, 'MD461', 1, 'Thanh Đứng ', 3, 0, 2.5, 6000, 1.6, 0, 0, 0, 0, 1, '2025-09-04 15:50:57', 6),
(28, 3, 'MD002', 1, 'CÁNH CỬA BẬT MẶT DỰNG', 10, 0, 0, 6000, 1.5, 0, 0, 0, 0, 1, '2025-09-04 15:57:39', 6),
(29, 4, 'P65D0615', 1, 'Đố động 61.8 x 61.7', 20, 0, 0, 5800, 1.5, 0, 1, 0, 0, 0, '2025-09-06 16:40:27', 6),
(30, 4, 'P65D0720', 1, 'Khung bao cửa đi 68 x 55.8', 18, 0, 0, 5800, 2, 0, 1, 0, 0, 0, '2025-09-06 16:41:06', 6),
(31, 4, 'P65D0920', 1, 'Cánh cửa đi mở trong 64.8 x 94', 23, 0, 0, 5800, 2, 0, 1, 0, 0, 0, '2025-09-06 16:41:42', 6),
(32, 4, 'P65D1210', 1, 'Che chân 33.9 x 59.4', 14, 0, 0, 5800, 1, 0, 1, 0, 0, 0, '2025-09-06 16:42:13', 6),
(33, 4, 'P65D0114', 1, 'Khung bao cửa sổ 50.5 x 55.8', 17, 0, 0, 5800, 1.4, 1, 0, 0, 0, 0, '2025-09-06 16:42:59', 6),
(34, 4, 'P65D0214', 1, 'Cánh cửa sổ 64.8 x 84.3', 40, 0, 0, 5800, 1.4, 1, 0, 0, 0, 0, '2025-09-06 16:43:34', 6),
(35, 6, 'C3300', 1, 'nẹp nối khung', 0, 0, 0, 6000, 2, 0, 0, 0, 0, 0, '2026-03-13 08:21:58', 2),
(36, 6, 'C3328', 1, 'khung bao cửa đi mở quay', 0, 0, 0, 6000, 2, 0, 0, 0, 0, 0, '2026-03-13 08:22:00', 2),
(37, 6, 'C3303', 1, 'cánh cửa đi mở quay ngoài', 0, 0, 0, 6000, 2, 0, 0, 0, 0, 0, '2026-03-13 08:22:01', 2),
(38, 6, 'C3295', 1, 'nẹp cánh', 0, 0, 0, 6000, 2, 0, 0, 0, 0, 0, '2026-03-13 08:22:03', 2),
(39, 6, 'C22903', 1, 'đố động cửa đi', 0, 0, 0, 6000, 2, 0, 0, 0, 0, 0, '2026-03-13 08:22:04', 2),
(40, 6, 'C22900', 1, 'ốp chân cánh', 0, 0, 0, 6000, 2, 0, 0, 0, 0, 0, '2026-03-13 08:22:06', 2),
(41, 6, 'C3209', 1, 'khung bao vách', 0, 0, 0, 6000, 2, 0, 0, 0, 0, 0, '2026-03-13 08:22:07', 2),
(42, 6, 'C3203', 1, 'đố chia vách', 0, 0, 0, 6000, 2, 0, 0, 0, 0, 0, '2026-03-13 08:22:09', 2),
(43, 6, 'D23151', 1, 'khung bao cửa sổ trượt', 0, 0, 0, 6000, 2, 0, 0, 0, 0, 0, '2026-03-13 08:22:11', 2),
(44, 6, 'D23156', 1, 'cánh cửa sổ trượt', 0, 0, 0, 6000, 2, 0, 0, 0, 0, 0, '2026-03-13 08:22:12', 2),
(45, 6, 'D23157', 1, 'ốp móc cánh cửa sổ trượt', 0, 0, 0, 6000, 2, 0, 0, 0, 0, 0, '2026-03-13 08:22:14', 2),
(46, 6, 'D23159', 1, 'nẹp che mưa cửa trượt', 0, 0, 0, 6000, 2, 0, 0, 0, 0, 0, '2026-03-13 08:22:15', 2),
(47, 7, 'DN38', 1, 'đế nẹp 38 (đế và nẹp cắt chung)', 0, 0, 0, 6000, 1, 0, 0, 0, 0, 0, '2026-03-14 09:56:33', 2),
(48, 6, 'F077', 1, 'pa-nô cửa', 0, 0, 0, 6000, 2, 0, 0, 0, 10, 1, '2026-03-14 09:56:35', 2),
(49, 6, 'C3332', 1, 'cánh cửa đi mở quay trong', 0, 0, 0, 6000, 2, 0, 0, 0, 0, 0, '2026-03-14 09:56:36', 2);

-- --------------------------------------------------------

--
-- Table structure for table `cua_cong_trinh`
--

DROP TABLE IF EXISTS `cua_cong_trinh`;
CREATE TABLE IF NOT EXISTS `cua_cong_trinh` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `ten_cong_trinh` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `id_khach_hang` int DEFAULT NULL,
  `dia_diem` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `ngay_bat_dau` date DEFAULT NULL,
  `ngay_hoan_thanh` date DEFAULT NULL,
  `ghi_chu` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `code_mau_thiet_ke` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_khach_hang` (`id_khach_hang`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `cua_cong_trinh`
--

INSERT INTO `cua_cong_trinh` (`id`, `code`, `ten_cong_trinh`, `id_khach_hang`, `dia_diem`, `ngay_bat_dau`, `ngay_hoan_thanh`, `ghi_chu`, `code_mau_thiet_ke`, `date_created`, `user_created`) VALUES
(2, '6PyKB', 'Nhà ở chú Út Cao', 1, 'Cầu Quan', '2024-09-09', '2024-09-09', '', 'VER.230928', '2024-09-09 16:14:58', 2),
(3, '9VOCh', 'A.Nam D5', 2, 'Duong D5', NULL, NULL, '', 'VER.230928', '2024-09-12 09:20:47', 2),
(4, '4Hoxg', 'anh AN', 19, 'TRÀ VINH', '2026-03-15', '2026-03-20', '', 'VER.230928', '2026-03-13 08:19:08', 2),
(5, '6IkrM', 'CHÚ ĐẦY', 20, 'TRÀ VINH', '2026-03-15', '2026-03-20', '', 'VER.230928', '2026-03-14 09:40:10', 2);

-- --------------------------------------------------------

--
-- Table structure for table `cua_cong_trinh_settings`
--

DROP TABLE IF EXISTS `cua_cong_trinh_settings`;
CREATE TABLE IF NOT EXISTS `cua_cong_trinh_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_cong_trinh` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_don_vi_tinh`
--

DROP TABLE IF EXISTS `cua_don_vi_tinh`;
CREATE TABLE IF NOT EXISTS `cua_don_vi_tinh` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `ten_dvt` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `cua_don_vi_tinh`
--

INSERT INTO `cua_don_vi_tinh` (`id`, `code`, `ten_dvt`, `date_created`, `user_created`) VALUES
(1, 'chua-phan-loai', 'Chưa phân loại', NULL, NULL),
(2, NULL, 'cái', NULL, NULL),
(3, NULL, 'cặp', NULL, NULL),
(4, NULL, 'm2', NULL, NULL),
(5, NULL, 'bộ', NULL, NULL),
(6, '', 'chiếc', NULL, NULL),
(7, '', 'thanh', NULL, NULL),
(8, '', 'chai', NULL, NULL),
(9, NULL, 'con', NULL, NULL),
(10, NULL, 'cuộn', NULL, NULL),
(11, NULL, 'kg', NULL, NULL),
(12, NULL, 'mét tới', NULL, NULL),
(13, 'CAY', 'cây', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cua_du_an`
--

DROP TABLE IF EXISTS `cua_du_an`;
CREATE TABLE IF NOT EXISTS `cua_du_an` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `ten_du_an` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `ten_khach_hang` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `dia_chi` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `so_dien_thoai` varchar(11) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `trang_thai` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `toi_uu_tat_ca` tinyint DEFAULT NULL,
  `ngay_bat_dau_thuc_hien` date DEFAULT NULL,
  `ngay_hoan_thanh_du_an` date DEFAULT NULL,
  `ghi_chu` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `code_mau_thiet_ke` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `cua_du_an`
--

INSERT INTO `cua_du_an` (`id`, `code`, `ten_du_an`, `ten_khach_hang`, `dia_chi`, `so_dien_thoai`, `email`, `trang_thai`, `toi_uu_tat_ca`, `ngay_bat_dau_thuc_hien`, `ngay_hoan_thanh_du_an`, `ghi_chu`, `code_mau_thiet_ke`, `date_created`, `user_created`) VALUES
(1, '8YRsx', 'ngày 13/03/2026', NULL, NULL, NULL, NULL, 'DA_NHAP_KHO', 1, '2026-03-13', '2026-03-13', '', 'VER.230928', '2026-03-13 08:33:25', 2),
(2, '2Eg3V', 'ngày 13/03/2026', NULL, NULL, NULL, NULL, 'KHOI_TAO', 1, '2026-03-13', '2026-03-13', '', 'VER.230928', '2026-03-13 10:10:17', 2),
(3, '3Tued', 'CHÚ ĐẦY - TRÀ VINH', NULL, NULL, NULL, NULL, 'TOI_UU', 1, '2026-03-14', '2026-03-20', '', 'VER.230928', '2026-03-14 09:37:23', 2);

-- --------------------------------------------------------

--
-- Table structure for table `cua_du_an_settings`
--

DROP TABLE IF EXISTS `cua_du_an_settings`;
CREATE TABLE IF NOT EXISTS `cua_du_an_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_du_an` int DEFAULT NULL,
  `vet_cat` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_du_an` (`id_du_an`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `cua_du_an_settings`
--

INSERT INTO `cua_du_an_settings` (`id`, `id_du_an`, `vet_cat`) VALUES
(1, 1, 2),
(2, 2, 2),
(3, 3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `cua_he_mau`
--

DROP TABLE IF EXISTS `cua_he_mau`;
CREATE TABLE IF NOT EXISTS `cua_he_mau` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(20) CHARACTER SET utf32 COLLATE utf32_unicode_ci DEFAULT NULL,
  `ten_he_mau` varchar(200) CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `ma_mau` varchar(20) CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `for_nhom` tinyint(1) DEFAULT NULL,
  `for_phu_kien` tinyint(1) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Dumping data for table `cua_he_mau`
--

INSERT INTO `cua_he_mau` (`id`, `code`, `ten_he_mau`, `ma_mau`, `for_nhom`, `for_phu_kien`, `date_created`, `user_created`) VALUES
(1, 'XÁM', 'Màu xám', '#726f6e', 1, 1, '2024-08-27 14:02:15', 1),
(2, 'XANH', 'Màu xanh', '#08e722', 1, 1, '2024-08-27 14:15:28', 1),
(7, 'ĐEN', 'Hệ màu đen', '#000000', 1, 1, '2024-08-30 08:39:35', 1),
(8, 'TRẮNG', 'TRẮNG', '#ffffff', 1, 1, '2025-07-29 07:51:36', 1),
(9, 'BẠC', 'BẠC', '#f3eded', 0, 1, '2025-07-29 07:52:14', 1),
(10, 'TIÊU CHUẨN', 'Tiêu chuẩn', '#e6e6e6', 1, 1, '2025-09-26 16:21:15', 1),
(11, 'NÂU CÀ PHÊ', 'NÂU CÀ PHÊ', '#40260d', 1, 0, '2025-09-30 10:53:21', 3),
(12, 'VÀNG', 'Màu vàng', '#f8fd08', 0, 1, '2025-10-01 09:22:39', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_he_nhom`
--

DROP TABLE IF EXISTS `cua_he_nhom`;
CREATE TABLE IF NOT EXISTS `cua_he_nhom` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `ten_he_nhom` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `xuat_xu` int DEFAULT NULL,
  `hang_san_xuat` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `nha_cung_cap` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `do_day_mac_dinh` float DEFAULT NULL,
  `ghi_chu` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `cua_he_nhom`
--

INSERT INTO `cua_he_nhom` (`id`, `code`, `ten_he_nhom`, `xuat_xu`, `hang_san_xuat`, `nha_cung_cap`, `do_day_mac_dinh`, `ghi_chu`, `date_created`, `user_created`) VALUES
(1, 'PMI-XF55D', 'PMI P55D Xingfa', 3, 'PMI', NULL, 2, 'ghi chú', '2024-08-28 14:53:48', 1),
(2, 'XF55', 'Xingfa Quảng Đông hệ 55', 1, 'Xingfa', NULL, 1.6, '', '2024-08-28 15:23:04', 1),
(3, 'SGA-XF55', 'SFA XINGFA55', 2, '', NULL, 2, '', '2025-09-01 21:25:17', 6),
(4, 'PMI-XF65D', 'PMI XINGFA65', 3, '', NULL, 2, '', '2025-09-06 16:38:47', 6),
(5, 'PMI-HỆ THUỶ LỰC 60D', 'PMI-HỆ THUỶ LỰC 60D', 3, 'PMI', NULL, 2, '', '2025-09-30 10:45:30', 3),
(6, 'XF 55', 'XINGFA_NK HỆ 55', 2, '', NULL, 2, '', '2026-03-13 08:21:38', 2),
(7, 'ĐẾ NẸP', 'CỬA VÁCH KÍNH', 2, '', NULL, 1, '', '2026-03-14 09:41:24', 2);

-- --------------------------------------------------------

--
-- Table structure for table `cua_he_nhom_mau`
--

DROP TABLE IF EXISTS `cua_he_nhom_mau`;
CREATE TABLE IF NOT EXISTS `cua_he_nhom_mau` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_he_nhom` int NOT NULL,
  `id_he_mau` int NOT NULL,
  `is_mac_dinh` tinyint(1) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_he_nhom` (`id_he_nhom`),
  KEY `id_mau` (`id_he_mau`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Dumping data for table `cua_he_nhom_mau`
--

INSERT INTO `cua_he_nhom_mau` (`id`, `id_he_nhom`, `id_he_mau`, `is_mac_dinh`, `date_created`, `user_created`) VALUES
(32, 1, 1, 1, '2024-08-28 14:57:39', 1),
(34, 3, 1, 1, '2025-09-01 21:25:17', 6),
(35, 4, 1, 1, '2025-09-06 16:45:04', 6),
(36, 5, 1, 1, '2025-09-30 10:45:30', 3),
(37, 6, 1, 1, '2026-03-13 08:21:38', 2),
(38, 7, 1, 1, '2026-03-14 09:41:24', 2);

-- --------------------------------------------------------

--
-- Table structure for table `cua_he_vach`
--

DROP TABLE IF EXISTS `cua_he_vach`;
CREATE TABLE IF NOT EXISTS `cua_he_vach` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `ten_he_vach` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `ghi_chu` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `cua_he_vach`
--

INSERT INTO `cua_he_vach` (`id`, `code`, `ten_he_vach`, `ghi_chu`, `date_created`, `user_created`) VALUES
(1, 'CL8', 'Kính trắng CL 8ly', 'Thêm từ import file #mau 1G2Qt', '2026-03-13 08:22:10', 2),
(2, 'CL10', 'Kính trắng CL 10ly', 'Thêm từ import file #mau 2tRuP', '2026-03-14 09:56:34', 2);

-- --------------------------------------------------------

--
-- Table structure for table `cua_hinh_anh`
--

DROP TABLE IF EXISTS `cua_hinh_anh`;
CREATE TABLE IF NOT EXISTS `cua_hinh_anh` (
  `id` int NOT NULL AUTO_INCREMENT,
  `loai` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `id_tham_chieu` int NOT NULL,
  `ten_hien_thi` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `duong_dan` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `ten_file_luu` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `img_extension` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `img_size` float DEFAULT NULL,
  `img_wh` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `ghi_chu` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `nguoi_tao` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `cua_hinh_anh`
--

INSERT INTO `cua_hinh_anh` (`id`, `loai`, `id_tham_chieu`, `ten_hien_thi`, `duong_dan`, `ten_file_luu`, `img_extension`, `img_size`, `img_wh`, `ghi_chu`, `thoi_gian_tao`, `nguoi_tao`) VALUES
(1, 'mau-cua', 1, NULL, '082158-tJCG.jpeg', '082158-tJCG.jpeg', 'jpeg', NULL, NULL, NULL, '2026-03-13 08:21:58', 2),
(2, 'mau-cua', 2, NULL, '082211-Jpk5.jpeg', '082211-Jpk5.jpeg', 'jpeg', NULL, NULL, NULL, '2026-03-13 08:22:11', 2),
(3, 'mau-cua', 3, NULL, '082217-iVfE.jpeg', '082217-iVfE.jpeg', 'jpeg', NULL, NULL, NULL, '2026-03-13 08:22:17', 2),
(4, 'mau-cua', 4, NULL, '095633-zN34.jpeg', '095633-zN34.jpeg', 'jpeg', NULL, NULL, NULL, '2026-03-14 09:56:33', 2),
(5, 'mau-cua', 5, NULL, '095635-iLo2.jpeg', '095635-iLo2.jpeg', 'jpeg', NULL, NULL, NULL, '2026-03-14 09:56:35', 2),
(6, 'mau-cua', 6, NULL, '095638-7rM3.jpeg', '095638-7rM3.jpeg', 'jpeg', NULL, NULL, NULL, '2026-03-14 09:56:38', 2),
(7, 'mau-cua', 7, NULL, '095638-C0gG.jpeg', '095638-C0gG.jpeg', 'jpeg', NULL, NULL, NULL, '2026-03-14 09:56:38', 2),
(8, 'mau-cua', 8, NULL, '095638-j8FT.jpeg', '095638-j8FT.jpeg', 'jpeg', NULL, NULL, NULL, '2026-03-14 09:56:38', 2);

-- --------------------------------------------------------

--
-- Table structure for table `cua_kho_nhom`
--

DROP TABLE IF EXISTS `cua_kho_nhom`;
CREATE TABLE IF NOT EXISTS `cua_kho_nhom` (
  `id` int NOT NULL AUTO_INCREMENT,
  `qr_code` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `id_cay_nhom` int NOT NULL,
  `chieu_dai` float NOT NULL,
  `so_luong` int DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_cay_nhom` (`id_cay_nhom`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `cua_kho_nhom`
--

INSERT INTO `cua_kho_nhom` (`id`, `qr_code`, `id_cay_nhom`, `chieu_dai`, `so_luong`, `date_created`, `user_created`) VALUES
(1, '6BudT', 1, 5800, 41, '2025-08-29 13:25:35', 6),
(2, '6jlGB', 2, 5800, 17, '2025-08-29 13:27:20', 6),
(3, '7fIFY', 3, 5800, 23, '2025-08-29 13:28:07', 6),
(4, '2drNW', 4, 5800, 10, '2025-08-29 13:28:58', 6),
(5, '4bhRp', 5, 5800, 20, '2025-08-29 13:29:35', 6),
(6, '9cTmX', 6, 5800, 41, '2025-08-29 13:30:22', 6),
(7, '1Hx8F', 7, 5800, 10, '2025-08-29 13:31:25', 6),
(8, '4jfJP', 8, 5800, 21, '2025-08-29 14:08:06', 6),
(9, '5IyVt', 9, 5800, 19, '2025-08-29 14:08:46', 6),
(10, '3dUT1', 10, 5800, 1, '2025-08-29 14:09:25', 6),
(11, '1tvRo', 11, 5800, 21, '2025-08-29 14:10:16', 6),
(12, '4WBow', 12, 5800, 1, '2025-08-29 14:11:02', 6),
(13, '7QNHx', 13, 5800, 38, '2025-08-29 14:11:48', 6),
(14, '7RGxw', 14, 5800, 59, '2025-08-29 14:12:33', 6),
(15, '6HcvI', 15, 5800, 32, '2025-08-29 14:13:14', 6),
(16, '1AmzY', 16, 5800, 12, '2025-08-29 14:14:04', 6),
(17, '7ecAp', 17, 5800, 27, '2025-08-29 14:15:25', 6),
(18, '2fhqZ', 18, 5800, 80, '2025-08-29 14:21:31', 6),
(19, '8JErR', 19, 5800, 80, '2025-09-01 21:18:01', 6),
(20, '6yTpb', 20, 5800, 17, '2025-09-01 21:18:53', 6),
(21, '9btFT', 21, 5800, 5, '2025-09-01 21:19:26', 6),
(22, '6Hw1W', 22, 5800, 9, '2025-09-01 21:20:13', 6),
(23, '9nHKq', 23, 5800, 14, '2025-09-01 21:20:50', 6),
(24, '41F7C', 24, 5800, 2, '2025-09-01 21:21:24', 6),
(25, '78TcS', 25, 6000, 2, '2025-09-01 21:26:34', 6),
(26, '4iYzx', 26, 6000, 35, '2025-09-04 15:49:36', 6),
(27, '4cV8j', 27, 6000, 3, '2025-09-04 15:50:57', 6),
(28, '3vOdQ', 28, 6000, 10, '2025-09-04 15:57:39', 6),
(29, '66eCX', 29, 5800, 20, '2025-09-06 16:40:27', 6),
(30, '4BDug', 30, 5800, 18, '2025-09-06 16:41:06', 6),
(31, '5m9qK', 31, 5800, 23, '2025-09-06 16:41:42', 6),
(32, '3Pcy3', 32, 5800, 14, '2025-09-06 16:42:14', 6),
(33, '1fzEm', 33, 5800, 17, '2025-09-06 16:42:59', 6),
(34, '2zVHg', 34, 5800, 40, '2025-09-06 16:43:34', 6),
(35, '36Qzw', 35, 6000, -2, '2026-03-13 08:21:58', 2),
(36, '9Gzax', 36, 6000, -2, '2026-03-13 08:22:00', 2),
(37, '3Wl3n', 37, 6000, -4, '2026-03-13 08:22:01', 2),
(38, '3c6Ka', 38, 6000, -8, '2026-03-13 08:22:03', 2),
(39, '52EzX', 39, 6000, -2, '2026-03-13 08:22:04', 2),
(40, '4SbFL', 40, 6000, -1, '2026-03-13 08:22:06', 2),
(41, '7vgSe', 41, 6000, -4, '2026-03-13 08:22:07', 2),
(42, '8v5mK', 42, 6000, -1, '2026-03-13 08:22:09', 2),
(43, '4WFQw', 43, 6000, -5, '2026-03-13 08:22:11', 2),
(44, '3Iz0x', 44, 6000, -7, '2026-03-13 08:22:12', 2),
(45, '8lABr', 45, 6000, -2, '2026-03-13 08:22:14', 2),
(46, '8BefA', 46, 6000, -2, '2026-03-13 08:22:15', 2),
(47, '8oluT', 35, 790, 1, '2026-03-13 08:46:21', 2),
(48, '2yklE', 35, 2394, 1, '2026-03-13 08:46:23', 2),
(49, '11kYZ', 36, 1198, 1, '2026-03-13 08:46:24', 2),
(50, '9RUn9', 36, 3698, 1, '2026-03-13 08:46:26', 2),
(51, '6RFjl', 37, 190, 4, '2026-03-13 08:46:27', 2),
(52, '9rwln', 38, 216, 3, '2026-03-13 08:46:29', 2),
(53, '3ihsv', 38, 87, 1, '2026-03-13 08:46:30', 2),
(54, '9WlMb', 38, 111, 1, '2026-03-13 08:46:32', 2),
(55, '7ISAp', 38, 168, 1, '2026-03-13 08:46:33', 2),
(56, '4BUyF', 38, 4644, 1, '2026-03-13 08:46:35', 2),
(57, '9icma', 39, 1356, 1, '2026-03-13 08:46:36', 2),
(58, '2pPws', 39, 3678, 1, '2026-03-13 08:46:37', 2),
(59, '88jgE', 40, 4032, 1, '2026-03-13 08:46:39', 2),
(60, '1HTWL', 41, 194, 1, '2026-03-13 08:46:40', 2),
(61, '1ztQA', 41, 192, 1, '2026-03-13 08:46:42', 2),
(62, '9d3tH', 41, 390, 1, '2026-03-13 08:46:43', 2),
(63, '2FkLm', 41, 788, 1, '2026-03-13 08:46:45', 2),
(64, '6xtXc', 42, 5302, 1, '2026-03-13 08:46:46', 2),
(65, '63n7l', 43, 192, 1, '2026-03-13 08:46:48', 2),
(66, '1PTDG', 43, 1192, 1, '2026-03-13 08:46:49', 2),
(67, '37Miz', 43, 1194, 1, '2026-03-13 08:46:51', 2),
(68, '4SKbM', 43, 1196, 2, '2026-03-13 08:46:52', 2),
(69, '7m3uV', 44, 380, 4, '2026-03-13 08:46:53', 2),
(70, '354pA', 44, 240, 1, '2026-03-13 08:46:55', 2),
(71, '2xJyj', 44, 50, 1, '2026-03-13 08:46:56', 2),
(72, '6BClA', 44, 4810, 1, '2026-03-13 08:46:58', 2),
(73, '2Oucw', 45, 380, 2, '2026-03-13 08:46:59', 2),
(74, '2eSEH', 46, 692, 1, '2026-03-13 08:47:01', 2),
(75, '22eyR', 46, 4798, 1, '2026-03-13 08:47:02', 2),
(76, '1toX8', 47, 6000, 0, '2026-03-14 09:56:33', 2),
(77, '3yw9A', 48, 6000, 0, '2026-03-14 09:56:35', 2),
(78, '7SC7K', 49, 6000, 0, '2026-03-14 09:56:36', 2);

-- --------------------------------------------------------

--
-- Table structure for table `cua_kho_nhom_lich_su`
--

DROP TABLE IF EXISTS `cua_kho_nhom_lich_su`;
CREATE TABLE IF NOT EXISTS `cua_kho_nhom_lich_su` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_kho_nhom` int NOT NULL,
  `so_luong` int NOT NULL,
  `so_luong_cu` int DEFAULT NULL,
  `so_luong_moi` int DEFAULT NULL,
  `noi_dung` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `id_mau_cua` int DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_kho_nhom` (`id_kho_nhom`)
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `cua_kho_nhom_lich_su`
--

INSERT INTO `cua_kho_nhom_lich_su` (`id`, `id_kho_nhom`, `so_luong`, `so_luong_cu`, `so_luong_moi`, `noi_dung`, `id_mau_cua`, `date_created`, `user_created`) VALUES
(1, 1, 41, 0, 41, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-08-29 13:25:35', 6),
(2, 2, 17, 0, 17, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-08-29 13:27:20', 6),
(3, 3, 23, 0, 23, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-08-29 13:28:07', 6),
(4, 4, 10, 0, 10, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-08-29 13:28:58', 6),
(5, 5, 20, 0, 20, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-08-29 13:29:35', 6),
(6, 6, 41, 0, 41, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-08-29 13:30:22', 6),
(7, 7, 10, 0, 10, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-08-29 13:31:25', 6),
(8, 8, 21, 0, 21, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-08-29 14:08:06', 6),
(9, 9, 19, 0, 19, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-08-29 14:08:46', 6),
(10, 10, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-08-29 14:09:25', 6),
(11, 11, 21, 0, 21, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-08-29 14:10:16', 6),
(12, 12, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-08-29 14:11:02', 6),
(13, 13, 38, 0, 38, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-08-29 14:11:48', 6),
(14, 14, 59, 0, 59, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-08-29 14:12:33', 6),
(15, 15, 32, 0, 32, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-08-29 14:13:14', 6),
(16, 16, 12, 0, 12, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-08-29 14:14:04', 6),
(17, 17, 27, 0, 27, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-08-29 14:15:25', 6),
(18, 18, 80, 0, 80, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-08-29 14:21:31', 6),
(19, 19, 80, 0, 80, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-09-01 21:18:01', 6),
(20, 20, 17, 0, 17, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-09-01 21:18:53', 6),
(21, 21, 5, 0, 5, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-09-01 21:19:26', 6),
(22, 22, 9, 0, 9, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-09-01 21:20:13', 6),
(23, 23, 14, 0, 14, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-09-01 21:20:50', 6),
(24, 24, 2, 0, 2, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-09-01 21:21:24', 6),
(25, 25, 2, 0, 2, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-09-01 21:26:34', 6),
(26, 26, 35, 0, 35, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-09-04 15:49:36', 6),
(27, 27, 3, 0, 3, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-09-04 15:50:57', 6),
(28, 28, 10, 0, 10, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-09-04 15:57:39', 6),
(29, 29, 20, 0, 20, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-09-06 16:40:27', 6),
(30, 30, 18, 0, 18, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-09-06 16:41:06', 6),
(31, 31, 23, 0, 23, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-09-06 16:41:42', 6),
(32, 32, 14, 0, 14, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-09-06 16:42:14', 6),
(33, 33, 17, 0, 17, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-09-06 16:42:59', 6),
(34, 34, 40, 0, 40, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2025-09-06 16:43:34', 6),
(35, 35, 0, 0, 0, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2026-03-13 08:21:58', 2),
(36, 36, 0, 0, 0, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2026-03-13 08:22:00', 2),
(37, 37, 0, 0, 0, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2026-03-13 08:22:01', 2),
(38, 38, 0, 0, 0, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2026-03-13 08:22:03', 2),
(39, 39, 0, 0, 0, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2026-03-13 08:22:04', 2),
(40, 40, 0, 0, 0, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2026-03-13 08:22:06', 2),
(41, 41, 0, 0, 0, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2026-03-13 08:22:07', 2),
(42, 42, 0, 0, 0, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2026-03-13 08:22:09', 2),
(43, 43, 0, 0, 0, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2026-03-13 08:22:11', 2),
(44, 44, 0, 0, 0, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2026-03-13 08:22:12', 2),
(45, 45, 0, 0, 0, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2026-03-13 08:22:14', 2),
(46, 46, 0, 0, 0, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2026-03-13 08:22:15', 2),
(47, 35, 1, 0, -1, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(48, 35, 1, -1, -2, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(49, 36, 1, 0, -1, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(50, 36, 1, -1, -2, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(51, 37, 1, 0, -1, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(52, 37, 1, -1, -2, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(53, 37, 1, -2, -3, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(54, 37, 1, -3, -4, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(55, 38, 1, 0, -1, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(56, 38, 1, -1, -2, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(57, 38, 1, -2, -3, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(58, 38, 1, -3, -4, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(59, 38, 1, -4, -5, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(60, 38, 1, -5, -6, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(61, 38, 1, -6, -7, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(62, 38, 1, -7, -8, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(63, 39, 1, 0, -1, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(64, 39, 1, -1, -2, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(65, 40, 1, 0, -1, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(66, 41, 1, 0, -1, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(67, 41, 1, -1, -2, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(68, 41, 1, -2, -3, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(69, 41, 1, -3, -4, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(70, 42, 1, 0, -1, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(71, 43, 1, 0, -1, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(72, 43, 1, -1, -2, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(73, 43, 1, -2, -3, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(74, 43, 1, -3, -4, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(75, 43, 1, -4, -5, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(76, 44, 1, 0, -1, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(77, 44, 1, -1, -2, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(78, 44, 1, -2, -3, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(79, 44, 1, -3, -4, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(80, 44, 1, -4, -5, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(81, 44, 1, -5, -6, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(82, 44, 1, -6, -7, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(83, 45, 1, 0, -1, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(84, 45, 1, -1, -2, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(85, 46, 1, 0, -1, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(86, 46, 1, -1, -2, 'Xuất kho mẫu cửa #8YRsx', 1, '2026-03-13 08:39:40', 2),
(87, 47, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm : Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:21', 2),
(88, 48, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm : Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:23', 2),
(89, 49, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm : Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:24', 2),
(90, 50, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm : Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:26', 2),
(91, 51, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm : Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:27', 2),
(92, 51, 1, 1, 2, 'Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:29', 2),
(93, 51, 1, 2, 3, 'Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:29', 2),
(94, 51, 1, 3, 4, 'Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:29', 2),
(95, 52, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm : Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:29', 2),
(96, 52, 1, 1, 2, 'Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:30', 2),
(97, 52, 1, 2, 3, 'Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:30', 2),
(98, 53, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm : Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:30', 2),
(99, 54, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm : Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:32', 2),
(100, 55, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm : Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:33', 2),
(101, 56, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm : Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:35', 2),
(102, 57, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm : Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:36', 2),
(103, 58, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm : Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:37', 2),
(104, 59, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm : Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:39', 2),
(105, 60, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm : Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:40', 2),
(106, 61, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm : Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:42', 2),
(107, 62, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm : Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:43', 2),
(108, 63, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm : Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:45', 2),
(109, 64, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm : Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:46', 2),
(110, 65, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm : Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:48', 2),
(111, 66, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm : Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:49', 2),
(112, 67, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm : Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:51', 2),
(113, 68, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm : Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:52', 2),
(114, 68, 1, 1, 2, 'Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:53', 2),
(115, 69, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm : Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:53', 2),
(116, 69, 1, 1, 2, 'Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:55', 2),
(117, 69, 1, 2, 3, 'Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:55', 2),
(118, 69, 1, 3, 4, 'Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:55', 2),
(119, 70, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm : Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:55', 2),
(120, 71, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm : Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:56', 2),
(121, 72, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm : Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:58', 2),
(122, 73, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm : Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:46:59', 2),
(123, 73, 1, 1, 2, 'Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:47:01', 2),
(124, 74, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm : Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:47:01', 2),
(125, 75, 1, 0, 1, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm : Nhập kho nhôm dư từ dự án #8YRsx', NULL, '2026-03-13 08:47:02', 2),
(126, 76, 0, 0, 0, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2026-03-14 09:56:33', 2),
(127, 77, 0, 0, 0, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2026-03-14 09:56:35', 2),
(128, 78, 0, 0, 0, 'Cập nhật tồn kho do thêm mới dữ liệu kho nhôm - Thêm cây nhôm mới', NULL, '2026-03-14 09:56:36', 2);

-- --------------------------------------------------------

--
-- Table structure for table `cua_kho_nhom_qr`
--

DROP TABLE IF EXISTS `cua_kho_nhom_qr`;
CREATE TABLE IF NOT EXISTS `cua_kho_nhom_qr` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_kho_nhom` int NOT NULL,
  `id_nhom_su_dung` int NOT NULL,
  `qr_code` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_kho_nhom` (`id_kho_nhom`),
  KEY `id_nhom_su_dung` (`id_nhom_su_dung`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_kho_vat_tu`
--

DROP TABLE IF EXISTS `cua_kho_vat_tu`;
CREATE TABLE IF NOT EXISTS `cua_kho_vat_tu` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `ten_vat_tu` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `id_he_mau` int DEFAULT NULL,
  `id_nhom_vat_tu` int DEFAULT NULL,
  `thuong_hieu` int DEFAULT NULL,
  `model` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `xuat_xu` int DEFAULT NULL,
  `nha_cung_cap` int DEFAULT NULL,
  `la_phu_kien` tinyint(1) DEFAULT NULL,
  `so_luong` float DEFAULT NULL,
  `dvt` int NOT NULL,
  `don_gia` double DEFAULT NULL,
  `ghi_chu` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_nhom_vat_tu` (`id_nhom_vat_tu`),
  KEY `xuat_xu` (`xuat_xu`),
  KEY `id_he_mau` (`id_he_mau`)
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `cua_kho_vat_tu`
--

INSERT INTO `cua_kho_vat_tu` (`id`, `code`, `ten_vat_tu`, `id_he_mau`, `id_nhom_vat_tu`, `thuong_hieu`, `model`, `xuat_xu`, `nha_cung_cap`, `la_phu_kien`, `so_luong`, `dvt`, `don_gia`, `ghi_chu`, `date_created`, `user_created`) VALUES
(1, 'ZH-168', 'Bản lề 4D (C-K)', 1, 1, 2, '', 1, NULL, 1, 292, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(2, 'ZH-168', 'Bản Lề 4D (c-k)', 8, 1, 2, '', 1, NULL, 1, 32, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(3, 'ZH-168', 'Bản Lề 4D (c-k)', 7, 1, 2, '', 1, NULL, 1, 79, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(4, 'ZH-169', 'Bản Lề 4D (c-c)', 1, 1, 2, '', 1, NULL, 1, 46, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(5, 'PM-23 (L8*90, M5*70)', 'Tay nắm (tay vuông)', 8, 1, 2, '', 1, NULL, 1, 30, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(6, 'PM-23 (L8*90, M5*70)', 'Tay nắm (tay vuông)', 1, 1, 2, '', 1, NULL, 1, 156, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(7, 'PM-23 (L8*90, M5*70)', 'Tay nắm (tay vuông)', 7, 1, 2, '', 1, NULL, 1, 174, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(8, ' 2885c ', 'Thân khóa đơn điểm', 10, 1, 2, '', 1, NULL, 1, 131, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(9, ' 2885c1', 'Thân khóa đa điểm', 10, 1, 2, '', 1, NULL, 1, 316, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(10, 'F64A', 'Tay gạt cs đa điểm', 8, 1, 2, '', 4, NULL, 1, 27, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(11, 'F64A', 'Tay gạt cs đơn điểm', 1, 1, 2, '', 4, NULL, 1, 16, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(12, 'l411', 'Tay gạt cs đơn điểm bên trái ', 1, 1, 2, NULL, 1, NULL, 1, 3, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(13, 'l411', 'Tay gạt cs đơn điểm bên phải', 8, 1, 2, '', 1, NULL, 1, 9, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(14, 'l411 ', 'Tay gạt cs đơn điểm bên phải', 7, 1, 2, NULL, 1, NULL, 1, 19, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(15, 'l409', 'Tay gạt cs đơn điểm bên trái', 8, 1, 2, NULL, 1, NULL, 1, 1, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(16, '32/47T', 'lỗi khoá mở trong', 10, 1, 2, '', 4, NULL, 1, 86, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(17, '47/32T', 'lỗi khoá mở ngoài ', 10, 1, 2, '', 4, NULL, 1, 87, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(18, '32/47B', 'lỗi khoá 2 đầu chìa', 10, 1, 2, '', 4, NULL, 1, 49, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(19, 'PTHC-221-12', 'Bản lề chữ A', 10, 1, 2, '', 4, NULL, 1, 15, 3, 0, NULL, '2025-09-26 16:53:33', 1),
(20, 'PTXC-22B-14', 'Bản lề chữ A', 10, 1, 2, '', 4, NULL, 1, 25, 3, 0, NULL, '2025-09-26 16:53:33', 1),
(21, 'PTHC-221-10', 'Bản lề chữ A', 10, 1, 2, '', 4, NULL, 1, 49, 3, 0, NULL, '2025-09-26 16:53:33', 1),
(22, 'FB8D', 'Hố trên ', 10, 1, 2, '', 4, NULL, 1, 61, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(23, 'FC3008', 'Hố dưới', 10, 1, 2, '', 4, NULL, 1, 212, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(24, 'FB7T', 'Đầu chốt', 10, 1, 2, '', 1, NULL, 1, 43, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(25, 'FB517', 'Cần đẩy ', 10, 1, 2, '', 1, NULL, 1, 81, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(26, 'F14C1', 'Vấu Hãm Ngắn', 10, 1, 2, '', 4, NULL, 1, 29, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(27, 'FB3H', 'Đầu Biên thấp', 10, 1, 2, NULL, 1, NULL, 1, 149, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(28, 'KB-19AG', 'Miệng ốp đơn điểm', 10, 1, 2, '', 4, NULL, 1, 56, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(29, ' KB-18AG', 'Miệng ốp đa điểm', 10, 1, 2, '', 4, NULL, 1, 17, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(30, 'TU2037', 'Khoá sò', 8, 1, 2, '', 1, NULL, 1, 47, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(31, 'TU2037', 'Khoá sò', 7, 1, 2, '', 4, NULL, 1, 38, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(32, 'TU2037', 'Khoá sò', 1, 1, 2, '', 1, NULL, 1, 62, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(33, 'TU2037', 'Khoá sò', 9, 1, 2, NULL, 1, NULL, 1, 10, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(34, 'SKG/41-Z5', 'Miệng sò', 10, 1, 2, '', 4, NULL, 1, 71, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(35, 'GHLD1', 'Bánh xe đơn lùa 55', 10, 1, 2, '', 4, NULL, 1, 75, 2, 0, NULL, '2025-09-26 16:53:33', 1),
(36, 'WD25', 'Bản lề 4D (C-K)', 12, 1, 3, NULL, 1, NULL, 1, 39, 2, 0, NULL, '2025-10-01 09:23:03', 1),
(37, 'WD25', 'Bản Lề 4D (c-k)', 9, 1, 3, NULL, 1, NULL, 1, 17, 2, 0, NULL, '2025-10-01 09:23:03', 1),
(38, ' WD24', 'Bản Lề 4D (c-c)', 12, 1, 3, NULL, 1, NULL, 1, 32, 2, 0, NULL, '2025-10-01 09:23:04', 1),
(39, ' WD24', 'Bản Lề 4D (c-c)', 9, 1, 3, NULL, 1, NULL, 1, 27, 2, 0, NULL, '2025-10-01 09:23:04', 1),
(40, 'WD12', 'Bản lề 4D ', 9, 1, 3, NULL, 1, NULL, 1, 19, 2, 0, NULL, '2025-10-01 09:23:04', 1),
(41, 'WD12', 'Bản lề 4D ', 12, 1, 3, NULL, 1, NULL, 1, 19, 2, 0, NULL, '2025-10-01 09:23:04', 1),
(42, 'BL20W17', 'Tay nắm cửa đi ', 9, 1, 3, NULL, 1, NULL, 1, 9, 2, 0, NULL, '2025-10-01 09:23:04', 1),
(43, 'BL20W17', 'Tay nắm cửa đi ', 1, 1, 3, '', 1, NULL, 1, 3, 2, 0, NULL, '2025-10-01 09:23:04', 1),
(44, 'BQ120A', 'Khóa Sập', 9, 1, 3, NULL, 1, NULL, 1, 26, 2, 0, NULL, '2025-10-01 09:23:04', 1),
(45, 'BQ120A', 'Khóa Sập', 12, 1, 3, NULL, 1, NULL, 1, 20, 2, 0, NULL, '2025-10-01 09:23:04', 1),
(46, 'BW-171 ', 'Bánh xe (hệ 55)', 10, 1, 3, NULL, 1, NULL, 1, 58, 2, 0, NULL, '2025-10-01 09:23:04', 1),
(47, 'SA-1964', 'Bộ khoá Biên + Vấu chốt hãm ', 10, 1, 3, NULL, 1, NULL, 1, 30, 3, 0, NULL, '2025-10-01 09:23:04', 1),
(48, 'BLX0759', 'Tay gạt cs đơn điểm bên phải', 9, 1, 3, NULL, 1, NULL, 1, 18, 2, 0, NULL, '2025-10-01 09:23:04', 1),
(49, 'BLX0759', 'Tay gạt cs đơn điểm bên trái', 12, 1, 3, NULL, 1, NULL, 1, 46, 2, 0, NULL, '2025-10-01 09:23:04', 1),
(50, 'BLX0759', 'Tay gạt cs đơn điểm bên phải', 1, 1, 3, NULL, 1, NULL, 1, 28, 2, 0, NULL, '2025-10-01 09:23:04', 1),
(51, 'BLP9217', 'Tay gạt cs đa điểm', 12, 1, 3, NULL, 1, NULL, 1, 21, 2, 0, NULL, '2025-10-01 09:23:04', 1),
(52, 'BLP9217', 'Tay gạt cs đa điểm', 9, 1, 3, NULL, 1, NULL, 1, 13, 2, 0, NULL, '2025-10-01 09:23:04', 1),
(53, '32/48T', 'Lỗi  khóa 1 đầu chìa mở trong 55', 10, 1, 3, NULL, 1, NULL, 1, 7, 2, 0, NULL, '2025-10-01 09:23:04', 1),
(54, '48/32T', 'Lỗi  khóa 1 đầu chìa mở ngoài  55', 10, 1, 3, NULL, 1, NULL, 1, 4, 2, 0, NULL, '2025-10-01 09:23:04', 1),
(55, '60/32T', 'Lỗi khóa 1 đầu chìa mở trong 65', 10, 1, 3, NULL, 1, NULL, 1, 5, 2, 0, NULL, '2025-10-01 09:23:04', 1),
(56, '32/60T', 'Lỗi khóa 1 đầu chìa mở ngoài 65', 10, 1, 3, NULL, 1, NULL, 1, 14, 2, 0, NULL, '2025-10-01 09:23:04', 1),
(57, 'sk80', 'Lỗi khóa 2 đầu chìa 55', 10, 1, 3, NULL, 1, NULL, 1, 6, 2, 0, NULL, '2025-10-01 09:23:04', 1),
(58, 'sk92', 'Lỗi khóa 2 đầu chìa 65 ', 10, 1, 3, NULL, 1, NULL, 1, 6, 2, 0, NULL, '2025-10-01 09:23:04', 1),
(59, 'ZY3085', 'Thân khoá đơn điểm 55', 10, 1, 3, NULL, 1, NULL, 1, 14, 2, 0, NULL, '2025-10-01 09:23:04', 1),
(60, 'ZY88530', 'Thân khoá đa điểm 55', 10, 1, 3, NULL, 1, NULL, 1, 3, 2, 0, NULL, '2025-10-01 09:23:04', 1),
(61, 'ZY3585', 'Thân khoá đơn điểm 65 ', 10, 1, 3, NULL, 1, NULL, 1, 3, 2, 0, NULL, '2025-10-01 09:23:04', 1),
(62, 'ZY88535', 'Thân khoá đa điểm 65', 10, 1, 3, NULL, 1, NULL, 1, 2, 2, 0, NULL, '2025-10-01 09:23:04', 1),
(63, 'jl-12', 'Bản lề chữ A300 12 Inch', 10, 1, 3, '', 1, NULL, 1, 125, 7, 0, NULL, '2025-10-01 09:23:04', 1),
(64, 'jl -10', 'Bản lề chữ A250 10 Inch ', 10, 1, 3, '', 1, NULL, 1, 112, 7, 0, NULL, '2025-10-01 09:23:04', 1),
(65, '3lmnH', 'Miệng khoá đa điểm', 10, 1, 3, NULL, 1, NULL, 1, 17, 2, 0, NULL, '2025-10-01 09:23:04', 1),
(66, '3hSyx', 'miệng khoá đơn điểm', 10, 1, 3, NULL, 1, NULL, 1, 58, 2, 0, NULL, '2025-10-01 09:23:04', 1),
(67, '3Lfea', 'Chốt bật Bogo', 10, 1, 3, NULL, 1, NULL, 1, 28, 3, 0, NULL, '2025-10-01 09:23:04', 1),
(68, 'Z06T', 'Chữ T', 10, 1, 3, NULL, 1, NULL, 1, 26, 2, 0, NULL, '2025-10-01 09:24:15', 1),
(69, 'ZH-169-1', 'Bản lề 4D (C-C)', 8, 1, 2, '', 1, NULL, 1, 33, 2, NULL, NULL, '2025-10-03 22:26:03', 6),
(70, 'L409-B17', 'Tay gạt cửa sổ đơn điểm bên trái', 7, 1, 2, '', 1, NULL, 1, 20, 2, NULL, NULL, '2025-10-06 21:29:59', 6),
(71, 'L409-B17', 'Tay gạt cửa sổ đơn điểm bên phải', 7, 1, 2, '', 1, NULL, 1, 56, 6, NULL, NULL, '2025-10-06 21:30:35', 6),
(72, 'BL20W17', 'Tay nắm cửa đi ', 12, 1, 3, '', 1, NULL, 1, 19, 2, NULL, NULL, '2025-10-06 21:38:12', 6),
(73, 'L409-B17 ', 'Tay gạt cửa sổ đơn điểm bên trái', 7, 1, 2, '', 1, NULL, 1, 30, 2, NULL, NULL, '2025-10-29 14:02:00', 6),
(74, 'F13CI', 'Vẫu Hãm Dài', 10, 1, 2, '', 4, NULL, 1, 99, 2, NULL, NULL, '2025-11-23 13:39:19', 6),
(75, 'F64A', 'Tay gạt cửa sổ đa điểm', 7, 1, 2, '', 4, NULL, 1, 2, 2, NULL, NULL, '2026-02-14 11:04:25', 6),
(76, 'L411L', 'Tay gạt cs đơn điểm', 1, 1, 2, '', 4, NULL, 1, 4, 2, 0, NULL, '2026-02-14 11:07:19', 6),
(77, 'L411R', 'Tay gạt cs đa điểm', 8, 1, 2, '', 4, NULL, 1, 5, 1, 0, NULL, '2026-02-14 11:08:13', 6),
(78, 'PTXC-22B-10', 'Bản lề chữ A', 10, 1, 2, '', 4, NULL, 1, 50, 3, 0, NULL, '2026-02-14 11:13:00', 6),
(79, 'PTXC-22B-12', 'Bản lề chữ A', 10, 1, 2, '', 4, NULL, 1, 27, 3, 0, NULL, '2026-02-14 11:13:26', 6),
(80, 'SHLS1', 'Bánh xe đôi lùa 93', 10, 1, 2, '', 4, NULL, 1, 33, 2, NULL, NULL, '2026-02-14 11:18:14', 6),
(81, 'GLHS2', 'Bánh xe đôi lùa 55', 10, 1, 2, '', 4, NULL, 1, 10, 2, NULL, NULL, '2026-02-14 11:18:58', 6),
(82, 'FB6T', 'Đầu Biên Ngắn', 10, 1, 2, '', 4, NULL, 1, 118, 2, NULL, NULL, '2026-02-22 19:11:34', 6),
(83, '8JG8D', 'Ke tăng cứng', NULL, 1, 1, NULL, 1, NULL, 1, -58, 2, 0, NULL, '2026-03-13 08:22:10', 2),
(84, '72mB1', 'Ke vĩnh cữu 31x41 (cửa đi mở quay XF55)', NULL, 1, 1, NULL, 1, NULL, 1, -18, 2, 0, NULL, '2026-03-13 08:22:10', 2),
(85, '84Xe7', 'Bản lề lá 4D (khung và cánh) - DRAHO', NULL, 1, 1, NULL, 1, NULL, 1, -8, 2, 0, NULL, '2026-03-13 08:22:10', 2),
(86, '52vSl', 'Bản lề lá 4D (cánh và cánh) - DRAHO', NULL, 1, 1, NULL, 1, NULL, 1, -8, 2, 0, NULL, '2026-03-13 08:22:10', 2),
(87, '89mNQ', 'Tay nắm gạt cửa đi - DRAHO', NULL, 1, 1, NULL, 1, NULL, 1, -1, 3, 0, NULL, '2026-03-13 08:22:10', 2),
(88, '6difa', 'Thân khóa đa điểm - DRAHO', NULL, 1, 1, NULL, 1, NULL, 1, -1, 2, 0, NULL, '2026-03-13 08:22:10', 2),
(89, '8Yuzk', 'Miệng khóa - DRAHO', NULL, 1, 1, NULL, 1, NULL, 1, -1, 2, 0, NULL, '2026-03-13 08:22:10', 2),
(90, '2xP5l', 'Lõi khóa 2 đầu chìa - DRAHO', NULL, 1, 1, NULL, 1, NULL, 1, -1, 2, 0, NULL, '2026-03-13 08:22:10', 2),
(91, '54Nsi', 'Vấu hãm 2-4 cánh - DRAHO', NULL, 1, 1, NULL, 1, NULL, 1, -2, 2, 0, NULL, '2026-03-13 08:22:10', 2),
(92, '6BZkg', 'Đầu chốt cánh phụ - DRAHO', NULL, 1, 1, NULL, 1, NULL, 1, -6, 2, 0, NULL, '2026-03-13 08:22:10', 2),
(93, '3F0Yx', 'Hố chốt - DRAHO', NULL, 1, 1, NULL, 1, NULL, 1, -6, 2, 0, NULL, '2026-03-13 08:22:10', 2),
(94, '8b3es', 'Chốt bật 320 - DRAHO', NULL, 1, 1, NULL, 1, NULL, 1, -6, 2, 0, NULL, '2026-03-13 08:22:10', 2),
(95, '8kNiW', 'Đầu nối chuyển động - DRAHO', NULL, 1, 1, NULL, 1, NULL, 1, -2, 2, 0, NULL, '2026-03-13 08:22:10', 2),
(96, '9Q5Aj', 'Ke vĩnh cữu 14x51 2 vít (khung vách - khung cửa lùa XF55)', NULL, 1, 1, NULL, 1, NULL, 1, -44, 2, 0, NULL, '2026-03-13 08:22:10', 2),
(97, '3jEev', 'Pát liên kết đố chia vách XF55', NULL, 1, 1, NULL, 1, NULL, 1, -4, 2, 0, NULL, '2026-03-13 08:22:10', 2),
(98, '4K89C', 'Nắp bịt đố động cửa đi (các loại)', NULL, 2, 1, NULL, 1, NULL, 0, -3, 2, 0, NULL, '2026-03-13 08:22:10', 2),
(99, '8DVWk', 'Nắp bịt ốp chân cánh (các loại)', NULL, 2, 1, NULL, 1, NULL, 0, -5, 2, 0, NULL, '2026-03-13 08:22:10', 2),
(100, '11Zre', 'VTP Cửa đi mở quay 4 cánh (gioăng - nêm - keo - vít)', NULL, 2, 1, NULL, 1, NULL, 0, -5.26, 4, 0, NULL, '2026-03-13 08:22:10', 2),
(101, '5b3NK', 'VTP ô vách (gioăng - nêm - keo - vít)', NULL, 2, 1, NULL, 1, NULL, 0, -2.81, 4, 0, NULL, '2026-03-13 08:22:10', 2),
(102, '5fzNJ', 'Ke vĩnh cữu 14x25 (cánh cửa lùa hệ 55)', NULL, 1, 1, NULL, 1, NULL, 1, -40, 2, 0, NULL, '2026-03-13 08:22:16', 2),
(103, '1kfaW', 'Khóa sò - DRAHO', NULL, 1, 1, NULL, 1, NULL, 1, -5, 2, 0, NULL, '2026-03-13 08:22:16', 2),
(104, '5LzuF', 'Miệng khóa sò - DRAHO', NULL, 1, 1, NULL, 1, NULL, 1, -5, 2, 0, NULL, '2026-03-13 08:22:16', 2),
(105, '7XlEu', 'Bánh xe đôi - DRAHO', NULL, 1, 1, NULL, 1, NULL, 1, -20, 2, 0, NULL, '2026-03-13 08:22:16', 2),
(106, '9NWSY', 'Đệm chống nhấc cánh', NULL, 2, 1, NULL, 1, NULL, 0, -5, 2, 0, NULL, '2026-03-13 08:22:16', 2),
(107, '9Mxy3', 'Đệm chống rung (lắp cánh)', NULL, 2, 1, NULL, 1, NULL, 0, -20, 2, 0, NULL, '2026-03-13 08:22:16', 2),
(108, '1gIAv', 'Đệm chống rung (lắp khung)', NULL, 2, 1, NULL, 1, NULL, 0, -20, 2, 0, NULL, '2026-03-13 08:22:16', 2),
(109, '3HUQ6', 'VTP Cửa sổ trượt 2 cánh (gioăng - nêm - keo - vít)', NULL, 2, 1, NULL, 1, NULL, 0, -6.67, 4, 0, NULL, '2026-03-13 08:22:16', 2),
(110, '7LUaj', 'Bản lề sàn 180kg', NULL, 1, 1, NULL, 1, NULL, 1, 0, 5, 0, NULL, '2026-03-14 09:56:34', 2),
(111, '7g5ED', 'Khóa sàn cửa kính thủy lực', NULL, 1, 1, NULL, 1, NULL, 1, 0, 5, 0, NULL, '2026-03-14 09:56:34', 2),
(112, '5ca0j', 'Kẹp trên cửa kính thủy lực', NULL, 1, 1, NULL, 1, NULL, 1, 0, 2, 0, NULL, '2026-03-14 09:56:34', 2),
(113, '1YUPR', 'Kẹp dưới cửa kính thủy lực', NULL, 1, 1, NULL, 1, NULL, 1, 0, 2, 0, NULL, '2026-03-14 09:56:34', 2),
(114, '41lJ3', 'Tay nắm cửa thủy lực 1200', NULL, 1, 1, NULL, 1, NULL, 1, 0, 2, 0, NULL, '2026-03-14 09:56:34', 2),
(115, '3wjiZ', 'Kẹp chữ L cửa kính thủy lực', NULL, 1, 1, NULL, 1, NULL, 1, 0, 2, 0, NULL, '2026-03-14 09:56:34', 2),
(116, '75p2n', 'Thân khóa đơn điểm - DRAHO', NULL, 1, 1, NULL, 1, NULL, 1, 0, 2, 0, NULL, '2026-03-14 09:56:38', 2),
(117, '7YadH', 'Lõi khóa 1 đầu chìa 1 đầu bịt mở trong - DRAHO', NULL, 1, 1, NULL, 1, NULL, 1, 0, 2, 0, NULL, '2026-03-14 09:56:38', 2),
(118, '2ChFt', 'VTP Cửa đi mở quay 1 cánh (gioăng - nêm - keo - vít)', NULL, 2, 1, NULL, 1, NULL, 0, 0, 4, 0, NULL, '2026-03-14 09:56:38', 2);

-- --------------------------------------------------------

--
-- Table structure for table `cua_kho_vat_tu_lich_su`
--

DROP TABLE IF EXISTS `cua_kho_vat_tu_lich_su`;
CREATE TABLE IF NOT EXISTS `cua_kho_vat_tu_lich_su` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_kho_vat_tu` int NOT NULL,
  `id_nha_cung_cap` int DEFAULT NULL,
  `ghi_chu` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `so_luong` float DEFAULT NULL,
  `so_luong_cu` float DEFAULT NULL,
  `so_luong_moi` float DEFAULT NULL,
  `id_mau_cua` int DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_kho_vat_tu` (`id_kho_vat_tu`),
  KEY `id_nha_cung_cap` (`id_nha_cung_cap`)
) ENGINE=InnoDB AUTO_INCREMENT=579 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `cua_kho_vat_tu_lich_su`
--

INSERT INTO `cua_kho_vat_tu_lich_su` (`id`, `id_kho_vat_tu`, `id_nha_cung_cap`, `ghi_chu`, `so_luong`, `so_luong_cu`, `so_luong_moi`, `id_mau_cua`, `date_created`, `user_created`) VALUES
(187, 1, 1, 'Nhập số lượng khi thêm mới vào kho', 287, 0, 287, NULL, '2025-09-26 16:53:33', 1),
(188, 2, 1, 'Nhập số lượng khi thêm mới vào kho', 86, 0, 86, NULL, '2025-09-26 16:53:33', 1),
(189, 3, 1, 'Nhập số lượng khi thêm mới vào kho', 77, 0, 77, NULL, '2025-09-26 16:53:33', 1),
(190, 4, 1, 'Nhập số lượng khi thêm mới vào kho', 86, 0, 86, NULL, '2025-09-26 16:53:33', 1),
(191, 5, 1, 'Nhập số lượng khi thêm mới vào kho', 38, 0, 38, NULL, '2025-09-26 16:53:33', 1),
(192, 6, 1, 'Nhập số lượng khi thêm mới vào kho', 87, 0, 87, NULL, '2025-09-26 16:53:33', 1),
(193, 7, 1, 'Nhập số lượng khi thêm mới vào kho', 20, 0, 20, NULL, '2025-09-26 16:53:33', 1),
(194, 8, 1, 'Nhập số lượng khi thêm mới vào kho', 143, 0, 143, NULL, '2025-09-26 16:53:33', 1),
(195, 9, 1, 'Nhập số lượng khi thêm mới vào kho', 42, 0, 42, NULL, '2025-09-26 16:53:33', 1),
(196, 10, 1, 'Nhập số lượng khi thêm mới vào kho', 29, 0, 29, NULL, '2025-09-26 16:53:33', 1),
(197, 11, 1, 'Nhập số lượng khi thêm mới vào kho', 26, 0, 26, NULL, '2025-09-26 16:53:33', 1),
(198, 12, 1, 'Nhập số lượng khi thêm mới vào kho', 34, 0, 34, NULL, '2025-09-26 16:53:33', 1),
(199, 12, NULL, 'Ghi đè tồn kho khi nhập excel', -25, 34, 9, NULL, '2025-09-26 16:53:33', 1),
(200, 13, 1, 'Nhập số lượng khi thêm mới vào kho', 8, 0, 8, NULL, '2025-09-26 16:53:33', 1),
(201, 14, 1, 'Nhập số lượng khi thêm mới vào kho', 19, 0, 19, NULL, '2025-09-26 16:53:33', 1),
(202, 15, 1, 'Nhập số lượng khi thêm mới vào kho', 1, 0, 1, NULL, '2025-09-26 16:53:33', 1),
(203, 16, 1, 'Nhập số lượng khi thêm mới vào kho', 60, 0, 60, NULL, '2025-09-26 16:53:33', 1),
(204, 17, 1, 'Nhập số lượng khi thêm mới vào kho', 88, 0, 88, NULL, '2025-09-26 16:53:33', 1),
(205, 18, 1, 'Nhập số lượng khi thêm mới vào kho', 30, 0, 30, NULL, '2025-09-26 16:53:33', 1),
(206, 19, 1, 'Nhập số lượng khi thêm mới vào kho', 52, 0, 52, NULL, '2025-09-26 16:53:33', 1),
(207, 20, 1, 'Nhập số lượng khi thêm mới vào kho', 25, 0, 25, NULL, '2025-09-26 16:53:33', 1),
(208, 21, 1, 'Nhập số lượng khi thêm mới vào kho', 66, 0, 66, NULL, '2025-09-26 16:53:33', 1),
(209, 22, 1, 'Nhập số lượng khi thêm mới vào kho', 196, 0, 196, NULL, '2025-09-26 16:53:33', 1),
(210, 23, 1, 'Nhập số lượng khi thêm mới vào kho', 406, 0, 406, NULL, '2025-09-26 16:53:33', 1),
(211, 24, 1, 'Nhập số lượng khi thêm mới vào kho', 117, 0, 117, NULL, '2025-09-26 16:53:33', 1),
(212, 25, 1, 'Nhập số lượng khi thêm mới vào kho', 10, 0, 10, NULL, '2025-09-26 16:53:33', 1),
(213, 26, 1, 'Nhập số lượng khi thêm mới vào kho', 102, 0, 102, NULL, '2025-09-26 16:53:33', 1),
(214, 27, 1, 'Nhập số lượng khi thêm mới vào kho', 157, 0, 157, NULL, '2025-09-26 16:53:33', 1),
(215, 28, 1, 'Nhập số lượng khi thêm mới vào kho', 77, 0, 77, NULL, '2025-09-26 16:53:33', 1),
(216, 29, 1, 'Nhập số lượng khi thêm mới vào kho', 55, 0, 55, NULL, '2025-09-26 16:53:33', 1),
(217, 30, 1, 'Nhập số lượng khi thêm mới vào kho', 72, 0, 72, NULL, '2025-09-26 16:53:33', 1),
(218, 31, 1, 'Nhập số lượng khi thêm mới vào kho', 29, 0, 29, NULL, '2025-09-26 16:53:33', 1),
(219, 32, 1, 'Nhập số lượng khi thêm mới vào kho', 80, 0, 80, NULL, '2025-09-26 16:53:33', 1),
(220, 33, 1, 'Nhập số lượng khi thêm mới vào kho', 10, 0, 10, NULL, '2025-09-26 16:53:33', 1),
(221, 34, 1, 'Nhập số lượng khi thêm mới vào kho', 117, 0, 117, NULL, '2025-09-26 16:53:33', 1),
(222, 35, 1, 'Nhập số lượng khi thêm mới vào kho', 181, 0, 181, NULL, '2025-09-26 16:53:33', 1),
(223, 36, 1, 'Nhập số lượng khi thêm mới vào kho', 37, 0, 37, NULL, '2025-10-01 09:23:03', 1),
(224, 37, 1, 'Nhập số lượng khi thêm mới vào kho', 17, 0, 17, NULL, '2025-10-01 09:23:03', 1),
(225, 38, 1, 'Nhập số lượng khi thêm mới vào kho', 32, 0, 32, NULL, '2025-10-01 09:23:04', 1),
(226, 39, 1, 'Nhập số lượng khi thêm mới vào kho', 27, 0, 27, NULL, '2025-10-01 09:23:04', 1),
(227, 40, 1, 'Nhập số lượng khi thêm mới vào kho', 19, 0, 19, NULL, '2025-10-01 09:23:04', 1),
(228, 41, 1, 'Nhập số lượng khi thêm mới vào kho', 19, 0, 19, NULL, '2025-10-01 09:23:04', 1),
(229, 42, 1, 'Nhập số lượng khi thêm mới vào kho', 9, 0, 9, NULL, '2025-10-01 09:23:04', 1),
(230, 43, 1, 'Nhập số lượng khi thêm mới vào kho', 3, 0, 3, NULL, '2025-10-01 09:23:04', 1),
(231, 44, 1, 'Nhập số lượng khi thêm mới vào kho', 26, 0, 26, NULL, '2025-10-01 09:23:04', 1),
(232, 45, 1, 'Nhập số lượng khi thêm mới vào kho', 21, 0, 21, NULL, '2025-10-01 09:23:04', 1),
(233, 46, 1, 'Nhập số lượng khi thêm mới vào kho', 60, 0, 60, NULL, '2025-10-01 09:23:04', 1),
(234, 47, 1, 'Nhập số lượng khi thêm mới vào kho', 34, 0, 34, NULL, '2025-10-01 09:23:04', 1),
(235, 48, 1, 'Nhập số lượng khi thêm mới vào kho', 11, 0, 11, NULL, '2025-10-01 09:23:04', 1),
(236, 48, NULL, 'Ghi đè tồn kho khi nhập excel', 7, 11, 18, NULL, '2025-10-01 09:23:04', 1),
(237, 49, 1, 'Nhập số lượng khi thêm mới vào kho', 30, 0, 30, NULL, '2025-10-01 09:23:04', 1),
(238, 50, 1, 'Nhập số lượng khi thêm mới vào kho', 28, 0, 28, NULL, '2025-10-01 09:23:04', 1),
(239, 51, 1, 'Nhập số lượng khi thêm mới vào kho', 21, 0, 21, NULL, '2025-10-01 09:23:04', 1),
(240, 52, 1, 'Nhập số lượng khi thêm mới vào kho', 13, 0, 13, NULL, '2025-10-01 09:23:04', 1),
(241, 53, 1, 'Nhập số lượng khi thêm mới vào kho', 11, 0, 11, NULL, '2025-10-01 09:23:04', 1),
(242, 54, 1, 'Nhập số lượng khi thêm mới vào kho', 4, 0, 4, NULL, '2025-10-01 09:23:04', 1),
(243, 55, 1, 'Nhập số lượng khi thêm mới vào kho', 5, 0, 5, NULL, '2025-10-01 09:23:04', 1),
(244, 56, 1, 'Nhập số lượng khi thêm mới vào kho', 14, 0, 14, NULL, '2025-10-01 09:23:04', 1),
(245, 57, 1, 'Nhập số lượng khi thêm mới vào kho', 8, 0, 8, NULL, '2025-10-01 09:23:04', 1),
(246, 58, 1, 'Nhập số lượng khi thêm mới vào kho', 6, 0, 6, NULL, '2025-10-01 09:23:04', 1),
(247, 59, 1, 'Nhập số lượng khi thêm mới vào kho', 7, 0, 7, NULL, '2025-10-01 09:23:04', 1),
(248, 60, 1, 'Nhập số lượng khi thêm mới vào kho', 5, 0, 5, NULL, '2025-10-01 09:23:04', 1),
(249, 61, 1, 'Nhập số lượng khi thêm mới vào kho', 3, 0, 3, NULL, '2025-10-01 09:23:04', 1),
(250, 62, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2025-10-01 09:23:04', 1),
(251, 63, 1, 'Nhập số lượng khi thêm mới vào kho', 43, 0, 43, NULL, '2025-10-01 09:23:04', 1),
(252, 64, 1, 'Nhập số lượng khi thêm mới vào kho', 20, 0, 20, NULL, '2025-10-01 09:23:04', 1),
(253, 65, 1, 'Nhập số lượng khi thêm mới vào kho', 19, 0, 19, NULL, '2025-10-01 09:23:04', 1),
(254, 66, 1, 'Nhập số lượng khi thêm mới vào kho', 51, 0, 51, NULL, '2025-10-01 09:23:04', 1),
(255, 67, 1, 'Nhập số lượng khi thêm mới vào kho', 36, 0, 36, NULL, '2025-10-01 09:23:04', 1),
(256, 68, 1, 'Nhập số lượng khi thêm mới vào kho', 28, 0, 28, NULL, '2025-10-01 09:24:15', 1),
(257, 32, 1, 'Xuất kho theo đơn hàng bán lẻ HD00002/2025', -2, 80, 78, NULL, '2025-10-03 22:13:27', 6),
(258, 35, 1, 'Xuất kho theo đơn hàng bán lẻ HD00002/2025', -4, 181, 177, NULL, '2025-10-03 22:13:27', 6),
(259, 34, 1, 'Xuất kho theo đơn hàng bán lẻ HD00002/2025', -2, 117, 115, NULL, '2025-10-03 22:13:27', 6),
(260, 11, 1, 'Xuất kho theo đơn hàng bán lẻ HD00002/2025', -2, 26, 24, NULL, '2025-10-03 22:13:27', 6),
(261, 19, 1, 'Xuất kho theo đơn hàng bán lẻ HD00002/2025', -4, 52, 48, NULL, '2025-10-03 22:13:27', 6),
(262, 25, NULL, '', 50, 10, 60, NULL, '2025-10-03 22:19:21', 6),
(263, 28, NULL, '', 50, 77, 127, NULL, '2025-10-03 22:20:45', 6),
(264, 35, NULL, '', 100, 177, 277, NULL, '2025-10-03 22:21:30', 6),
(265, 9, NULL, '', 36, 42, 78, NULL, '2025-10-03 22:21:53', 6),
(266, 7, NULL, '', 40, 20, 60, NULL, '2025-10-03 22:22:47', 6),
(267, 6, NULL, '', 60, 87, 147, NULL, '2025-10-03 22:23:05', 6),
(268, 3, NULL, '', 30, 77, 107, NULL, '2025-10-03 22:24:17', 6),
(269, 69, 1, 'Nhập số lượng khi thêm mới vào kho', 60, 0, 60, NULL, '2025-10-03 22:26:03', 6),
(270, 63, 1, 'Xuất kho theo đơn hàng bán lẻ HD00003/2025', -18, 43, 25, NULL, '2025-10-05 21:36:40', 6),
(271, 11, 1, 'Xuất kho theo đơn hàng bán lẻ HD00003/2025', -2, 24, 22, NULL, '2025-10-05 21:36:40', 6),
(272, 68, 1, 'Xuất kho theo đơn hàng bán lẻ HD00003/2025', -2, 28, 26, NULL, '2025-10-05 21:36:40', 6),
(273, 47, 1, 'Xuất kho theo đơn hàng bán lẻ HD00003/2025', -2, 34, 32, NULL, '2025-10-05 21:36:40', 6),
(274, 67, 1, 'Xuất kho theo đơn hàng bán lẻ HD00003/2025', -4, 36, 32, NULL, '2025-10-05 21:36:40', 6),
(275, 22, 1, 'Xuất kho theo đơn hàng bán lẻ HD00003/2025', -2, 196, 194, NULL, '2025-10-05 21:36:40', 6),
(276, 36, 1, 'Xuất kho theo đơn hàng bán lẻ HD00003/2025', -9, 37, 28, NULL, '2025-10-05 21:36:40', 6),
(277, 59, 1, 'Xuất kho theo đơn hàng bán lẻ HD00003/2025', -3, 7, 4, NULL, '2025-10-05 21:36:40', 6),
(278, 53, 1, 'Xuất kho theo đơn hàng bán lẻ HD00003/2025', -3, 11, 8, NULL, '2025-10-05 21:36:40', 6),
(279, 66, 1, 'Xuất kho theo đơn hàng bán lẻ HD00003/2025', -3, 51, 48, NULL, '2025-10-05 21:36:40', 6),
(280, 64, 1, 'Xuất kho theo đơn hàng bán lẻ HD00003/2025', -8, 20, 12, NULL, '2025-10-05 21:36:40', 6),
(281, 49, 1, 'Xuất kho theo đơn hàng bán lẻ HD00003/2025', -4, 30, 26, NULL, '2025-10-05 21:36:41', 6),
(282, 3, NULL, '', 90, 107, 197, NULL, '2025-10-06 21:25:20', 6),
(283, 18, NULL, '', 25, 30, 55, NULL, '2025-10-06 21:25:53', 6),
(284, 16, NULL, '', 50, 60, 110, NULL, '2025-10-06 21:26:04', 6),
(285, 21, NULL, '', 24, 66, 90, NULL, '2025-10-06 21:27:03', 6),
(286, 8, NULL, '', 36, 143, 179, NULL, '2025-10-06 21:27:59', 6),
(287, 70, 1, 'Nhập số lượng khi thêm mới vào kho', 40, 0, 40, NULL, '2025-10-06 21:29:59', 6),
(288, 71, 1, 'Nhập số lượng khi thêm mới vào kho', 40, 0, 40, NULL, '2025-10-06 21:30:35', 6),
(289, 63, NULL, '', 100, 25, 125, NULL, '2025-10-06 21:32:50', 6),
(290, 64, NULL, '', 100, 12, 112, NULL, '2025-10-06 21:33:12', 6),
(291, 66, NULL, '', 10, 48, 58, NULL, '2025-10-06 21:35:08', 6),
(292, 59, NULL, '', 10, 4, 14, NULL, '2025-10-06 21:35:46', 6),
(293, 36, NULL, '', 30, 28, 58, NULL, '2025-10-06 21:36:28', 6),
(294, 49, NULL, '', 20, 26, 46, NULL, '2025-10-06 21:36:57', 6),
(295, 72, 1, 'Nhập số lượng khi thêm mới vào kho', 20, 0, 20, NULL, '2025-10-06 21:38:12', 6),
(296, 36, 1, 'Xuất kho theo đơn hàng bán lẻ HD00004/2025', -16, 58, 42, NULL, '2025-10-06 21:40:27', 6),
(297, 60, 1, 'Xuất kho theo đơn hàng bán lẻ HD00004/2025', -2, 5, 3, NULL, '2025-10-06 21:40:27', 6),
(298, 65, 1, 'Xuất kho theo đơn hàng bán lẻ HD00004/2025', -2, 19, 17, NULL, '2025-10-06 21:40:27', 6),
(299, 57, 1, 'Xuất kho theo đơn hàng bán lẻ HD00004/2025', -2, 8, 6, NULL, '2025-10-06 21:40:27', 6),
(300, 47, 1, 'Xuất kho theo đơn hàng bán lẻ HD00004/2025', -2, 32, 30, NULL, '2025-10-06 21:40:27', 6),
(301, 67, 1, 'Xuất kho theo đơn hàng bán lẻ HD00004/2025', -4, 32, 28, NULL, '2025-10-06 21:40:27', 6),
(302, 23, 1, 'Xuất kho theo đơn hàng bán lẻ HD00004/2025', -2, 406, 404, NULL, '2025-10-06 21:40:27', 6),
(303, 45, 1, 'Xuất kho theo đơn hàng bán lẻ HD00004/2025', -1, 21, 20, NULL, '2025-10-06 21:40:27', 6),
(304, 46, 1, 'Xuất kho theo đơn hàng bán lẻ HD00004/2025', -2, 60, 58, NULL, '2025-10-06 21:40:27', 6),
(305, 1, 1, 'Xuất kho theo đơn hàng bán lẻ HD00005/2025', -9, 287, 278, NULL, '2025-10-09 10:04:56', 6),
(306, 16, 1, 'Xuất kho theo đơn hàng bán lẻ HD00005/2025', -3, 110, 107, NULL, '2025-10-09 10:04:56', 6),
(307, 8, 1, 'Xuất kho theo đơn hàng bán lẻ HD00005/2025', -3, 179, 176, NULL, '2025-10-09 10:04:56', 6),
(308, 28, 1, 'Xuất kho theo đơn hàng bán lẻ HD00005/2025', -3, 127, 124, NULL, '2025-10-09 10:04:56', 6),
(309, 6, 1, 'Xuất kho theo đơn hàng bán lẻ HD00005/2025', -3, 147, 144, NULL, '2025-10-09 10:04:56', 6),
(310, 32, 1, 'Xuất kho theo đơn hàng bán lẻ HD00005/2025', -5, 78, 73, NULL, '2025-10-09 10:04:56', 6),
(311, 35, 1, 'Xuất kho theo đơn hàng bán lẻ HD00005/2025', -10, 277, 267, NULL, '2025-10-09 10:04:56', 6),
(312, 12, 1, 'Xuất kho theo đơn hàng bán lẻ HD00005/2025', -6, 9, 3, NULL, '2025-10-09 10:04:56', 6),
(313, 11, 1, 'Xuất kho theo đơn hàng bán lẻ HD00005/2025', -1, 22, 21, NULL, '2025-10-09 10:04:56', 6),
(314, 21, 1, 'Xuất kho theo đơn hàng bán lẻ HD00005/2025', -12, 90, 78, NULL, '2025-10-09 10:04:56', 6),
(315, 27, 1, 'Xuất kho theo đơn hàng bán lẻ HD00005/2025', -2, 157, 155, NULL, '2025-10-09 10:04:56', 6),
(316, 26, 1, 'Xuất kho theo đơn hàng bán lẻ HD00005/2025', -2, 102, 100, NULL, '2025-10-09 10:04:56', 6),
(317, 24, 1, 'Xuất kho theo đơn hàng bán lẻ HD00005/2025', -2, 117, 115, NULL, '2025-10-09 10:04:56', 6),
(318, 25, 1, 'Xuất kho theo đơn hàng bán lẻ HD00005/2025', -2, 60, 58, NULL, '2025-10-09 10:04:56', 6),
(319, 22, 1, 'Xuất kho theo đơn hàng bán lẻ HD00005/2025', -1, 194, 193, NULL, '2025-10-09 10:04:56', 6),
(320, 23, 1, 'Xuất kho theo đơn hàng bán lẻ HD00005/2025', -1, 404, 403, NULL, '2025-10-09 10:04:56', 6),
(321, 25, NULL, '', 30, 58, 88, NULL, '2025-10-23 20:59:40', 6),
(322, 24, NULL, '', 30, 115, 145, NULL, '2025-10-23 21:00:14', 6),
(323, 3, NULL, '', 240, 197, 437, NULL, '2025-10-23 21:00:40', 6),
(324, 1, NULL, '', 30, 278, 308, NULL, '2025-10-23 21:01:02', 6),
(325, 1, 1, 'Xuất kho theo đơn hàng bán lẻ HD00006/2025', -120, 308, 188, NULL, '2025-10-23 21:09:30', 6),
(326, 28, 1, 'Xuất kho theo đơn hàng bán lẻ HD00006/2025', -30, 124, 94, NULL, '2025-10-23 21:09:30', 6),
(327, 30, 1, 'Xuất kho theo đơn hàng bán lẻ HD00006/2025', -10, 72, 62, NULL, '2025-10-23 21:09:30', 6),
(328, 34, 1, 'Xuất kho theo đơn hàng bán lẻ HD00006/2025', -10, 115, 105, NULL, '2025-10-23 21:09:30', 6),
(329, 16, 1, 'Xuất kho theo đơn hàng bán lẻ HD00006/2025', -10, 107, 97, NULL, '2025-10-23 21:09:30', 6),
(330, 17, 1, 'Xuất kho theo đơn hàng bán lẻ HD00006/2025', -10, 88, 78, NULL, '2025-10-23 21:09:30', 6),
(331, 8, 1, 'Xuất kho theo đơn hàng bán lẻ HD00006/2025', -20, 176, 156, NULL, '2025-10-23 21:09:30', 6),
(332, 24, 1, 'Xuất kho theo đơn hàng bán lẻ HD00006/2025', -30, 145, 115, NULL, '2025-10-23 21:09:30', 6),
(333, 25, 1, 'Xuất kho theo đơn hàng bán lẻ HD00006/2025', -30, 88, 58, NULL, '2025-10-23 21:09:30', 6),
(334, 6, 1, 'Xuất kho theo đơn hàng bán lẻ HD00007/2025', -15, 144, 129, NULL, '2025-10-25 09:22:46', 6),
(335, 16, NULL, '', 20, 97, 117, NULL, '2025-10-29 13:58:23', 6),
(336, 17, NULL, '', 20, 78, 98, NULL, '2025-10-29 13:59:05', 6),
(337, 8, NULL, '', 20, 156, 176, NULL, '2025-10-29 13:59:29', 6),
(338, 25, NULL, '', 10, 58, 68, NULL, '2025-10-29 13:59:56', 6),
(339, 24, NULL, '', 10, 115, 125, NULL, '2025-10-29 14:00:18', 6),
(340, 73, 1, 'Nhập số lượng khi thêm mới vào kho', 30, 0, 30, NULL, '2025-10-29 14:02:00', 6),
(341, 3, 1, 'Xuất kho theo đơn hàng bán lẻ HD00008/2025', -150, 437, 287, NULL, '2025-10-29 14:08:34', 6),
(342, 9, 1, 'Xuất kho theo đơn hàng bán lẻ HD00008/2025', -5, 78, 73, NULL, '2025-10-29 14:08:34', 6),
(343, 8, 1, 'Xuất kho theo đơn hàng bán lẻ HD00008/2025', -30, 176, 146, NULL, '2025-10-29 14:08:34', 6),
(344, 7, 1, 'Xuất kho theo đơn hàng bán lẻ HD00008/2025', -15, 60, 45, NULL, '2025-10-29 14:08:34', 6),
(345, 25, 1, 'Xuất kho theo đơn hàng bán lẻ HD00008/2025', -30, 68, 38, NULL, '2025-10-29 14:08:34', 6),
(346, 24, 1, 'Xuất kho theo đơn hàng bán lẻ HD00008/2025', -30, 125, 95, NULL, '2025-10-29 14:08:34', 6),
(347, 28, 1, 'Xuất kho theo đơn hàng bán lẻ HD00008/2025', -30, 94, 64, NULL, '2025-10-29 14:08:34', 6),
(348, 29, 1, 'Xuất kho theo đơn hàng bán lẻ HD00008/2025', -10, 55, 45, NULL, '2025-10-29 14:08:34', 6),
(349, 16, 1, 'Xuất kho theo đơn hàng bán lẻ HD00008/2025', -20, 117, 97, NULL, '2025-10-29 14:08:34', 6),
(350, 17, 1, 'Xuất kho theo đơn hàng bán lẻ HD00008/2025', -10, 98, 88, NULL, '2025-10-29 14:08:34', 6),
(351, 31, 1, 'Xuất kho theo đơn hàng bán lẻ HD00008/2025', -30, 29, -1, NULL, '2025-10-29 14:08:34', 6),
(352, 34, 1, 'Xuất kho theo đơn hàng bán lẻ HD00008/2025', -30, 105, 75, NULL, '2025-10-29 14:08:34', 6),
(353, 3, NULL, '', 150, 287, 437, NULL, '2025-10-30 09:33:45', 6),
(354, 7, NULL, '', 50, 45, 95, NULL, '2025-10-30 09:34:28', 6),
(355, 25, NULL, '', 100, 38, 138, NULL, '2025-10-30 09:35:04', 6),
(356, 24, NULL, '', 100, 95, 195, NULL, '2025-10-30 09:35:34', 6),
(357, 28, NULL, '', 30, 64, 94, NULL, '2025-10-30 09:35:52', 6),
(358, 17, NULL, '', 10, 88, 98, NULL, '2025-10-30 09:36:15', 6),
(359, 31, NULL, '', 50, -1, 49, NULL, '2025-10-30 09:38:08', 6),
(360, 34, NULL, '', 20, 75, 95, NULL, '2025-10-30 09:38:27', 6),
(361, 7, NULL, '', 40, 95, 135, NULL, '2025-11-11 17:50:41', 6),
(362, 3, 1, 'Xuất kho theo đơn hàng bán lẻ HD00009/2025', -9, 437, 428, NULL, '2025-11-13 09:35:38', 6),
(363, 6, 1, 'Xuất kho theo đơn hàng bán lẻ HD00009/2025', -3, 129, 126, NULL, '2025-11-13 09:35:38', 6),
(364, 8, 1, 'Xuất kho theo đơn hàng bán lẻ HD00009/2025', -3, 146, 143, NULL, '2025-11-13 09:35:38', 6),
(365, 16, 1, 'Xuất kho theo đơn hàng bán lẻ HD00009/2025', -3, 97, 94, NULL, '2025-11-13 09:35:38', 6),
(366, 28, 1, 'Xuất kho theo đơn hàng bán lẻ HD00009/2025', -3, 94, 91, NULL, '2025-11-13 09:35:38', 6),
(367, 1, 1, 'Xuất kho theo đơn hàng bán lẻ HD00010/2025', -11, 188, 177, NULL, '2025-11-13 09:45:58', 6),
(368, 4, 1, 'Xuất kho theo đơn hàng bán lẻ HD00010/2025', -8, 86, 78, NULL, '2025-11-13 09:45:58', 6),
(369, 6, 1, 'Xuất kho theo đơn hàng bán lẻ HD00010/2025', -2, 126, 124, NULL, '2025-11-13 09:45:58', 6),
(370, 9, 1, 'Xuất kho theo đơn hàng bán lẻ HD00010/2025', -1, 73, 72, NULL, '2025-11-13 09:45:58', 6),
(371, 18, 1, 'Xuất kho theo đơn hàng bán lẻ HD00010/2025', -1, 55, 54, NULL, '2025-11-13 09:45:58', 6),
(372, 29, 1, 'Xuất kho theo đơn hàng bán lẻ HD00010/2025', -1, 45, 44, NULL, '2025-11-13 09:45:58', 6),
(373, 27, 1, 'Xuất kho theo đơn hàng bán lẻ HD00010/2025', -2, 155, 153, NULL, '2025-11-13 09:45:58', 6),
(374, 26, 1, 'Xuất kho theo đơn hàng bán lẻ HD00010/2025', -2, 100, 98, NULL, '2025-11-13 09:45:58', 6),
(375, 24, 1, 'Xuất kho theo đơn hàng bán lẻ HD00010/2025', -6, 195, 189, NULL, '2025-11-13 09:45:58', 6),
(376, 25, 1, 'Xuất kho theo đơn hàng bán lẻ HD00010/2025', -6, 138, 132, NULL, '2025-11-13 09:45:58', 6),
(377, 22, 1, 'Xuất kho theo đơn hàng bán lẻ HD00010/2025', -3, 193, 190, NULL, '2025-11-13 09:45:58', 6),
(378, 23, 1, 'Xuất kho theo đơn hàng bán lẻ HD00010/2025', -3, 403, 400, NULL, '2025-11-13 09:45:58', 6),
(379, 16, 1, 'Xuất kho theo đơn hàng bán lẻ HD00010/2025', -1, 94, 93, NULL, '2025-11-13 09:45:58', 6),
(380, 28, 1, 'Xuất kho theo đơn hàng bán lẻ HD00010/2025', -1, 91, 90, NULL, '2025-11-13 09:45:58', 6),
(381, 8, 1, 'Xuất kho theo đơn hàng bán lẻ HD00010/2025', -1, 143, 142, NULL, '2025-11-13 09:45:58', 6),
(382, 5, 1, 'Xuất kho theo đơn hàng bán lẻ HD00011/2025', -1, 38, 37, NULL, '2025-11-13 09:51:37', 6),
(383, 9, 1, 'Xuất kho theo đơn hàng bán lẻ HD00011/2025', -1, 72, 71, NULL, '2025-11-13 09:51:37', 6),
(384, 18, 1, 'Xuất kho theo đơn hàng bán lẻ HD00011/2025', -1, 54, 53, NULL, '2025-11-13 09:51:38', 6),
(385, 29, 1, 'Xuất kho theo đơn hàng bán lẻ HD00011/2025', -1, 44, 43, NULL, '2025-11-13 09:51:38', 6),
(386, 27, 1, 'Xuất kho theo đơn hàng bán lẻ HD00011/2025', -2, 153, 151, NULL, '2025-11-13 09:51:38', 6),
(387, 26, 1, 'Xuất kho theo đơn hàng bán lẻ HD00011/2025', -2, 98, 96, NULL, '2025-11-13 09:51:38', 6),
(388, 24, 1, 'Xuất kho theo đơn hàng bán lẻ HD00011/2025', -6, 189, 183, NULL, '2025-11-13 09:51:38', 6),
(389, 25, 1, 'Xuất kho theo đơn hàng bán lẻ HD00011/2025', -6, 132, 126, NULL, '2025-11-13 09:51:38', 6),
(390, 22, 1, 'Xuất kho theo đơn hàng bán lẻ HD00011/2025', -3, 190, 187, NULL, '2025-11-13 09:51:38', 6),
(391, 23, 1, 'Xuất kho theo đơn hàng bán lẻ HD00011/2025', -3, 400, 397, NULL, '2025-11-13 09:51:38', 6),
(392, 35, 1, 'Xuất kho theo đơn hàng bán lẻ HD00011/2025', -4, 267, 263, NULL, '2025-11-13 09:51:38', 6),
(393, 32, 1, 'Xuất kho theo đơn hàng bán lẻ HD00011/2025', -1, 73, 72, NULL, '2025-11-13 09:51:38', 6),
(394, 34, 1, 'Xuất kho theo đơn hàng bán lẻ HD00011/2025', -1, 95, 94, NULL, '2025-11-13 09:51:38', 6),
(395, 4, 1, 'Xuất kho theo đơn hàng bán lẻ HD00012/2025', -9, 78, 69, NULL, '2025-11-13 09:59:32', 6),
(396, 5, 1, 'Xuất kho theo đơn hàng bán lẻ HD00012/2025', -3, 37, 34, NULL, '2025-11-13 09:59:32', 6),
(397, 8, 1, 'Xuất kho theo đơn hàng bán lẻ HD00012/2025', -3, 142, 139, NULL, '2025-11-13 09:59:32', 6),
(398, 16, 1, 'Xuất kho theo đơn hàng bán lẻ HD00012/2025', -1, 93, 92, NULL, '2025-11-13 09:59:32', 6),
(399, 17, 1, 'Xuất kho theo đơn hàng bán lẻ HD00012/2025', -2, 98, 96, NULL, '2025-11-13 09:59:32', 6),
(400, 28, 1, 'Xuất kho theo đơn hàng bán lẻ HD00012/2025', -3, 90, 87, NULL, '2025-11-13 09:59:32', 6),
(401, 3, 1, 'Xuất kho theo đơn hàng bán lẻ HD00013/2025', -9, 428, 419, NULL, '2025-11-13 10:08:31', 6),
(402, 6, 1, 'Xuất kho theo đơn hàng bán lẻ HD00013/2025', -2, 124, 122, NULL, '2025-11-13 10:08:31', 6),
(403, 9, 1, 'Xuất kho theo đơn hàng bán lẻ HD00013/2025', -1, 71, 70, NULL, '2025-11-13 10:08:31', 6),
(404, 8, 1, 'Xuất kho theo đơn hàng bán lẻ HD00013/2025', -1, 139, 138, NULL, '2025-11-13 10:08:31', 6),
(405, 18, 1, 'Xuất kho theo đơn hàng bán lẻ HD00013/2025', -1, 53, 52, NULL, '2025-11-13 10:08:31', 6),
(406, 16, 1, 'Xuất kho theo đơn hàng bán lẻ HD00013/2025', -1, 92, 91, NULL, '2025-11-13 10:08:31', 6),
(407, 28, 1, 'Xuất kho theo đơn hàng bán lẻ HD00013/2025', -1, 87, 86, NULL, '2025-11-13 10:08:31', 6),
(408, 29, 1, 'Xuất kho theo đơn hàng bán lẻ HD00013/2025', -1, 43, 42, NULL, '2025-11-13 10:08:31', 6),
(409, 27, 1, 'Xuất kho theo đơn hàng bán lẻ HD00013/2025', -2, 151, 149, NULL, '2025-11-13 10:08:31', 6),
(410, 26, 1, 'Xuất kho theo đơn hàng bán lẻ HD00013/2025', -2, 96, 94, NULL, '2025-11-13 10:08:31', 6),
(411, 24, 1, 'Xuất kho theo đơn hàng bán lẻ HD00013/2025', -2, 183, 181, NULL, '2025-11-13 10:08:31', 6),
(412, 25, 1, 'Xuất kho theo đơn hàng bán lẻ HD00013/2025', -2, 126, 124, NULL, '2025-11-13 10:08:31', 6),
(413, 22, 1, 'Xuất kho theo đơn hàng bán lẻ HD00013/2025', -1, 187, 186, NULL, '2025-11-13 10:08:31', 6),
(414, 23, 1, 'Xuất kho theo đơn hàng bán lẻ HD00013/2025', -1, 397, 396, NULL, '2025-11-13 10:08:31', 6),
(415, 35, 1, 'Xuất kho theo đơn hàng bán lẻ HD00013/2025', -8, 263, 255, NULL, '2025-11-13 10:08:31', 6),
(416, 31, 1, 'Xuất kho theo đơn hàng bán lẻ HD00013/2025', -2, 49, 47, NULL, '2025-11-13 10:08:31', 6),
(417, 34, 1, 'Xuất kho theo đơn hàng bán lẻ HD00013/2025', -2, 94, 92, NULL, '2025-11-13 10:08:31', 6),
(418, 28, NULL, '', 100, 86, 186, NULL, '2025-11-16 21:07:41', 6),
(419, 16, NULL, '', 60, 91, 151, NULL, '2025-11-16 21:08:01', 6),
(420, 7, NULL, '', 80, 135, 215, NULL, '2025-11-16 21:08:42', 6),
(421, 3, NULL, '', 105, 419, 524, NULL, '2025-11-16 21:09:08', 6),
(422, 30, 1, 'Xuất kho theo đơn hàng bán lẻ HD00014/2025', -4, 62, 58, NULL, '2025-11-16 21:17:50', 6),
(423, 34, 1, 'Xuất kho theo đơn hàng bán lẻ HD00014/2025', -4, 92, 88, NULL, '2025-11-16 21:17:50', 6),
(424, 35, 1, 'Xuất kho theo đơn hàng bán lẻ HD00014/2025', -16, 255, 239, NULL, '2025-11-16 21:17:50', 6),
(425, 2, 1, 'Xuất kho theo đơn hàng bán lẻ HD00014/2025', -6, 86, 80, NULL, '2025-11-16 21:17:50', 6),
(426, 5, 1, 'Xuất kho theo đơn hàng bán lẻ HD00014/2025', -2, 34, 32, NULL, '2025-11-16 21:17:50', 6),
(427, 8, 1, 'Xuất kho theo đơn hàng bán lẻ HD00014/2025', -2, 138, 136, NULL, '2025-11-16 21:17:50', 6),
(428, 28, 1, 'Xuất kho theo đơn hàng bán lẻ HD00014/2025', -2, 186, 184, NULL, '2025-11-16 21:17:50', 6),
(429, 16, 1, 'Xuất kho theo đơn hàng bán lẻ HD00014/2025', -2, 151, 149, NULL, '2025-11-16 21:17:50', 6),
(430, 36, 1, 'Xuất kho theo đơn hàng bán lẻ HD00015/2025', -3, 42, 39, NULL, '2025-11-16 21:32:35', 6),
(431, 72, 1, 'Xuất kho theo đơn hàng bán lẻ HD00015/2025', -1, 20, 19, NULL, '2025-11-16 21:32:35', 6),
(432, 1, 1, 'Xuất kho theo đơn hàng bán lẻ HD00015/2025', -3, 177, 174, NULL, '2025-11-16 21:32:35', 6),
(433, 53, 1, 'Xuất kho theo đơn hàng bán lẻ HD00015/2025', -1, 8, 7, NULL, '2025-11-16 21:32:35', 6),
(434, 8, 1, 'Xuất kho theo đơn hàng bán lẻ HD00015/2025', -1, 136, 135, NULL, '2025-11-16 21:32:35', 6),
(435, 6, 1, 'Xuất kho theo đơn hàng bán lẻ HD00015/2025', -1, 122, 121, NULL, '2025-11-16 21:32:35', 6),
(436, 28, 1, 'Xuất kho theo đơn hàng bán lẻ HD00015/2025', -1, 184, 183, NULL, '2025-11-16 21:32:35', 6),
(437, 16, 1, 'Xuất kho theo đơn hàng bán lẻ HD00015/2025', -1, 149, 148, NULL, '2025-11-16 21:32:35', 6),
(438, 8, NULL, '', 40, 135, 175, NULL, '2025-11-23 13:30:49', 6),
(439, 7, NULL, '', 40, 215, 255, NULL, '2025-11-23 13:31:23', 6),
(440, 28, NULL, '', 10, 183, 193, NULL, '2025-11-23 13:31:48', 6),
(441, 29, NULL, '', 20, 42, 62, NULL, '2025-11-23 13:32:19', 6),
(442, 29, NULL, '', 20, 62, 82, NULL, '2025-11-23 13:32:21', 6),
(443, 29, 1, 'Sửa số lượng tồn kho', -20, 82, 62, NULL, '2025-11-23 13:33:04', 6),
(444, 16, NULL, '', 20, 148, 168, NULL, '2025-11-23 13:33:28', 6),
(445, 17, NULL, '', 20, 96, 116, NULL, '2025-11-23 13:33:45', 6),
(446, 3, NULL, '', 90, 524, 614, NULL, '2025-11-23 13:34:06', 6),
(447, 2, NULL, '', 60, 80, 140, NULL, '2025-11-23 13:34:39', 6),
(448, 26, NULL, '', 20, 94, 114, NULL, '2025-11-23 13:36:27', 6),
(449, 74, 1, 'Nhập số lượng khi thêm mới vào kho', 20, 0, 20, NULL, '2025-11-23 13:39:19', 6),
(450, 8, NULL, '', 108, 175, 283, NULL, '2025-12-22 09:55:49', 6),
(451, 9, NULL, '', 36, 70, 106, NULL, '2025-12-22 09:56:10', 6),
(452, 7, NULL, '', 20, 255, 275, NULL, '2025-12-22 09:56:33', 6),
(453, 28, NULL, '', 20, 193, 213, NULL, '2025-12-22 09:57:32', 6),
(454, 29, NULL, '', 20, 62, 82, NULL, '2025-12-22 09:57:55', 6),
(455, 16, NULL, '', 20, 168, 188, NULL, '2025-12-22 09:58:16', 6),
(456, 17, NULL, '', 20, 116, 136, NULL, '2025-12-22 09:58:33', 6),
(457, 3, NULL, '', 90, 614, 704, NULL, '2025-12-22 09:58:58', 6),
(458, 1, NULL, '', 90, 174, 264, NULL, '2025-12-22 09:59:17', 6),
(459, 1, 1, 'Sửa số lượng tồn kho', -72, 264, 192, NULL, '2026-02-14 10:55:48', 6),
(460, 1, 1, 'Sửa số lượng tồn kho', 100, 192, 292, NULL, '2026-02-14 10:56:06', 6),
(461, 2, 1, 'Sửa số lượng tồn kho', -108, 140, 32, NULL, '2026-02-14 10:56:45', 6),
(462, 3, 1, 'Sửa số lượng tồn kho', -625, 704, 79, NULL, '2026-02-14 10:57:03', 6),
(463, 4, 1, 'Sửa số lượng tồn kho', -23, 69, 46, NULL, '2026-02-14 10:57:37', 6),
(464, 69, 1, 'Sửa số lượng tồn kho', -27, 60, 33, NULL, '2026-02-14 10:57:54', 6),
(465, 5, 1, 'Sửa số lượng tồn kho', -22, 32, 10, NULL, '2026-02-14 10:58:58', 6),
(466, 6, 1, 'Sửa số lượng tồn kho', 35, 121, 156, NULL, '2026-02-14 10:59:37', 6),
(467, 7, 1, 'Sửa số lượng tồn kho', -101, 275, 174, NULL, '2026-02-14 11:00:09', 6),
(468, 5, NULL, '', 20, 10, 30, NULL, '2026-02-14 11:00:30', 6),
(469, 8, 1, 'Sửa số lượng tồn kho', -152, 283, 131, NULL, '2026-02-14 11:01:16', 6),
(470, 9, 1, 'Sửa số lượng tồn kho', 210, 106, 316, NULL, '2026-02-14 11:01:27', 6),
(471, 75, 1, 'Nhập số lượng khi thêm mới vào kho', 2, 0, 2, NULL, '2026-02-14 11:04:25', 6),
(472, 11, 1, 'Sửa số lượng tồn kho', -5, 21, 16, NULL, '2026-02-14 11:05:06', 6),
(473, 10, 1, 'Sửa số lượng tồn kho', -2, 29, 27, NULL, '2026-02-14 11:05:51', 6),
(474, 76, 1, 'Nhập số lượng khi thêm mới vào kho', 4, 0, 4, NULL, '2026-02-14 11:07:19', 6),
(475, 77, 1, 'Nhập số lượng khi thêm mới vào kho', 5, 0, 5, NULL, '2026-02-14 11:08:13', 6),
(476, 21, 1, 'Sửa số lượng tồn kho', -29, 78, 49, NULL, '2026-02-14 11:10:27', 6),
(477, 19, 1, 'Sửa số lượng tồn kho', -33, 48, 15, NULL, '2026-02-14 11:11:24', 6),
(478, 78, 1, 'Nhập số lượng khi thêm mới vào kho', 50, 0, 50, NULL, '2026-02-14 11:13:00', 6),
(479, 79, 1, 'Nhập số lượng khi thêm mới vào kho', 27, 0, 27, NULL, '2026-02-14 11:13:26', 6),
(480, 30, 1, 'Sửa số lượng tồn kho', -11, 58, 47, NULL, '2026-02-14 11:14:15', 6),
(481, 31, 1, 'Sửa số lượng tồn kho', -9, 47, 38, NULL, '2026-02-14 11:14:32', 6),
(482, 32, 1, 'Sửa số lượng tồn kho', -10, 72, 62, NULL, '2026-02-14 11:15:30', 6),
(483, 34, 1, 'Sửa số lượng tồn kho', -17, 88, 71, NULL, '2026-02-14 11:15:58', 6),
(484, 25, 1, 'Sửa số lượng tồn kho', -43, 124, 81, NULL, '2026-02-14 11:16:38', 6),
(485, 24, 1, 'Sửa số lượng tồn kho', -138, 181, 43, NULL, '2026-02-14 11:16:55', 6),
(486, 80, 1, 'Nhập số lượng khi thêm mới vào kho', 33, 0, 33, NULL, '2026-02-14 11:18:14', 6),
(487, 81, 1, 'Nhập số lượng khi thêm mới vào kho', 10, 0, 10, NULL, '2026-02-14 11:18:58', 6),
(488, 35, 1, 'Sửa số lượng tồn kho', -164, 239, 75, NULL, '2026-02-14 11:20:16', 6),
(489, 28, 1, 'Sửa số lượng tồn kho', -157, 213, 56, NULL, '2026-02-22 19:06:49', 6),
(490, 29, 1, 'Sửa số lượng tồn kho', -65, 82, 17, NULL, '2026-02-22 19:07:15', 6),
(491, 23, 1, 'Sửa số lượng tồn kho', -184, 396, 212, NULL, '2026-02-22 19:08:31', 6),
(492, 74, 1, 'Sửa số lượng tồn kho', 79, 20, 99, NULL, '2026-02-22 19:09:26', 6),
(493, 26, 1, 'Sửa số lượng tồn kho', -85, 114, 29, NULL, '2026-02-22 19:09:55', 6),
(494, 82, 1, 'Nhập số lượng khi thêm mới vào kho', 118, 0, 118, NULL, '2026-02-22 19:11:34', 6),
(495, 22, 1, 'Sửa số lượng tồn kho', -125, 186, 61, NULL, '2026-02-22 19:12:18', 6),
(496, 18, 1, 'Sửa số lượng tồn kho', -3, 52, 49, NULL, '2026-02-22 19:13:27', 6),
(497, 17, 1, 'Sửa số lượng tồn kho', -49, 136, 87, NULL, '2026-02-22 19:14:04', 6),
(498, 16, 1, 'Sửa số lượng tồn kho', -102, 188, 86, NULL, '2026-02-22 19:14:34', 6),
(499, 70, 1, 'Sửa số lượng tồn kho', -20, 40, 20, NULL, '2026-02-22 19:23:07', 6),
(500, 71, 1, 'Sửa số lượng tồn kho', 16, 40, 56, NULL, '2026-02-22 19:24:24', 6),
(501, 13, 1, 'Sửa số lượng tồn kho', 1, 8, 9, NULL, '2026-02-22 19:25:28', 6),
(502, 83, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-13 08:22:10', 2),
(503, 84, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-13 08:22:10', 2),
(504, 85, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-13 08:22:10', 2),
(505, 86, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-13 08:22:10', 2),
(506, 87, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-13 08:22:10', 2),
(507, 88, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-13 08:22:10', 2),
(508, 89, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-13 08:22:10', 2),
(509, 90, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-13 08:22:10', 2),
(510, 91, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-13 08:22:10', 2),
(511, 92, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-13 08:22:10', 2),
(512, 93, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-13 08:22:10', 2),
(513, 94, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-13 08:22:10', 2),
(514, 95, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-13 08:22:10', 2),
(515, 96, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-13 08:22:10', 2),
(516, 97, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-13 08:22:10', 2),
(517, 98, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-13 08:22:10', 2),
(518, 99, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-13 08:22:10', 2),
(519, 100, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-13 08:22:10', 2),
(520, 101, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-13 08:22:10', 2),
(521, 102, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-13 08:22:16', 2),
(522, 103, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-13 08:22:16', 2),
(523, 104, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-13 08:22:16', 2),
(524, 105, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-13 08:22:16', 2),
(525, 106, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-13 08:22:16', 2),
(526, 107, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-13 08:22:16', 2),
(527, 108, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-13 08:22:16', 2),
(528, 109, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-13 08:22:16', 2),
(529, 83, 1, 'Xuất kho mẫu cửa #8YRsx', 38, 0, -38, 1, '2026-03-13 08:39:40', 2),
(530, 84, 1, 'Xuất kho mẫu cửa #8YRsx', 18, 0, -18, 1, '2026-03-13 08:39:40', 2),
(531, 85, 1, 'Xuất kho mẫu cửa #8YRsx', 8, 0, -8, 1, '2026-03-13 08:39:40', 2),
(532, 86, 1, 'Xuất kho mẫu cửa #8YRsx', 8, 0, -8, 1, '2026-03-13 08:39:40', 2),
(533, 87, 1, 'Xuất kho mẫu cửa #8YRsx', 1, 0, -1, 1, '2026-03-13 08:39:40', 2),
(534, 88, 1, 'Xuất kho mẫu cửa #8YRsx', 1, 0, -1, 1, '2026-03-13 08:39:40', 2),
(535, 89, 1, 'Xuất kho mẫu cửa #8YRsx', 1, 0, -1, 1, '2026-03-13 08:39:40', 2),
(536, 90, 1, 'Xuất kho mẫu cửa #8YRsx', 1, 0, -1, 1, '2026-03-13 08:39:40', 2),
(537, 91, 1, 'Xuất kho mẫu cửa #8YRsx', 2, 0, -2, 1, '2026-03-13 08:39:40', 2),
(538, 92, 1, 'Xuất kho mẫu cửa #8YRsx', 6, 0, -6, 1, '2026-03-13 08:39:40', 2),
(539, 93, 1, 'Xuất kho mẫu cửa #8YRsx', 6, 0, -6, 1, '2026-03-13 08:39:40', 2),
(540, 94, 1, 'Xuất kho mẫu cửa #8YRsx', 6, 0, -6, 1, '2026-03-13 08:39:40', 2),
(541, 95, 1, 'Xuất kho mẫu cửa #8YRsx', 2, 0, -2, 1, '2026-03-13 08:39:40', 2),
(542, 96, 1, 'Xuất kho mẫu cửa #8YRsx', 4, 0, -4, 1, '2026-03-13 08:39:40', 2),
(543, 97, 1, 'Xuất kho mẫu cửa #8YRsx', 4, 0, -4, 1, '2026-03-13 08:39:40', 2),
(544, 98, 1, 'Xuất kho mẫu cửa #8YRsx', 3, 0, -3, 1, '2026-03-13 08:39:40', 2),
(545, 99, 1, 'Xuất kho mẫu cửa #8YRsx', 5, 0, -5, 1, '2026-03-13 08:39:40', 2),
(546, 100, 1, 'Xuất kho mẫu cửa #8YRsx', 5.26, 0, -5.26, 1, '2026-03-13 08:39:40', 2),
(547, 101, 1, 'Xuất kho mẫu cửa #8YRsx', 0.73, 0, -0.73, 1, '2026-03-13 08:39:40', 2),
(548, 96, 1, 'Xuất kho mẫu cửa #8YRsx', 16, -4, -20, 1, '2026-03-13 08:39:40', 2),
(549, 102, 1, 'Xuất kho mẫu cửa #8YRsx', 16, 0, -16, 1, '2026-03-13 08:39:40', 2),
(550, 103, 1, 'Xuất kho mẫu cửa #8YRsx', 2, 0, -2, 1, '2026-03-13 08:39:40', 2),
(551, 104, 1, 'Xuất kho mẫu cửa #8YRsx', 2, 0, -2, 1, '2026-03-13 08:39:40', 2),
(552, 105, 1, 'Xuất kho mẫu cửa #8YRsx', 8, 0, -8, 1, '2026-03-13 08:39:40', 2),
(553, 83, 1, 'Xuất kho mẫu cửa #8YRsx', 8, -38, -46, 1, '2026-03-13 08:39:40', 2),
(554, 106, 1, 'Xuất kho mẫu cửa #8YRsx', 2, 0, -2, 1, '2026-03-13 08:39:40', 2),
(555, 107, 1, 'Xuất kho mẫu cửa #8YRsx', 8, 0, -8, 1, '2026-03-13 08:39:40', 2),
(556, 108, 1, 'Xuất kho mẫu cửa #8YRsx', 8, 0, -8, 1, '2026-03-13 08:39:40', 2),
(557, 109, 1, 'Xuất kho mẫu cửa #8YRsx', 3, 0, -3, 1, '2026-03-13 08:39:40', 2),
(558, 101, 1, 'Xuất kho mẫu cửa #8YRsx', 0.93, -0.73, -1.66, 1, '2026-03-13 08:39:40', 2),
(559, 96, 1, 'Xuất kho mẫu cửa #8YRsx', 24, -20, -44, 1, '2026-03-13 08:39:40', 2),
(560, 102, 1, 'Xuất kho mẫu cửa #8YRsx', 24, -16, -40, 1, '2026-03-13 08:39:40', 2),
(561, 103, 1, 'Xuất kho mẫu cửa #8YRsx', 3, -2, -5, 1, '2026-03-13 08:39:40', 2),
(562, 104, 1, 'Xuất kho mẫu cửa #8YRsx', 3, -2, -5, 1, '2026-03-13 08:39:40', 2),
(563, 105, 1, 'Xuất kho mẫu cửa #8YRsx', 12, -8, -20, 1, '2026-03-13 08:39:40', 2),
(564, 83, 1, 'Xuất kho mẫu cửa #8YRsx', 12, -46, -58, 1, '2026-03-13 08:39:40', 2),
(565, 106, 1, 'Xuất kho mẫu cửa #8YRsx', 3, -2, -5, 1, '2026-03-13 08:39:40', 2),
(566, 107, 1, 'Xuất kho mẫu cửa #8YRsx', 12, -8, -20, 1, '2026-03-13 08:39:40', 2),
(567, 108, 1, 'Xuất kho mẫu cửa #8YRsx', 12, -8, -20, 1, '2026-03-13 08:39:40', 2),
(568, 109, 1, 'Xuất kho mẫu cửa #8YRsx', 3.67, -3, -6.67, 1, '2026-03-13 08:39:40', 2),
(569, 101, 1, 'Xuất kho mẫu cửa #8YRsx', 1.15, -1.66, -2.81, 1, '2026-03-13 08:39:40', 2),
(570, 110, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-14 09:56:34', 2),
(571, 111, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-14 09:56:34', 2),
(572, 112, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-14 09:56:34', 2),
(573, 113, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-14 09:56:34', 2),
(574, 114, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-14 09:56:34', 2),
(575, 115, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-14 09:56:34', 2),
(576, 116, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-14 09:56:38', 2),
(577, 117, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-14 09:56:38', 2),
(578, 118, 1, 'Nhập số lượng khi thêm mới vào kho', 0, 0, 0, NULL, '2026-03-14 09:56:38', 2);

-- --------------------------------------------------------

--
-- Table structure for table `cua_kho_vat_tu_nha_cung_cap`
--

DROP TABLE IF EXISTS `cua_kho_vat_tu_nha_cung_cap`;
CREATE TABLE IF NOT EXISTS `cua_kho_vat_tu_nha_cung_cap` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `ten_nha_cung_cap` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `dia_chi` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `cua_kho_vat_tu_nha_cung_cap`
--

INSERT INTO `cua_kho_vat_tu_nha_cung_cap` (`id`, `code`, `ten_nha_cung_cap`, `dia_chi`, `date_created`, `user_created`) VALUES
(2, 'NCC01', 'Công ty TNHH ABCD', 'thành phố Trà Vinh\r\n', '2023-12-05 08:20:45', 1),
(3, 'NCC02', 'Công ty NVT', 'Trà VINH', '2023-12-05 08:41:01', 1),
(4, 'SG.PMI', 'CÔNG TY TNHH SÀI GÒN NHÔM', '26-28 Đường số 57-P. Tân Tạo-Q. Bình Tân-Tp. HCM', '2025-09-30 10:52:35', 3);

-- --------------------------------------------------------

--
-- Table structure for table `cua_loai_bao_gia`
--

DROP TABLE IF EXISTS `cua_loai_bao_gia`;
CREATE TABLE IF NOT EXISTS `cua_loai_bao_gia` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `ten_loai_bao_gia` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `nhom_bao_gia` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `ghi_chu` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `cua_loai_bao_gia`
--

INSERT INTO `cua_loai_bao_gia` (`id`, `code`, `ten_loai_bao_gia`, `nhom_bao_gia`, `ghi_chu`) VALUES
(1, 'nhom-mac-dinh', 'Báo giá nhôm', 'NHOM', NULL),
(2, 'vat-tu-mac-dinh', 'Báo giá vật tư', 'VATTU', NULL),
(3, 'vach-mac-dinh', 'Báo giá vách', 'VACH', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cua_loai_cua`
--

DROP TABLE IF EXISTS `cua_loai_cua`;
CREATE TABLE IF NOT EXISTS `cua_loai_cua` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `ten_loai_cua` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `ghi_chu` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `cua_loai_cua`
--

INSERT INTO `cua_loai_cua` (`id`, `code`, `ten_loai_cua`, `ghi_chu`, `date_created`, `user_created`) VALUES
(1, '40PhU', 'C1', NULL, '2026-03-13 08:21:58', 2),
(2, '7QWiI', 'C2', NULL, '2026-03-13 08:22:10', 2),
(3, '8HBLd', 'C2_COPY', NULL, '2026-03-13 08:22:16', 2),
(4, '1XnfJ', 'K1', NULL, '2026-03-14 09:56:33', 2),
(5, '4LrIZ', 'C1_COPY', NULL, '2026-03-14 09:56:38', 2);

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua`
--

DROP TABLE IF EXISTS `cua_mau_cua`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `ten_cua` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `kich_thuoc` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `ngang` float DEFAULT NULL,
  `cao` float DEFAULT NULL,
  `id_he_nhom` int DEFAULT NULL,
  `id_loai_cua` int NOT NULL,
  `id_parent` int DEFAULT NULL,
  `id_du_an` int DEFAULT NULL,
  `id_cong_trinh` int DEFAULT NULL,
  `ngay_yeu_cau` date DEFAULT NULL,
  `so_luong` int DEFAULT NULL,
  `status` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `ghi_chu` text COLLATE utf8mb3_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `id_he_nhom` (`id_he_nhom`),
  KEY `id_parent` (`id_parent`),
  KEY `id_loai_cua` (`id_loai_cua`),
  KEY `id_du_an` (`id_du_an`),
  KEY `id_cong_trinh` (`id_cong_trinh`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `cua_mau_cua`
--

INSERT INTO `cua_mau_cua` (`id`, `code`, `ten_cua`, `kich_thuoc`, `ngang`, `cao`, `id_he_nhom`, `id_loai_cua`, `id_parent`, `id_du_an`, `id_cong_trinh`, `ngay_yeu_cau`, `so_luong`, `status`, `ghi_chu`, `date_created`, `user_created`) VALUES
(1, '1G2Qt', 'C1', '2300x2800 (mm)', NULL, NULL, 6, 1, 0, 1, 4, NULL, 1, 'TOI_UU', NULL, '2026-03-13 08:21:58', 2),
(2, '73zbQ', 'C2', '1450x1600 (mm)', NULL, NULL, 6, 2, 0, 1, 4, NULL, 2, 'TOI_UU', NULL, '2026-03-13 08:22:10', 2),
(3, '5DAnS', 'C2_COPY', '1200x1600 (mm)', NULL, NULL, 6, 3, 0, 1, 4, NULL, 3, 'TOI_UU', NULL, '2026-03-13 08:22:16', 2),
(4, '2tRuP', 'K1', '4063x2968 (mm)', NULL, NULL, 7, 4, 0, 3, 5, NULL, 1, 'TOI_UU', NULL, '2026-03-14 09:56:33', 2),
(5, '6Tu67', 'C1', '2820x3192 (mm)', NULL, NULL, 6, 1, 0, 3, 5, NULL, 1, 'TOI_UU', NULL, '2026-03-14 09:56:34', 2),
(6, '3vmcZ', 'C1_COPY', '2830x3192 (mm)', NULL, NULL, 6, 5, 0, 3, 5, NULL, 1, 'TOI_UU', NULL, '2026-03-14 09:56:38', 2),
(7, '7xGEJ', 'C2', '2730x3192 (mm)', NULL, NULL, 6, 2, 0, 3, 5, NULL, 2, 'TOI_UU', NULL, '2026-03-14 09:56:38', 2),
(8, '8x05h', 'C2_COPY', '2740x3192 (mm)', NULL, NULL, 6, 3, 0, 3, 5, NULL, 1, 'TOI_UU', NULL, '2026-03-14 09:56:38', 2);

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua_danh_gia`
--

DROP TABLE IF EXISTS `cua_mau_cua_danh_gia`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua_danh_gia` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_mau_cua` int NOT NULL,
  `id_nguoi_danh_gia` int NOT NULL,
  `ten_nguoi_danh_gia` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `lan_thu` int NOT NULL,
  `ngay_danh_gia` date NOT NULL,
  `ghi_chu` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  `check_he_nhom` tinyint(1) DEFAULT NULL,
  `check_kich_thuoc_phu_bi` tinyint(1) DEFAULT NULL,
  `check_kich_thuoc_thuc_te` tinyint(1) DEFAULT NULL,
  `check_nhan_hieu` tinyint(1) DEFAULT NULL,
  `check_chu_thich` tinyint(1) DEFAULT NULL,
  `check_tham_my` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_nguoi_danh_gia` (`id_nguoi_danh_gia`),
  KEY `id_mau_cua` (`id_mau_cua`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `cua_mau_cua_danh_gia`
--

INSERT INTO `cua_mau_cua_danh_gia` (`id`, `id_mau_cua`, `id_nguoi_danh_gia`, `ten_nguoi_danh_gia`, `lan_thu`, `ngay_danh_gia`, `ghi_chu`, `date_created`, `user_created`, `check_he_nhom`, `check_kich_thuoc_phu_bi`, `check_kich_thuoc_thuc_te`, `check_nhan_hieu`, `check_chu_thich`, `check_tham_my`) VALUES
(1, 1, 2, 'Quang', 1, '2026-03-13', '', '2026-03-13 08:57:47', 2, 1, 1, 1, 1, 0, 0),
(2, 1, 2, 'Quang', 2, '2026-03-14', '', '2026-03-13 08:58:52', 2, 1, 1, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua_nhom`
--

DROP TABLE IF EXISTS `cua_mau_cua_nhom`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua_nhom` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_mau_cua` int NOT NULL,
  `id_cay_nhom` int NOT NULL,
  `chieu_dai` float DEFAULT NULL,
  `so_luong` int DEFAULT NULL,
  `kieu_cat` varchar(11) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `khoi_luong` float DEFAULT NULL,
  `don_gia` double DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_mau_cua` (`id_mau_cua`),
  KEY `id_cay_nhom` (`id_cay_nhom`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `cua_mau_cua_nhom`
--

INSERT INTO `cua_mau_cua_nhom` (`id`, `id_mau_cua`, `id_cay_nhom`, `chieu_dai`, `so_luong`, `kieu_cat`, `khoi_luong`, `don_gia`, `date_created`, `user_created`) VALUES
(1, 1, 35, 2300, 1, '|===|', 0.8, 0, '2026-03-13 08:22:00', 2),
(2, 1, 36, 2300, 1, '/===\\', 2.89, 0, '2026-03-13 08:22:01', 2),
(3, 1, 36, 2399, 1, '|===\\', 3.02, 0, '2026-03-13 08:22:01', 2),
(4, 1, 36, 2399, 1, '/===|', 3.02, 0, '2026-03-13 08:22:01', 2),
(5, 1, 37, 551, 8, '/===\\', 6.35, 0, '2026-03-13 08:22:03', 2),
(6, 1, 37, 2350, 8, '/===\\', 27.09, 0, '2026-03-13 08:22:03', 2),
(7, 1, 38, 2214, 8, '|===|', 4.8, 0, '2026-03-13 08:22:04', 2),
(8, 1, 38, 377, 8, '|===|', 0.82, 0, '2026-03-13 08:22:04', 2),
(9, 1, 39, 2320, 3, '|===|', 6.2, 0, '2026-03-13 08:22:06', 2),
(10, 1, 40, 490, 4, '|===|', 0.93, 0, '2026-03-13 08:22:07', 2),
(11, 1, 41, 2300, 2, '/===\\', 3.69, 0, '2026-03-13 08:22:09', 2),
(12, 1, 41, 399, 2, '/===\\', 0.64, 0, '2026-03-13 08:22:09', 2),
(13, 1, 42, 347, 2, '|===|', 0.66, 0, '2026-03-13 08:22:10', 2),
(14, 1, 38, 337, 6, '|===|', 0.55, 0, '2026-03-13 08:22:10', 2),
(15, 1, 38, 507, 4, '|===|', 0.55, 0, '2026-03-13 08:22:10', 2),
(16, 1, 38, 1049, 2, '|===|', 0.57, 0, '2026-03-13 08:22:10', 2),
(17, 2, 35, 1450, 2, '|===|', 1.01, 0, '2026-03-13 08:22:11', 2),
(18, 2, 43, 1450, 4, '/===\\', 5.5, 0, '2026-03-13 08:22:12', 2),
(19, 2, 43, 1199, 4, '/===\\', 4.55, 0, '2026-03-13 08:22:12', 2),
(20, 2, 44, 718, 8, '/===\\', 5.38, 0, '2026-03-13 08:22:14', 2),
(21, 2, 44, 1122, 8, '/===\\', 8.4, 0, '2026-03-13 08:22:14', 2),
(22, 2, 45, 1122, 4, '|===|', 1.64, 0, '2026-03-13 08:22:15', 2),
(23, 2, 46, 1450, 2, '|===|', 0.81, 0, '2026-03-13 08:22:16', 2),
(24, 2, 41, 1450, 4, '/===\\', 4.65, 0, '2026-03-13 08:22:16', 2),
(25, 2, 41, 399, 4, '/===\\', 1.28, 0, '2026-03-13 08:22:16', 2),
(26, 2, 38, 337, 4, '|===|', 0.36, 0, '2026-03-13 08:22:16', 2),
(27, 2, 38, 1350, 4, '|===|', 1.46, 0, '2026-03-13 08:22:16', 2),
(28, 3, 35, 1200, 3, '|===|', 1.25, 0, '2026-03-13 08:22:17', 2),
(29, 3, 43, 1200, 6, '/===\\', 6.83, 0, '2026-03-13 08:22:17', 2),
(30, 3, 43, 1199, 6, '/===\\', 6.83, 0, '2026-03-13 08:22:17', 2),
(31, 3, 44, 593, 12, '/===\\', 6.66, 0, '2026-03-13 08:22:17', 2),
(32, 3, 44, 1122, 12, '/===\\', 12.6, 0, '2026-03-13 08:22:17', 2),
(33, 3, 45, 1122, 6, '|===|', 2.46, 0, '2026-03-13 08:22:17', 2),
(34, 3, 46, 1200, 3, '|===|', 1, 0, '2026-03-13 08:22:17', 2),
(35, 3, 41, 1200, 6, '/===\\', 5.77, 0, '2026-03-13 08:22:17', 2),
(36, 3, 41, 399, 6, '/===\\', 1.92, 0, '2026-03-13 08:22:17', 2),
(37, 3, 38, 337, 6, '|===|', 0.55, 0, '2026-03-13 08:22:17', 2),
(38, 3, 38, 1100, 6, '|===|', 1.79, 0, '2026-03-13 08:22:17', 2),
(39, 4, 47, 2968, 2, '/===\\', 2.02, 0, '2026-03-14 09:56:34', 2),
(40, 4, 47, 4063, 1, '/===\\', 1.38, 0, '2026-03-14 09:56:34', 2),
(41, 4, 47, 792, 1, '/===|', 0.27, 0, '2026-03-14 09:56:34', 2),
(42, 4, 47, 871, 1, '|===\\', 0.3, 0, '2026-03-14 09:56:34', 2),
(43, 5, 41, 1920, 2, '/===\\', 3.08, 0, '2026-03-14 09:56:35', 2),
(44, 5, 41, 3192, 2, '/===\\', 5.12, 0, '2026-03-14 09:56:35', 2),
(45, 5, 42, 3140, 1, '|===|', 2.99, 0, '2026-03-14 09:56:35', 2),
(46, 5, 42, 924, 4, '|===|', 3.52, 0, '2026-03-14 09:56:35', 2),
(47, 5, 38, 854, 4, '|===|', 0.93, 0, '2026-03-14 09:56:35', 2),
(48, 5, 38, 876, 12, '|===|', 2.85, 0, '2026-03-14 09:56:35', 2),
(49, 5, 48, 848, 18, '|===|', 10.14, 0, '2026-03-14 09:56:36', 2),
(50, 5, 38, 1470, 4, '|===|', 1.59, 0, '2026-03-14 09:56:36', 2),
(51, 5, 38, 746, 4, '|===|', 0.81, 0, '2026-03-14 09:56:36', 2),
(52, 5, 36, 900, 1, '/===\\', 1.13, 0, '2026-03-14 09:56:36', 2),
(53, 5, 36, 2400, 1, '|===\\', 3.02, 0, '2026-03-14 09:56:36', 2),
(54, 5, 36, 2400, 1, '/===|', 3.02, 0, '2026-03-14 09:56:36', 2),
(55, 5, 49, 818, 2, '/===\\', 2.36, 0, '2026-03-14 09:56:37', 2),
(56, 5, 49, 2351, 2, '/===\\', 6.78, 0, '2026-03-14 09:56:37', 2),
(57, 5, 42, 692, 1, '|===|', 0.66, 0, '2026-03-14 09:56:37', 2),
(58, 5, 38, 807, 2, '|===|', 0.44, 0, '2026-03-14 09:56:38', 2),
(59, 5, 38, 644, 4, '|===|', 0.7, 0, '2026-03-14 09:56:38', 2),
(60, 5, 48, 801, 7, '|===|', 3.72, 0, '2026-03-14 09:56:38', 2),
(61, 5, 38, 1378, 2, '|===|', 0.75, 0, '2026-03-14 09:56:38', 2),
(62, 5, 40, 757, 1, '|===|', 0.36, 0, '2026-03-14 09:56:38', 2),
(63, 5, 41, 900, 2, '/===\\', 1.44, 0, '2026-03-14 09:56:38', 2),
(64, 5, 41, 792, 2, '/===\\', 1.27, 0, '2026-03-14 09:56:38', 2),
(65, 5, 38, 730, 2, '|===|', 0.4, 0, '2026-03-14 09:56:38', 2),
(66, 5, 38, 800, 2, '|===|', 0.43, 0, '2026-03-14 09:56:38', 2),
(67, 6, 41, 1930, 2, '/===\\', 3.1, 0, '2026-03-14 09:56:38', 2),
(68, 6, 41, 3192, 2, '/===\\', 5.12, 0, '2026-03-14 09:56:38', 2),
(69, 6, 42, 3140, 1, '|===|', 2.99, 0, '2026-03-14 09:56:38', 2),
(70, 6, 42, 929, 4, '|===|', 3.54, 0, '2026-03-14 09:56:38', 2),
(71, 6, 38, 854, 4, '|===|', 0.93, 0, '2026-03-14 09:56:38', 2),
(72, 6, 38, 881, 12, '|===|', 2.87, 0, '2026-03-14 09:56:38', 2),
(73, 6, 48, 848, 20, '|===|', 11.26, 0, '2026-03-14 09:56:38', 2),
(74, 6, 38, 1470, 4, '|===|', 1.59, 0, '2026-03-14 09:56:38', 2),
(75, 6, 38, 746, 4, '|===|', 0.81, 0, '2026-03-14 09:56:38', 2),
(76, 6, 36, 900, 1, '/===\\', 1.13, 0, '2026-03-14 09:56:38', 2),
(77, 6, 36, 2400, 1, '|===\\', 3.02, 0, '2026-03-14 09:56:38', 2),
(78, 6, 36, 2400, 1, '/===|', 3.02, 0, '2026-03-14 09:56:38', 2),
(79, 6, 49, 818, 2, '/===\\', 2.36, 0, '2026-03-14 09:56:38', 2),
(80, 6, 49, 2351, 2, '/===\\', 6.78, 0, '2026-03-14 09:56:38', 2),
(81, 6, 42, 692, 1, '|===|', 0.66, 0, '2026-03-14 09:56:38', 2),
(82, 6, 38, 807, 2, '|===|', 0.44, 0, '2026-03-14 09:56:38', 2),
(83, 6, 38, 644, 4, '|===|', 0.7, 0, '2026-03-14 09:56:38', 2),
(84, 6, 48, 801, 7, '|===|', 3.72, 0, '2026-03-14 09:56:38', 2),
(85, 6, 38, 1378, 2, '|===|', 0.75, 0, '2026-03-14 09:56:38', 2),
(86, 6, 40, 757, 1, '|===|', 0.36, 0, '2026-03-14 09:56:38', 2),
(87, 6, 41, 900, 2, '/===\\', 1.44, 0, '2026-03-14 09:56:38', 2),
(88, 6, 41, 792, 2, '/===\\', 1.27, 0, '2026-03-14 09:56:38', 2),
(89, 6, 38, 730, 2, '|===|', 0.4, 0, '2026-03-14 09:56:38', 2),
(90, 6, 38, 800, 2, '|===|', 0.43, 0, '2026-03-14 09:56:38', 2),
(91, 7, 41, 2730, 4, '/===\\', 8.76, 0, '2026-03-14 09:56:38', 2),
(92, 7, 41, 3192, 4, '/===\\', 10.24, 0, '2026-03-14 09:56:38', 2),
(93, 7, 42, 3140, 4, '|===|', 11.97, 0, '2026-03-14 09:56:38', 2),
(94, 7, 42, 874, 8, '|===|', 6.66, 0, '2026-03-14 09:56:38', 2),
(95, 7, 42, 890, 4, '|===|', 3.39, 0, '2026-03-14 09:56:38', 2),
(96, 7, 38, 854, 12, '|===|', 2.78, 0, '2026-03-14 09:56:38', 2),
(97, 7, 38, 826, 24, '|===|', 5.37, 0, '2026-03-14 09:56:38', 2),
(98, 7, 48, 848, 54, '|===|', 30.41, 0, '2026-03-14 09:56:38', 2),
(99, 7, 38, 1470, 12, '|===|', 4.78, 0, '2026-03-14 09:56:38', 2),
(100, 7, 38, 842, 12, '|===|', 2.74, 0, '2026-03-14 09:56:38', 2),
(101, 7, 38, 746, 12, '|===|', 2.42, 0, '2026-03-14 09:56:38', 2),
(102, 8, 41, 2740, 2, '/===\\', 4.39, 0, '2026-03-14 09:56:38', 2),
(103, 8, 41, 3192, 2, '/===\\', 5.12, 0, '2026-03-14 09:56:38', 2),
(104, 8, 42, 3140, 2, '|===|', 5.98, 0, '2026-03-14 09:56:38', 2),
(105, 8, 42, 877, 4, '|===|', 3.34, 0, '2026-03-14 09:56:39', 2),
(106, 8, 42, 893, 2, '|===|', 1.7, 0, '2026-03-14 09:56:39', 2),
(107, 8, 38, 854, 6, '|===|', 1.39, 0, '2026-03-14 09:56:39', 2),
(108, 8, 38, 829, 12, '|===|', 2.7, 0, '2026-03-14 09:56:39', 2),
(109, 8, 48, 848, 27, '|===|', 15.2, 0, '2026-03-14 09:56:39', 2),
(110, 8, 38, 1470, 6, '|===|', 2.39, 0, '2026-03-14 09:56:39', 2),
(111, 8, 38, 845, 6, '|===|', 1.37, 0, '2026-03-14 09:56:39', 2),
(112, 8, 38, 746, 6, '|===|', 1.21, 0, '2026-03-14 09:56:39', 2);

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua_nhom_su_dung`
--

DROP TABLE IF EXISTS `cua_mau_cua_nhom_su_dung`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua_nhom_su_dung` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_mau_cua` int DEFAULT NULL,
  `id_du_an` int DEFAULT NULL,
  `id_kho_nhom` int NOT NULL,
  `chieu_dai_ban_dau` float NOT NULL,
  `chieu_dai_con_lai` float NOT NULL,
  `chieu_dai_nhap_lai` float DEFAULT NULL,
  `ghi_chu_nhap_lai` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_mau_cua` (`id_mau_cua`),
  KEY `id_kho_nhom` (`id_kho_nhom`),
  KEY `id_du_an` (`id_du_an`)
) ENGINE=InnoDB AUTO_INCREMENT=429 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `cua_mau_cua_nhom_su_dung`
--

INSERT INTO `cua_mau_cua_nhom_su_dung` (`id`, `id_mau_cua`, `id_du_an`, `id_kho_nhom`, `chieu_dai_ban_dau`, `chieu_dai_con_lai`, `chieu_dai_nhap_lai`, `ghi_chu_nhap_lai`, `date_created`, `user_created`) VALUES
(81, NULL, 1, 35, 6000, 794, NULL, NULL, '2026-03-13 08:35:13', 2),
(82, NULL, 1, 35, 6000, 2394, NULL, NULL, '2026-03-13 08:35:13', 2),
(83, NULL, 1, 36, 6000, 1198, NULL, NULL, '2026-03-13 08:35:13', 2),
(84, NULL, 1, 36, 6000, 3698, NULL, NULL, '2026-03-13 08:35:13', 2),
(85, NULL, 1, 37, 6000, 190, NULL, NULL, '2026-03-13 08:35:13', 2),
(86, NULL, 1, 37, 6000, 190, NULL, NULL, '2026-03-13 08:35:13', 2),
(87, NULL, 1, 37, 6000, 190, NULL, NULL, '2026-03-13 08:35:13', 2),
(88, NULL, 1, 37, 6000, 190, NULL, NULL, '2026-03-13 08:35:13', 2),
(89, NULL, 1, 38, 6000, 0, NULL, NULL, '2026-03-13 08:35:14', 2),
(90, NULL, 1, 38, 6000, 216, NULL, NULL, '2026-03-13 08:35:14', 2),
(91, NULL, 1, 38, 6000, 216, NULL, NULL, '2026-03-13 08:35:14', 2),
(92, NULL, 1, 38, 6000, 216, NULL, NULL, '2026-03-13 08:35:14', 2),
(93, NULL, 1, 38, 6000, 87, NULL, NULL, '2026-03-13 08:35:14', 2),
(94, NULL, 1, 38, 6000, 111, NULL, NULL, '2026-03-13 08:35:14', 2),
(95, NULL, 1, 38, 6000, 168, NULL, NULL, '2026-03-13 08:35:14', 2),
(96, NULL, 1, 38, 6000, 4644, NULL, NULL, '2026-03-13 08:35:14', 2),
(97, NULL, 1, 39, 6000, 1356, NULL, NULL, '2026-03-13 08:35:14', 2),
(98, NULL, 1, 39, 6000, 3678, NULL, NULL, '2026-03-13 08:35:14', 2),
(99, NULL, 1, 40, 6000, 4032, NULL, NULL, '2026-03-13 08:35:14', 2),
(100, NULL, 1, 41, 6000, 194, NULL, NULL, '2026-03-13 08:35:14', 2),
(101, NULL, 1, 41, 6000, 192, NULL, NULL, '2026-03-13 08:35:14', 2),
(102, NULL, 1, 41, 6000, 390, NULL, NULL, '2026-03-13 08:35:14', 2),
(103, NULL, 1, 41, 6000, 788, NULL, NULL, '2026-03-13 08:35:14', 2),
(104, NULL, 1, 42, 6000, 5302, NULL, NULL, '2026-03-13 08:35:14', 2),
(105, NULL, 1, 43, 6000, 192, NULL, NULL, '2026-03-13 08:35:14', 2),
(106, NULL, 1, 43, 6000, 1192, NULL, NULL, '2026-03-13 08:35:14', 2),
(107, NULL, 1, 43, 6000, 1194, NULL, NULL, '2026-03-13 08:35:14', 2),
(108, NULL, 1, 43, 6000, 1196, NULL, NULL, '2026-03-13 08:35:14', 2),
(109, NULL, 1, 43, 6000, 1196, NULL, NULL, '2026-03-13 08:35:14', 2),
(110, NULL, 1, 44, 6000, 380, NULL, NULL, '2026-03-13 08:35:14', 2),
(111, NULL, 1, 44, 6000, 380, NULL, NULL, '2026-03-13 08:35:14', 2),
(112, NULL, 1, 44, 6000, 380, NULL, NULL, '2026-03-13 08:35:14', 2),
(113, NULL, 1, 44, 6000, 380, NULL, NULL, '2026-03-13 08:35:14', 2),
(114, NULL, 1, 44, 6000, 240, NULL, NULL, '2026-03-13 08:35:14', 2),
(115, NULL, 1, 44, 6000, 50, NULL, NULL, '2026-03-13 08:35:14', 2),
(116, NULL, 1, 44, 6000, 4810, NULL, NULL, '2026-03-13 08:35:14', 2),
(117, NULL, 1, 45, 6000, 380, NULL, NULL, '2026-03-13 08:35:14', 2),
(118, NULL, 1, 45, 6000, 380, NULL, NULL, '2026-03-13 08:35:14', 2),
(119, NULL, 1, 46, 6000, 692, NULL, NULL, '2026-03-13 08:35:14', 2),
(120, NULL, 1, 46, 6000, 4798, NULL, NULL, '2026-03-13 08:35:14', 2),
(352, NULL, 3, 76, 6000, 244, NULL, NULL, '2026-03-14 10:13:49', 2),
(353, NULL, 3, 76, 6000, 44, NULL, NULL, '2026-03-14 10:13:49', 2),
(354, NULL, 3, 41, 6000, 48, NULL, NULL, '2026-03-14 10:13:49', 2),
(355, NULL, 3, 41, 6000, 48, NULL, NULL, '2026-03-14 10:13:49', 2),
(356, NULL, 3, 41, 6000, 58, NULL, NULL, '2026-03-14 10:13:49', 2),
(357, NULL, 3, 41, 6000, 58, NULL, NULL, '2026-03-14 10:13:49', 2),
(358, NULL, 3, 41, 6000, 58, NULL, NULL, '2026-03-14 10:13:49', 2),
(359, NULL, 3, 41, 6000, 58, NULL, NULL, '2026-03-14 10:13:49', 2),
(360, NULL, 3, 41, 6000, 56, NULL, NULL, '2026-03-14 10:13:49', 2),
(361, NULL, 3, 41, 6000, 56, NULL, NULL, '2026-03-14 10:13:49', 2),
(362, NULL, 3, 41, 6000, 66, NULL, NULL, '2026-03-14 10:13:49', 2),
(363, NULL, 3, 41, 6000, 66, NULL, NULL, '2026-03-14 10:13:49', 2),
(364, NULL, 3, 41, 6000, 2360, NULL, NULL, '2026-03-14 10:13:49', 2),
(365, NULL, 3, 42, 6000, 0, NULL, NULL, '2026-03-14 10:13:49', 2),
(366, NULL, 3, 42, 6000, 38, NULL, NULL, '2026-03-14 10:13:49', 2),
(367, NULL, 3, 42, 6000, 79, NULL, NULL, '2026-03-14 10:13:49', 2),
(368, NULL, 3, 42, 6000, 147, NULL, NULL, '2026-03-14 10:13:49', 2),
(369, NULL, 3, 42, 6000, 176, NULL, NULL, '2026-03-14 10:13:49', 2),
(370, NULL, 3, 42, 6000, 192, NULL, NULL, '2026-03-14 10:13:49', 2),
(371, NULL, 3, 42, 6000, 198, NULL, NULL, '2026-03-14 10:13:49', 2),
(372, NULL, 3, 42, 6000, 198, NULL, NULL, '2026-03-14 10:13:49', 2),
(373, NULL, 3, 42, 6000, 2850, NULL, NULL, '2026-03-14 10:13:49', 2),
(374, NULL, 3, 38, 6000, 0, NULL, NULL, '2026-03-14 10:13:50', 2),
(375, NULL, 3, 38, 6000, 0, NULL, NULL, '2026-03-14 10:13:50', 2),
(376, NULL, 3, 38, 6000, 0, NULL, NULL, '2026-03-14 10:13:50', 2),
(377, NULL, 3, 38, 6000, 0, NULL, NULL, '2026-03-14 10:13:50', 2),
(378, NULL, 3, 38, 6000, 0, NULL, NULL, '2026-03-14 10:13:50', 2),
(379, NULL, 3, 38, 6000, 0, NULL, NULL, '2026-03-14 10:13:50', 2),
(380, NULL, 3, 38, 6000, 0, NULL, NULL, '2026-03-14 10:13:50', 2),
(381, NULL, 3, 38, 6000, 0, NULL, NULL, '2026-03-14 10:13:50', 2),
(382, NULL, 3, 38, 6000, 0, NULL, NULL, '2026-03-14 10:13:50', 2),
(383, NULL, 3, 38, 6000, 0, NULL, NULL, '2026-03-14 10:13:50', 2),
(384, NULL, 3, 38, 6000, 0, NULL, NULL, '2026-03-14 10:13:50', 2),
(385, NULL, 3, 38, 6000, 0, NULL, NULL, '2026-03-14 10:13:50', 2),
(386, NULL, 3, 38, 6000, 0, NULL, NULL, '2026-03-14 10:13:50', 2),
(387, NULL, 3, 38, 6000, 0, NULL, NULL, '2026-03-14 10:13:50', 2),
(388, NULL, 3, 38, 6000, 0, NULL, NULL, '2026-03-14 10:13:50', 2),
(389, NULL, 3, 38, 6000, 0, NULL, NULL, '2026-03-14 10:13:50', 2),
(390, NULL, 3, 38, 6000, 80, NULL, NULL, '2026-03-14 10:13:50', 2),
(391, NULL, 3, 38, 6000, 80, NULL, NULL, '2026-03-14 10:13:50', 2),
(392, NULL, 3, 38, 6000, 80, NULL, NULL, '2026-03-14 10:13:50', 2),
(393, NULL, 3, 38, 6000, 80, NULL, NULL, '2026-03-14 10:13:50', 2),
(394, NULL, 3, 38, 6000, 80, NULL, NULL, '2026-03-14 10:13:50', 2),
(395, NULL, 3, 38, 6000, 200, NULL, NULL, '2026-03-14 10:13:50', 2),
(396, NULL, 3, 38, 6000, 816, NULL, NULL, '2026-03-14 10:13:50', 2),
(397, NULL, 3, 38, 6000, 13, NULL, NULL, '2026-03-14 10:13:50', 2),
(398, NULL, 3, 38, 6000, 127, NULL, NULL, '2026-03-14 10:13:50', 2),
(399, NULL, 3, 38, 6000, 139, NULL, NULL, '2026-03-14 10:13:50', 2),
(400, NULL, 3, 38, 6000, 148, NULL, NULL, '2026-03-14 10:13:50', 2),
(401, NULL, 3, 38, 6000, 148, NULL, NULL, '2026-03-14 10:13:50', 2),
(402, NULL, 3, 38, 6000, 4347, NULL, NULL, '2026-03-14 10:13:51', 2),
(403, NULL, 3, 77, 6000, 41, NULL, NULL, '2026-03-14 10:13:51', 2),
(404, NULL, 3, 77, 6000, 41, NULL, NULL, '2026-03-14 10:13:51', 2),
(405, NULL, 3, 77, 6000, 41, NULL, NULL, '2026-03-14 10:13:51', 2),
(406, NULL, 3, 77, 6000, 41, NULL, NULL, '2026-03-14 10:13:51', 2),
(407, NULL, 3, 77, 6000, 41, NULL, NULL, '2026-03-14 10:13:51', 2),
(408, NULL, 3, 77, 6000, 41, NULL, NULL, '2026-03-14 10:13:51', 2),
(409, NULL, 3, 77, 6000, 41, NULL, NULL, '2026-03-14 10:13:51', 2),
(410, NULL, 3, 77, 6000, 41, NULL, NULL, '2026-03-14 10:13:51', 2),
(411, NULL, 3, 77, 6000, 41, NULL, NULL, '2026-03-14 10:13:51', 2),
(412, NULL, 3, 77, 6000, 41, NULL, NULL, '2026-03-14 10:13:51', 2),
(413, NULL, 3, 77, 6000, 41, NULL, NULL, '2026-03-14 10:13:51', 2),
(414, NULL, 3, 77, 6000, 41, NULL, NULL, '2026-03-14 10:13:51', 2),
(415, NULL, 3, 77, 6000, 41, NULL, NULL, '2026-03-14 10:13:51', 2),
(416, NULL, 3, 77, 6000, 41, NULL, NULL, '2026-03-14 10:13:51', 2),
(417, NULL, 3, 77, 6000, 852, NULL, NULL, '2026-03-14 10:13:51', 2),
(418, NULL, 3, 77, 6000, 852, NULL, NULL, '2026-03-14 10:13:51', 2),
(419, NULL, 3, 77, 6000, 852, NULL, NULL, '2026-03-14 10:13:51', 2),
(420, NULL, 3, 77, 6000, 852, NULL, NULL, '2026-03-14 10:13:51', 2),
(421, NULL, 3, 77, 6000, 852, NULL, NULL, '2026-03-14 10:13:51', 2),
(422, NULL, 3, 77, 6000, 1710, NULL, NULL, '2026-03-14 10:13:51', 2),
(423, NULL, 3, 36, 6000, 270, NULL, NULL, '2026-03-14 10:13:51', 2),
(424, NULL, 3, 36, 6000, 270, NULL, NULL, '2026-03-14 10:13:51', 2),
(425, NULL, 3, 78, 6000, 450, NULL, NULL, '2026-03-14 10:13:52', 2),
(426, NULL, 3, 78, 6000, 450, NULL, NULL, '2026-03-14 10:13:52', 2),
(427, NULL, 3, 78, 6000, 4344, NULL, NULL, '2026-03-14 10:13:52', 2),
(428, NULL, 3, 40, 6000, 4466, NULL, NULL, '2026-03-14 10:13:52', 2);

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua_nhom_su_dung_chi_tiet`
--

DROP TABLE IF EXISTS `cua_mau_cua_nhom_su_dung_chi_tiet`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua_nhom_su_dung_chi_tiet` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_nhom_su_dung` int NOT NULL,
  `id_nhom_toi_uu` int NOT NULL,
  `date_created` int DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_nhom_su_dung` (`id_nhom_su_dung`),
  KEY `id_nhom_toi_uu` (`id_nhom_toi_uu`)
) ENGINE=InnoDB AUTO_INCREMENT=2136 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `cua_mau_cua_nhom_su_dung_chi_tiet`
--

INSERT INTO `cua_mau_cua_nhom_su_dung_chi_tiet` (`id`, `id_nhom_su_dung`, `id_nhom_toi_uu`, `date_created`, `user_created`) VALUES
(363, 81, 363, 2026, 2),
(364, 81, 424, 2026, 2),
(365, 81, 425, 2026, 2),
(366, 82, 472, 2026, 2),
(367, 82, 473, 2026, 2),
(368, 82, 474, 2026, 2),
(369, 83, 365, 2026, 2),
(370, 83, 366, 2026, 2),
(371, 84, 364, 2026, 2),
(372, 85, 375, 2026, 2),
(373, 85, 376, 2026, 2),
(374, 85, 367, 2026, 2),
(375, 85, 368, 2026, 2),
(376, 86, 377, 2026, 2),
(377, 86, 378, 2026, 2),
(378, 86, 369, 2026, 2),
(379, 86, 370, 2026, 2),
(380, 87, 379, 2026, 2),
(381, 87, 380, 2026, 2),
(382, 87, 371, 2026, 2),
(383, 87, 372, 2026, 2),
(384, 88, 381, 2026, 2),
(385, 88, 382, 2026, 2),
(386, 88, 373, 2026, 2),
(387, 88, 374, 2026, 2),
(388, 89, 468, 2026, 2),
(389, 89, 418, 2026, 2),
(390, 89, 419, 2026, 2),
(391, 89, 391, 2026, 2),
(392, 89, 392, 2026, 2),
(393, 89, 393, 2026, 2),
(394, 89, 394, 2026, 2),
(395, 89, 395, 2026, 2),
(396, 89, 396, 2026, 2),
(397, 89, 412, 2026, 2),
(398, 89, 413, 2026, 2),
(399, 89, 414, 2026, 2),
(400, 89, 415, 2026, 2),
(401, 90, 383, 2026, 2),
(402, 90, 384, 2026, 2),
(403, 90, 469, 2026, 2),
(404, 91, 385, 2026, 2),
(405, 91, 386, 2026, 2),
(406, 91, 470, 2026, 2),
(407, 92, 387, 2026, 2),
(408, 92, 388, 2026, 2),
(409, 92, 471, 2026, 2),
(410, 93, 389, 2026, 2),
(411, 93, 390, 2026, 2),
(412, 93, 538, 2026, 2),
(413, 93, 397, 2026, 2),
(414, 94, 539, 2026, 2),
(415, 94, 540, 2026, 2),
(416, 94, 541, 2026, 2),
(417, 94, 542, 2026, 2),
(418, 94, 543, 2026, 2),
(419, 94, 398, 2026, 2),
(420, 95, 422, 2026, 2),
(421, 95, 423, 2026, 2),
(422, 95, 420, 2026, 2),
(423, 95, 421, 2026, 2),
(424, 95, 416, 2026, 2),
(425, 95, 417, 2026, 2),
(426, 95, 464, 2026, 2),
(427, 95, 465, 2026, 2),
(428, 95, 466, 2026, 2),
(429, 95, 467, 2026, 2),
(430, 95, 532, 2026, 2),
(431, 95, 533, 2026, 2),
(432, 96, 534, 2026, 2),
(433, 96, 535, 2026, 2),
(434, 96, 536, 2026, 2),
(435, 96, 537, 2026, 2),
(436, 97, 399, 2026, 2),
(437, 97, 400, 2026, 2),
(438, 98, 401, 2026, 2),
(439, 99, 402, 2026, 2),
(440, 99, 403, 2026, 2),
(441, 99, 404, 2026, 2),
(442, 99, 405, 2026, 2),
(443, 100, 406, 2026, 2),
(444, 100, 407, 2026, 2),
(445, 100, 520, 2026, 2),
(446, 101, 456, 2026, 2),
(447, 101, 457, 2026, 2),
(448, 101, 458, 2026, 2),
(449, 101, 459, 2026, 2),
(450, 102, 521, 2026, 2),
(451, 102, 522, 2026, 2),
(452, 102, 523, 2026, 2),
(453, 102, 524, 2026, 2),
(454, 102, 408, 2026, 2),
(455, 102, 409, 2026, 2),
(456, 103, 525, 2026, 2),
(457, 103, 460, 2026, 2),
(458, 103, 461, 2026, 2),
(459, 103, 462, 2026, 2),
(460, 103, 463, 2026, 2),
(461, 103, 526, 2026, 2),
(462, 103, 527, 2026, 2),
(463, 103, 528, 2026, 2),
(464, 103, 529, 2026, 2),
(465, 103, 530, 2026, 2),
(466, 103, 531, 2026, 2),
(467, 104, 410, 2026, 2),
(468, 104, 411, 2026, 2),
(469, 105, 426, 2026, 2),
(470, 105, 427, 2026, 2),
(471, 105, 428, 2026, 2),
(472, 105, 429, 2026, 2),
(473, 106, 475, 2026, 2),
(474, 106, 476, 2026, 2),
(475, 106, 477, 2026, 2),
(476, 106, 478, 2026, 2),
(477, 107, 479, 2026, 2),
(478, 107, 480, 2026, 2),
(479, 107, 430, 2026, 2),
(480, 107, 431, 2026, 2),
(481, 108, 432, 2026, 2),
(482, 108, 433, 2026, 2),
(483, 108, 481, 2026, 2),
(484, 108, 482, 2026, 2),
(485, 109, 483, 2026, 2),
(486, 109, 484, 2026, 2),
(487, 109, 485, 2026, 2),
(488, 109, 486, 2026, 2),
(489, 110, 442, 2026, 2),
(490, 110, 443, 2026, 2),
(491, 110, 444, 2026, 2),
(492, 110, 445, 2026, 2),
(493, 110, 446, 2026, 2),
(494, 111, 447, 2026, 2),
(495, 111, 448, 2026, 2),
(496, 111, 449, 2026, 2),
(497, 111, 499, 2026, 2),
(498, 111, 500, 2026, 2),
(499, 112, 501, 2026, 2),
(500, 112, 502, 2026, 2),
(501, 112, 503, 2026, 2),
(502, 112, 504, 2026, 2),
(503, 112, 505, 2026, 2),
(504, 113, 506, 2026, 2),
(505, 113, 507, 2026, 2),
(506, 113, 508, 2026, 2),
(507, 113, 509, 2026, 2),
(508, 113, 510, 2026, 2),
(509, 114, 434, 2026, 2),
(510, 114, 435, 2026, 2),
(511, 114, 436, 2026, 2),
(512, 114, 437, 2026, 2),
(513, 114, 438, 2026, 2),
(514, 114, 439, 2026, 2),
(515, 114, 440, 2026, 2),
(516, 114, 441, 2026, 2),
(517, 115, 487, 2026, 2),
(518, 115, 488, 2026, 2),
(519, 115, 489, 2026, 2),
(520, 115, 490, 2026, 2),
(521, 115, 491, 2026, 2),
(522, 115, 492, 2026, 2),
(523, 115, 493, 2026, 2),
(524, 115, 494, 2026, 2),
(525, 115, 495, 2026, 2),
(526, 115, 496, 2026, 2),
(527, 116, 497, 2026, 2),
(528, 116, 498, 2026, 2),
(529, 117, 450, 2026, 2),
(530, 117, 451, 2026, 2),
(531, 117, 452, 2026, 2),
(532, 117, 453, 2026, 2),
(533, 117, 511, 2026, 2),
(534, 118, 512, 2026, 2),
(535, 118, 513, 2026, 2),
(536, 118, 514, 2026, 2),
(537, 118, 515, 2026, 2),
(538, 118, 516, 2026, 2),
(539, 119, 454, 2026, 2),
(540, 119, 455, 2026, 2),
(541, 119, 517, 2026, 2),
(542, 119, 518, 2026, 2),
(543, 120, 519, 2026, 2),
(1738, 352, 1740, 2026, 2),
(1739, 352, 1742, 2026, 2),
(1740, 352, 1741, 2026, 2),
(1741, 353, 1738, 2026, 2),
(1742, 353, 1739, 2026, 2),
(1743, 354, 1745, 2026, 2),
(1744, 354, 2061, 2026, 2),
(1745, 355, 1746, 2026, 2),
(1746, 355, 2062, 2026, 2),
(1747, 356, 1828, 2026, 2),
(1748, 356, 1911, 2026, 2),
(1749, 357, 1829, 2026, 2),
(1750, 357, 1912, 2026, 2),
(1751, 358, 1915, 2026, 2),
(1752, 358, 1913, 2026, 2),
(1753, 359, 1916, 2026, 2),
(1754, 359, 1914, 2026, 2),
(1755, 360, 1917, 2026, 2),
(1756, 360, 1826, 2026, 2),
(1757, 360, 1820, 2026, 2),
(1758, 361, 1918, 2026, 2),
(1759, 361, 1827, 2026, 2),
(1760, 361, 1821, 2026, 2),
(1761, 362, 2063, 2026, 2),
(1762, 362, 1743, 2026, 2),
(1763, 362, 1905, 2026, 2),
(1764, 363, 2064, 2026, 2),
(1765, 363, 1744, 2026, 2),
(1766, 363, 1906, 2026, 2),
(1767, 364, 1818, 2026, 2),
(1768, 364, 1819, 2026, 2),
(1769, 364, 1903, 2026, 2),
(1770, 364, 1904, 2026, 2),
(1771, 365, 1831, 2026, 2),
(1772, 365, 1832, 2026, 2),
(1773, 365, 1748, 2026, 2),
(1774, 365, 1931, 2026, 2),
(1775, 365, 1923, 2026, 2),
(1776, 365, 1801, 2026, 2),
(1777, 365, 1886, 2026, 2),
(1778, 366, 1747, 2026, 2),
(1779, 366, 1833, 2026, 2),
(1780, 366, 1834, 2026, 2),
(1781, 366, 1749, 2026, 2),
(1782, 367, 1830, 2026, 2),
(1783, 367, 1750, 2026, 2),
(1784, 367, 1751, 2026, 2),
(1785, 367, 2071, 2026, 2),
(1786, 368, 1919, 2026, 2),
(1787, 368, 2072, 2026, 2),
(1788, 368, 1932, 2026, 2),
(1789, 368, 1933, 2026, 2),
(1790, 369, 1920, 2026, 2),
(1791, 369, 1934, 2026, 2),
(1792, 369, 2067, 2026, 2),
(1793, 369, 2068, 2026, 2),
(1794, 370, 1921, 2026, 2),
(1795, 370, 2069, 2026, 2),
(1796, 370, 2070, 2026, 2),
(1797, 370, 1924, 2026, 2),
(1798, 371, 1922, 2026, 2),
(1799, 371, 1925, 2026, 2),
(1800, 371, 1926, 2026, 2),
(1801, 371, 1927, 2026, 2),
(1802, 372, 2065, 2026, 2),
(1803, 372, 1928, 2026, 2),
(1804, 372, 1929, 2026, 2),
(1805, 372, 1930, 2026, 2),
(1806, 373, 2066, 2026, 2),
(1807, 374, 1756, 2026, 2),
(1808, 374, 2037, 2026, 2),
(1809, 374, 1947, 2026, 2),
(1810, 374, 1824, 2026, 2),
(1811, 374, 1804, 2026, 2),
(1812, 374, 1805, 2026, 2),
(1813, 374, 1806, 2026, 2),
(1814, 374, 1807, 2026, 2),
(1815, 375, 1757, 2026, 2),
(1816, 375, 2038, 2026, 2),
(1817, 375, 1948, 2026, 2),
(1818, 375, 1825, 2026, 2),
(1819, 375, 1889, 2026, 2),
(1820, 375, 1890, 2026, 2),
(1821, 375, 1891, 2026, 2),
(1822, 375, 1892, 2026, 2),
(1823, 376, 1790, 2026, 2),
(1824, 376, 1791, 2026, 2),
(1825, 376, 1792, 2026, 2),
(1826, 376, 1793, 2026, 2),
(1827, 376, 1875, 2026, 2),
(1828, 376, 1822, 2026, 2),
(1829, 376, 1823, 2026, 2),
(1830, 376, 1907, 2026, 2),
(1831, 377, 1786, 2026, 2),
(1832, 377, 1876, 2026, 2),
(1833, 377, 1877, 2026, 2),
(1834, 377, 1878, 2026, 2),
(1835, 377, 2049, 2026, 2),
(1836, 377, 2050, 2026, 2),
(1837, 377, 1908, 2026, 2),
(1838, 378, 1787, 2026, 2),
(1839, 378, 1815, 2026, 2),
(1840, 378, 1752, 2026, 2),
(1841, 378, 2051, 2026, 2),
(1842, 378, 2052, 2026, 2),
(1843, 378, 2053, 2026, 2),
(1844, 379, 1788, 2026, 2),
(1845, 379, 1816, 2026, 2),
(1846, 379, 1753, 2026, 2),
(1847, 379, 2054, 2026, 2),
(1848, 379, 2055, 2026, 2),
(1849, 379, 2056, 2026, 2),
(1850, 380, 1789, 2026, 2),
(1851, 380, 1900, 2026, 2),
(1852, 380, 1754, 2026, 2),
(1853, 380, 2057, 2026, 2),
(1854, 380, 2058, 2026, 2),
(1855, 380, 2059, 2026, 2),
(1856, 381, 1871, 2026, 2),
(1857, 381, 1901, 2026, 2),
(1858, 381, 1755, 2026, 2),
(1859, 381, 2060, 2026, 2),
(1860, 381, 2130, 2026, 2),
(1861, 381, 2131, 2026, 2),
(1862, 382, 1758, 2026, 2),
(1863, 382, 1759, 2026, 2),
(1864, 382, 1760, 2026, 2),
(1865, 382, 1761, 2026, 2),
(1866, 382, 1835, 2026, 2),
(1867, 382, 1949, 2026, 2),
(1868, 382, 2132, 2026, 2),
(1869, 383, 1762, 2026, 2),
(1870, 383, 1763, 2026, 2),
(1871, 383, 1764, 2026, 2),
(1872, 383, 1765, 2026, 2),
(1873, 383, 1836, 2026, 2),
(1874, 383, 1950, 2026, 2),
(1875, 383, 2133, 2026, 2),
(1876, 384, 1839, 2026, 2),
(1877, 384, 1840, 2026, 2),
(1878, 384, 1841, 2026, 2),
(1879, 384, 1837, 2026, 2),
(1880, 384, 2124, 2026, 2),
(1881, 384, 2039, 2026, 2),
(1882, 384, 2134, 2026, 2),
(1883, 385, 1842, 2026, 2),
(1884, 385, 1843, 2026, 2),
(1885, 385, 1844, 2026, 2),
(1886, 385, 1838, 2026, 2),
(1887, 385, 2125, 2026, 2),
(1888, 385, 2040, 2026, 2),
(1889, 385, 2135, 2026, 2),
(1890, 386, 1845, 2026, 2),
(1891, 386, 1846, 2026, 2),
(1892, 386, 1847, 2026, 2),
(1893, 386, 2126, 2026, 2),
(1894, 386, 2041, 2026, 2),
(1895, 386, 1909, 2026, 2),
(1896, 386, 1910, 2026, 2),
(1897, 387, 1848, 2026, 2),
(1898, 387, 1766, 2026, 2),
(1899, 387, 1767, 2026, 2),
(1900, 387, 1935, 2026, 2),
(1901, 387, 2079, 2026, 2),
(1902, 387, 1802, 2026, 2),
(1903, 387, 1803, 2026, 2),
(1904, 388, 1849, 2026, 2),
(1905, 388, 1850, 2026, 2),
(1906, 388, 2127, 2026, 2),
(1907, 388, 2128, 2026, 2),
(1908, 388, 2129, 2026, 2),
(1909, 388, 1951, 2026, 2),
(1910, 388, 1887, 2026, 2),
(1911, 389, 1936, 2026, 2),
(1912, 389, 1937, 2026, 2),
(1913, 389, 1938, 2026, 2),
(1914, 389, 2042, 2026, 2),
(1915, 389, 2043, 2026, 2),
(1916, 389, 2044, 2026, 2),
(1917, 389, 2045, 2026, 2),
(1918, 390, 1872, 2026, 2),
(1919, 390, 1873, 2026, 2),
(1920, 390, 1874, 2026, 2),
(1921, 390, 2025, 2026, 2),
(1922, 391, 2026, 2026, 2),
(1923, 391, 2027, 2026, 2),
(1924, 391, 2028, 2026, 2),
(1925, 391, 2029, 2026, 2),
(1926, 392, 2030, 2026, 2),
(1927, 392, 2031, 2026, 2),
(1928, 392, 2032, 2026, 2),
(1929, 392, 2033, 2026, 2),
(1930, 393, 2034, 2026, 2),
(1931, 393, 2035, 2026, 2),
(1932, 393, 2036, 2026, 2),
(1933, 393, 2118, 2026, 2),
(1934, 394, 2119, 2026, 2),
(1935, 394, 2120, 2026, 2),
(1936, 394, 2121, 2026, 2),
(1937, 394, 2122, 2026, 2),
(1938, 395, 2123, 2026, 2),
(1939, 395, 1939, 2026, 2),
(1940, 395, 1940, 2026, 2),
(1941, 395, 1941, 2026, 2),
(1942, 395, 1942, 2026, 2),
(1943, 395, 1943, 2026, 2),
(1944, 396, 1944, 2026, 2),
(1945, 396, 1945, 2026, 2),
(1946, 396, 1946, 2026, 2),
(1947, 396, 2073, 2026, 2),
(1948, 396, 2074, 2026, 2),
(1949, 396, 2075, 2026, 2),
(1950, 397, 2076, 2026, 2),
(1951, 397, 2077, 2026, 2),
(1952, 397, 2078, 2026, 2),
(1953, 397, 2046, 2026, 2),
(1954, 397, 2047, 2026, 2),
(1955, 397, 2048, 2026, 2),
(1956, 397, 2080, 2026, 2),
(1957, 398, 2081, 2026, 2),
(1958, 398, 2082, 2026, 2),
(1959, 398, 2083, 2026, 2),
(1960, 398, 2084, 2026, 2),
(1961, 398, 2085, 2026, 2),
(1962, 398, 2086, 2026, 2),
(1963, 398, 2087, 2026, 2),
(1964, 399, 2088, 2026, 2),
(1965, 399, 2089, 2026, 2),
(1966, 399, 2090, 2026, 2),
(1967, 399, 1952, 2026, 2),
(1968, 399, 1953, 2026, 2),
(1969, 399, 1954, 2026, 2),
(1970, 399, 1955, 2026, 2),
(1971, 400, 1956, 2026, 2),
(1972, 400, 1957, 2026, 2),
(1973, 400, 1958, 2026, 2),
(1974, 400, 1959, 2026, 2),
(1975, 400, 1960, 2026, 2),
(1976, 400, 1961, 2026, 2),
(1977, 400, 1962, 2026, 2),
(1978, 401, 1963, 2026, 2),
(1979, 401, 1964, 2026, 2),
(1980, 401, 1965, 2026, 2),
(1981, 401, 1966, 2026, 2),
(1982, 401, 1967, 2026, 2),
(1983, 401, 1968, 2026, 2),
(1984, 401, 1969, 2026, 2),
(1985, 402, 1970, 2026, 2),
(1986, 402, 1888, 2026, 2),
(1987, 403, 1768, 2026, 2),
(1988, 403, 1769, 2026, 2),
(1989, 403, 1770, 2026, 2),
(1990, 403, 1771, 2026, 2),
(1991, 403, 1772, 2026, 2),
(1992, 403, 1773, 2026, 2),
(1993, 403, 1808, 2026, 2),
(1994, 404, 1774, 2026, 2),
(1995, 404, 1775, 2026, 2),
(1996, 404, 1776, 2026, 2),
(1997, 404, 1777, 2026, 2),
(1998, 404, 1778, 2026, 2),
(1999, 404, 1779, 2026, 2),
(2000, 404, 1809, 2026, 2),
(2001, 405, 1780, 2026, 2),
(2002, 405, 1781, 2026, 2),
(2003, 405, 1782, 2026, 2),
(2004, 405, 1783, 2026, 2),
(2005, 405, 1784, 2026, 2),
(2006, 405, 1785, 2026, 2),
(2007, 405, 1810, 2026, 2),
(2008, 406, 1851, 2026, 2),
(2009, 406, 1852, 2026, 2),
(2010, 406, 1853, 2026, 2),
(2011, 406, 1854, 2026, 2),
(2012, 406, 1855, 2026, 2),
(2013, 406, 1856, 2026, 2),
(2014, 406, 1811, 2026, 2),
(2015, 407, 1857, 2026, 2),
(2016, 407, 1858, 2026, 2),
(2017, 407, 1859, 2026, 2),
(2018, 407, 1860, 2026, 2),
(2019, 407, 1861, 2026, 2),
(2020, 407, 1862, 2026, 2),
(2021, 407, 1812, 2026, 2),
(2022, 408, 1863, 2026, 2),
(2023, 408, 1864, 2026, 2),
(2024, 408, 1865, 2026, 2),
(2025, 408, 1866, 2026, 2),
(2026, 408, 1867, 2026, 2),
(2027, 408, 1868, 2026, 2),
(2028, 408, 1813, 2026, 2),
(2029, 409, 1869, 2026, 2),
(2030, 409, 1870, 2026, 2),
(2031, 409, 1971, 2026, 2),
(2032, 409, 1972, 2026, 2),
(2033, 409, 1973, 2026, 2),
(2034, 409, 1974, 2026, 2),
(2035, 409, 1814, 2026, 2),
(2036, 410, 1975, 2026, 2),
(2037, 410, 1976, 2026, 2),
(2038, 410, 1977, 2026, 2),
(2039, 410, 1978, 2026, 2),
(2040, 410, 1979, 2026, 2),
(2041, 410, 1980, 2026, 2),
(2042, 410, 1893, 2026, 2),
(2043, 411, 1981, 2026, 2),
(2044, 411, 1982, 2026, 2),
(2045, 411, 1983, 2026, 2),
(2046, 411, 1984, 2026, 2),
(2047, 411, 1985, 2026, 2),
(2048, 411, 1986, 2026, 2),
(2049, 411, 1894, 2026, 2),
(2050, 412, 1987, 2026, 2),
(2051, 412, 1988, 2026, 2),
(2052, 412, 1989, 2026, 2),
(2053, 412, 1990, 2026, 2),
(2054, 412, 1991, 2026, 2),
(2055, 412, 1992, 2026, 2),
(2056, 412, 1895, 2026, 2),
(2057, 413, 1993, 2026, 2),
(2058, 413, 1994, 2026, 2),
(2059, 413, 1995, 2026, 2),
(2060, 413, 1996, 2026, 2),
(2061, 413, 1997, 2026, 2),
(2062, 413, 1998, 2026, 2),
(2063, 413, 1896, 2026, 2),
(2064, 414, 1999, 2026, 2),
(2065, 414, 2000, 2026, 2),
(2066, 414, 2001, 2026, 2),
(2067, 414, 2002, 2026, 2),
(2068, 414, 2003, 2026, 2),
(2069, 414, 2004, 2026, 2),
(2070, 414, 1897, 2026, 2),
(2071, 415, 2005, 2026, 2),
(2072, 415, 2006, 2026, 2),
(2073, 415, 2007, 2026, 2),
(2074, 415, 2008, 2026, 2),
(2075, 415, 2009, 2026, 2),
(2076, 415, 2010, 2026, 2),
(2077, 415, 1898, 2026, 2),
(2078, 416, 2011, 2026, 2),
(2079, 416, 2012, 2026, 2),
(2080, 416, 2013, 2026, 2),
(2081, 416, 2014, 2026, 2),
(2082, 416, 2015, 2026, 2),
(2083, 416, 2016, 2026, 2),
(2084, 416, 1899, 2026, 2),
(2085, 417, 2017, 2026, 2),
(2086, 417, 2018, 2026, 2),
(2087, 417, 2019, 2026, 2),
(2088, 417, 2020, 2026, 2),
(2089, 417, 2021, 2026, 2),
(2090, 417, 2022, 2026, 2),
(2091, 418, 2023, 2026, 2),
(2092, 418, 2024, 2026, 2),
(2093, 418, 2091, 2026, 2),
(2094, 418, 2092, 2026, 2),
(2095, 418, 2093, 2026, 2),
(2096, 418, 2094, 2026, 2),
(2097, 419, 2095, 2026, 2),
(2098, 419, 2096, 2026, 2),
(2099, 419, 2097, 2026, 2),
(2100, 419, 2098, 2026, 2),
(2101, 419, 2099, 2026, 2),
(2102, 419, 2100, 2026, 2),
(2103, 420, 2101, 2026, 2),
(2104, 420, 2102, 2026, 2),
(2105, 420, 2103, 2026, 2),
(2106, 420, 2104, 2026, 2),
(2107, 420, 2105, 2026, 2),
(2108, 420, 2106, 2026, 2),
(2109, 421, 2107, 2026, 2),
(2110, 421, 2108, 2026, 2),
(2111, 421, 2109, 2026, 2),
(2112, 421, 2110, 2026, 2),
(2113, 421, 2111, 2026, 2),
(2114, 421, 2112, 2026, 2),
(2115, 422, 2113, 2026, 2),
(2116, 422, 2114, 2026, 2),
(2117, 422, 2115, 2026, 2),
(2118, 422, 2116, 2026, 2),
(2119, 422, 2117, 2026, 2),
(2120, 423, 1795, 2026, 2),
(2121, 423, 1796, 2026, 2),
(2122, 423, 1794, 2026, 2),
(2123, 424, 1880, 2026, 2),
(2124, 424, 1881, 2026, 2),
(2125, 424, 1879, 2026, 2),
(2126, 425, 1799, 2026, 2),
(2127, 425, 1800, 2026, 2),
(2128, 425, 1797, 2026, 2),
(2129, 426, 1884, 2026, 2),
(2130, 426, 1885, 2026, 2),
(2131, 426, 1798, 2026, 2),
(2132, 427, 1882, 2026, 2),
(2133, 427, 1883, 2026, 2),
(2134, 428, 1817, 2026, 2),
(2135, 428, 1902, 2026, 2);

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua_settings`
--

DROP TABLE IF EXISTS `cua_mau_cua_settings`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_mau_cua` int DEFAULT NULL,
  `vet_cat` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_mau_cua` (`id_mau_cua`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `cua_mau_cua_settings`
--

INSERT INTO `cua_mau_cua_settings` (`id`, `id_mau_cua`, `vet_cat`) VALUES
(1, 1, 2),
(2, 2, 2),
(3, 3, 2),
(4, 4, 10),
(5, 5, 10),
(6, 6, 10),
(7, 7, 10),
(8, 8, 10);

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua_vach`
--

DROP TABLE IF EXISTS `cua_mau_cua_vach`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua_vach` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_mau_cua` int NOT NULL,
  `id_vach` int NOT NULL,
  `rong` float DEFAULT NULL,
  `cao` float DEFAULT NULL,
  `so_luong` float DEFAULT NULL,
  `dien_tich` float DEFAULT NULL,
  `don_gia` double NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int NOT NULL,
  `so_luong_xuat` float DEFAULT NULL,
  `ghi_chu_xuat` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `so_luong_nhap_lai` float DEFAULT NULL,
  `ghi_chu_nhap_lai` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `code_bao_gia` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_mau_cua` (`id_mau_cua`),
  KEY `id_vach` (`id_vach`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `cua_mau_cua_vach`
--

INSERT INTO `cua_mau_cua_vach` (`id`, `id_mau_cua`, `id_vach`, `rong`, `cao`, `so_luong`, `dien_tich`, `don_gia`, `date_created`, `user_created`, `so_luong_xuat`, `ghi_chu_xuat`, `so_luong_nhap_lai`, `ghi_chu_nhap_lai`, `code_bao_gia`) VALUES
(1, 1, 1, 409, 2208, 4, 3.61, 0, '2026-03-13 08:22:10', 2, 0, '', 0, '', NULL),
(2, 1, 1, 539, 331, 2, 0.36, 0, '2026-03-13 08:22:10', 2, 0, '', 0, '', NULL),
(3, 1, 1, 1081, 331, 1, 0.36, 0, '2026-03-13 08:22:10', 2, 0, '', 0, '', NULL),
(4, 2, 1, 620, 1024, 4, 2.54, 0, '2026-03-13 08:22:16', 2, 0, '', 0, '', NULL),
(5, 2, 1, 1382, 331, 2, 0.91, 0, '2026-03-13 08:22:16', 2, 0, '', 0, '', NULL),
(6, 3, 1, 495, 1024, 6, 3.04, 0, '2026-03-13 08:22:17', 2, 0, '', 0, '', NULL),
(7, 3, 1, 1132, 331, 3, 1.12, 0, '2026-03-13 08:22:17', 2, 0, '', 0, '', NULL),
(8, 4, 2, 864, 2954, 1, 2.55, 0, '2026-03-14 09:56:34', 2, 0, '', 0, '', NULL),
(9, 4, 2, 1195, 2535, 2, 6.06, 0, '2026-03-14 09:56:34', 2, 0, '', 0, '', NULL),
(10, 4, 2, 2394, 411, 1, 0.98, 0, '2026-03-14 09:56:34', 2, 0, '', 0, '', NULL),
(11, 4, 2, 785, 2954, 1, 2.32, 0, '2026-03-14 09:56:34', 2, 0, '', 0, '', NULL),
(12, 5, 1, 908, 1464, 2, 2.66, 0, '2026-03-14 09:56:38', 2, 0, '', 0, '', NULL),
(13, 5, 1, 908, 740, 2, 1.34, 0, '2026-03-14 09:56:38', 2, 0, '', 0, '', NULL),
(14, 5, 1, 676, 1372, 1, 0.93, 0, '2026-03-14 09:56:38', 2, 0, '', 0, '', NULL),
(15, 5, 1, 832, 724, 1, 0.6, 0, '2026-03-14 09:56:38', 2, 0, '', 0, '', NULL),
(16, 6, 1, 913, 1464, 2, 2.67, 0, '2026-03-14 09:56:38', 2, 0, '', 0, '', NULL),
(17, 6, 1, 913, 740, 2, 1.35, 0, '2026-03-14 09:56:38', 2, 0, '', 0, '', NULL),
(18, 6, 1, 676, 1372, 1, 0.93, 0, '2026-03-14 09:56:38', 2, 0, '', 0, '', NULL),
(19, 6, 1, 832, 724, 1, 0.6, 0, '2026-03-14 09:56:38', 2, 0, '', 0, '', NULL),
(20, 7, 1, 858, 1464, 4, 5.02, 0, '2026-03-14 09:56:38', 2, 0, '', 0, '', NULL),
(21, 7, 1, 874, 1464, 2, 2.56, 0, '2026-03-14 09:56:38', 2, 0, '', 0, '', NULL),
(22, 7, 1, 858, 740, 4, 2.54, 0, '2026-03-14 09:56:38', 2, 0, '', 0, '', NULL),
(23, 7, 1, 874, 740, 2, 1.29, 0, '2026-03-14 09:56:38', 2, 0, '', 0, '', NULL),
(24, 8, 1, 861, 1464, 2, 2.52, 0, '2026-03-14 09:56:39', 2, 0, '', 0, '', NULL),
(25, 8, 1, 877, 1464, 1, 1.28, 0, '2026-03-14 09:56:39', 2, 0, '', 0, '', NULL),
(26, 8, 1, 861, 740, 2, 1.27, 0, '2026-03-14 09:56:39', 2, 0, '', 0, '', NULL),
(27, 8, 1, 877, 740, 1, 0.65, 0, '2026-03-14 09:56:39', 2, 0, '', 0, '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua_vat_tu`
--

DROP TABLE IF EXISTS `cua_mau_cua_vat_tu`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua_vat_tu` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_mau_cua` int NOT NULL,
  `id_kho_vat_tu` int NOT NULL,
  `so_luong` float NOT NULL,
  `dvt` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `don_gia` double DEFAULT NULL,
  `la_phu_kien` tinyint DEFAULT NULL,
  `so_luong_xuat` float DEFAULT NULL,
  `ghi_chu_xuat` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `so_luong_nhap_lai` float DEFAULT NULL,
  `ghi_chu_nhap_lai` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  `code_bao_gia` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_mau_cua` (`id_mau_cua`),
  KEY `id_kho_vat_tu` (`id_kho_vat_tu`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `cua_mau_cua_vat_tu`
--

INSERT INTO `cua_mau_cua_vat_tu` (`id`, `id_mau_cua`, `id_kho_vat_tu`, `so_luong`, `dvt`, `don_gia`, `la_phu_kien`, `so_luong_xuat`, `ghi_chu_xuat`, `so_luong_nhap_lai`, `ghi_chu_nhap_lai`, `date_created`, `user_created`, `code_bao_gia`) VALUES
(1, 1, 83, 38, 'cái', 0, 1, 38, '', 0, '', NULL, NULL, NULL),
(2, 1, 84, 18, 'cái', 0, 1, 18, '', 0, '', NULL, NULL, NULL),
(3, 1, 85, 8, 'cái', 0, 1, 8, '', 0, '', NULL, NULL, NULL),
(4, 1, 86, 8, 'cái', 0, 1, 8, '', 0, '', NULL, NULL, NULL),
(5, 1, 87, 1, 'cặp', 0, 1, 1, '', 0, '', NULL, NULL, NULL),
(6, 1, 88, 1, 'cái', 0, 1, 1, '', 0, '', NULL, NULL, NULL),
(7, 1, 89, 1, 'cái', 0, 1, 1, '', 0, '', NULL, NULL, NULL),
(8, 1, 90, 1, 'cái', 0, 1, 1, '', 0, '', NULL, NULL, NULL),
(9, 1, 91, 2, 'cái', 0, 1, 2, '', 0, '', NULL, NULL, NULL),
(10, 1, 92, 6, 'cái', 0, 1, 6, '', 0, '', NULL, NULL, NULL),
(11, 1, 93, 6, 'cái', 0, 1, 6, '', 0, '', NULL, NULL, NULL),
(12, 1, 94, 6, 'cái', 0, 1, 6, '', 0, '', NULL, NULL, NULL),
(13, 1, 95, 2, 'cái', 0, 1, 2, '', 0, '', NULL, NULL, NULL),
(14, 1, 96, 4, 'cái', 0, 1, 4, '', 0, '', NULL, NULL, NULL),
(15, 1, 97, 4, 'cái', 0, 1, 4, '', 0, '', NULL, NULL, NULL),
(16, 1, 98, 3, 'cái', 0, 0, 3, '', 0, '', NULL, NULL, NULL),
(17, 1, 99, 5, 'cái', 0, 0, 5, '', 0, '', NULL, NULL, NULL),
(18, 1, 100, 5.26, 'm2', 0, 0, 5.26, '', 0, '', NULL, NULL, NULL),
(19, 1, 101, 0.73, 'm2', 0, 0, 0.73, '', 0, '', NULL, NULL, NULL),
(20, 2, 96, 16, 'cái', 0, 1, 16, '', 0, '', NULL, NULL, NULL),
(21, 2, 102, 16, 'cái', 0, 1, 16, '', 0, '', NULL, NULL, NULL),
(22, 2, 103, 2, 'cái', 0, 1, 2, '', 0, '', NULL, NULL, NULL),
(23, 2, 104, 2, 'cái', 0, 1, 2, '', 0, '', NULL, NULL, NULL),
(24, 2, 105, 8, 'cái', 0, 1, 8, '', 0, '', NULL, NULL, NULL),
(25, 2, 83, 8, 'cái', 0, 1, 8, '', 0, '', NULL, NULL, NULL),
(26, 2, 106, 2, 'cái', 0, 0, 2, '', 0, '', NULL, NULL, NULL),
(27, 2, 107, 8, 'cái', 0, 0, 8, '', 0, '', NULL, NULL, NULL),
(28, 2, 108, 8, 'cái', 0, 0, 8, '', 0, '', NULL, NULL, NULL),
(29, 2, 109, 3, 'm2', 0, 0, 3, '', 0, '', NULL, NULL, NULL),
(30, 2, 101, 0.93, 'm2', 0, 0, 0.93, '', 0, '', NULL, NULL, NULL),
(31, 3, 96, 24, 'cái', 0, 1, 24, '', 0, '', NULL, NULL, NULL),
(32, 3, 102, 24, 'cái', 0, 1, 24, '', 0, '', NULL, NULL, NULL),
(33, 3, 103, 3, 'cái', 0, 1, 3, '', 0, '', NULL, NULL, NULL),
(34, 3, 104, 3, 'cái', 0, 1, 3, '', 0, '', NULL, NULL, NULL),
(35, 3, 105, 12, 'cái', 0, 1, 12, '', 0, '', NULL, NULL, NULL),
(36, 3, 83, 12, 'cái', 0, 1, 12, '', 0, '', NULL, NULL, NULL),
(37, 3, 106, 3, 'cái', 0, 0, 3, '', 0, '', NULL, NULL, NULL),
(38, 3, 107, 12, 'cái', 0, 0, 12, '', 0, '', NULL, NULL, NULL),
(39, 3, 108, 12, 'cái', 0, 0, 12, '', 0, '', NULL, NULL, NULL),
(40, 3, 109, 3.67, 'm2', 0, 0, 3.67, '', 0, '', NULL, NULL, NULL),
(41, 3, 101, 1.15, 'm2', 0, 0, 1.15, '', 0, '', NULL, NULL, NULL),
(42, 4, 110, 2, 'bộ', 0, 1, 2, '', 0, '', NULL, NULL, NULL),
(43, 4, 111, 2, 'bộ', 0, 1, 2, '', 0, '', NULL, NULL, NULL),
(44, 4, 112, 2, 'cái', 0, 1, 2, '', 0, '', NULL, NULL, NULL),
(45, 4, 113, 2, 'cái', 0, 1, 2, '', 0, '', NULL, NULL, NULL),
(46, 4, 114, 2, 'cái', 0, 1, 2, '', 0, '', NULL, NULL, NULL),
(47, 4, 115, 2, 'cái', 0, 1, 2, '', 0, '', NULL, NULL, NULL),
(48, 5, 83, 18, 'cái', 0, 1, 18, '', 0, '', NULL, NULL, NULL),
(49, 5, 96, 8, 'cái', 0, 1, 8, '', 0, '', NULL, NULL, NULL),
(50, 5, 97, 12, 'cái', 0, 1, 12, '', 0, '', NULL, NULL, NULL),
(51, 5, 84, 6, 'cái', 0, 1, 6, '', 0, '', NULL, NULL, NULL),
(52, 5, 85, 3, 'cái', 0, 1, 3, '', 0, '', NULL, NULL, NULL),
(53, 5, 87, 1, 'cặp', 0, 1, 1, '', 0, '', NULL, NULL, NULL),
(54, 5, 116, 1, 'cái', 0, 1, 1, '', 0, '', NULL, NULL, NULL),
(55, 5, 89, 1, 'cái', 0, 1, 1, '', 0, '', NULL, NULL, NULL),
(56, 5, 117, 1, 'cái', 0, 1, 1, '', 0, '', NULL, NULL, NULL),
(57, 5, 101, 6.21, 'm2', 0, 0, 6.21, '', 0, '', NULL, NULL, NULL),
(58, 5, 99, 2, 'cái', 0, 0, 2, '', 0, '', NULL, NULL, NULL),
(59, 5, 118, 1.96, 'm2', 0, 0, 1.96, '', 0, '', NULL, NULL, NULL),
(60, 6, 83, 18, 'cái', 0, 1, 18, '', 0, '', NULL, NULL, NULL),
(61, 6, 96, 8, 'cái', 0, 1, 8, '', 0, '', NULL, NULL, NULL),
(62, 6, 97, 12, 'cái', 0, 1, 12, '', 0, '', NULL, NULL, NULL),
(63, 6, 84, 6, 'cái', 0, 1, 6, '', 0, '', NULL, NULL, NULL),
(64, 6, 85, 3, 'cái', 0, 1, 3, '', 0, '', NULL, NULL, NULL),
(65, 6, 87, 1, 'cặp', 0, 1, 1, '', 0, '', NULL, NULL, NULL),
(66, 6, 116, 1, 'cái', 0, 1, 1, '', 0, '', NULL, NULL, NULL),
(67, 6, 89, 1, 'cái', 0, 1, 1, '', 0, '', NULL, NULL, NULL),
(68, 6, 117, 1, 'cái', 0, 1, 1, '', 0, '', NULL, NULL, NULL),
(69, 6, 101, 6.23, 'm2', 0, 0, 6.23, '', 0, '', NULL, NULL, NULL),
(70, 6, 99, 2, 'cái', 0, 0, 2, '', 0, '', NULL, NULL, NULL),
(71, 6, 118, 1.96, 'm2', 0, 0, 1.96, '', 0, '', NULL, NULL, NULL),
(72, 7, 83, 8, 'cái', 0, 1, 8, '', 0, '', NULL, NULL, NULL),
(73, 7, 96, 8, 'cái', 0, 1, 8, '', 0, '', NULL, NULL, NULL),
(74, 7, 97, 32, 'cái', 0, 1, 32, '', 0, '', NULL, NULL, NULL),
(75, 7, 101, 16, 'm2', 0, 0, 16, '', 0, '', NULL, NULL, NULL),
(76, 8, 83, 4, 'cái', 0, 1, 4, '', 0, '', NULL, NULL, NULL),
(77, 8, 96, 4, 'cái', 0, 1, 4, '', 0, '', NULL, NULL, NULL),
(78, 8, 97, 16, 'cái', 0, 1, 16, '', 0, '', NULL, NULL, NULL),
(79, 8, 101, 8.03, 'm2', 0, 0, 8.03, '', 0, '', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cua_settings`
--

DROP TABLE IF EXISTS `cua_settings`;
CREATE TABLE IF NOT EXISTS `cua_settings` (
  `id` int NOT NULL,
  `cho_phep_nhap_kho_am` tinyint(1) DEFAULT NULL,
  `an_kho_nhom_bang_khong` tinyint(1) DEFAULT NULL,
  `vet_cat` float DEFAULT NULL,
  `chieu_dai_nhom_mac_dinh` float DEFAULT NULL,
  `so_ngay_canh_bao_giao_cua` tinyint DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `cua_settings`
--

INSERT INTO `cua_settings` (`id`, `cho_phep_nhap_kho_am`, `an_kho_nhom_bang_khong`, `vet_cat`, `chieu_dai_nhom_mac_dinh`, `so_ngay_canh_bao_giao_cua`) VALUES
(1, 1, 1, 2, 6000, 2);

-- --------------------------------------------------------

--
-- Table structure for table `cua_thuong_hieu`
--

DROP TABLE IF EXISTS `cua_thuong_hieu`;
CREATE TABLE IF NOT EXISTS `cua_thuong_hieu` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `ten_thuong_hieu` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `ghi_chu` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `cua_thuong_hieu`
--

INSERT INTO `cua_thuong_hieu` (`id`, `code`, `ten_thuong_hieu`, `ghi_chu`) VALUES
(1, 'chua-phan-loai', 'Mặc định', ''),
(2, 'DRAHO', 'DRAHO', ''),
(3, 'BOGO', 'BOGO', 'Thương hiệu BOGO');

-- --------------------------------------------------------

--
-- Table structure for table `cua_toi_uu`
--

DROP TABLE IF EXISTS `cua_toi_uu`;
CREATE TABLE IF NOT EXISTS `cua_toi_uu` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_mau_cua` int NOT NULL,
  `id_mau_cua_nhom` int NOT NULL,
  `id_ton_kho_nhom` int DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_mau_cua` (`id_mau_cua`),
  KEY `id_mau_cua_nhom` (`id_mau_cua_nhom`),
  KEY `id_ton_kho_nhom` (`id_ton_kho_nhom`)
) ENGINE=InnoDB AUTO_INCREMENT=2136 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `cua_toi_uu`
--

INSERT INTO `cua_toi_uu` (`id`, `id_mau_cua`, `id_mau_cua_nhom`, `id_ton_kho_nhom`, `date_created`, `user_created`) VALUES
(363, 1, 1, 35, '2026-03-13 08:35:12', 2),
(364, 1, 2, 36, '2026-03-13 08:35:12', 2),
(365, 1, 3, 36, '2026-03-13 08:35:12', 2),
(366, 1, 4, 36, '2026-03-13 08:35:12', 2),
(367, 1, 5, 37, '2026-03-13 08:35:12', 2),
(368, 1, 5, 37, '2026-03-13 08:35:12', 2),
(369, 1, 5, 37, '2026-03-13 08:35:12', 2),
(370, 1, 5, 37, '2026-03-13 08:35:12', 2),
(371, 1, 5, 37, '2026-03-13 08:35:12', 2),
(372, 1, 5, 37, '2026-03-13 08:35:12', 2),
(373, 1, 5, 37, '2026-03-13 08:35:12', 2),
(374, 1, 5, 37, '2026-03-13 08:35:12', 2),
(375, 1, 6, 37, '2026-03-13 08:35:12', 2),
(376, 1, 6, 37, '2026-03-13 08:35:12', 2),
(377, 1, 6, 37, '2026-03-13 08:35:12', 2),
(378, 1, 6, 37, '2026-03-13 08:35:12', 2),
(379, 1, 6, 37, '2026-03-13 08:35:12', 2),
(380, 1, 6, 37, '2026-03-13 08:35:12', 2),
(381, 1, 6, 37, '2026-03-13 08:35:12', 2),
(382, 1, 6, 37, '2026-03-13 08:35:12', 2),
(383, 1, 7, 38, '2026-03-13 08:35:12', 2),
(384, 1, 7, 38, '2026-03-13 08:35:12', 2),
(385, 1, 7, 38, '2026-03-13 08:35:12', 2),
(386, 1, 7, 38, '2026-03-13 08:35:12', 2),
(387, 1, 7, 38, '2026-03-13 08:35:12', 2),
(388, 1, 7, 38, '2026-03-13 08:35:12', 2),
(389, 1, 7, 38, '2026-03-13 08:35:12', 2),
(390, 1, 7, 38, '2026-03-13 08:35:12', 2),
(391, 1, 8, 38, '2026-03-13 08:35:12', 2),
(392, 1, 8, 38, '2026-03-13 08:35:12', 2),
(393, 1, 8, 38, '2026-03-13 08:35:12', 2),
(394, 1, 8, 38, '2026-03-13 08:35:12', 2),
(395, 1, 8, 38, '2026-03-13 08:35:12', 2),
(396, 1, 8, 38, '2026-03-13 08:35:12', 2),
(397, 1, 8, 38, '2026-03-13 08:35:12', 2),
(398, 1, 8, 38, '2026-03-13 08:35:12', 2),
(399, 1, 9, 39, '2026-03-13 08:35:12', 2),
(400, 1, 9, 39, '2026-03-13 08:35:12', 2),
(401, 1, 9, 39, '2026-03-13 08:35:12', 2),
(402, 1, 10, 40, '2026-03-13 08:35:12', 2),
(403, 1, 10, 40, '2026-03-13 08:35:12', 2),
(404, 1, 10, 40, '2026-03-13 08:35:12', 2),
(405, 1, 10, 40, '2026-03-13 08:35:12', 2),
(406, 1, 11, 41, '2026-03-13 08:35:12', 2),
(407, 1, 11, 41, '2026-03-13 08:35:12', 2),
(408, 1, 12, 41, '2026-03-13 08:35:12', 2),
(409, 1, 12, 41, '2026-03-13 08:35:12', 2),
(410, 1, 13, 42, '2026-03-13 08:35:12', 2),
(411, 1, 13, 42, '2026-03-13 08:35:12', 2),
(412, 1, 14, 38, '2026-03-13 08:35:12', 2),
(413, 1, 14, 38, '2026-03-13 08:35:12', 2),
(414, 1, 14, 38, '2026-03-13 08:35:12', 2),
(415, 1, 14, 38, '2026-03-13 08:35:12', 2),
(416, 1, 14, 38, '2026-03-13 08:35:12', 2),
(417, 1, 14, 38, '2026-03-13 08:35:12', 2),
(418, 1, 15, 38, '2026-03-13 08:35:12', 2),
(419, 1, 15, 38, '2026-03-13 08:35:12', 2),
(420, 1, 15, 38, '2026-03-13 08:35:12', 2),
(421, 1, 15, 38, '2026-03-13 08:35:12', 2),
(422, 1, 16, 38, '2026-03-13 08:35:12', 2),
(423, 1, 16, 38, '2026-03-13 08:35:12', 2),
(424, 2, 17, 35, '2026-03-13 08:35:12', 2),
(425, 2, 17, 35, '2026-03-13 08:35:12', 2),
(426, 2, 18, 43, '2026-03-13 08:35:12', 2),
(427, 2, 18, 43, '2026-03-13 08:35:12', 2),
(428, 2, 18, 43, '2026-03-13 08:35:12', 2),
(429, 2, 18, 43, '2026-03-13 08:35:12', 2),
(430, 2, 19, 43, '2026-03-13 08:35:12', 2),
(431, 2, 19, 43, '2026-03-13 08:35:12', 2),
(432, 2, 19, 43, '2026-03-13 08:35:12', 2),
(433, 2, 19, 43, '2026-03-13 08:35:12', 2),
(434, 2, 20, 44, '2026-03-13 08:35:12', 2),
(435, 2, 20, 44, '2026-03-13 08:35:12', 2),
(436, 2, 20, 44, '2026-03-13 08:35:12', 2),
(437, 2, 20, 44, '2026-03-13 08:35:12', 2),
(438, 2, 20, 44, '2026-03-13 08:35:12', 2),
(439, 2, 20, 44, '2026-03-13 08:35:12', 2),
(440, 2, 20, 44, '2026-03-13 08:35:12', 2),
(441, 2, 20, 44, '2026-03-13 08:35:12', 2),
(442, 2, 21, 44, '2026-03-13 08:35:12', 2),
(443, 2, 21, 44, '2026-03-13 08:35:12', 2),
(444, 2, 21, 44, '2026-03-13 08:35:12', 2),
(445, 2, 21, 44, '2026-03-13 08:35:12', 2),
(446, 2, 21, 44, '2026-03-13 08:35:12', 2),
(447, 2, 21, 44, '2026-03-13 08:35:12', 2),
(448, 2, 21, 44, '2026-03-13 08:35:12', 2),
(449, 2, 21, 44, '2026-03-13 08:35:12', 2),
(450, 2, 22, 45, '2026-03-13 08:35:12', 2),
(451, 2, 22, 45, '2026-03-13 08:35:12', 2),
(452, 2, 22, 45, '2026-03-13 08:35:12', 2),
(453, 2, 22, 45, '2026-03-13 08:35:12', 2),
(454, 2, 23, 46, '2026-03-13 08:35:12', 2),
(455, 2, 23, 46, '2026-03-13 08:35:12', 2),
(456, 2, 24, 41, '2026-03-13 08:35:12', 2),
(457, 2, 24, 41, '2026-03-13 08:35:12', 2),
(458, 2, 24, 41, '2026-03-13 08:35:12', 2),
(459, 2, 24, 41, '2026-03-13 08:35:12', 2),
(460, 2, 25, 41, '2026-03-13 08:35:12', 2),
(461, 2, 25, 41, '2026-03-13 08:35:12', 2),
(462, 2, 25, 41, '2026-03-13 08:35:12', 2),
(463, 2, 25, 41, '2026-03-13 08:35:12', 2),
(464, 2, 26, 38, '2026-03-13 08:35:12', 2),
(465, 2, 26, 38, '2026-03-13 08:35:12', 2),
(466, 2, 26, 38, '2026-03-13 08:35:12', 2),
(467, 2, 26, 38, '2026-03-13 08:35:12', 2),
(468, 2, 27, 38, '2026-03-13 08:35:12', 2),
(469, 2, 27, 38, '2026-03-13 08:35:12', 2),
(470, 2, 27, 38, '2026-03-13 08:35:12', 2),
(471, 2, 27, 38, '2026-03-13 08:35:12', 2),
(472, 3, 28, 35, '2026-03-13 08:35:13', 2),
(473, 3, 28, 35, '2026-03-13 08:35:13', 2),
(474, 3, 28, 35, '2026-03-13 08:35:13', 2),
(475, 3, 29, 43, '2026-03-13 08:35:13', 2),
(476, 3, 29, 43, '2026-03-13 08:35:13', 2),
(477, 3, 29, 43, '2026-03-13 08:35:13', 2),
(478, 3, 29, 43, '2026-03-13 08:35:13', 2),
(479, 3, 29, 43, '2026-03-13 08:35:13', 2),
(480, 3, 29, 43, '2026-03-13 08:35:13', 2),
(481, 3, 30, 43, '2026-03-13 08:35:13', 2),
(482, 3, 30, 43, '2026-03-13 08:35:13', 2),
(483, 3, 30, 43, '2026-03-13 08:35:13', 2),
(484, 3, 30, 43, '2026-03-13 08:35:13', 2),
(485, 3, 30, 43, '2026-03-13 08:35:13', 2),
(486, 3, 30, 43, '2026-03-13 08:35:13', 2),
(487, 3, 31, 44, '2026-03-13 08:35:13', 2),
(488, 3, 31, 44, '2026-03-13 08:35:13', 2),
(489, 3, 31, 44, '2026-03-13 08:35:13', 2),
(490, 3, 31, 44, '2026-03-13 08:35:13', 2),
(491, 3, 31, 44, '2026-03-13 08:35:13', 2),
(492, 3, 31, 44, '2026-03-13 08:35:13', 2),
(493, 3, 31, 44, '2026-03-13 08:35:13', 2),
(494, 3, 31, 44, '2026-03-13 08:35:13', 2),
(495, 3, 31, 44, '2026-03-13 08:35:13', 2),
(496, 3, 31, 44, '2026-03-13 08:35:13', 2),
(497, 3, 31, 44, '2026-03-13 08:35:13', 2),
(498, 3, 31, 44, '2026-03-13 08:35:13', 2),
(499, 3, 32, 44, '2026-03-13 08:35:13', 2),
(500, 3, 32, 44, '2026-03-13 08:35:13', 2),
(501, 3, 32, 44, '2026-03-13 08:35:13', 2),
(502, 3, 32, 44, '2026-03-13 08:35:13', 2),
(503, 3, 32, 44, '2026-03-13 08:35:13', 2),
(504, 3, 32, 44, '2026-03-13 08:35:13', 2),
(505, 3, 32, 44, '2026-03-13 08:35:13', 2),
(506, 3, 32, 44, '2026-03-13 08:35:13', 2),
(507, 3, 32, 44, '2026-03-13 08:35:13', 2),
(508, 3, 32, 44, '2026-03-13 08:35:13', 2),
(509, 3, 32, 44, '2026-03-13 08:35:13', 2),
(510, 3, 32, 44, '2026-03-13 08:35:13', 2),
(511, 3, 33, 45, '2026-03-13 08:35:13', 2),
(512, 3, 33, 45, '2026-03-13 08:35:13', 2),
(513, 3, 33, 45, '2026-03-13 08:35:13', 2),
(514, 3, 33, 45, '2026-03-13 08:35:13', 2),
(515, 3, 33, 45, '2026-03-13 08:35:13', 2),
(516, 3, 33, 45, '2026-03-13 08:35:13', 2),
(517, 3, 34, 46, '2026-03-13 08:35:13', 2),
(518, 3, 34, 46, '2026-03-13 08:35:13', 2),
(519, 3, 34, 46, '2026-03-13 08:35:13', 2),
(520, 3, 35, 41, '2026-03-13 08:35:13', 2),
(521, 3, 35, 41, '2026-03-13 08:35:13', 2),
(522, 3, 35, 41, '2026-03-13 08:35:13', 2),
(523, 3, 35, 41, '2026-03-13 08:35:13', 2),
(524, 3, 35, 41, '2026-03-13 08:35:13', 2),
(525, 3, 35, 41, '2026-03-13 08:35:13', 2),
(526, 3, 36, 41, '2026-03-13 08:35:13', 2),
(527, 3, 36, 41, '2026-03-13 08:35:13', 2),
(528, 3, 36, 41, '2026-03-13 08:35:13', 2),
(529, 3, 36, 41, '2026-03-13 08:35:13', 2),
(530, 3, 36, 41, '2026-03-13 08:35:13', 2),
(531, 3, 36, 41, '2026-03-13 08:35:13', 2),
(532, 3, 37, 38, '2026-03-13 08:35:13', 2),
(533, 3, 37, 38, '2026-03-13 08:35:13', 2),
(534, 3, 37, 38, '2026-03-13 08:35:13', 2),
(535, 3, 37, 38, '2026-03-13 08:35:13', 2),
(536, 3, 37, 38, '2026-03-13 08:35:13', 2),
(537, 3, 37, 38, '2026-03-13 08:35:13', 2),
(538, 3, 38, 38, '2026-03-13 08:35:13', 2),
(539, 3, 38, 38, '2026-03-13 08:35:13', 2),
(540, 3, 38, 38, '2026-03-13 08:35:13', 2),
(541, 3, 38, 38, '2026-03-13 08:35:13', 2),
(542, 3, 38, 38, '2026-03-13 08:35:13', 2),
(543, 3, 38, 38, '2026-03-13 08:35:13', 2),
(1738, 4, 39, 76, '2026-03-14 10:13:46', 2),
(1739, 4, 39, 76, '2026-03-14 10:13:46', 2),
(1740, 4, 40, 76, '2026-03-14 10:13:46', 2),
(1741, 4, 41, 76, '2026-03-14 10:13:46', 2),
(1742, 4, 42, 76, '2026-03-14 10:13:46', 2),
(1743, 5, 43, 41, '2026-03-14 10:13:46', 2),
(1744, 5, 43, 41, '2026-03-14 10:13:46', 2),
(1745, 5, 44, 41, '2026-03-14 10:13:46', 2),
(1746, 5, 44, 41, '2026-03-14 10:13:46', 2),
(1747, 5, 45, 42, '2026-03-14 10:13:46', 2),
(1748, 5, 46, 42, '2026-03-14 10:13:46', 2),
(1749, 5, 46, 42, '2026-03-14 10:13:46', 2),
(1750, 5, 46, 42, '2026-03-14 10:13:46', 2),
(1751, 5, 46, 42, '2026-03-14 10:13:46', 2),
(1752, 5, 47, 38, '2026-03-14 10:13:46', 2),
(1753, 5, 47, 38, '2026-03-14 10:13:46', 2),
(1754, 5, 47, 38, '2026-03-14 10:13:46', 2),
(1755, 5, 47, 38, '2026-03-14 10:13:46', 2),
(1756, 5, 48, 38, '2026-03-14 10:13:46', 2),
(1757, 5, 48, 38, '2026-03-14 10:13:46', 2),
(1758, 5, 48, 38, '2026-03-14 10:13:46', 2),
(1759, 5, 48, 38, '2026-03-14 10:13:46', 2),
(1760, 5, 48, 38, '2026-03-14 10:13:46', 2),
(1761, 5, 48, 38, '2026-03-14 10:13:46', 2),
(1762, 5, 48, 38, '2026-03-14 10:13:46', 2),
(1763, 5, 48, 38, '2026-03-14 10:13:46', 2),
(1764, 5, 48, 38, '2026-03-14 10:13:46', 2),
(1765, 5, 48, 38, '2026-03-14 10:13:46', 2),
(1766, 5, 48, 38, '2026-03-14 10:13:46', 2),
(1767, 5, 48, 38, '2026-03-14 10:13:46', 2),
(1768, 5, 49, 77, '2026-03-14 10:13:46', 2),
(1769, 5, 49, 77, '2026-03-14 10:13:46', 2),
(1770, 5, 49, 77, '2026-03-14 10:13:46', 2),
(1771, 5, 49, 77, '2026-03-14 10:13:46', 2),
(1772, 5, 49, 77, '2026-03-14 10:13:46', 2),
(1773, 5, 49, 77, '2026-03-14 10:13:46', 2),
(1774, 5, 49, 77, '2026-03-14 10:13:46', 2),
(1775, 5, 49, 77, '2026-03-14 10:13:46', 2),
(1776, 5, 49, 77, '2026-03-14 10:13:46', 2),
(1777, 5, 49, 77, '2026-03-14 10:13:46', 2),
(1778, 5, 49, 77, '2026-03-14 10:13:46', 2),
(1779, 5, 49, 77, '2026-03-14 10:13:46', 2),
(1780, 5, 49, 77, '2026-03-14 10:13:46', 2),
(1781, 5, 49, 77, '2026-03-14 10:13:46', 2),
(1782, 5, 49, 77, '2026-03-14 10:13:46', 2),
(1783, 5, 49, 77, '2026-03-14 10:13:46', 2),
(1784, 5, 49, 77, '2026-03-14 10:13:46', 2),
(1785, 5, 49, 77, '2026-03-14 10:13:46', 2),
(1786, 5, 50, 38, '2026-03-14 10:13:46', 2),
(1787, 5, 50, 38, '2026-03-14 10:13:46', 2),
(1788, 5, 50, 38, '2026-03-14 10:13:46', 2),
(1789, 5, 50, 38, '2026-03-14 10:13:46', 2),
(1790, 5, 51, 38, '2026-03-14 10:13:46', 2),
(1791, 5, 51, 38, '2026-03-14 10:13:46', 2),
(1792, 5, 51, 38, '2026-03-14 10:13:46', 2),
(1793, 5, 51, 38, '2026-03-14 10:13:46', 2),
(1794, 5, 52, 36, '2026-03-14 10:13:46', 2),
(1795, 5, 53, 36, '2026-03-14 10:13:46', 2),
(1796, 5, 54, 36, '2026-03-14 10:13:46', 2),
(1797, 5, 55, 78, '2026-03-14 10:13:46', 2),
(1798, 5, 55, 78, '2026-03-14 10:13:46', 2),
(1799, 5, 56, 78, '2026-03-14 10:13:46', 2),
(1800, 5, 56, 78, '2026-03-14 10:13:46', 2),
(1801, 5, 57, 42, '2026-03-14 10:13:46', 2),
(1802, 5, 58, 38, '2026-03-14 10:13:46', 2),
(1803, 5, 58, 38, '2026-03-14 10:13:46', 2),
(1804, 5, 59, 38, '2026-03-14 10:13:46', 2),
(1805, 5, 59, 38, '2026-03-14 10:13:46', 2),
(1806, 5, 59, 38, '2026-03-14 10:13:46', 2),
(1807, 5, 59, 38, '2026-03-14 10:13:46', 2),
(1808, 5, 60, 77, '2026-03-14 10:13:46', 2),
(1809, 5, 60, 77, '2026-03-14 10:13:47', 2),
(1810, 5, 60, 77, '2026-03-14 10:13:47', 2),
(1811, 5, 60, 77, '2026-03-14 10:13:47', 2),
(1812, 5, 60, 77, '2026-03-14 10:13:47', 2),
(1813, 5, 60, 77, '2026-03-14 10:13:47', 2),
(1814, 5, 60, 77, '2026-03-14 10:13:47', 2),
(1815, 5, 61, 38, '2026-03-14 10:13:47', 2),
(1816, 5, 61, 38, '2026-03-14 10:13:47', 2),
(1817, 5, 62, 40, '2026-03-14 10:13:47', 2),
(1818, 5, 63, 41, '2026-03-14 10:13:47', 2),
(1819, 5, 63, 41, '2026-03-14 10:13:47', 2),
(1820, 5, 64, 41, '2026-03-14 10:13:47', 2),
(1821, 5, 64, 41, '2026-03-14 10:13:47', 2),
(1822, 5, 65, 38, '2026-03-14 10:13:47', 2),
(1823, 5, 65, 38, '2026-03-14 10:13:47', 2),
(1824, 5, 66, 38, '2026-03-14 10:13:47', 2),
(1825, 5, 66, 38, '2026-03-14 10:13:47', 2),
(1826, 6, 67, 41, '2026-03-14 10:13:47', 2),
(1827, 6, 67, 41, '2026-03-14 10:13:47', 2),
(1828, 6, 68, 41, '2026-03-14 10:13:47', 2),
(1829, 6, 68, 41, '2026-03-14 10:13:47', 2),
(1830, 6, 69, 42, '2026-03-14 10:13:47', 2),
(1831, 6, 70, 42, '2026-03-14 10:13:47', 2),
(1832, 6, 70, 42, '2026-03-14 10:13:47', 2),
(1833, 6, 70, 42, '2026-03-14 10:13:47', 2),
(1834, 6, 70, 42, '2026-03-14 10:13:47', 2),
(1835, 6, 71, 38, '2026-03-14 10:13:47', 2),
(1836, 6, 71, 38, '2026-03-14 10:13:47', 2),
(1837, 6, 71, 38, '2026-03-14 10:13:47', 2),
(1838, 6, 71, 38, '2026-03-14 10:13:47', 2),
(1839, 6, 72, 38, '2026-03-14 10:13:47', 2),
(1840, 6, 72, 38, '2026-03-14 10:13:47', 2),
(1841, 6, 72, 38, '2026-03-14 10:13:47', 2),
(1842, 6, 72, 38, '2026-03-14 10:13:47', 2),
(1843, 6, 72, 38, '2026-03-14 10:13:47', 2),
(1844, 6, 72, 38, '2026-03-14 10:13:47', 2),
(1845, 6, 72, 38, '2026-03-14 10:13:47', 2),
(1846, 6, 72, 38, '2026-03-14 10:13:47', 2),
(1847, 6, 72, 38, '2026-03-14 10:13:47', 2),
(1848, 6, 72, 38, '2026-03-14 10:13:47', 2),
(1849, 6, 72, 38, '2026-03-14 10:13:47', 2),
(1850, 6, 72, 38, '2026-03-14 10:13:47', 2),
(1851, 6, 73, 77, '2026-03-14 10:13:47', 2),
(1852, 6, 73, 77, '2026-03-14 10:13:47', 2),
(1853, 6, 73, 77, '2026-03-14 10:13:47', 2),
(1854, 6, 73, 77, '2026-03-14 10:13:47', 2),
(1855, 6, 73, 77, '2026-03-14 10:13:47', 2),
(1856, 6, 73, 77, '2026-03-14 10:13:47', 2),
(1857, 6, 73, 77, '2026-03-14 10:13:47', 2),
(1858, 6, 73, 77, '2026-03-14 10:13:47', 2),
(1859, 6, 73, 77, '2026-03-14 10:13:47', 2),
(1860, 6, 73, 77, '2026-03-14 10:13:47', 2),
(1861, 6, 73, 77, '2026-03-14 10:13:47', 2),
(1862, 6, 73, 77, '2026-03-14 10:13:47', 2),
(1863, 6, 73, 77, '2026-03-14 10:13:47', 2),
(1864, 6, 73, 77, '2026-03-14 10:13:47', 2),
(1865, 6, 73, 77, '2026-03-14 10:13:47', 2),
(1866, 6, 73, 77, '2026-03-14 10:13:47', 2),
(1867, 6, 73, 77, '2026-03-14 10:13:47', 2),
(1868, 6, 73, 77, '2026-03-14 10:13:47', 2),
(1869, 6, 73, 77, '2026-03-14 10:13:47', 2),
(1870, 6, 73, 77, '2026-03-14 10:13:47', 2),
(1871, 6, 74, 38, '2026-03-14 10:13:47', 2),
(1872, 6, 74, 38, '2026-03-14 10:13:47', 2),
(1873, 6, 74, 38, '2026-03-14 10:13:47', 2),
(1874, 6, 74, 38, '2026-03-14 10:13:47', 2),
(1875, 6, 75, 38, '2026-03-14 10:13:47', 2),
(1876, 6, 75, 38, '2026-03-14 10:13:47', 2),
(1877, 6, 75, 38, '2026-03-14 10:13:47', 2),
(1878, 6, 75, 38, '2026-03-14 10:13:47', 2),
(1879, 6, 76, 36, '2026-03-14 10:13:47', 2),
(1880, 6, 77, 36, '2026-03-14 10:13:47', 2),
(1881, 6, 78, 36, '2026-03-14 10:13:47', 2),
(1882, 6, 79, 78, '2026-03-14 10:13:47', 2),
(1883, 6, 79, 78, '2026-03-14 10:13:47', 2),
(1884, 6, 80, 78, '2026-03-14 10:13:47', 2),
(1885, 6, 80, 78, '2026-03-14 10:13:47', 2),
(1886, 6, 81, 42, '2026-03-14 10:13:47', 2),
(1887, 6, 82, 38, '2026-03-14 10:13:47', 2),
(1888, 6, 82, 38, '2026-03-14 10:13:47', 2),
(1889, 6, 83, 38, '2026-03-14 10:13:47', 2),
(1890, 6, 83, 38, '2026-03-14 10:13:47', 2),
(1891, 6, 83, 38, '2026-03-14 10:13:47', 2),
(1892, 6, 83, 38, '2026-03-14 10:13:47', 2),
(1893, 6, 84, 77, '2026-03-14 10:13:47', 2),
(1894, 6, 84, 77, '2026-03-14 10:13:47', 2),
(1895, 6, 84, 77, '2026-03-14 10:13:47', 2),
(1896, 6, 84, 77, '2026-03-14 10:13:47', 2),
(1897, 6, 84, 77, '2026-03-14 10:13:47', 2),
(1898, 6, 84, 77, '2026-03-14 10:13:47', 2),
(1899, 6, 84, 77, '2026-03-14 10:13:47', 2),
(1900, 6, 85, 38, '2026-03-14 10:13:47', 2),
(1901, 6, 85, 38, '2026-03-14 10:13:47', 2),
(1902, 6, 86, 40, '2026-03-14 10:13:47', 2),
(1903, 6, 87, 41, '2026-03-14 10:13:47', 2),
(1904, 6, 87, 41, '2026-03-14 10:13:47', 2),
(1905, 6, 88, 41, '2026-03-14 10:13:47', 2),
(1906, 6, 88, 41, '2026-03-14 10:13:47', 2),
(1907, 6, 89, 38, '2026-03-14 10:13:47', 2),
(1908, 6, 89, 38, '2026-03-14 10:13:47', 2),
(1909, 6, 90, 38, '2026-03-14 10:13:47', 2),
(1910, 6, 90, 38, '2026-03-14 10:13:47', 2),
(1911, 7, 91, 41, '2026-03-14 10:13:47', 2),
(1912, 7, 91, 41, '2026-03-14 10:13:47', 2),
(1913, 7, 91, 41, '2026-03-14 10:13:47', 2),
(1914, 7, 91, 41, '2026-03-14 10:13:47', 2),
(1915, 7, 92, 41, '2026-03-14 10:13:47', 2),
(1916, 7, 92, 41, '2026-03-14 10:13:47', 2),
(1917, 7, 92, 41, '2026-03-14 10:13:47', 2),
(1918, 7, 92, 41, '2026-03-14 10:13:47', 2),
(1919, 7, 93, 42, '2026-03-14 10:13:47', 2),
(1920, 7, 93, 42, '2026-03-14 10:13:47', 2),
(1921, 7, 93, 42, '2026-03-14 10:13:47', 2),
(1922, 7, 93, 42, '2026-03-14 10:13:47', 2),
(1923, 7, 94, 42, '2026-03-14 10:13:47', 2),
(1924, 7, 94, 42, '2026-03-14 10:13:47', 2),
(1925, 7, 94, 42, '2026-03-14 10:13:47', 2),
(1926, 7, 94, 42, '2026-03-14 10:13:47', 2),
(1927, 7, 94, 42, '2026-03-14 10:13:47', 2),
(1928, 7, 94, 42, '2026-03-14 10:13:47', 2),
(1929, 7, 94, 42, '2026-03-14 10:13:47', 2),
(1930, 7, 94, 42, '2026-03-14 10:13:47', 2),
(1931, 7, 95, 42, '2026-03-14 10:13:47', 2),
(1932, 7, 95, 42, '2026-03-14 10:13:47', 2),
(1933, 7, 95, 42, '2026-03-14 10:13:47', 2),
(1934, 7, 95, 42, '2026-03-14 10:13:47', 2),
(1935, 7, 96, 38, '2026-03-14 10:13:47', 2),
(1936, 7, 96, 38, '2026-03-14 10:13:47', 2),
(1937, 7, 96, 38, '2026-03-14 10:13:47', 2),
(1938, 7, 96, 38, '2026-03-14 10:13:47', 2),
(1939, 7, 96, 38, '2026-03-14 10:13:47', 2),
(1940, 7, 96, 38, '2026-03-14 10:13:47', 2),
(1941, 7, 96, 38, '2026-03-14 10:13:47', 2),
(1942, 7, 96, 38, '2026-03-14 10:13:47', 2),
(1943, 7, 96, 38, '2026-03-14 10:13:47', 2),
(1944, 7, 96, 38, '2026-03-14 10:13:47', 2),
(1945, 7, 96, 38, '2026-03-14 10:13:47', 2),
(1946, 7, 96, 38, '2026-03-14 10:13:47', 2),
(1947, 7, 97, 38, '2026-03-14 10:13:47', 2),
(1948, 7, 97, 38, '2026-03-14 10:13:47', 2),
(1949, 7, 97, 38, '2026-03-14 10:13:47', 2),
(1950, 7, 97, 38, '2026-03-14 10:13:47', 2),
(1951, 7, 97, 38, '2026-03-14 10:13:47', 2),
(1952, 7, 97, 38, '2026-03-14 10:13:47', 2),
(1953, 7, 97, 38, '2026-03-14 10:13:47', 2),
(1954, 7, 97, 38, '2026-03-14 10:13:47', 2),
(1955, 7, 97, 38, '2026-03-14 10:13:47', 2),
(1956, 7, 97, 38, '2026-03-14 10:13:47', 2),
(1957, 7, 97, 38, '2026-03-14 10:13:47', 2),
(1958, 7, 97, 38, '2026-03-14 10:13:47', 2),
(1959, 7, 97, 38, '2026-03-14 10:13:47', 2),
(1960, 7, 97, 38, '2026-03-14 10:13:47', 2),
(1961, 7, 97, 38, '2026-03-14 10:13:47', 2),
(1962, 7, 97, 38, '2026-03-14 10:13:47', 2),
(1963, 7, 97, 38, '2026-03-14 10:13:47', 2),
(1964, 7, 97, 38, '2026-03-14 10:13:47', 2),
(1965, 7, 97, 38, '2026-03-14 10:13:47', 2),
(1966, 7, 97, 38, '2026-03-14 10:13:47', 2),
(1967, 7, 97, 38, '2026-03-14 10:13:47', 2),
(1968, 7, 97, 38, '2026-03-14 10:13:47', 2),
(1969, 7, 97, 38, '2026-03-14 10:13:47', 2),
(1970, 7, 97, 38, '2026-03-14 10:13:47', 2),
(1971, 7, 98, 77, '2026-03-14 10:13:47', 2),
(1972, 7, 98, 77, '2026-03-14 10:13:47', 2),
(1973, 7, 98, 77, '2026-03-14 10:13:47', 2),
(1974, 7, 98, 77, '2026-03-14 10:13:47', 2),
(1975, 7, 98, 77, '2026-03-14 10:13:47', 2),
(1976, 7, 98, 77, '2026-03-14 10:13:47', 2),
(1977, 7, 98, 77, '2026-03-14 10:13:47', 2),
(1978, 7, 98, 77, '2026-03-14 10:13:47', 2),
(1979, 7, 98, 77, '2026-03-14 10:13:47', 2),
(1980, 7, 98, 77, '2026-03-14 10:13:47', 2),
(1981, 7, 98, 77, '2026-03-14 10:13:47', 2),
(1982, 7, 98, 77, '2026-03-14 10:13:47', 2),
(1983, 7, 98, 77, '2026-03-14 10:13:47', 2),
(1984, 7, 98, 77, '2026-03-14 10:13:47', 2),
(1985, 7, 98, 77, '2026-03-14 10:13:47', 2),
(1986, 7, 98, 77, '2026-03-14 10:13:47', 2),
(1987, 7, 98, 77, '2026-03-14 10:13:47', 2),
(1988, 7, 98, 77, '2026-03-14 10:13:47', 2),
(1989, 7, 98, 77, '2026-03-14 10:13:47', 2),
(1990, 7, 98, 77, '2026-03-14 10:13:47', 2),
(1991, 7, 98, 77, '2026-03-14 10:13:47', 2),
(1992, 7, 98, 77, '2026-03-14 10:13:47', 2),
(1993, 7, 98, 77, '2026-03-14 10:13:47', 2),
(1994, 7, 98, 77, '2026-03-14 10:13:47', 2),
(1995, 7, 98, 77, '2026-03-14 10:13:47', 2),
(1996, 7, 98, 77, '2026-03-14 10:13:47', 2),
(1997, 7, 98, 77, '2026-03-14 10:13:47', 2),
(1998, 7, 98, 77, '2026-03-14 10:13:47', 2),
(1999, 7, 98, 77, '2026-03-14 10:13:47', 2),
(2000, 7, 98, 77, '2026-03-14 10:13:47', 2),
(2001, 7, 98, 77, '2026-03-14 10:13:47', 2),
(2002, 7, 98, 77, '2026-03-14 10:13:47', 2),
(2003, 7, 98, 77, '2026-03-14 10:13:47', 2),
(2004, 7, 98, 77, '2026-03-14 10:13:47', 2),
(2005, 7, 98, 77, '2026-03-14 10:13:47', 2),
(2006, 7, 98, 77, '2026-03-14 10:13:47', 2),
(2007, 7, 98, 77, '2026-03-14 10:13:47', 2),
(2008, 7, 98, 77, '2026-03-14 10:13:47', 2),
(2009, 7, 98, 77, '2026-03-14 10:13:47', 2),
(2010, 7, 98, 77, '2026-03-14 10:13:47', 2),
(2011, 7, 98, 77, '2026-03-14 10:13:47', 2),
(2012, 7, 98, 77, '2026-03-14 10:13:47', 2),
(2013, 7, 98, 77, '2026-03-14 10:13:47', 2),
(2014, 7, 98, 77, '2026-03-14 10:13:47', 2),
(2015, 7, 98, 77, '2026-03-14 10:13:47', 2),
(2016, 7, 98, 77, '2026-03-14 10:13:47', 2),
(2017, 7, 98, 77, '2026-03-14 10:13:47', 2),
(2018, 7, 98, 77, '2026-03-14 10:13:47', 2),
(2019, 7, 98, 77, '2026-03-14 10:13:47', 2),
(2020, 7, 98, 77, '2026-03-14 10:13:47', 2),
(2021, 7, 98, 77, '2026-03-14 10:13:47', 2),
(2022, 7, 98, 77, '2026-03-14 10:13:47', 2),
(2023, 7, 98, 77, '2026-03-14 10:13:47', 2),
(2024, 7, 98, 77, '2026-03-14 10:13:47', 2),
(2025, 7, 99, 38, '2026-03-14 10:13:47', 2),
(2026, 7, 99, 38, '2026-03-14 10:13:47', 2),
(2027, 7, 99, 38, '2026-03-14 10:13:47', 2),
(2028, 7, 99, 38, '2026-03-14 10:13:47', 2),
(2029, 7, 99, 38, '2026-03-14 10:13:47', 2),
(2030, 7, 99, 38, '2026-03-14 10:13:47', 2),
(2031, 7, 99, 38, '2026-03-14 10:13:47', 2),
(2032, 7, 99, 38, '2026-03-14 10:13:47', 2),
(2033, 7, 99, 38, '2026-03-14 10:13:47', 2),
(2034, 7, 99, 38, '2026-03-14 10:13:47', 2),
(2035, 7, 99, 38, '2026-03-14 10:13:47', 2),
(2036, 7, 99, 38, '2026-03-14 10:13:47', 2),
(2037, 7, 100, 38, '2026-03-14 10:13:47', 2),
(2038, 7, 100, 38, '2026-03-14 10:13:47', 2),
(2039, 7, 100, 38, '2026-03-14 10:13:47', 2),
(2040, 7, 100, 38, '2026-03-14 10:13:47', 2),
(2041, 7, 100, 38, '2026-03-14 10:13:47', 2),
(2042, 7, 100, 38, '2026-03-14 10:13:47', 2),
(2043, 7, 100, 38, '2026-03-14 10:13:47', 2),
(2044, 7, 100, 38, '2026-03-14 10:13:47', 2),
(2045, 7, 100, 38, '2026-03-14 10:13:47', 2),
(2046, 7, 100, 38, '2026-03-14 10:13:47', 2),
(2047, 7, 100, 38, '2026-03-14 10:13:47', 2),
(2048, 7, 100, 38, '2026-03-14 10:13:47', 2),
(2049, 7, 101, 38, '2026-03-14 10:13:47', 2),
(2050, 7, 101, 38, '2026-03-14 10:13:47', 2),
(2051, 7, 101, 38, '2026-03-14 10:13:47', 2),
(2052, 7, 101, 38, '2026-03-14 10:13:47', 2),
(2053, 7, 101, 38, '2026-03-14 10:13:48', 2),
(2054, 7, 101, 38, '2026-03-14 10:13:48', 2),
(2055, 7, 101, 38, '2026-03-14 10:13:48', 2),
(2056, 7, 101, 38, '2026-03-14 10:13:48', 2),
(2057, 7, 101, 38, '2026-03-14 10:13:48', 2),
(2058, 7, 101, 38, '2026-03-14 10:13:48', 2),
(2059, 7, 101, 38, '2026-03-14 10:13:48', 2),
(2060, 7, 101, 38, '2026-03-14 10:13:48', 2),
(2061, 8, 102, 41, '2026-03-14 10:13:48', 2),
(2062, 8, 102, 41, '2026-03-14 10:13:48', 2),
(2063, 8, 103, 41, '2026-03-14 10:13:48', 2),
(2064, 8, 103, 41, '2026-03-14 10:13:48', 2),
(2065, 8, 104, 42, '2026-03-14 10:13:48', 2),
(2066, 8, 104, 42, '2026-03-14 10:13:48', 2),
(2067, 8, 105, 42, '2026-03-14 10:13:48', 2),
(2068, 8, 105, 42, '2026-03-14 10:13:48', 2),
(2069, 8, 105, 42, '2026-03-14 10:13:48', 2),
(2070, 8, 105, 42, '2026-03-14 10:13:48', 2),
(2071, 8, 106, 42, '2026-03-14 10:13:48', 2),
(2072, 8, 106, 42, '2026-03-14 10:13:48', 2),
(2073, 8, 107, 38, '2026-03-14 10:13:48', 2),
(2074, 8, 107, 38, '2026-03-14 10:13:48', 2),
(2075, 8, 107, 38, '2026-03-14 10:13:48', 2),
(2076, 8, 107, 38, '2026-03-14 10:13:48', 2),
(2077, 8, 107, 38, '2026-03-14 10:13:48', 2),
(2078, 8, 107, 38, '2026-03-14 10:13:48', 2),
(2079, 8, 108, 38, '2026-03-14 10:13:48', 2),
(2080, 8, 108, 38, '2026-03-14 10:13:48', 2),
(2081, 8, 108, 38, '2026-03-14 10:13:48', 2),
(2082, 8, 108, 38, '2026-03-14 10:13:48', 2),
(2083, 8, 108, 38, '2026-03-14 10:13:48', 2),
(2084, 8, 108, 38, '2026-03-14 10:13:48', 2),
(2085, 8, 108, 38, '2026-03-14 10:13:48', 2),
(2086, 8, 108, 38, '2026-03-14 10:13:48', 2),
(2087, 8, 108, 38, '2026-03-14 10:13:48', 2),
(2088, 8, 108, 38, '2026-03-14 10:13:48', 2),
(2089, 8, 108, 38, '2026-03-14 10:13:48', 2),
(2090, 8, 108, 38, '2026-03-14 10:13:48', 2),
(2091, 8, 109, 77, '2026-03-14 10:13:48', 2),
(2092, 8, 109, 77, '2026-03-14 10:13:48', 2),
(2093, 8, 109, 77, '2026-03-14 10:13:48', 2),
(2094, 8, 109, 77, '2026-03-14 10:13:48', 2),
(2095, 8, 109, 77, '2026-03-14 10:13:48', 2),
(2096, 8, 109, 77, '2026-03-14 10:13:48', 2),
(2097, 8, 109, 77, '2026-03-14 10:13:48', 2),
(2098, 8, 109, 77, '2026-03-14 10:13:48', 2),
(2099, 8, 109, 77, '2026-03-14 10:13:48', 2),
(2100, 8, 109, 77, '2026-03-14 10:13:48', 2),
(2101, 8, 109, 77, '2026-03-14 10:13:48', 2),
(2102, 8, 109, 77, '2026-03-14 10:13:48', 2),
(2103, 8, 109, 77, '2026-03-14 10:13:48', 2),
(2104, 8, 109, 77, '2026-03-14 10:13:48', 2),
(2105, 8, 109, 77, '2026-03-14 10:13:48', 2),
(2106, 8, 109, 77, '2026-03-14 10:13:48', 2),
(2107, 8, 109, 77, '2026-03-14 10:13:48', 2),
(2108, 8, 109, 77, '2026-03-14 10:13:48', 2),
(2109, 8, 109, 77, '2026-03-14 10:13:48', 2),
(2110, 8, 109, 77, '2026-03-14 10:13:48', 2),
(2111, 8, 109, 77, '2026-03-14 10:13:48', 2),
(2112, 8, 109, 77, '2026-03-14 10:13:48', 2),
(2113, 8, 109, 77, '2026-03-14 10:13:48', 2),
(2114, 8, 109, 77, '2026-03-14 10:13:48', 2),
(2115, 8, 109, 77, '2026-03-14 10:13:48', 2),
(2116, 8, 109, 77, '2026-03-14 10:13:48', 2),
(2117, 8, 109, 77, '2026-03-14 10:13:48', 2),
(2118, 8, 110, 38, '2026-03-14 10:13:48', 2),
(2119, 8, 110, 38, '2026-03-14 10:13:48', 2),
(2120, 8, 110, 38, '2026-03-14 10:13:48', 2),
(2121, 8, 110, 38, '2026-03-14 10:13:48', 2),
(2122, 8, 110, 38, '2026-03-14 10:13:48', 2),
(2123, 8, 110, 38, '2026-03-14 10:13:48', 2),
(2124, 8, 111, 38, '2026-03-14 10:13:48', 2),
(2125, 8, 111, 38, '2026-03-14 10:13:48', 2),
(2126, 8, 111, 38, '2026-03-14 10:13:48', 2),
(2127, 8, 111, 38, '2026-03-14 10:13:48', 2),
(2128, 8, 111, 38, '2026-03-14 10:13:48', 2),
(2129, 8, 111, 38, '2026-03-14 10:13:48', 2),
(2130, 8, 112, 38, '2026-03-14 10:13:48', 2),
(2131, 8, 112, 38, '2026-03-14 10:13:48', 2),
(2132, 8, 112, 38, '2026-03-14 10:13:48', 2),
(2133, 8, 112, 38, '2026-03-14 10:13:48', 2),
(2134, 8, 112, 38, '2026-03-14 10:13:48', 2),
(2135, 8, 112, 38, '2026-03-14 10:13:48', 2);

-- --------------------------------------------------------

--
-- Table structure for table `cua_xuat_xu`
--

DROP TABLE IF EXISTS `cua_xuat_xu`;
CREATE TABLE IF NOT EXISTS `cua_xuat_xu` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `ten_xuat_xu` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `ghi_chu` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `cua_xuat_xu`
--

INSERT INTO `cua_xuat_xu` (`id`, `code`, `ten_xuat_xu`, `ghi_chu`) VALUES
(1, 'chua-phan-loai', 'Chưa phân loại', ''),
(2, 'VN', 'Việt Nam', ''),
(3, 'ML', 'Malaysia', ''),
(4, 'TQ', 'Trung Quốc', '');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

DROP TABLE IF EXISTS `history`;
CREATE TABLE IF NOT EXISTS `history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `loai` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `id_tham_chieu` int NOT NULL,
  `noi_dung` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `nguoi_tao` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

DROP TABLE IF EXISTS `migration`;
CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `apply_time` int DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1695691639),
('m140608_173539_create_user_table', 1695691642),
('m140611_133903_init_rbac', 1695691642),
('m140808_073114_create_auth_item_group_table', 1695691642),
('m140809_072112_insert_superadmin_to_user', 1695691643),
('m140809_073114_insert_common_permisison_to_auth_item', 1695691643),
('m141023_141535_create_user_visit_log', 1695691643),
('m141116_115804_add_bind_to_ip_and_registration_ip_to_user', 1695691643),
('m141121_194858_split_browser_and_os_column', 1695691643),
('m141201_220516_add_email_and_email_confirmed_to_user', 1695691644),
('m141207_001649_create_basic_user_permissions', 1695691644);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `auth_key` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `password_hash` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `confirmation_token` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `status` int NOT NULL DEFAULT '1',
  `superadmin` smallint DEFAULT '0',
  `created_at` int NOT NULL,
  `updated_at` int NOT NULL,
  `registration_ip` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `bind_to_ip` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `email` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `email_confirmed` smallint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `confirmation_token`, `status`, `superadmin`, `created_at`, `updated_at`, `registration_ip`, `bind_to_ip`, `email`, `email_confirmed`) VALUES
(1, 'superadmin', 'MDvwUlYvBDOYlfwXEkNhRChWr2utQ3xU', '$2y$13$.82.TmKU5VxndDwYIY8KOeQFIn7WJ6tZinx6mz0MGdkqmpYC0wmHK', NULL, 1, 1, 1695691643, 1695691643, NULL, NULL, NULL, 0),
(2, 'admin', 'Hch1yqSEXM8MbzZLQqQ0J30xv47Y6QO0', '$2y$13$3p5trtYB74PqiNHtIOB43.7GD8V.TJqLR8MHgcJGBRGo/NZm1wUMG', NULL, 1, 1, 1702256795, 1773367032, '::1', '', 'lamnhutquang1996@gmail.com', 0),
(3, 'quangduy', 'qh8WbhrvW-0S4JeRSyZXucUiDi6sMddZ', '$2y$13$nYbxziOKmQpDW0jroJ6A1uWc3S2.SEUe4cbhVCRiYDQsBjJMOuLf2', NULL, 1, 1, 1725984106, 1759130332, '112.197.240.147', '', '', 0),
(4, 'toan', 'z3dlynUsZBhBFdAG2b4goELl1CIgaVHQ', '$2y$13$Ic4T8CdnKAfL4pqIiTLtaejXangIwEaa2ApbuHuIZ4OGeICKi0fOK', NULL, 1, 1, 1725984121, 1725984121, '112.197.240.147', '', '', 0),
(5, 'vu', '0CwIZQADdLP_xR25Cl-78C356PlVSb7W', '$2y$13$V2vHmdOfFdvTJLUcP6.CJ.VsXDyd.7Wd075cemqw6w3tASFa3s66G', NULL, 1, 1, 1741681796, 1741681796, '27.71.99.104', '', '', 0),
(6, 'khang', 'ml6v09OqIB5N6A3m2exb_c2Konj53pMQ', '$2y$13$ht.X8RFKEZFrRcFnHB5YZuNxh4jz8AEqQXBr3TJ0oHeS/XsM3rlnq', NULL, 1, 1, 1753607029, 1753607029, '14.191.61.35', '', '', 0),
(7, 'txlam', '-RssYiFq7Jp-RFZzC0QweFVaiSHYvWIo', '$2y$13$22q9AAXWIXi7GcAnSUJIqut6l4moLS2ibDvZumKONtg/bP.eC/T/S', NULL, 1, 1, 1753672583, 1753672583, '115.73.240.234', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

DROP TABLE IF EXISTS `user_info`;
CREATE TABLE IF NOT EXISTS `user_info` (
  `id_user` int NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `chuc_vu` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `email` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `nhan_thong_bao` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`id_user`, `name`, `chuc_vu`, `email`, `nhan_thong_bao`) VALUES
(1, 'Nguyễn Văn Tý An', 'Nhân viên phòng LAS', 'nguyenvantyan@gmail.com', 0),
(2, NULL, NULL, NULL, NULL),
(3, 'Quang Duy', 'Quản lý', 'quangduy@nguyentrinhtravinh.com.vn', 1),
(4, 'Toàn', 'Nhân viên', '', 1),
(5, NULL, NULL, NULL, NULL),
(6, NULL, NULL, NULL, NULL),
(7, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_visit_log`
--

DROP TABLE IF EXISTS `user_visit_log`;
CREATE TABLE IF NOT EXISTS `user_visit_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `ip` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `language` char(2) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `user_agent` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `user_id` int DEFAULT NULL,
  `visit_time` int NOT NULL,
  `browser` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `os` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=197 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `user_visit_log`
--

INSERT INTO `user_visit_log` (`id`, `token`, `ip`, `language`, `user_agent`, `user_id`, `visit_time`, `browser`, `os`) VALUES
(1, '651233ac68058', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695691692, 'Chrome', 'Windows'),
(2, '651236d4e41f3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695692500, 'Chrome', 'Windows'),
(3, '6512462aa9eb3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695696426, 'Chrome', 'Windows'),
(4, '65137e1b21d83', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695776283, 'Chrome', 'Windows'),
(5, '65152884d18a2', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695885444, 'Chrome', 'Windows'),
(6, '65167bc86b56f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695972296, 'Chrome', 'Windows'),
(7, '651fc82504a1f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1696581669, 'Chrome', 'Windows'),
(8, '65294c755aebb', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1697205365, 'Chrome', 'Windows'),
(9, '65295a386d589', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1697208888, 'Chrome', 'Windows'),
(10, '652d5011ee601', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1697468434, 'Chrome', 'Windows'),
(11, '652e4ad038376', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1697532624, 'Chrome', 'Windows'),
(12, '652e4b0664a5e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1697532678, 'Chrome', 'Windows'),
(13, '6535c66babd70', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1698023019, 'Chrome', 'Windows'),
(14, '653f6657106a4', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1698653783, 'Chrome', 'Windows'),
(15, '65449a2cbcaff', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1698994732, 'Chrome', 'Windows'),
(16, '65449a409b40e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1698994752, 'Chrome', 'Windows'),
(17, '654839f01d33e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1699232240, 'Chrome', 'Windows'),
(18, '65498b0e1a435', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1699318542, 'Chrome', 'Windows'),
(19, '654c30af3f6b2', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1699492015, 'Chrome', 'Windows'),
(20, '654d8251ec3db', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1699578449, 'Chrome', 'Windows'),
(21, '6552c5c3166bb', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1699923395, 'Chrome', 'Windows'),
(22, '65556baa09cc4', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1700096938, 'Chrome', 'Windows'),
(23, '6556ba7927cfa', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1700182649, 'Chrome', 'Windows'),
(24, '655ea55da9335', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1700701533, 'Chrome', 'Windows'),
(25, '655ff4cb95ae2', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1700787403, 'Chrome', 'Windows'),
(26, '6563f2c74ad32', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701049031, 'Chrome', 'Windows'),
(27, '65668958eaae0', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701218648, 'Chrome', 'Windows'),
(28, '656696bf09e09', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701222079, 'Chrome', 'Windows'),
(29, '656990dc9d085', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701417180, 'Chrome', 'Windows'),
(30, '656d21257611e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701650725, 'Chrome', 'Windows'),
(31, '656d774245afa', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701672770, 'Chrome', 'Windows'),
(32, '656e743392498', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701737523, 'Chrome', 'Windows'),
(33, '656ed00f1ba53', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701761039, 'Chrome', 'Windows'),
(34, '656fc4e0009c2', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701823712, 'Chrome', 'Windows'),
(35, '657114ef13fe3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701909743, 'Chrome', 'Windows'),
(36, '6573c4d291c4d', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1702085842, 'Chrome', 'Windows'),
(37, '6573cc0e3eb38', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1702087694, 'Chrome', 'Windows'),
(38, '6573cc35bc770', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1702087733, 'Chrome', 'Windows'),
(39, '6576608310f74', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1702256771, 'Chrome', 'Windows'),
(40, '657660c3ae9e3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 2, 1702256835, 'Chrome', 'Windows'),
(41, '65796d9e815a9', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1702456734, 'Chrome', 'Windows'),
(42, '657aa2e74b599', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1702535911, 'Chrome', 'Windows'),
(43, '657d510622e04', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1702711558, 'Chrome', 'Windows'),
(44, '65810b57b2f61', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1702955863, 'Chrome', 'Windows'),
(45, '6582468034135', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1703036544, 'Chrome', 'Windows'),
(46, '6582491abea69', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1703037210, 'Chrome', 'Windows'),
(47, '65839ed9a5f36', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1703124697, 'Chrome', 'Windows'),
(48, '6584e95dbe283', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1703209309, 'Chrome', 'Windows'),
(49, '658535af6d642', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 2, 1703228847, 'Chrome', 'Windows'),
(50, '65869dcc6e44b', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1703321036, 'Chrome', 'Windows'),
(51, '6590d3d4a581c', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 2, 1703990228, 'Chrome', 'Windows'),
(52, '65920c8cabb6f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 2, 1704070284, 'Chrome', 'Windows'),
(53, '65937af25d400', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1704164082, 'Chrome', 'Windows'),
(54, '6597b3f56be13', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1704440821, 'Chrome', 'Windows'),
(55, '6598c2c65b204', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1704510150, 'Chrome', 'Windows'),
(56, '65a9d9fcf3381', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1705630205, 'Chrome', 'Windows'),
(57, '65dffd9ae2235', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 1, 1709178266, 'Chrome', 'Windows'),
(58, '661f1e67032e3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36', 1, 1713315431, 'Chrome', 'Windows'),
(59, '66289d637b30a', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36', 1, 1713937763, 'Chrome', 'Windows'),
(60, '6639dc619ad26', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36', 1, 1715068001, 'Chrome', 'Windows'),
(61, '663b3f0b24c2e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36', 1, 1715158795, 'Chrome', 'Windows'),
(62, '66417d1cbda0e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36', 1, 1715567900, 'Chrome', 'Windows'),
(63, '6645bb7c30896', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36', 1, 1715846012, 'Chrome', 'Windows'),
(64, '6646c35433573', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1715913556, 'Chrome', 'Windows'),
(65, '6648542336357', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1716016163, 'Chrome', 'Windows'),
(66, '664bf20e94cfc', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1716253198, 'Chrome', 'Windows'),
(67, '66541d2094eb0', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1716788512, 'Chrome', 'Windows'),
(68, '66553a56ab953', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1716861526, 'Chrome', 'Windows'),
(69, '66569e3c0c02f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1716952636, 'Chrome', 'Windows'),
(70, '6659459bc84b0', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1717126555, 'Chrome', 'Windows'),
(71, '665d74a793765', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1717400743, 'Chrome', 'Windows'),
(72, '66625b5d80cb4', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1717721949, 'Chrome', 'Windows'),
(73, '666652f49f33a', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1717981940, 'Chrome', 'Windows'),
(74, '666907579d104', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1718159191, 'Chrome', 'Windows'),
(75, '666aa5e531457', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1718265317, 'Chrome', 'Windows'),
(76, '668214cd48c94', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36', 1, 1719801037, 'Chrome', 'Windows'),
(77, '66821e653feab', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36', 1, 1719803493, 'Chrome', 'Windows'),
(78, '6684b50300013', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36', 1, 1719973123, 'Chrome', 'Windows'),
(79, '668bc8ea5c881', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36', 1, 1720436970, 'Chrome', 'Windows'),
(80, '668f427c643f6', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36', 1, 1720664700, 'Chrome', 'Windows'),
(81, '66a845a42818f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1722303908, 'Chrome', 'Windows'),
(82, '66a8ac6ad9580', '27.71.99.151', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1722330218, 'Chrome', 'Windows'),
(83, '66aae45ee2255', '27.71.99.151', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1722475614, 'Chrome', 'Windows'),
(84, '66add28829bda', '115.74.244.101', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36', 1, 1722667656, 'Chrome', 'Windows'),
(85, '66aeece1cde01', '115.76.39.62', 'en', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36', 2, 1722739937, 'Chrome', 'mac'),
(86, '66b03742736ac', '115.74.244.101', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1722824514, 'Chrome', 'Windows'),
(87, '66b06d363cf26', '115.74.244.101', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0', 2, 1722838326, 'Chrome', 'Windows'),
(88, '66b08606444ae', '27.71.99.151', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1722844678, 'Chrome', 'Windows'),
(89, '66b17d13435a1', '116.109.226.45', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 2, 1722907923, 'Chrome', 'Windows'),
(90, '66b1894219e41', '27.71.99.151', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1722911042, 'Chrome', 'Windows'),
(91, '66b1c1239b715', '116.109.226.45', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 2, 1722925347, 'Chrome', 'Windows'),
(92, '66b5623a10e2c', '116.109.225.253', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 2, 1723163194, 'Chrome', 'Windows'),
(93, '66b9abda3d26c', '112.197.240.147', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1723444186, 'Chrome', 'Windows'),
(94, '66b9b92da7d0d', '116.109.225.253', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 2, 1723447597, 'Chrome', 'Windows'),
(95, '66bc6383dea81', '27.71.99.151', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1723622275, 'Chrome', 'Windows'),
(96, '66bc6b72df46f', '116.109.225.253', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 2, 1723624306, 'Chrome', 'Windows'),
(97, '66bd4ca32747d', '116.109.225.253', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 2, 1723681955, 'Chrome', 'Windows'),
(98, '66bd56b85bc8b', '27.71.99.151', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1723684536, 'Chrome', 'Windows'),
(99, '66bd9fb4f0bf0', '116.109.225.253', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 2, 1723703220, 'Chrome', 'Windows'),
(100, '66bdab887985e', '27.71.99.151', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1723706248, 'Chrome', 'Windows'),
(101, '66bdc62cf2154', '116.109.225.253', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 2, 1723713068, 'Chrome', 'Windows'),
(102, '66beadce5ea1f', '116.109.225.253', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 2, 1723772366, 'Chrome', 'Windows'),
(103, '66c053b911043', '116.109.225.253', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 2, 1723880377, 'Chrome', 'Windows'),
(104, '66c2f9dd27cb2', '116.109.225.253', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 2, 1724053981, 'Chrome', 'Windows'),
(105, '66c94b253a1a4', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1724468005, 'Chrome', 'Windows'),
(106, '66cbf7bb8260f', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1724643259, 'Chrome', 'Windows'),
(107, '66cdeeed6ea7c', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1724772077, 'Chrome', 'Windows'),
(108, '66d17558b9b6a', '27.71.99.30', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 2, 1725003096, 'Chrome', 'Windows'),
(109, '66d6883651a17', '115.73.243.47', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 2, 1725335606, 'Chrome', 'Windows'),
(110, '66dbb8049b77c', '115.73.243.47', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 2, 1725675524, 'Chrome', 'Windows'),
(111, '66deb4866f10d', '115.76.36.232', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 2, 1725871238, 'Chrome', 'Windows'),
(112, '66deb5daad535', '27.71.99.30', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 2, 1725871578, 'Chrome', 'Windows'),
(113, '66e15777d35fb', '27.71.99.12', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 3, 1726044023, 'Chrome', 'Windows'),
(114, '66e24e6735573', '27.71.98.97', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 2, 1726107239, 'Chrome', 'Windows'),
(115, '67c96a1214621', '27.71.99.104', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36 Edg/133.0.0.0', 1, 1741253138, 'Chrome', 'Windows'),
(116, '67cff4652ff99', '27.71.99.104', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36', 1, 1741681765, 'Chrome', 'Windows'),
(117, '67cff5163ad58', '27.71.99.104', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36', 5, 1741681942, 'Chrome', 'Windows'),
(118, '67cff920d218e', '116.102.122.254', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36 Edg/133.0.0.0', 5, 1741682976, 'Chrome', 'Windows'),
(119, '67cff94272a08', '116.102.122.254', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36', 5, 1741683010, 'Chrome', 'Windows'),
(120, '67fef68586bb8', '112.197.242.141', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36', 2, 1744762501, 'Chrome', 'Windows'),
(121, '68099daf77b19', '115.76.40.121', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36 Edg/133.0.0.0', 5, 1745460655, 'Chrome', 'Windows'),
(122, '6879f51c5bad5', '115.76.45.112', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', 1, 1752823068, 'Chrome', 'Windows'),
(123, '687c511df0ebc', '14.234.79.142', 'en', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36', 2, 1752977693, 'Chrome', 'mac'),
(124, '6881e2e6458c2', '116.109.226.190', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', 1, 1753342694, 'Chrome', 'Windows'),
(125, '6885eb0de6e46', '14.191.61.35', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', 1, 1753606925, 'Chrome', 'Windows'),
(126, '6885ebb1326a9', '14.191.61.35', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', 6, 1753607089, 'Chrome', 'Windows'),
(127, '688765fc60aad', '27.71.99.81', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0', 6, 1753703932, 'Chrome', 'Windows'),
(128, '6888180167e66', '115.73.240.234', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', 1, 1753749505, 'Chrome', 'Windows'),
(129, '68882ebb6e890', '115.73.249.244', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0', 6, 1753755323, 'Chrome', 'Windows'),
(130, '6888689bd6b26', '115.73.240.234', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', 1, 1753770139, 'Chrome', 'Windows'),
(131, '688868e72de83', '115.73.240.234', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', 1, 1753770215, 'Chrome', 'Windows'),
(132, '6888755325d48', '115.73.240.234', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', 1, 1753773395, 'Chrome', 'Windows'),
(133, '688c84150801c', '115.73.249.147', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', 1, 1754039317, 'Chrome', 'Windows'),
(134, '6896b4d64c985', '115.73.249.147', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', 1, 1754707158, 'Chrome', 'Windows'),
(135, '68998f146d585', '115.73.249.147', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', 1, 1754894100, 'Chrome', 'Windows'),
(136, '68b101a654cc3', '115.76.45.63', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36', 1, 1756430758, 'Chrome', 'Windows'),
(137, '68b146f16729b', '115.73.240.19', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36 Edg/139.0.0.0', 6, 1756448497, 'Chrome', 'Windows'),
(138, '68b155ed0fd2b', '115.76.45.63', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36', 1, 1756452333, 'Chrome', 'Windows'),
(139, '68b250cea4815', '115.73.240.19', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36 Edg/139.0.0.0', 6, 1756516558, 'Chrome', 'Windows'),
(140, '68b298f49186b', '115.76.45.63', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36', 1, 1756535028, 'Chrome', 'Windows'),
(141, '68b5aab449261', '27.71.98.102', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36 Edg/139.0.0.0', 6, 1756736180, 'Chrome', 'Windows'),
(142, '68b9516591be5', '115.73.242.91', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36 Edg/139.0.0.0', 6, 1756975461, 'Chrome', 'Windows'),
(143, '68ba3f4f5519f', '115.73.242.91', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36 Edg/139.0.0.0', 6, 1757036367, 'Chrome', 'Windows'),
(144, '68ba3f4ff3c78', '115.73.242.91', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36 Edg/139.0.0.0', 6, 1757036367, 'Chrome', 'Windows'),
(145, '68ba3f58e7987', '115.73.242.91', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36 Edg/139.0.0.0', 6, 1757036376, 'Chrome', 'Windows'),
(146, '68bbf46248aa5', '27.71.98.102', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36 Edg/139.0.0.0', 6, 1757148258, 'Chrome', 'Windows'),
(147, '68ca23563e1f9', '115.73.247.196', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36', 1, 1758077782, 'Chrome', 'Windows'),
(148, '68d5e6b9d7e7e', '115.76.43.199', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36', 1, 1758848697, 'Chrome', 'Windows'),
(149, '68d65a02282e9', '115.76.43.199', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36', 1, 1758878210, 'Chrome', 'Windows'),
(150, '68d75dfb74656', '27.71.99.188', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36', 1, 1758944763, 'Chrome', 'Windows'),
(151, '68da322aa5144', '112.197.70.92', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36', 1, 1759130154, 'Chrome', 'Windows'),
(152, '68db385a0fcc2', '115.74.244.101', 'en', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36', 3, 1759197274, 'Chrome', 'mac'),
(153, '68db77424b048', '115.76.43.199', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36', 1, 1759213378, 'Chrome', 'Windows'),
(154, '68db7982c3f5c', '115.74.244.101', 'en', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36', 3, 1759213954, 'Chrome', 'mac'),
(155, '68db7995abdf6', '115.74.244.101', 'en', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36', 3, 1759213973, 'Chrome', 'mac'),
(156, '68db799658e97', '115.74.244.101', 'en', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36', 3, 1759213974, 'Chrome', 'mac'),
(157, '68db799706269', '115.74.244.101', 'en', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36', 3, 1759213975, 'Chrome', 'mac'),
(158, '68dc756b181bd', '115.76.43.199', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36', 1, 1759278443, 'Chrome', 'Windows'),
(159, '68ddc6061744f', '115.76.43.199', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36', 1, 1759364614, 'Chrome', 'Windows'),
(160, '68ddf83604764', '115.74.244.101', 'en', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36', 3, 1759377462, 'Chrome', 'mac'),
(161, '68dfe6bb98cbb', '27.71.98.245', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36 Edg/140.0.0.0', 6, 1759504059, 'Chrome', 'Windows'),
(162, '68e27b44a0e4a', '27.71.98.245', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', 6, 1759673156, 'Chrome', 'Windows'),
(163, '68e3829abad36', '116.102.115.229', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', 6, 1759740570, 'Chrome', 'Windows'),
(164, '68e382e6786b9', '115.74.255.99', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36', 1, 1759740646, 'Chrome', 'Windows'),
(165, '68e3d0b597d05', '27.71.98.245', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', 6, 1759760565, 'Chrome', 'Windows'),
(166, '68e723355fa55', '116.102.115.229', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', 6, 1759978293, 'Chrome', 'Windows'),
(167, '68e727570560b', '115.76.43.199', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36', 1, 1759979351, 'Chrome', 'Windows'),
(168, '68efc6b1da775', '27.71.99.104', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', 6, 1760544433, 'Chrome', 'Windows'),
(169, '68f05f9177f03', '116.102.115.229', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', 6, 1760583569, 'Chrome', 'Windows'),
(170, '68fa325c11427', '27.71.99.181', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', 6, 1761227356, 'Chrome', 'Windows'),
(171, '68fc344648a75', '115.76.47.240', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', 6, 1761358918, 'Chrome', 'Windows'),
(172, '6901ba1f869ee', '115.76.47.240', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', 6, 1761720863, 'Chrome', 'Windows'),
(173, '6902ce08386e7', '115.76.47.240', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', 6, 1761791496, 'Chrome', 'Windows'),
(174, '69099c683dece', '115.76.47.240', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', 6, 1762237544, 'Chrome', 'Windows'),
(175, '6909af3ac9f18', '115.76.47.240', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', 6, 1762242362, 'Chrome', 'Windows'),
(176, '690aaf6954081', '27.71.99.23', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0', 6, 1762307945, 'Chrome', 'Windows'),
(177, '690c11cd042ea', '115.76.47.240', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', 6, 1762398669, 'Chrome', 'Windows'),
(178, '690d6506a42df', '115.76.47.240', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0', 6, 1762485510, 'Chrome', 'Windows'),
(179, '690dfba8ea748', '27.71.99.23', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0', 6, 1762524072, 'Chrome', 'Windows'),
(180, '691156baf1c0d', '27.71.98.227', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 1, 1762743994, 'Chrome', 'Windows'),
(181, '6913144eeb829', '27.71.98.97', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0', 6, 1762858062, 'Chrome', 'Windows'),
(182, '69154356e9232', '115.76.47.240', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0', 6, 1763001174, 'Chrome', 'Windows'),
(183, '6916819395fea', '115.76.47.240', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0', 6, 1763082643, 'Chrome', 'Windows'),
(184, '6919cd614dde1', '27.71.99.187', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0', 6, 1763298657, 'Chrome', 'Windows'),
(185, '691b45122ee8d', '27.71.99.187', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0', 6, 1763394834, 'Chrome', 'Windows'),
(186, '691b4512ccf6c', '27.71.99.187', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0', 6, 1763394834, 'Chrome', 'Windows'),
(187, '6922954eec3fd', '27.71.99.187', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0', 6, 1763874126, 'Chrome', 'Windows'),
(188, '69266aaaeab63', '115.76.36.20', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0', 6, 1764125354, 'Chrome', 'Windows'),
(189, '69377262d553c', '116.102.114.201', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0', 6, 1765241442, 'Chrome', 'Windows'),
(190, '6948ab7a46e35', '115.76.44.185', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0', 6, 1766370170, 'Chrome', 'Windows'),
(191, '698ff214ea3fa', '115.76.33.159', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 6, 1771041300, 'Chrome', 'Windows'),
(192, '699aee3ee2ecc', '27.71.98.240', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', 6, 1771761214, 'Chrome', 'Windows'),
(193, '699aef507126a', '27.71.98.240', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', 6, 1771761488, 'Chrome', 'Windows'),
(194, '69b361838faf9', '115.73.240.112', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 1, 1773363587, 'Chrome', 'Windows'),
(195, '69b3633a9a6ac', '115.73.240.112', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', 2, 1773364026, 'Chrome', 'Windows'),
(196, '69b4c9b4eaba1', '115.73.240.112', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', 2, 1773455796, 'Chrome', 'Windows');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_assignment`
--
ALTER TABLE `auth_assignment`
  ADD CONSTRAINT `auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_assignment_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `auth_item`
--
ALTER TABLE `auth_item`
  ADD CONSTRAINT `auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_auth_item_group_code` FOREIGN KEY (`group_code`) REFERENCES `auth_item_group` (`code`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `banle_hoa_don`
--
ALTER TABLE `banle_hoa_don`
  ADD CONSTRAINT `banle_hoa_don_ibfk_1` FOREIGN KEY (`id_khach_hang`) REFERENCES `banle_khach_hang` (`id`);

--
-- Constraints for table `banle_hoa_don_chi_tiet`
--
ALTER TABLE `banle_hoa_don_chi_tiet`
  ADD CONSTRAINT `banle_hoa_don_chi_tiet_ibfk_1` FOREIGN KEY (`id_hoa_don`) REFERENCES `banle_hoa_don` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `banle_khach_hang`
--
ALTER TABLE `banle_khach_hang`
  ADD CONSTRAINT `banle_khach_hang_ibfk_1` FOREIGN KEY (`id_loai_khach_hang`) REFERENCES `banle_loai_khach_hang` (`id`);

--
-- Constraints for table `cua_cay_nhom`
--
ALTER TABLE `cua_cay_nhom`
  ADD CONSTRAINT `cua_cay_nhom_ibfk_1` FOREIGN KEY (`id_he_nhom`) REFERENCES `cua_he_nhom` (`id`),
  ADD CONSTRAINT `cua_cay_nhom_ibfk_2` FOREIGN KEY (`id_he_mau`) REFERENCES `cua_he_mau` (`id`);

--
-- Constraints for table `cua_cong_trinh`
--
ALTER TABLE `cua_cong_trinh`
  ADD CONSTRAINT `cua_cong_trinh_ibfk_1` FOREIGN KEY (`id_khach_hang`) REFERENCES `banle_khach_hang` (`id`);

--
-- Constraints for table `cua_du_an_settings`
--
ALTER TABLE `cua_du_an_settings`
  ADD CONSTRAINT `cua_du_an_settings_ibfk_1` FOREIGN KEY (`id_du_an`) REFERENCES `cua_du_an` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_he_nhom_mau`
--
ALTER TABLE `cua_he_nhom_mau`
  ADD CONSTRAINT `cua_he_nhom_mau_ibfk_1` FOREIGN KEY (`id_he_nhom`) REFERENCES `cua_he_nhom` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cua_he_nhom_mau_ibfk_2` FOREIGN KEY (`id_he_mau`) REFERENCES `cua_he_mau` (`id`);

--
-- Constraints for table `cua_kho_nhom`
--
ALTER TABLE `cua_kho_nhom`
  ADD CONSTRAINT `cua_kho_nhom_ibfk_1` FOREIGN KEY (`id_cay_nhom`) REFERENCES `cua_cay_nhom` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_kho_nhom_lich_su`
--
ALTER TABLE `cua_kho_nhom_lich_su`
  ADD CONSTRAINT `cua_kho_nhom_lich_su_ibfk_1` FOREIGN KEY (`id_kho_nhom`) REFERENCES `cua_kho_nhom` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_kho_nhom_qr`
--
ALTER TABLE `cua_kho_nhom_qr`
  ADD CONSTRAINT `cua_kho_nhom_qr_ibfk_1` FOREIGN KEY (`id_kho_nhom`) REFERENCES `cua_kho_nhom` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cua_kho_nhom_qr_ibfk_2` FOREIGN KEY (`id_nhom_su_dung`) REFERENCES `cua_mau_cua_nhom_su_dung` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_kho_vat_tu`
--
ALTER TABLE `cua_kho_vat_tu`
  ADD CONSTRAINT `cua_kho_vat_tu_ibfk_1` FOREIGN KEY (`xuat_xu`) REFERENCES `cua_xuat_xu` (`id`),
  ADD CONSTRAINT `cua_kho_vat_tu_ibfk_2` FOREIGN KEY (`id_he_mau`) REFERENCES `cua_he_mau` (`id`);

--
-- Constraints for table `cua_kho_vat_tu_lich_su`
--
ALTER TABLE `cua_kho_vat_tu_lich_su`
  ADD CONSTRAINT `cua_kho_vat_tu_lich_su_ibfk_1` FOREIGN KEY (`id_kho_vat_tu`) REFERENCES `cua_kho_vat_tu` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_mau_cua`
--
ALTER TABLE `cua_mau_cua`
  ADD CONSTRAINT `cua_mau_cua_ibfk_1` FOREIGN KEY (`id_he_nhom`) REFERENCES `cua_he_nhom` (`id`),
  ADD CONSTRAINT `cua_mau_cua_ibfk_2` FOREIGN KEY (`id_loai_cua`) REFERENCES `cua_loai_cua` (`id`),
  ADD CONSTRAINT `cua_mau_cua_ibfk_3` FOREIGN KEY (`id_du_an`) REFERENCES `cua_du_an` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `cua_mau_cua_ibfk_4` FOREIGN KEY (`id_cong_trinh`) REFERENCES `cua_cong_trinh` (`id`);

--
-- Constraints for table `cua_mau_cua_danh_gia`
--
ALTER TABLE `cua_mau_cua_danh_gia`
  ADD CONSTRAINT `cua_mau_cua_danh_gia_ibfk_1` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cua_mau_cua_danh_gia_ibfk_2` FOREIGN KEY (`id_nguoi_danh_gia`) REFERENCES `user` (`id`);

--
-- Constraints for table `cua_mau_cua_nhom`
--
ALTER TABLE `cua_mau_cua_nhom`
  ADD CONSTRAINT `cua_mau_cua_nhom_ibfk_1` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cua_mau_cua_nhom_ibfk_2` FOREIGN KEY (`id_cay_nhom`) REFERENCES `cua_cay_nhom` (`id`);

--
-- Constraints for table `cua_mau_cua_nhom_su_dung`
--
ALTER TABLE `cua_mau_cua_nhom_su_dung`
  ADD CONSTRAINT `cua_mau_cua_nhom_su_dung_ibfk_1` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cua_mau_cua_nhom_su_dung_ibfk_2` FOREIGN KEY (`id_kho_nhom`) REFERENCES `cua_kho_nhom` (`id`),
  ADD CONSTRAINT `cua_mau_cua_nhom_su_dung_ibfk_3` FOREIGN KEY (`id_du_an`) REFERENCES `cua_du_an` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_mau_cua_nhom_su_dung_chi_tiet`
--
ALTER TABLE `cua_mau_cua_nhom_su_dung_chi_tiet`
  ADD CONSTRAINT `cua_mau_cua_nhom_su_dung_chi_tiet_ibfk_1` FOREIGN KEY (`id_nhom_su_dung`) REFERENCES `cua_mau_cua_nhom_su_dung` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cua_mau_cua_nhom_su_dung_chi_tiet_ibfk_2` FOREIGN KEY (`id_nhom_toi_uu`) REFERENCES `cua_toi_uu` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_mau_cua_settings`
--
ALTER TABLE `cua_mau_cua_settings`
  ADD CONSTRAINT `cua_mau_cua_settings_ibfk_1` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_mau_cua_vach`
--
ALTER TABLE `cua_mau_cua_vach`
  ADD CONSTRAINT `cua_mau_cua_vach_ibfk_1` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cua_mau_cua_vach_ibfk_2` FOREIGN KEY (`id_vach`) REFERENCES `cua_he_vach` (`id`);

--
-- Constraints for table `cua_mau_cua_vat_tu`
--
ALTER TABLE `cua_mau_cua_vat_tu`
  ADD CONSTRAINT `cua_mau_cua_vat_tu_ibfk_1` FOREIGN KEY (`id_kho_vat_tu`) REFERENCES `cua_kho_vat_tu` (`id`),
  ADD CONSTRAINT `cua_mau_cua_vat_tu_ibfk_2` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_toi_uu`
--
ALTER TABLE `cua_toi_uu`
  ADD CONSTRAINT `cua_toi_uu_ibfk_1` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`),
  ADD CONSTRAINT `cua_toi_uu_ibfk_2` FOREIGN KEY (`id_mau_cua_nhom`) REFERENCES `cua_mau_cua_nhom` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cua_toi_uu_ibfk_3` FOREIGN KEY (`id_ton_kho_nhom`) REFERENCES `cua_kho_nhom` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_visit_log`
--
ALTER TABLE `user_visit_log`
  ADD CONSTRAINT `user_visit_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
