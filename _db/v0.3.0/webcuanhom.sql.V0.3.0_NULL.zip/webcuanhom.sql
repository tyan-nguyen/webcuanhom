-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 30, 2024 at 02:58 AM
-- Server version: 5.7.36
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webcuanhom`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_assignment`
--

DROP TABLE IF EXISTS `auth_assignment`;
CREATE TABLE IF NOT EXISTS `auth_assignment` (
  `item_name` varchar(64) CHARACTER SET utf8 NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_item`
--

DROP TABLE IF EXISTS `auth_item`;
CREATE TABLE IF NOT EXISTS `auth_item` (
  `name` varchar(64) CHARACTER SET utf8 NOT NULL,
  `type` int(11) NOT NULL,
  `description` text CHARACTER SET utf8,
  `rule_name` varchar(64) CHARACTER SET utf8 DEFAULT NULL,
  `data` text CHARACTER SET utf8,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `group_code` varchar(64) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `idx-auth_item-type` (`type`),
  KEY `fk_auth_item_group_code` (`group_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item`
--

INSERT INTO `auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`, `group_code`) VALUES
('/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//ajaxcrud', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//controller', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//crud', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//extension', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//form', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//model', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//module', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/asset/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/asset/compress', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/asset/template', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/cache/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/cache/flush', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/cache/flush-all', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/cache/flush-schema', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/cache/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/db-explain', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/download-mail', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/toolbar', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/view', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/user/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/user/reset-identity', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/user/set-identity', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/fixture/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/fixture/load', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/fixture/unload', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/action', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/diff', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/preview', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/view', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/hello/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/hello/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/help/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/help/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/help/list', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/help/list-action-options', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/help/usage', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/message/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/message/config', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/message/config-template', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/message/extract', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/create', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/down', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/fresh', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/history', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/mark', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/new', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/redo', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/to', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/up', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/serve/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/serve/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/auth/change-own-password', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user-permission/set', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user-permission/set-roles', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/bulk-activate', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/bulk-deactivate', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/bulk-delete', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/change-password', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/create', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/delete', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/grid-page-size', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/update', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/view', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('Admin', 1, 'Admin', NULL, NULL, 1695691644, 1695691644, NULL),
('assignRolesToUsers', 2, 'Assign roles to users', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('bindUserToIp', 2, 'Bind user to IP', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('changeOwnPassword', 2, 'Change own password', NULL, NULL, 1695691644, 1695691644, 'userCommonPermissions'),
('changeUserPassword', 2, 'Change user password', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('commonPermission', 2, 'Common permission', NULL, NULL, 1695691643, 1695691643, NULL),
('createUsers', 2, 'Create users', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('deleteUsers', 2, 'Delete users', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('editUserEmail', 2, 'Edit user email', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('editUsers', 2, 'Edit users', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('viewRegistrationIp', 2, 'View registration IP', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('viewUserEmail', 2, 'View user email', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('viewUserRoles', 2, 'View user roles', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('viewUsers', 2, 'View users', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('viewVisitLog', 2, 'View visit log', NULL, NULL, 1695691644, 1695691644, 'userManagement');

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_child`
--

DROP TABLE IF EXISTS `auth_item_child`;
CREATE TABLE IF NOT EXISTS `auth_item_child` (
  `parent` varchar(64) CHARACTER SET utf8 NOT NULL,
  `child` varchar(64) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item_child`
--

INSERT INTO `auth_item_child` (`parent`, `child`) VALUES
('changeOwnPassword', '/user-management/auth/change-own-password'),
('assignRolesToUsers', '/user-management/user-permission/set'),
('assignRolesToUsers', '/user-management/user-permission/set-roles'),
('editUsers', '/user-management/user/bulk-activate'),
('editUsers', '/user-management/user/bulk-deactivate'),
('deleteUsers', '/user-management/user/bulk-delete'),
('changeUserPassword', '/user-management/user/change-password'),
('createUsers', '/user-management/user/create'),
('deleteUsers', '/user-management/user/delete'),
('viewUsers', '/user-management/user/grid-page-size'),
('viewUsers', '/user-management/user/index'),
('editUsers', '/user-management/user/update'),
('viewUsers', '/user-management/user/view'),
('Admin', 'assignRolesToUsers'),
('Admin', 'changeOwnPassword'),
('Admin', 'changeUserPassword'),
('Admin', 'createUsers'),
('Admin', 'deleteUsers'),
('Admin', 'editUsers'),
('editUserEmail', 'viewUserEmail'),
('assignRolesToUsers', 'viewUserRoles'),
('Admin', 'viewUsers'),
('assignRolesToUsers', 'viewUsers'),
('changeUserPassword', 'viewUsers'),
('createUsers', 'viewUsers'),
('deleteUsers', 'viewUsers'),
('editUsers', 'viewUsers');

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_group`
--

DROP TABLE IF EXISTS `auth_item_group`;
CREATE TABLE IF NOT EXISTS `auth_item_group` (
  `code` varchar(64) CHARACTER SET utf8 NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item_group`
--

INSERT INTO `auth_item_group` (`code`, `name`, `created_at`, `updated_at`) VALUES
('userCommonPermissions', 'User common permission', 1695691644, 1695691644),
('userManagement', 'User management', 1695691644, 1695691644);

-- --------------------------------------------------------

--
-- Table structure for table `auth_rule`
--

DROP TABLE IF EXISTS `auth_rule`;
CREATE TABLE IF NOT EXISTS `auth_rule` (
  `name` varchar(64) CHARACTER SET utf8 NOT NULL,
  `data` text CHARACTER SET utf8,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `banle_hoa_don`
--

DROP TABLE IF EXISTS `banle_hoa_don`;
CREATE TABLE IF NOT EXISTS `banle_hoa_don` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ma_hoa_don` int(11) DEFAULT NULL,
  `so_vao_so` int(11) DEFAULT NULL,
  `nam` int(11) DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `id_nguoi_ban` int(11) DEFAULT NULL,
  `ngay_ban` date DEFAULT NULL,
  `id_nguoi_lap` int(11) DEFAULT NULL,
  `ngay_lap` date DEFAULT NULL,
  `trang_thai` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edit_mode` tinyint(1) DEFAULT NULL,
  `id_khach_hang` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_khach_hang` (`id_khach_hang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `banle_hoa_don_chi_tiet`
--

DROP TABLE IF EXISTS `banle_hoa_don_chi_tiet`;
CREATE TABLE IF NOT EXISTS `banle_hoa_don_chi_tiet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_hoa_don` int(11) NOT NULL,
  `id_vat_tu` int(11) DEFAULT NULL,
  `loai_vat_tu` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `don_gia` int(11) DEFAULT NULL,
  `so_luong` double DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_hoa_don` (`id_hoa_don`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `banle_khach_hang`
--

DROP TABLE IF EXISTS `banle_khach_hang`;
CREATE TABLE IF NOT EXISTS `banle_khach_hang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_loai_khach_hang` int(11) NOT NULL,
  `ten_khach_hang` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `dia_chi` text COLLATE utf8_unicode_ci NOT NULL,
  `so_dien_thoai` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_loai_khach_hang` (`id_loai_khach_hang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `banle_loai_khach_hang`
--

DROP TABLE IF EXISTS `banle_loai_khach_hang`;
CREATE TABLE IF NOT EXISTS `banle_loai_khach_hang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten_loai_khach_hang` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `banle_loai_khach_hang`
--

INSERT INTO `banle_loai_khach_hang` (`id`, `ten_loai_khach_hang`, `ghi_chu`, `date_created`, `user_created`) VALUES
(1, 'Doanh nghiệp', NULL, NULL, NULL),
(2, 'Cá nhân', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cua_cay_nhom`
--

DROP TABLE IF EXISTS `cua_cay_nhom`;
CREATE TABLE IF NOT EXISTS `cua_cay_nhom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_he_nhom` int(11) NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `id_he_mau` int(11) DEFAULT NULL,
  `ten_cay_nhom` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `so_luong` int(11) DEFAULT NULL,
  `don_gia` double DEFAULT NULL,
  `khoi_luong` float DEFAULT NULL,
  `chieu_dai` float DEFAULT NULL,
  `do_day` float DEFAULT NULL,
  `for_cua_so` tinyint(1) DEFAULT NULL,
  `for_cua_di` tinyint(1) DEFAULT NULL,
  `min_allow_cut` float DEFAULT NULL,
  `min_allow_cut_under` float DEFAULT NULL,
  `dung_cho_nhieu_he_nhom` tinyint(1) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_he_nhom` (`id_he_nhom`),
  KEY `id_mau` (`id_he_mau`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_cong_trinh`
--

DROP TABLE IF EXISTS `cua_cong_trinh`;
CREATE TABLE IF NOT EXISTS `cua_cong_trinh` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_cong_trinh` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `id_khach_hang` int(11) DEFAULT NULL,
  `dia_diem` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ngay_bat_dau` date DEFAULT NULL,
  `ngay_hoan_thanh` date DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `code_mau_thiet_ke` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_khach_hang` (`id_khach_hang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_cong_trinh_settings`
--

DROP TABLE IF EXISTS `cua_cong_trinh_settings`;
CREATE TABLE IF NOT EXISTS `cua_cong_trinh_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_cong_trinh` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_don_vi_tinh`
--

DROP TABLE IF EXISTS `cua_don_vi_tinh`;
CREATE TABLE IF NOT EXISTS `cua_don_vi_tinh` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_dvt` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_don_vi_tinh`
--

INSERT INTO `cua_don_vi_tinh` (`id`, `code`, `ten_dvt`, `date_created`, `user_created`) VALUES
(1, 'chua-phan-loai', 'Chưa phân loại', NULL, NULL),
(2, NULL, 'cái', NULL, NULL),
(3, NULL, 'cặp', NULL, NULL),
(4, NULL, 'm2', NULL, NULL),
(5, NULL, 'bộ', NULL, NULL),
(6, NULL, 'Chiếc', NULL, NULL),
(7, NULL, 'Thanh', NULL, NULL),
(8, NULL, 'Chai', NULL, NULL),
(9, NULL, 'con', NULL, NULL),
(10, NULL, 'cuộn', NULL, NULL),
(11, NULL, 'kg', NULL, NULL),
(12, NULL, 'mét tới', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cua_du_an`
--

DROP TABLE IF EXISTS `cua_du_an`;
CREATE TABLE IF NOT EXISTS `cua_du_an` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_du_an` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ten_khach_hang` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dia_chi` text COLLATE utf8_unicode_ci,
  `so_dien_thoai` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trang_thai` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `toi_uu_tat_ca` tinyint(4) DEFAULT NULL,
  `ngay_bat_dau_thuc_hien` date DEFAULT NULL,
  `ngay_hoan_thanh_du_an` date DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `code_mau_thiet_ke` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_du_an_settings`
--

DROP TABLE IF EXISTS `cua_du_an_settings`;
CREATE TABLE IF NOT EXISTS `cua_du_an_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_du_an` int(11) DEFAULT NULL,
  `vet_cat` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_du_an` (`id_du_an`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_he_mau`
--

DROP TABLE IF EXISTS `cua_he_mau`;
CREATE TABLE IF NOT EXISTS `cua_he_mau` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf32_unicode_ci DEFAULT NULL,
  `ten_he_mau` varchar(200) COLLATE utf32_unicode_ci NOT NULL,
  `ma_mau` varchar(20) COLLATE utf32_unicode_ci NOT NULL,
  `for_nhom` tinyint(1) DEFAULT NULL,
  `for_phu_kien` tinyint(1) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Dumping data for table `cua_he_mau`
--

INSERT INTO `cua_he_mau` (`id`, `code`, `ten_he_mau`, `ma_mau`, `for_nhom`, `for_phu_kien`, `date_created`, `user_created`) VALUES
(1, 'Xám', 'Màu xám', '#615551', 1, 0, '2024-08-27 14:02:15', 1),
(2, 'XANH', 'Màu xanh', '#08e722', 1, 1, '2024-08-27 14:15:28', 1),
(3, 'DO', 'Màu đỏ', '#df3207', 1, 0, '2024-08-27 14:15:52', 1),
(4, 'VANG', 'Màu vàng', '#f3f708', 1, 1, '2024-08-27 14:16:23', 1),
(5, 'Sữa', 'Hệ màu trắng sữa', '#ebe5e5', 1, 0, '2024-08-29 15:31:30', 1),
(6, 'Gỗ', 'Hệ màu vân gỗ', '#dac22b', 1, 0, '2024-08-29 15:32:17', 1),
(7, 'Đen', 'Hệ màu đen', '#000000', 0, 1, '2024-08-30 08:39:35', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_he_nhom`
--

DROP TABLE IF EXISTS `cua_he_nhom`;
CREATE TABLE IF NOT EXISTS `cua_he_nhom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_he_nhom` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `xuat_xu` int(11) DEFAULT NULL,
  `hang_san_xuat` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nha_cung_cap` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `do_day_mac_dinh` float DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_he_nhom`
--

INSERT INTO `cua_he_nhom` (`id`, `code`, `ten_he_nhom`, `xuat_xu`, `hang_san_xuat`, `nha_cung_cap`, `do_day_mac_dinh`, `ghi_chu`, `date_created`, `user_created`) VALUES
(1, 'PMI-XF55D', 'PMI P55D Xingfa', 2, 'PMI', NULL, 1.4, 'ghi chú', '2024-08-28 14:53:48', 1),
(2, 'XF55', 'Xingfa Quảng Đông hệ 55', 1, 'Xingfa', NULL, 1.6, '', '2024-08-28 15:23:04', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_he_nhom_mau`
--

DROP TABLE IF EXISTS `cua_he_nhom_mau`;
CREATE TABLE IF NOT EXISTS `cua_he_nhom_mau` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_he_nhom` int(11) NOT NULL,
  `id_he_mau` int(11) NOT NULL,
  `is_mac_dinh` tinyint(1) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_he_nhom` (`id_he_nhom`),
  KEY `id_mau` (`id_he_mau`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Dumping data for table `cua_he_nhom_mau`
--

INSERT INTO `cua_he_nhom_mau` (`id`, `id_he_nhom`, `id_he_mau`, `is_mac_dinh`, `date_created`, `user_created`) VALUES
(32, 1, 1, 0, '2024-08-28 14:57:39', 1),
(33, 1, 2, 1, '2024-08-28 14:57:39', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_he_vach`
--

DROP TABLE IF EXISTS `cua_he_vach`;
CREATE TABLE IF NOT EXISTS `cua_he_vach` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_he_vach` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_hinh_anh`
--

DROP TABLE IF EXISTS `cua_hinh_anh`;
CREATE TABLE IF NOT EXISTS `cua_hinh_anh` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loai` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `id_tham_chieu` int(11) NOT NULL,
  `ten_hien_thi` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `duong_dan` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_file_luu` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `img_extension` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `img_size` float DEFAULT NULL,
  `img_wh` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_kho_nhom`
--

DROP TABLE IF EXISTS `cua_kho_nhom`;
CREATE TABLE IF NOT EXISTS `cua_kho_nhom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `qr_code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id_cay_nhom` int(11) NOT NULL,
  `chieu_dai` float NOT NULL,
  `so_luong` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_cay_nhom` (`id_cay_nhom`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_kho_nhom_lich_su`
--

DROP TABLE IF EXISTS `cua_kho_nhom_lich_su`;
CREATE TABLE IF NOT EXISTS `cua_kho_nhom_lich_su` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_kho_nhom` int(11) NOT NULL,
  `so_luong` int(11) NOT NULL,
  `so_luong_cu` int(11) DEFAULT NULL,
  `so_luong_moi` int(11) DEFAULT NULL,
  `noi_dung` text COLLATE utf8_unicode_ci NOT NULL,
  `id_mau_cua` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_kho_nhom` (`id_kho_nhom`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_kho_nhom_qr`
--

DROP TABLE IF EXISTS `cua_kho_nhom_qr`;
CREATE TABLE IF NOT EXISTS `cua_kho_nhom_qr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_kho_nhom` int(11) NOT NULL,
  `id_nhom_su_dung` int(11) NOT NULL,
  `qr_code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_kho_nhom` (`id_kho_nhom`),
  KEY `id_nhom_su_dung` (`id_nhom_su_dung`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_kho_vat_tu`
--

DROP TABLE IF EXISTS `cua_kho_vat_tu`;
CREATE TABLE IF NOT EXISTS `cua_kho_vat_tu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_vat_tu` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `id_he_mau` int(11) DEFAULT NULL,
  `id_nhom_vat_tu` int(11) DEFAULT NULL,
  `thuong_hieu` int(11) DEFAULT NULL,
  `model` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `xuat_xu` int(11) DEFAULT NULL,
  `nha_cung_cap` int(11) DEFAULT NULL,
  `la_phu_kien` tinyint(1) DEFAULT NULL,
  `so_luong` float DEFAULT NULL,
  `dvt` int(11) NOT NULL,
  `don_gia` double DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_nhom_vat_tu` (`id_nhom_vat_tu`),
  KEY `xuat_xu` (`xuat_xu`),
  KEY `id_he_mau` (`id_he_mau`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_kho_vat_tu_lich_su`
--

DROP TABLE IF EXISTS `cua_kho_vat_tu_lich_su`;
CREATE TABLE IF NOT EXISTS `cua_kho_vat_tu_lich_su` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_kho_vat_tu` int(11) NOT NULL,
  `id_nha_cung_cap` int(11) DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `so_luong` float DEFAULT NULL,
  `so_luong_cu` float DEFAULT NULL,
  `so_luong_moi` float DEFAULT NULL,
  `id_mau_cua` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_kho_vat_tu` (`id_kho_vat_tu`),
  KEY `id_nha_cung_cap` (`id_nha_cung_cap`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_kho_vat_tu_nha_cung_cap`
--

DROP TABLE IF EXISTS `cua_kho_vat_tu_nha_cung_cap`;
CREATE TABLE IF NOT EXISTS `cua_kho_vat_tu_nha_cung_cap` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_nha_cung_cap` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dia_chi` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_kho_vat_tu_nha_cung_cap`
--

INSERT INTO `cua_kho_vat_tu_nha_cung_cap` (`id`, `code`, `ten_nha_cung_cap`, `dia_chi`, `date_created`, `user_created`) VALUES
(2, 'NCC01', 'Công ty TNHH ABCD', 'thành phố Trà Vinh\r\n', '2023-12-05 08:20:45', 1),
(3, 'NCC02', 'Công ty NVT', 'Trà VINH', '2023-12-05 08:41:01', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_loai_bao_gia`
--

DROP TABLE IF EXISTS `cua_loai_bao_gia`;
CREATE TABLE IF NOT EXISTS `cua_loai_bao_gia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_loai_bao_gia` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nhom_bao_gia` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_loai_bao_gia`
--

INSERT INTO `cua_loai_bao_gia` (`id`, `code`, `ten_loai_bao_gia`, `nhom_bao_gia`, `ghi_chu`) VALUES
(1, 'nhom-mac-dinh', 'Báo giá nhôm', 'NHOM', NULL),
(2, 'vat-tu-mac-dinh', 'Báo giá vật tư', 'VATTU', NULL),
(3, 'vach-mac-dinh', 'Báo giá vách', 'VACH', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cua_loai_cua`
--

DROP TABLE IF EXISTS `cua_loai_cua`;
CREATE TABLE IF NOT EXISTS `cua_loai_cua` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_loai_cua` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua`
--

DROP TABLE IF EXISTS `cua_mau_cua`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_cua` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `kich_thuoc` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ngang` float DEFAULT NULL,
  `cao` float DEFAULT NULL,
  `id_he_nhom` int(11) DEFAULT NULL,
  `id_loai_cua` int(11) NOT NULL,
  `id_parent` int(11) DEFAULT NULL,
  `id_du_an` int(11) DEFAULT NULL,
  `id_cong_trinh` int(11) DEFAULT NULL,
  `ngay_yeu_cau` date DEFAULT NULL,
  `so_luong` int(11) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `id_he_nhom` (`id_he_nhom`),
  KEY `id_parent` (`id_parent`),
  KEY `id_loai_cua` (`id_loai_cua`),
  KEY `id_du_an` (`id_du_an`),
  KEY `id_cong_trinh` (`id_cong_trinh`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua_nhom`
--

DROP TABLE IF EXISTS `cua_mau_cua_nhom`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua_nhom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mau_cua` int(11) NOT NULL,
  `id_cay_nhom` int(11) NOT NULL,
  `chieu_dai` float DEFAULT NULL,
  `so_luong` int(11) DEFAULT NULL,
  `kieu_cat` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `khoi_luong` float DEFAULT NULL,
  `don_gia` double DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_mau_cua` (`id_mau_cua`),
  KEY `id_cay_nhom` (`id_cay_nhom`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua_nhom_su_dung`
--

DROP TABLE IF EXISTS `cua_mau_cua_nhom_su_dung`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua_nhom_su_dung` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mau_cua` int(11) DEFAULT NULL,
  `id_du_an` int(11) DEFAULT NULL,
  `id_kho_nhom` int(11) NOT NULL,
  `chieu_dai_ban_dau` float NOT NULL,
  `chieu_dai_con_lai` float NOT NULL,
  `chieu_dai_nhap_lai` float DEFAULT NULL,
  `ghi_chu_nhap_lai` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_mau_cua` (`id_mau_cua`),
  KEY `id_kho_nhom` (`id_kho_nhom`),
  KEY `id_du_an` (`id_du_an`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua_nhom_su_dung_chi_tiet`
--

DROP TABLE IF EXISTS `cua_mau_cua_nhom_su_dung_chi_tiet`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua_nhom_su_dung_chi_tiet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_nhom_su_dung` int(11) NOT NULL,
  `id_nhom_toi_uu` int(11) NOT NULL,
  `date_created` int(11) DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_nhom_su_dung` (`id_nhom_su_dung`),
  KEY `id_nhom_toi_uu` (`id_nhom_toi_uu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua_settings`
--

DROP TABLE IF EXISTS `cua_mau_cua_settings`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mau_cua` int(11) DEFAULT NULL,
  `vet_cat` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_mau_cua` (`id_mau_cua`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua_vach`
--

DROP TABLE IF EXISTS `cua_mau_cua_vach`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua_vach` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mau_cua` int(11) NOT NULL,
  `id_vach` int(11) NOT NULL,
  `rong` float DEFAULT NULL,
  `cao` float DEFAULT NULL,
  `so_luong` float DEFAULT NULL,
  `dien_tich` float DEFAULT NULL,
  `don_gia` double NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) NOT NULL,
  `so_luong_xuat` float DEFAULT NULL,
  `ghi_chu_xuat` text COLLATE utf8_unicode_ci,
  `so_luong_nhap_lai` float DEFAULT NULL,
  `ghi_chu_nhap_lai` text COLLATE utf8_unicode_ci,
  `code_bao_gia` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_mau_cua` (`id_mau_cua`),
  KEY `id_vach` (`id_vach`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua_vat_tu`
--

DROP TABLE IF EXISTS `cua_mau_cua_vat_tu`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua_vat_tu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mau_cua` int(11) NOT NULL,
  `id_kho_vat_tu` int(11) NOT NULL,
  `so_luong` float NOT NULL,
  `dvt` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `don_gia` double DEFAULT NULL,
  `la_phu_kien` tinyint(4) DEFAULT NULL,
  `so_luong_xuat` float DEFAULT NULL,
  `ghi_chu_xuat` text COLLATE utf8_unicode_ci,
  `so_luong_nhap_lai` float DEFAULT NULL,
  `ghi_chu_nhap_lai` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  `code_bao_gia` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_mau_cua` (`id_mau_cua`),
  KEY `id_kho_vat_tu` (`id_kho_vat_tu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_settings`
--

DROP TABLE IF EXISTS `cua_settings`;
CREATE TABLE IF NOT EXISTS `cua_settings` (
  `id` int(11) NOT NULL,
  `cho_phep_nhap_kho_am` tinyint(1) DEFAULT NULL,
  `an_kho_nhom_bang_khong` tinyint(1) DEFAULT NULL,
  `vet_cat` float DEFAULT NULL,
  `chieu_dai_nhom_mac_dinh` float DEFAULT NULL,
  `so_ngay_canh_bao_giao_cua` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_settings`
--

INSERT INTO `cua_settings` (`id`, `cho_phep_nhap_kho_am`, `an_kho_nhom_bang_khong`, `vet_cat`, `chieu_dai_nhom_mac_dinh`, `so_ngay_canh_bao_giao_cua`) VALUES
(1, 1, 1, 2, 6000, 2);

-- --------------------------------------------------------

--
-- Table structure for table `cua_thuong_hieu`
--

DROP TABLE IF EXISTS `cua_thuong_hieu`;
CREATE TABLE IF NOT EXISTS `cua_thuong_hieu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_thuong_hieu` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_thuong_hieu`
--

INSERT INTO `cua_thuong_hieu` (`id`, `code`, `ten_thuong_hieu`, `ghi_chu`) VALUES
(1, 'chua-phan-loai', 'Mặc định', ''),
(2, '9AM1y', 'Thương hiệu 1', ''),
(3, '6FYOl', 'Thương hiệu 2', '');

-- --------------------------------------------------------

--
-- Table structure for table `cua_toi_uu`
--

DROP TABLE IF EXISTS `cua_toi_uu`;
CREATE TABLE IF NOT EXISTS `cua_toi_uu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mau_cua` int(11) NOT NULL,
  `id_mau_cua_nhom` int(11) NOT NULL,
  `id_ton_kho_nhom` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_mau_cua` (`id_mau_cua`),
  KEY `id_mau_cua_nhom` (`id_mau_cua_nhom`),
  KEY `id_ton_kho_nhom` (`id_ton_kho_nhom`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_xuat_xu`
--

DROP TABLE IF EXISTS `cua_xuat_xu`;
CREATE TABLE IF NOT EXISTS `cua_xuat_xu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_xuat_xu` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_xuat_xu`
--

INSERT INTO `cua_xuat_xu` (`id`, `code`, `ten_xuat_xu`, `ghi_chu`) VALUES
(1, 'chua-phan-loai', 'Chưa phân loại', ''),
(2, 'VN', 'Việt Nam', '');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

DROP TABLE IF EXISTS `history`;
CREATE TABLE IF NOT EXISTS `history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loai` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `id_tham_chieu` int(11) NOT NULL,
  `noi_dung` text COLLATE utf8_unicode_ci NOT NULL,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

DROP TABLE IF EXISTS `migration`;
CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1695691639),
('m140608_173539_create_user_table', 1695691642),
('m140611_133903_init_rbac', 1695691642),
('m140808_073114_create_auth_item_group_table', 1695691642),
('m140809_072112_insert_superadmin_to_user', 1695691643),
('m140809_073114_insert_common_permisison_to_auth_item', 1695691643),
('m141023_141535_create_user_visit_log', 1695691643),
('m141116_115804_add_bind_to_ip_and_registration_ip_to_user', 1695691643),
('m141121_194858_split_browser_and_os_column', 1695691643),
('m141201_220516_add_email_and_email_confirmed_to_user', 1695691644),
('m141207_001649_create_basic_user_permissions', 1695691644);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8 NOT NULL,
  `auth_key` varchar(32) CHARACTER SET utf8 NOT NULL,
  `password_hash` varchar(255) CHARACTER SET utf8 NOT NULL,
  `confirmation_token` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `superadmin` smallint(6) DEFAULT '0',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `registration_ip` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
  `bind_to_ip` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(128) CHARACTER SET utf8 DEFAULT NULL,
  `email_confirmed` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `confirmation_token`, `status`, `superadmin`, `created_at`, `updated_at`, `registration_ip`, `bind_to_ip`, `email`, `email_confirmed`) VALUES
(1, 'superadmin', 'MDvwUlYvBDOYlfwXEkNhRChWr2utQ3xU', '$2y$13$.82.TmKU5VxndDwYIY8KOeQFIn7WJ6tZinx6mz0MGdkqmpYC0wmHK', NULL, 1, 1, 1695691643, 1695691643, NULL, NULL, NULL, 0),
(2, 'admin', 'Hch1yqSEXM8MbzZLQqQ0J30xv47Y6QO0', '$2y$13$OaXrxEFYubo0F1g5yRqmJOuxbmzqaFPeh9tPjcZ/aY4wjpBtspgyO', NULL, 1, 1, 1702256795, 1702256795, '::1', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_visit_log`
--

DROP TABLE IF EXISTS `user_visit_log`;
CREATE TABLE IF NOT EXISTS `user_visit_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` varchar(255) CHARACTER SET utf8 NOT NULL,
  `ip` varchar(15) CHARACTER SET utf8 NOT NULL,
  `language` char(2) CHARACTER SET utf8 NOT NULL,
  `user_agent` varchar(255) CHARACTER SET utf8 NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `visit_time` int(11) NOT NULL,
  `browser` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `os` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_visit_log`
--

INSERT INTO `user_visit_log` (`id`, `token`, `ip`, `language`, `user_agent`, `user_id`, `visit_time`, `browser`, `os`) VALUES
(1, '651233ac68058', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695691692, 'Chrome', 'Windows'),
(2, '651236d4e41f3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695692500, 'Chrome', 'Windows'),
(3, '6512462aa9eb3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695696426, 'Chrome', 'Windows'),
(4, '65137e1b21d83', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695776283, 'Chrome', 'Windows'),
(5, '65152884d18a2', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695885444, 'Chrome', 'Windows'),
(6, '65167bc86b56f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695972296, 'Chrome', 'Windows'),
(7, '651fc82504a1f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1696581669, 'Chrome', 'Windows'),
(8, '65294c755aebb', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1697205365, 'Chrome', 'Windows'),
(9, '65295a386d589', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1697208888, 'Chrome', 'Windows'),
(10, '652d5011ee601', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1697468434, 'Chrome', 'Windows'),
(11, '652e4ad038376', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1697532624, 'Chrome', 'Windows'),
(12, '652e4b0664a5e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1697532678, 'Chrome', 'Windows'),
(13, '6535c66babd70', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1698023019, 'Chrome', 'Windows'),
(14, '653f6657106a4', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1698653783, 'Chrome', 'Windows'),
(15, '65449a2cbcaff', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1698994732, 'Chrome', 'Windows'),
(16, '65449a409b40e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1698994752, 'Chrome', 'Windows'),
(17, '654839f01d33e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1699232240, 'Chrome', 'Windows'),
(18, '65498b0e1a435', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1699318542, 'Chrome', 'Windows'),
(19, '654c30af3f6b2', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1699492015, 'Chrome', 'Windows'),
(20, '654d8251ec3db', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1699578449, 'Chrome', 'Windows'),
(21, '6552c5c3166bb', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1699923395, 'Chrome', 'Windows'),
(22, '65556baa09cc4', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1700096938, 'Chrome', 'Windows'),
(23, '6556ba7927cfa', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1700182649, 'Chrome', 'Windows'),
(24, '655ea55da9335', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1700701533, 'Chrome', 'Windows'),
(25, '655ff4cb95ae2', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1700787403, 'Chrome', 'Windows'),
(26, '6563f2c74ad32', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701049031, 'Chrome', 'Windows'),
(27, '65668958eaae0', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701218648, 'Chrome', 'Windows'),
(28, '656696bf09e09', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701222079, 'Chrome', 'Windows'),
(29, '656990dc9d085', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701417180, 'Chrome', 'Windows'),
(30, '656d21257611e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701650725, 'Chrome', 'Windows'),
(31, '656d774245afa', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701672770, 'Chrome', 'Windows'),
(32, '656e743392498', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701737523, 'Chrome', 'Windows'),
(33, '656ed00f1ba53', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701761039, 'Chrome', 'Windows'),
(34, '656fc4e0009c2', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701823712, 'Chrome', 'Windows'),
(35, '657114ef13fe3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701909743, 'Chrome', 'Windows'),
(36, '6573c4d291c4d', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1702085842, 'Chrome', 'Windows'),
(37, '6573cc0e3eb38', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1702087694, 'Chrome', 'Windows'),
(38, '6573cc35bc770', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1702087733, 'Chrome', 'Windows'),
(39, '6576608310f74', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1702256771, 'Chrome', 'Windows'),
(40, '657660c3ae9e3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 2, 1702256835, 'Chrome', 'Windows'),
(41, '65796d9e815a9', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1702456734, 'Chrome', 'Windows'),
(42, '657aa2e74b599', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1702535911, 'Chrome', 'Windows'),
(43, '657d510622e04', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1702711558, 'Chrome', 'Windows'),
(44, '65810b57b2f61', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1702955863, 'Chrome', 'Windows'),
(45, '6582468034135', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1703036544, 'Chrome', 'Windows'),
(46, '6582491abea69', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1703037210, 'Chrome', 'Windows'),
(47, '65839ed9a5f36', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1703124697, 'Chrome', 'Windows'),
(48, '6584e95dbe283', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1703209309, 'Chrome', 'Windows'),
(49, '658535af6d642', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 2, 1703228847, 'Chrome', 'Windows'),
(50, '65869dcc6e44b', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1703321036, 'Chrome', 'Windows'),
(51, '6590d3d4a581c', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 2, 1703990228, 'Chrome', 'Windows'),
(52, '65920c8cabb6f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 2, 1704070284, 'Chrome', 'Windows'),
(53, '65937af25d400', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1704164082, 'Chrome', 'Windows'),
(54, '6597b3f56be13', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1704440821, 'Chrome', 'Windows'),
(55, '6598c2c65b204', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1704510150, 'Chrome', 'Windows'),
(56, '65a9d9fcf3381', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1705630205, 'Chrome', 'Windows'),
(57, '65dffd9ae2235', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 1, 1709178266, 'Chrome', 'Windows'),
(58, '661f1e67032e3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36', 1, 1713315431, 'Chrome', 'Windows'),
(59, '66289d637b30a', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36', 1, 1713937763, 'Chrome', 'Windows'),
(60, '6639dc619ad26', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36', 1, 1715068001, 'Chrome', 'Windows'),
(61, '663b3f0b24c2e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36', 1, 1715158795, 'Chrome', 'Windows'),
(62, '66417d1cbda0e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36', 1, 1715567900, 'Chrome', 'Windows'),
(63, '6645bb7c30896', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36', 1, 1715846012, 'Chrome', 'Windows'),
(64, '6646c35433573', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1715913556, 'Chrome', 'Windows'),
(65, '6648542336357', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1716016163, 'Chrome', 'Windows'),
(66, '664bf20e94cfc', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1716253198, 'Chrome', 'Windows'),
(67, '66541d2094eb0', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1716788512, 'Chrome', 'Windows'),
(68, '66553a56ab953', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1716861526, 'Chrome', 'Windows'),
(69, '66569e3c0c02f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1716952636, 'Chrome', 'Windows'),
(70, '6659459bc84b0', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1717126555, 'Chrome', 'Windows'),
(71, '665d74a793765', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1717400743, 'Chrome', 'Windows'),
(72, '66625b5d80cb4', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1717721949, 'Chrome', 'Windows'),
(73, '666652f49f33a', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1717981940, 'Chrome', 'Windows'),
(74, '666907579d104', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1718159191, 'Chrome', 'Windows'),
(75, '666aa5e531457', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 1, 1718265317, 'Chrome', 'Windows'),
(76, '668214cd48c94', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36', 1, 1719801037, 'Chrome', 'Windows'),
(77, '66821e653feab', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36', 1, 1719803493, 'Chrome', 'Windows'),
(78, '6684b50300013', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36', 1, 1719973123, 'Chrome', 'Windows'),
(79, '668bc8ea5c881', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36', 1, 1720436970, 'Chrome', 'Windows'),
(80, '668f427c643f6', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36', 1, 1720664700, 'Chrome', 'Windows'),
(81, '66a845a42818f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1722303908, 'Chrome', 'Windows'),
(82, '66a8ac6ad9580', '27.71.99.151', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1722330218, 'Chrome', 'Windows'),
(83, '66aae45ee2255', '27.71.99.151', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1722475614, 'Chrome', 'Windows'),
(84, '66add28829bda', '115.74.244.101', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36', 1, 1722667656, 'Chrome', 'Windows'),
(85, '66aeece1cde01', '115.76.39.62', 'en', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36', 2, 1722739937, 'Chrome', 'mac'),
(86, '66b03742736ac', '115.74.244.101', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1722824514, 'Chrome', 'Windows'),
(87, '66b06d363cf26', '115.74.244.101', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0', 2, 1722838326, 'Chrome', 'Windows'),
(88, '66b08606444ae', '27.71.99.151', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1722844678, 'Chrome', 'Windows'),
(89, '66b17d13435a1', '116.109.226.45', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 2, 1722907923, 'Chrome', 'Windows'),
(90, '66b1894219e41', '27.71.99.151', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1722911042, 'Chrome', 'Windows'),
(91, '66b1c1239b715', '116.109.226.45', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 2, 1722925347, 'Chrome', 'Windows'),
(92, '66b5623a10e2c', '116.109.225.253', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 2, 1723163194, 'Chrome', 'Windows'),
(93, '66b9abda3d26c', '112.197.240.147', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1723444186, 'Chrome', 'Windows'),
(94, '66b9b92da7d0d', '116.109.225.253', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 2, 1723447597, 'Chrome', 'Windows'),
(95, '66bc6383dea81', '27.71.99.151', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1723622275, 'Chrome', 'Windows'),
(96, '66bc6b72df46f', '116.109.225.253', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 2, 1723624306, 'Chrome', 'Windows'),
(97, '66bd4ca32747d', '116.109.225.253', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 2, 1723681955, 'Chrome', 'Windows'),
(98, '66bd56b85bc8b', '27.71.99.151', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1723684536, 'Chrome', 'Windows'),
(99, '66bd9fb4f0bf0', '116.109.225.253', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 2, 1723703220, 'Chrome', 'Windows'),
(100, '66bdab887985e', '27.71.99.151', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1723706248, 'Chrome', 'Windows'),
(101, '66bdc62cf2154', '116.109.225.253', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 2, 1723713068, 'Chrome', 'Windows'),
(102, '66beadce5ea1f', '116.109.225.253', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 2, 1723772366, 'Chrome', 'Windows'),
(103, '66c053b911043', '116.109.225.253', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 2, 1723880377, 'Chrome', 'Windows'),
(104, '66c2f9dd27cb2', '116.109.225.253', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 2, 1724053981, 'Chrome', 'Windows'),
(105, '66c94b253a1a4', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1724468005, 'Chrome', 'Windows'),
(106, '66cbf7bb8260f', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', 1, 1724643259, 'Chrome', 'Windows'),
(107, '66cdeeed6ea7c', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', 1, 1724772077, 'Chrome', 'Windows');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_assignment`
--
ALTER TABLE `auth_assignment`
  ADD CONSTRAINT `auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_assignment_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `auth_item`
--
ALTER TABLE `auth_item`
  ADD CONSTRAINT `auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_auth_item_group_code` FOREIGN KEY (`group_code`) REFERENCES `auth_item_group` (`code`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `banle_hoa_don`
--
ALTER TABLE `banle_hoa_don`
  ADD CONSTRAINT `banle_hoa_don_ibfk_1` FOREIGN KEY (`id_khach_hang`) REFERENCES `banle_khach_hang` (`id`);

--
-- Constraints for table `banle_hoa_don_chi_tiet`
--
ALTER TABLE `banle_hoa_don_chi_tiet`
  ADD CONSTRAINT `banle_hoa_don_chi_tiet_ibfk_1` FOREIGN KEY (`id_hoa_don`) REFERENCES `banle_hoa_don` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `banle_khach_hang`
--
ALTER TABLE `banle_khach_hang`
  ADD CONSTRAINT `banle_khach_hang_ibfk_1` FOREIGN KEY (`id_loai_khach_hang`) REFERENCES `banle_loai_khach_hang` (`id`);

--
-- Constraints for table `cua_cay_nhom`
--
ALTER TABLE `cua_cay_nhom`
  ADD CONSTRAINT `cua_cay_nhom_ibfk_1` FOREIGN KEY (`id_he_nhom`) REFERENCES `cua_he_nhom` (`id`),
  ADD CONSTRAINT `cua_cay_nhom_ibfk_2` FOREIGN KEY (`id_he_mau`) REFERENCES `cua_he_mau` (`id`);

--
-- Constraints for table `cua_cong_trinh`
--
ALTER TABLE `cua_cong_trinh`
  ADD CONSTRAINT `cua_cong_trinh_ibfk_1` FOREIGN KEY (`id_khach_hang`) REFERENCES `banle_khach_hang` (`id`);

--
-- Constraints for table `cua_du_an_settings`
--
ALTER TABLE `cua_du_an_settings`
  ADD CONSTRAINT `cua_du_an_settings_ibfk_1` FOREIGN KEY (`id_du_an`) REFERENCES `cua_du_an` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_he_nhom_mau`
--
ALTER TABLE `cua_he_nhom_mau`
  ADD CONSTRAINT `cua_he_nhom_mau_ibfk_1` FOREIGN KEY (`id_he_nhom`) REFERENCES `cua_he_nhom` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cua_he_nhom_mau_ibfk_2` FOREIGN KEY (`id_he_mau`) REFERENCES `cua_he_mau` (`id`);

--
-- Constraints for table `cua_kho_nhom`
--
ALTER TABLE `cua_kho_nhom`
  ADD CONSTRAINT `cua_kho_nhom_ibfk_1` FOREIGN KEY (`id_cay_nhom`) REFERENCES `cua_cay_nhom` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_kho_nhom_lich_su`
--
ALTER TABLE `cua_kho_nhom_lich_su`
  ADD CONSTRAINT `cua_kho_nhom_lich_su_ibfk_1` FOREIGN KEY (`id_kho_nhom`) REFERENCES `cua_kho_nhom` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_kho_nhom_qr`
--
ALTER TABLE `cua_kho_nhom_qr`
  ADD CONSTRAINT `cua_kho_nhom_qr_ibfk_1` FOREIGN KEY (`id_kho_nhom`) REFERENCES `cua_kho_nhom` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cua_kho_nhom_qr_ibfk_2` FOREIGN KEY (`id_nhom_su_dung`) REFERENCES `cua_mau_cua_nhom_su_dung` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_kho_vat_tu`
--
ALTER TABLE `cua_kho_vat_tu`
  ADD CONSTRAINT `cua_kho_vat_tu_ibfk_1` FOREIGN KEY (`xuat_xu`) REFERENCES `cua_xuat_xu` (`id`),
  ADD CONSTRAINT `cua_kho_vat_tu_ibfk_2` FOREIGN KEY (`id_he_mau`) REFERENCES `cua_he_mau` (`id`);

--
-- Constraints for table `cua_kho_vat_tu_lich_su`
--
ALTER TABLE `cua_kho_vat_tu_lich_su`
  ADD CONSTRAINT `cua_kho_vat_tu_lich_su_ibfk_1` FOREIGN KEY (`id_kho_vat_tu`) REFERENCES `cua_kho_vat_tu` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_mau_cua`
--
ALTER TABLE `cua_mau_cua`
  ADD CONSTRAINT `cua_mau_cua_ibfk_1` FOREIGN KEY (`id_he_nhom`) REFERENCES `cua_he_nhom` (`id`),
  ADD CONSTRAINT `cua_mau_cua_ibfk_2` FOREIGN KEY (`id_loai_cua`) REFERENCES `cua_loai_cua` (`id`),
  ADD CONSTRAINT `cua_mau_cua_ibfk_3` FOREIGN KEY (`id_du_an`) REFERENCES `cua_du_an` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `cua_mau_cua_ibfk_4` FOREIGN KEY (`id_cong_trinh`) REFERENCES `cua_cong_trinh` (`id`);

--
-- Constraints for table `cua_mau_cua_nhom`
--
ALTER TABLE `cua_mau_cua_nhom`
  ADD CONSTRAINT `cua_mau_cua_nhom_ibfk_1` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cua_mau_cua_nhom_ibfk_2` FOREIGN KEY (`id_cay_nhom`) REFERENCES `cua_cay_nhom` (`id`);

--
-- Constraints for table `cua_mau_cua_nhom_su_dung`
--
ALTER TABLE `cua_mau_cua_nhom_su_dung`
  ADD CONSTRAINT `cua_mau_cua_nhom_su_dung_ibfk_1` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cua_mau_cua_nhom_su_dung_ibfk_2` FOREIGN KEY (`id_kho_nhom`) REFERENCES `cua_kho_nhom` (`id`),
  ADD CONSTRAINT `cua_mau_cua_nhom_su_dung_ibfk_3` FOREIGN KEY (`id_du_an`) REFERENCES `cua_du_an` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_mau_cua_nhom_su_dung_chi_tiet`
--
ALTER TABLE `cua_mau_cua_nhom_su_dung_chi_tiet`
  ADD CONSTRAINT `cua_mau_cua_nhom_su_dung_chi_tiet_ibfk_1` FOREIGN KEY (`id_nhom_su_dung`) REFERENCES `cua_mau_cua_nhom_su_dung` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cua_mau_cua_nhom_su_dung_chi_tiet_ibfk_2` FOREIGN KEY (`id_nhom_toi_uu`) REFERENCES `cua_toi_uu` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_mau_cua_settings`
--
ALTER TABLE `cua_mau_cua_settings`
  ADD CONSTRAINT `cua_mau_cua_settings_ibfk_1` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_mau_cua_vach`
--
ALTER TABLE `cua_mau_cua_vach`
  ADD CONSTRAINT `cua_mau_cua_vach_ibfk_1` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cua_mau_cua_vach_ibfk_2` FOREIGN KEY (`id_vach`) REFERENCES `cua_he_vach` (`id`);

--
-- Constraints for table `cua_mau_cua_vat_tu`
--
ALTER TABLE `cua_mau_cua_vat_tu`
  ADD CONSTRAINT `cua_mau_cua_vat_tu_ibfk_1` FOREIGN KEY (`id_kho_vat_tu`) REFERENCES `cua_kho_vat_tu` (`id`),
  ADD CONSTRAINT `cua_mau_cua_vat_tu_ibfk_2` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_toi_uu`
--
ALTER TABLE `cua_toi_uu`
  ADD CONSTRAINT `cua_toi_uu_ibfk_1` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`),
  ADD CONSTRAINT `cua_toi_uu_ibfk_2` FOREIGN KEY (`id_mau_cua_nhom`) REFERENCES `cua_mau_cua_nhom` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cua_toi_uu_ibfk_3` FOREIGN KEY (`id_ton_kho_nhom`) REFERENCES `cua_kho_nhom` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_visit_log`
--
ALTER TABLE `user_visit_log`
  ADD CONSTRAINT `user_visit_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
