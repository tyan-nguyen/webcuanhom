-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 06, 2023 at 09:58 AM
-- Server version: 5.7.40
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webcuanhom`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_assignment`
--

DROP TABLE IF EXISTS `auth_assignment`;
CREATE TABLE IF NOT EXISTS `auth_assignment` (
  `item_name` varchar(64) CHARACTER SET utf8 NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_item`
--

DROP TABLE IF EXISTS `auth_item`;
CREATE TABLE IF NOT EXISTS `auth_item` (
  `name` varchar(64) CHARACTER SET utf8 NOT NULL,
  `type` int(11) NOT NULL,
  `description` text CHARACTER SET utf8,
  `rule_name` varchar(64) CHARACTER SET utf8 DEFAULT NULL,
  `data` text CHARACTER SET utf8,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `group_code` varchar(64) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `idx-auth_item-type` (`type`),
  KEY `fk_auth_item_group_code` (`group_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item`
--

INSERT INTO `auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`, `group_code`) VALUES
('/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//ajaxcrud', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//controller', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//crud', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//extension', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//form', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//model', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('//module', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/asset/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/asset/compress', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/asset/template', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/cache/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/cache/flush', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/cache/flush-all', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/cache/flush-schema', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/cache/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/db-explain', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/download-mail', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/toolbar', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/default/view', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/user/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/user/reset-identity', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/debug/user/set-identity', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/fixture/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/fixture/load', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/fixture/unload', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/action', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/diff', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/preview', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/gii/default/view', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/hello/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/hello/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/help/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/help/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/help/list', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/help/list-action-options', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/help/usage', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/message/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/message/config', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/message/config-template', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/message/extract', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/create', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/down', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/fresh', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/history', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/mark', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/new', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/redo', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/to', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/migrate/up', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/serve/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/serve/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/*', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/auth/change-own-password', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user-permission/set', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user-permission/set-roles', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/bulk-activate', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/bulk-deactivate', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/bulk-delete', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/change-password', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/create', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/delete', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/grid-page-size', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/index', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/update', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('/user-management/user/view', 3, NULL, NULL, NULL, 1695691644, 1695691644, NULL),
('Admin', 1, 'Admin', NULL, NULL, 1695691644, 1695691644, NULL),
('assignRolesToUsers', 2, 'Assign roles to users', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('bindUserToIp', 2, 'Bind user to IP', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('changeOwnPassword', 2, 'Change own password', NULL, NULL, 1695691644, 1695691644, 'userCommonPermissions'),
('changeUserPassword', 2, 'Change user password', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('commonPermission', 2, 'Common permission', NULL, NULL, 1695691643, 1695691643, NULL),
('createUsers', 2, 'Create users', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('deleteUsers', 2, 'Delete users', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('editUserEmail', 2, 'Edit user email', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('editUsers', 2, 'Edit users', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('viewRegistrationIp', 2, 'View registration IP', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('viewUserEmail', 2, 'View user email', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('viewUserRoles', 2, 'View user roles', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('viewUsers', 2, 'View users', NULL, NULL, 1695691644, 1695691644, 'userManagement'),
('viewVisitLog', 2, 'View visit log', NULL, NULL, 1695691644, 1695691644, 'userManagement');

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_child`
--

DROP TABLE IF EXISTS `auth_item_child`;
CREATE TABLE IF NOT EXISTS `auth_item_child` (
  `parent` varchar(64) CHARACTER SET utf8 NOT NULL,
  `child` varchar(64) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item_child`
--

INSERT INTO `auth_item_child` (`parent`, `child`) VALUES
('changeOwnPassword', '/user-management/auth/change-own-password'),
('assignRolesToUsers', '/user-management/user-permission/set'),
('assignRolesToUsers', '/user-management/user-permission/set-roles'),
('editUsers', '/user-management/user/bulk-activate'),
('editUsers', '/user-management/user/bulk-deactivate'),
('deleteUsers', '/user-management/user/bulk-delete'),
('changeUserPassword', '/user-management/user/change-password'),
('createUsers', '/user-management/user/create'),
('deleteUsers', '/user-management/user/delete'),
('viewUsers', '/user-management/user/grid-page-size'),
('viewUsers', '/user-management/user/index'),
('editUsers', '/user-management/user/update'),
('viewUsers', '/user-management/user/view'),
('Admin', 'assignRolesToUsers'),
('Admin', 'changeOwnPassword'),
('Admin', 'changeUserPassword'),
('Admin', 'createUsers'),
('Admin', 'deleteUsers'),
('Admin', 'editUsers'),
('editUserEmail', 'viewUserEmail'),
('assignRolesToUsers', 'viewUserRoles'),
('Admin', 'viewUsers'),
('assignRolesToUsers', 'viewUsers'),
('changeUserPassword', 'viewUsers'),
('createUsers', 'viewUsers'),
('deleteUsers', 'viewUsers'),
('editUsers', 'viewUsers');

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_group`
--

DROP TABLE IF EXISTS `auth_item_group`;
CREATE TABLE IF NOT EXISTS `auth_item_group` (
  `code` varchar(64) CHARACTER SET utf8 NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item_group`
--

INSERT INTO `auth_item_group` (`code`, `name`, `created_at`, `updated_at`) VALUES
('userCommonPermissions', 'User common permission', 1695691644, 1695691644),
('userManagement', 'User management', 1695691644, 1695691644);

-- --------------------------------------------------------

--
-- Table structure for table `auth_rule`
--

DROP TABLE IF EXISTS `auth_rule`;
CREATE TABLE IF NOT EXISTS `auth_rule` (
  `name` varchar(64) CHARACTER SET utf8 NOT NULL,
  `data` text CHARACTER SET utf8,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_cay_nhom`
--

DROP TABLE IF EXISTS `cua_cay_nhom`;
CREATE TABLE IF NOT EXISTS `cua_cay_nhom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_he_nhom` int(11) NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ten_cay_nhom` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `so_luong` int(11) DEFAULT NULL,
  `don_gia` double DEFAULT NULL,
  `khoi_luong` float DEFAULT NULL,
  `chieu_dai` float DEFAULT NULL,
  `for_cua_so` tinyint(1) DEFAULT NULL,
  `for_cua_di` tinyint(1) DEFAULT NULL,
  `min_allow_cut` float DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_he_nhom` (`id_he_nhom`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_cay_nhom`
--

INSERT INTO `cua_cay_nhom` (`id`, `id_he_nhom`, `code`, `ten_cay_nhom`, `so_luong`, `don_gia`, `khoi_luong`, `chieu_dai`, `for_cua_so`, `for_cua_di`, `min_allow_cut`, `date_created`, `user_created`) VALUES
(1, 3, 'PE450520', 'Khung bao cửa đi mở quay', 0, 0, 0, 5800, 0, 0, 0, '2023-10-04 10:06:45', 1),
(2, 3, 'PE452320', 'Cánh cửa đi mở quay ngoài', 0, 0, 0, NULL, 0, 0, 0, '2023-10-04 10:06:45', 1),
(3, 3, 'PE452420', 'Cánh cửa đi ngang dưới (bản to)', 0, 0, 0, NULL, 0, 0, 0, '2023-10-04 10:06:45', 1),
(4, 3, 'GE020212', 'Nẹp cánh', 0, 0, 0, NULL, 0, 0, 0, '2023-10-04 10:06:45', 1),
(5, 3, 'GE021312', 'Nẹp gài chân', 0, 0, 0, NULL, 0, 0, 0, '2023-10-04 10:06:45', 1),
(6, 3, 'PE450313', 'Đố động cửa đi mở quay', 0, 0, 0, NULL, 0, 0, 0, '2023-10-04 10:06:45', 1),
(7, 4, 'C3300', 'Nẹp nối khung', 0, 0, 0, 0, 0, 0, 0, '2023-11-09 08:06:15', 1),
(8, 4, 'C3328', 'Khung bao cửa đi mở quay', 0, 0, 0, 0, 0, 0, 0, '2023-11-09 08:06:15', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_don_vi_tinh`
--

DROP TABLE IF EXISTS `cua_don_vi_tinh`;
CREATE TABLE IF NOT EXISTS `cua_don_vi_tinh` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_dvt` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_don_vi_tinh`
--

INSERT INTO `cua_don_vi_tinh` (`id`, `code`, `ten_dvt`, `date_created`, `user_created`) VALUES
(1, '11', 'Chưa phân loại', NULL, NULL),
(2, '', 'Tạ', NULL, NULL),
(3, '', 'Yến', NULL, NULL),
(4, '', 'Kilogram', NULL, NULL),
(5, '', 'gram', NULL, NULL),
(6, '', 'Miligram', NULL, NULL),
(7, '', 'Cái', NULL, NULL),
(8, '', 'Hộp', NULL, NULL),
(9, '', 'Cái', NULL, NULL),
(10, '', 'Cái', NULL, NULL),
(11, '', 'Cái', NULL, NULL),
(12, '', 'test', NULL, NULL),
(13, NULL, 'avbb', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cua_du_an`
--

DROP TABLE IF EXISTS `cua_du_an`;
CREATE TABLE IF NOT EXISTS `cua_du_an` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_du_an` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ten_khach_hang` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dia_chi` text COLLATE utf8_unicode_ci,
  `so_dien_thoai` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trang_thai` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ngay_tao_du_an` date DEFAULT NULL,
  `ngay_bat_dau_thuc_hien` date DEFAULT NULL,
  `ngay_hoan_thanh_du_an` date DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `code_mau_thiet_ke` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_du_an`
--

INSERT INTO `cua_du_an` (`id`, `code`, `ten_du_an`, `ten_khach_hang`, `dia_chi`, `so_dien_thoai`, `email`, `trang_thai`, `ngay_tao_du_an`, `ngay_bat_dau_thuc_hien`, `ngay_hoan_thanh_du_an`, `ghi_chu`, `code_mau_thiet_ke`, `date_created`, `user_created`) VALUES
(1, NULL, 'Dự án 1', 'Nguyễn Văn A', '', '', '', 'KHOI_TAO', NULL, NULL, NULL, 'sss', 'VER.230928', '2023-09-27 15:25:41', 1),
(2, NULL, 'Dự án 2', '', '', '', '', 'KHOI_TAO', NULL, NULL, NULL, '', 'VER.230928', '2023-10-02 10:17:44', 1),
(3, '20E5D', 'Dự án 3', 'Nguyễn Văn A', 'ấp Dừa Đỏ 2, xã Nhị Long Phú, huyện Càng Long, tỉnh Trà Vinh', '0374711908', 'nguyenvana@gmail.com', 'KHOI_TAO', NULL, NULL, NULL, '', 'VER.230928', '2023-10-02 10:33:13', 1),
(4, '6n1Ud', 'Dự án 4', '', '', '', '', 'KHOI_TAO', NULL, NULL, NULL, '', 'VER.230928', '2023-10-03 09:33:39', 1),
(5, '23f4R', 'Dự án 5', '', '', '', '', 'KHOI_TAO', NULL, NULL, NULL, '', 'VER.230928', '2023-10-04 08:02:08', 1),
(6, '2MX12', 'Dự án 9/11/2023', 'Nguyễn Văn Tý An', 'Càng Long, Trà Vinh', '0374711908', 'nguyenvana@gmail.com', 'KHOI_TAO', NULL, NULL, NULL, '<p>sss kk</p>', 'VER.230928', '2023-11-09 07:57:46', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_du_an_chi_tiet`
--

DROP TABLE IF EXISTS `cua_du_an_chi_tiet`;
CREATE TABLE IF NOT EXISTS `cua_du_an_chi_tiet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_du_an` int(11) NOT NULL,
  `id_mau_cua` int(11) NOT NULL,
  `so_luong` int(11) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_du_an` (`id_du_an`),
  KEY `id_mau_cua` (`id_mau_cua`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_du_an_chi_tiet`
--

INSERT INTO `cua_du_an_chi_tiet` (`id`, `id_du_an`, `id_mau_cua`, `so_luong`, `date_created`, `user_created`) VALUES
(1, 1, 3, 1, '2023-09-29 15:26:40', 1),
(2, 1, 4, 1, '2023-09-29 16:49:21', 1),
(3, 1, 5, 1, '2023-10-01 23:09:20', 1),
(4, 1, 6, 1, '2023-10-02 05:34:05', 1),
(5, 1, 7, 1, '2023-10-02 05:53:36', 1),
(6, 3, 8, 1, '2023-10-02 11:00:33', 1),
(7, 4, 9, 1, '2023-10-03 10:01:45', 1),
(8, 4, 10, 1, '2023-10-03 10:05:59', 1),
(9, 4, 11, 1, '2023-10-03 10:06:54', 1),
(10, 4, 12, 1, '2023-10-03 10:07:27', 1),
(11, 4, 13, 1, '2023-10-03 10:08:39', 1),
(12, 5, 14, 1, '2023-10-04 10:06:45', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_he_nhom`
--

DROP TABLE IF EXISTS `cua_he_nhom`;
CREATE TABLE IF NOT EXISTS `cua_he_nhom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_he_nhom` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_he_nhom`
--

INSERT INTO `cua_he_nhom` (`id`, `code`, `ten_he_nhom`, `ghi_chu`, `date_created`, `user_created`) VALUES
(1, 'xf55', 'Nhôm Xingfa hệ 55', '', '2023-09-26 09:36:12', 1),
(2, 'xf65', 'Nhôm Xingfa hệ 65', '', '2023-09-26 09:40:02', 1),
(3, '6uQoU', 'PMI hệ 45', NULL, '2023-09-29 15:11:45', 1),
(4, '4k0Eb', 'Xingfa Quảng Đông hệ 55', NULL, '2023-10-03 10:07:27', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_he_vach`
--

DROP TABLE IF EXISTS `cua_he_vach`;
CREATE TABLE IF NOT EXISTS `cua_he_vach` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_loai_vach` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_hinh_anh`
--

DROP TABLE IF EXISTS `cua_hinh_anh`;
CREATE TABLE IF NOT EXISTS `cua_hinh_anh` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loai` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `id_tham_chieu` int(11) NOT NULL,
  `ten_hien_thi` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `duong_dan` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_file_luu` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `img_extension` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `img_size` float DEFAULT NULL,
  `img_wh` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `thoi_gian_tao` datetime DEFAULT NULL,
  `nguoi_tao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_hinh_anh`
--

INSERT INTO `cua_hinh_anh` (`id`, `loai`, `id_tham_chieu`, `ten_hien_thi`, `duong_dan`, `ten_file_luu`, `img_extension`, `img_size`, `img_wh`, `ghi_chu`, `thoi_gian_tao`, `nguoi_tao`) VALUES
(5, 'mau-cua', 1, '', '29d9900e300d60bd8745e563ffd19d0b.jpg', '927-536x354[1].jpg', 'jpg', 25121, NULL, '', '2023-09-27 10:34:24', 1),
(8, 'mau-cua', 1, '', 'addbaf372d13766987512e85aced810c.jpg', '137-536x354[1].jpg', 'jpg', 13665, NULL, '', '2023-09-27 10:37:46', 1),
(9, 'mau-cua', 4, NULL, 'addbaf372d13766987512e85aced810c.jpg', 'addbaf372d13766987512e85aced810c.jpg', 'jpg', NULL, NULL, NULL, '2023-09-29 16:49:21', 1),
(10, 'mau-cua', 5, NULL, '230920-S1Dq.jpeg', '230920-S1Dq.jpeg', 'jpeg', NULL, NULL, NULL, '2023-10-01 23:09:20', 1),
(11, 'mau-cua', 6, NULL, '053405-ZQYE.jpeg', '053405-ZQYE.jpeg', 'jpeg', NULL, NULL, NULL, '2023-10-02 05:34:05', 1),
(12, 'mau-cua', 7, NULL, '055336-tJEp.jpeg', '055336-tJEp.jpeg', 'jpeg', NULL, NULL, NULL, '2023-10-02 05:53:36', 1),
(13, 'mau-cua', 8, NULL, '110033-seH1.jpeg', '110033-seH1.jpeg', 'jpeg', NULL, NULL, NULL, '2023-10-02 11:00:33', 1),
(14, 'mau-cua', 9, NULL, '100145-8B0D.jpeg', '100145-8B0D.jpeg', 'jpeg', NULL, NULL, NULL, '2023-10-03 10:01:45', 1),
(15, 'mau-cua', 10, NULL, '100559-BQFH.jpeg', '100559-BQFH.jpeg', 'jpeg', NULL, NULL, NULL, '2023-10-03 10:05:59', 1),
(16, 'mau-cua', 11, NULL, '100654-jpTu.jpeg', '100654-jpTu.jpeg', 'jpeg', NULL, NULL, NULL, '2023-10-03 10:06:54', 1),
(17, 'mau-cua', 12, 'xxyy', '100727-Cl6K.jpeg', '100727-Cl6K.jpeg', 'jpeg', NULL, NULL, '', '2023-10-03 10:07:27', 1),
(18, 'mau-cua', 13, NULL, '100839-CJmT.jpeg', '100839-CJmT.jpeg', 'jpeg', NULL, NULL, NULL, '2023-10-03 10:08:39', 1),
(21, 'mau-cua', 12, 'x', 'a9fb523534204f9f4f185212f1e217db.jpg', 'bbee919bbd626f3c3673.jpg', 'jpg', 365532, NULL, 'y', '2023-10-03 14:26:31', 1),
(22, 'mau-cua', 14, NULL, '100645-yZKo.jpeg', '100645-yZKo.jpeg', 'jpeg', NULL, NULL, NULL, '2023-10-04 10:06:45', 1),
(23, 'mau-cua', 15, NULL, '081013-lrJH.jpeg', '081013-lrJH.jpeg', 'jpeg', NULL, NULL, NULL, '2023-11-09 08:10:13', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_kho_nhom`
--

DROP TABLE IF EXISTS `cua_kho_nhom`;
CREATE TABLE IF NOT EXISTS `cua_kho_nhom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_cay_nhom` int(11) NOT NULL,
  `chieu_dai` float NOT NULL,
  `so_luong` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_cay_nhom` (`id_cay_nhom`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_kho_nhom`
--

INSERT INTO `cua_kho_nhom` (`id`, `id_cay_nhom`, `chieu_dai`, `so_luong`, `date_created`, `user_created`) VALUES
(1, 6, 1000, 12, '2023-10-17 09:42:16', 1),
(2, 6, 1200, 5, '2023-10-17 09:42:41', 1),
(4, 1, 1200, 5, '2023-10-18 07:38:00', 1),
(5, 1, 1400, 5, '2023-10-19 10:42:51', 1),
(6, 3, 523, 2, '2023-10-19 10:43:42', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_kho_nhom_lich_su`
--

DROP TABLE IF EXISTS `cua_kho_nhom_lich_su`;
CREATE TABLE IF NOT EXISTS `cua_kho_nhom_lich_su` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_kho_nhom` int(11) NOT NULL,
  `so_luong` int(11) NOT NULL,
  `noi_dung` text COLLATE utf8_unicode_ci NOT NULL,
  `id_mau_cua` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_kho_nhom` (`id_kho_nhom`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_kho_nhom_lich_su`
--

INSERT INTO `cua_kho_nhom_lich_su` (`id`, `id_kho_nhom`, `so_luong`, `noi_dung`, `id_mau_cua`, `date_created`, `user_created`) VALUES
(1, 2, 2, '<p>csxcsxc</p>', NULL, '2023-10-17 09:53:30', 1),
(3, 2, -3, '<p>cập nhật thực tế kho nh&ocirc;m</p>', NULL, '2023-10-17 09:55:08', 1),
(4, 2, -3, 'ss', NULL, '2023-10-17 10:07:36', 1),
(5, 4, 5, '<p>th&ecirc;m v&agrave;o từ kho phế liệu cũ</p>', NULL, '2023-10-18 07:38:00', 1),
(6, 5, 5, '<p>fdsafasf</p>', NULL, '2023-10-19 10:42:51', 1),
(7, 6, 2, '<p>fdsafsaf</p>', NULL, '2023-10-19 10:43:42', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_kho_vat_tu`
--

DROP TABLE IF EXISTS `cua_kho_vat_tu`;
CREATE TABLE IF NOT EXISTS `cua_kho_vat_tu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_vat_tu` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `id_nhom_vat_tu` int(11) DEFAULT NULL,
  `la_phu_kien` tinyint(1) DEFAULT NULL,
  `so_luong` float DEFAULT NULL,
  `dvt` int(11) NOT NULL,
  `don_gia` double DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_nhom_vat_tu` (`id_nhom_vat_tu`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_kho_vat_tu`
--

INSERT INTO `cua_kho_vat_tu` (`id`, `code`, `ten_vat_tu`, `id_nhom_vat_tu`, `la_phu_kien`, `so_luong`, `dvt`, `don_gia`, `ghi_chu`, `date_created`, `user_created`) VALUES
(1, '4C49q', 'Vật tư 1', 0, 1, 5, 1, 50000, NULL, '2023-12-06 07:49:22', 1),
(4, '7kqGh', 'Ổ khóa AA', 0, 0, 50, 7, 50000, NULL, '2023-12-06 15:42:28', 1),
(5, '9i5kO', 'Ổ khóa BB', 0, 0, NULL, 13, NULL, NULL, '2023-12-06 15:42:28', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_kho_vat_tu_lich_su`
--

DROP TABLE IF EXISTS `cua_kho_vat_tu_lich_su`;
CREATE TABLE IF NOT EXISTS `cua_kho_vat_tu_lich_su` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_kho_vat_tu` int(11) NOT NULL,
  `id_nha_cung_cap` int(11) DEFAULT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `so_luong` float DEFAULT NULL,
  `id_mau_cua` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_kho_vat_tu` (`id_kho_vat_tu`),
  KEY `id_nha_cung_cap` (`id_nha_cung_cap`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_kho_vat_tu_nha_cung_cap`
--

DROP TABLE IF EXISTS `cua_kho_vat_tu_nha_cung_cap`;
CREATE TABLE IF NOT EXISTS `cua_kho_vat_tu_nha_cung_cap` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_nha_cung_cap` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dia_chi` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_kho_vat_tu_nha_cung_cap`
--

INSERT INTO `cua_kho_vat_tu_nha_cung_cap` (`id`, `code`, `ten_nha_cung_cap`, `dia_chi`, `date_created`, `user_created`) VALUES
(1, 'abcd', 'Nhà cung cấp 1', 'Thành phố Trà Vinh, tỉnh Trà Vinh', NULL, NULL),
(2, 'NCC01', 'Công ty TNHH ABCD', 'thành phố Trà Vinh\r\n', '2023-12-05 08:20:45', 1),
(3, 'NCC02', 'Công ty NVT', 'Trà VINH', '2023-12-05 08:41:01', 1),
(4, 'NCC03', 'Công ty DEF', 'Vĩnh Long', '2023-12-05 08:41:25', 1),
(5, 'NCC04', 'Nhà cung cấp 04', 'Long An', '2023-12-05 08:41:48', 1),
(6, 'fsadfas', 'fdsaf', 'fasdf', '2023-12-05 08:44:55', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_loai_cua`
--

DROP TABLE IF EXISTS `cua_loai_cua`;
CREATE TABLE IF NOT EXISTS `cua_loai_cua` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_loai_cua` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ghi_chu` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_loai_cua`
--

INSERT INTO `cua_loai_cua` (`id`, `code`, `ten_loai_cua`, `ghi_chu`, `date_created`, `user_created`) VALUES
(1, 'cua1canh', 'Cửa đi một cánh', '', '2023-09-26 08:39:38', 1),
(2, 'cua2canh', 'Cửa đi hai cánh', 'ghi chú', '2023-09-26 09:40:46', 1),
(3, '4cQDZ', 'CĐ 2 CÁNH', NULL, '2023-09-29 15:12:32', 1),
(4, '8BNY3', 'CỬA ĐI 2 CÁNH FIX RỜI', NULL, '2023-10-03 10:07:27', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua`
--

DROP TABLE IF EXISTS `cua_mau_cua`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_cua` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `kich_thuoc` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ngang` float DEFAULT NULL,
  `cao` float DEFAULT NULL,
  `id_he_nhom` int(11) DEFAULT NULL,
  `id_loai_cua` int(11) NOT NULL,
  `id_parent` int(11) DEFAULT NULL,
  `id_du_an` int(11) NOT NULL,
  `so_luong` int(11) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `id_he_nhom` (`id_he_nhom`),
  KEY `id_parent` (`id_parent`),
  KEY `id_loai_cua` (`id_loai_cua`),
  KEY `id_du_an` (`id_du_an`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_mau_cua`
--

INSERT INTO `cua_mau_cua` (`id`, `code`, `ten_cua`, `kich_thuoc`, `ngang`, `cao`, `id_he_nhom`, `id_loai_cua`, `id_parent`, `id_du_an`, `so_luong`, `status`, `date_created`, `user_created`) VALUES
(1, 'xx11', 'cua di 2 canh 1', '1400x700', NULL, NULL, 1, 1, 0, 5, 1, NULL, NULL, NULL),
(3, 'abc', 'CĐ 2 CÁNH', '1400x2100 (mm)', NULL, NULL, 3, 3, 0, 5, 1, NULL, '2023-09-29 15:26:40', 1),
(4, 'abc1', 'CĐ 2 CÁNH', '1400x2100 (mm)', NULL, NULL, 3, 3, 0, 5, 1, '', '2023-09-29 16:49:21', 1),
(5, 'abc2', 'CĐ 2 CÁNH', '1400x2100 (mm)', NULL, NULL, 3, 3, 0, 5, 1, NULL, '2023-10-01 23:09:20', 1),
(6, '7iZNW', 'CĐ 2 CÁNH', '1400x2100 (mm)', NULL, NULL, 3, 3, 0, 5, 1, NULL, '2023-10-02 05:34:05', 1),
(7, '79CqH', 'CĐ 2 CÁNH', '1400x2100 (mm)', NULL, NULL, 3, 3, 0, 5, 1, NULL, '2023-10-02 05:53:36', 1),
(8, '2vIVg', 'CĐ 2 CÁNH', '1400x2100 (mm)', NULL, NULL, 3, 3, 0, 5, 1, NULL, '2023-10-02 11:00:33', 1),
(9, '8ajqR', 'CĐ 2 CÁNH', '1400x2100 (mm)', NULL, NULL, 3, 3, 0, 5, 1, NULL, '2023-10-03 10:01:45', 1),
(10, '8kcDv', 'CĐ 2 CÁNH', '1400x2100 (mm)', NULL, NULL, 3, 3, 0, 5, 1, NULL, '2023-10-03 10:05:59', 1),
(11, '2hBtX', 'CĐ 2 CÁNH', '1400x2100 (mm)', NULL, NULL, 3, 3, 0, 5, 1, NULL, '2023-10-03 10:06:54', 1),
(12, '8aiqA', 'CỬA ĐI 2 CÁNH FIX RỜI', '1400x2700 (mm)', NULL, NULL, 4, 4, 0, 5, 1, NULL, '2023-10-03 10:07:27', 1),
(13, '17sJF', 'CĐ 2 CÁNH', '1400x2100 (mm)', NULL, NULL, 3, 3, 0, 5, 1, NULL, '2023-10-03 10:08:39', 1),
(14, '39M7c', 'CĐ 2 CÁNH', '1400x2100 (mm)', NULL, NULL, 3, 3, 0, 4, 1, 'KHOI_TAO', '2023-10-04 10:06:45', 1),
(15, '6HSFb', 'CỬA ĐI 2 CÁNH FIX RỜI', '1400x2700 (mm)', NULL, NULL, 4, 4, 0, 6, 1, 'KHOI_TAO', '2023-11-09 08:10:13', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua_nhom`
--

DROP TABLE IF EXISTS `cua_mau_cua_nhom`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua_nhom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mau_cua` int(11) NOT NULL,
  `id_cay_nhom` int(11) NOT NULL,
  `chieu_dai` float DEFAULT NULL,
  `so_luong` int(11) DEFAULT NULL,
  `kieu_cat` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `khoi_luong` float DEFAULT NULL,
  `don_gia` double DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_mau_cua` (`id_mau_cua`),
  KEY `id_cay_nhom` (`id_cay_nhom`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_mau_cua_nhom`
--

INSERT INTO `cua_mau_cua_nhom` (`id`, `id_mau_cua`, `id_cay_nhom`, `chieu_dai`, `so_luong`, `kieu_cat`, `khoi_luong`, `don_gia`, `date_created`, `user_created`) VALUES
(1, 14, 1, 1400, 1, '/===\\', 1.69, 0, '2023-10-04 10:06:45', 1),
(2, 14, 1, 2100, 2, '|===\\', 5.08, 0, '2023-10-04 10:06:45', 1),
(3, 14, 2, 655, 2, '/===\\', 2.01, 0, '2023-10-04 10:06:45', 1),
(4, 14, 2, 2049, 4, '|===\\', 12.56, 0, '2023-10-04 10:06:45', 1),
(5, 14, 3, 523, 2, '|===|', 2.38, 0, '2023-10-04 10:06:45', 1),
(6, 14, 4, 1857, 4, '/===\\', 2.08, 0, '2023-10-04 10:06:45', 1),
(7, 14, 4, 513, 2, '/===\\', 0.29, 0, '2023-10-04 10:06:45', 1),
(8, 14, 5, 513, 2, '/===\\', 0.21, 0, '2023-10-04 10:06:45', 1),
(9, 14, 6, 2013, 1, '|===|', 1.84, 0, '2023-10-04 10:06:45', 1),
(10, 15, 7, 1400, 1, '|===|', 0.49, 0, '2023-11-09 08:10:13', 1),
(11, 15, 8, 2000, 1, '/===\\', 1.76, 0, '2023-11-09 08:10:13', 1),
(12, 15, 8, 1000, 2, '/===\\', 1.76, 0, '2023-11-09 08:10:13', 1),
(13, 15, 8, 500, 1, '/===\\', 1.76, 0, '2023-11-09 08:10:13', 1),
(14, 15, 8, 2500, 1, '/===\\', 1.76, 0, '2023-11-09 08:10:13', 1),
(15, 15, 8, 5800, 1, '/===\\', 1.76, 0, '2023-11-09 08:10:13', 1),
(16, 15, 8, 5000, 1, '/===\\', 1.76, 0, '2023-11-09 08:10:13', 1),
(17, 15, 8, 1700, 1, '/===\\', 1.76, 0, '2023-11-09 08:10:13', 1),
(18, 15, 8, 300, 10, '/===\\', 1.76, 0, '2023-11-09 08:10:13', 1),
(19, 15, 7, 200, 5, '|===|', 0.49, 0, '2023-11-09 08:10:13', 1),
(20, 15, 7, 1700, 2, '|===|', 0.49, 0, '2023-11-09 08:10:13', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua_vach`
--

DROP TABLE IF EXISTS `cua_mau_cua_vach`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua_vach` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mau_cua` int(11) NOT NULL,
  `id_vach` int(11) NOT NULL,
  `rong` float DEFAULT NULL,
  `cao` float DEFAULT NULL,
  `so_luong` float DEFAULT NULL,
  `dien_tich` float DEFAULT NULL,
  `don_gia` double NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) NOT NULL,
  `so_luong_xuat` float DEFAULT NULL,
  `ghi_chu_xuat` text COLLATE utf8_unicode_ci,
  `so_luong_nhap_lai` float DEFAULT NULL,
  `ghi_chu_nhap_lai` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `id_mau_cua` (`id_mau_cua`),
  KEY `id_vach` (`id_vach`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_mau_cua_vat_tu`
--

DROP TABLE IF EXISTS `cua_mau_cua_vat_tu`;
CREATE TABLE IF NOT EXISTS `cua_mau_cua_vat_tu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mau_cua` int(11) NOT NULL,
  `id_kho_vat_tu` int(11) NOT NULL,
  `so_luong` float NOT NULL,
  `dvt` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `don_gia` double DEFAULT NULL,
  `la_phu_kien` tinyint(4) DEFAULT NULL,
  `so_luong_xuat` float DEFAULT NULL,
  `ghi_chu_xuat` text COLLATE utf8_unicode_ci,
  `so_luong_nhap_lai` float DEFAULT NULL,
  `ghi_chu_nhap_lai` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_mau_cua` (`id_mau_cua`),
  KEY `id_kho_vat_tu` (`id_kho_vat_tu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cua_toi_uu`
--

DROP TABLE IF EXISTS `cua_toi_uu`;
CREATE TABLE IF NOT EXISTS `cua_toi_uu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mau_cua` int(11) NOT NULL,
  `id_mau_cua_nhom` int(11) NOT NULL,
  `id_ton_kho_nhom` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_mau_cua` (`id_mau_cua`),
  KEY `id_mau_cua_nhom` (`id_mau_cua_nhom`),
  KEY `id_ton_kho_nhom` (`id_ton_kho_nhom`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cua_toi_uu`
--

INSERT INTO `cua_toi_uu` (`id`, `id_mau_cua`, `id_mau_cua_nhom`, `id_ton_kho_nhom`, `date_created`, `user_created`) VALUES
(28, 15, 10, 1, '2023-12-01 15:00:16', 1),
(29, 15, 11, 1, '2023-12-01 15:00:16', 1),
(30, 15, 12, 1, '2023-12-01 15:00:16', 1),
(31, 15, 12, 1, '2023-12-01 15:00:16', 1),
(32, 15, 13, 1, '2023-12-01 15:00:16', 1),
(33, 15, 14, 1, '2023-12-01 15:00:16', 1),
(34, 15, 15, 1, '2023-12-01 15:00:16', 1),
(35, 15, 16, 1, '2023-12-01 15:00:16', 1),
(36, 15, 17, 1, '2023-12-01 15:00:16', 1),
(37, 15, 18, 1, '2023-12-01 15:00:16', 1),
(38, 15, 18, 1, '2023-12-01 15:00:16', 1),
(39, 15, 18, 1, '2023-12-01 15:00:16', 1),
(40, 15, 18, 1, '2023-12-01 15:00:16', 1),
(41, 15, 18, 1, '2023-12-01 15:00:16', 1),
(42, 15, 18, 1, '2023-12-01 15:00:16', 1),
(43, 15, 18, 1, '2023-12-01 15:00:16', 1),
(44, 15, 18, 1, '2023-12-01 15:00:16', 1),
(45, 15, 18, 1, '2023-12-01 15:00:16', 1),
(46, 15, 18, 1, '2023-12-01 15:00:16', 1),
(47, 15, 19, 1, '2023-12-01 15:00:16', 1),
(48, 15, 19, 1, '2023-12-01 15:00:16', 1),
(49, 15, 19, 1, '2023-12-01 15:00:16', 1),
(50, 15, 19, 1, '2023-12-01 15:00:16', 1),
(51, 15, 19, 1, '2023-12-01 15:00:16', 1),
(52, 15, 20, 1, '2023-12-01 15:00:16', 1),
(53, 15, 20, 1, '2023-12-01 15:00:16', 1);

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

DROP TABLE IF EXISTS `migration`;
CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1695691639),
('m140608_173539_create_user_table', 1695691642),
('m140611_133903_init_rbac', 1695691642),
('m140808_073114_create_auth_item_group_table', 1695691642),
('m140809_072112_insert_superadmin_to_user', 1695691643),
('m140809_073114_insert_common_permisison_to_auth_item', 1695691643),
('m141023_141535_create_user_visit_log', 1695691643),
('m141116_115804_add_bind_to_ip_and_registration_ip_to_user', 1695691643),
('m141121_194858_split_browser_and_os_column', 1695691643),
('m141201_220516_add_email_and_email_confirmed_to_user', 1695691644),
('m141207_001649_create_basic_user_permissions', 1695691644);

-- --------------------------------------------------------

--
-- Table structure for table `technologies`
--

DROP TABLE IF EXISTS `technologies`;
CREATE TABLE IF NOT EXISTS `technologies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `summary` text COLLATE utf8_unicode_ci,
  `datetime_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `template`
--

DROP TABLE IF EXISTS `template`;
CREATE TABLE IF NOT EXISTS `template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `summary` text COLLATE utf8_unicode_ci,
  `user_created` int(11) DEFAULT NULL,
  `datetime_created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `template`
--

INSERT INTO `template` (`id`, `code`, `name`, `summary`, `user_created`, `datetime_created`) VALUES
(6, '67817125f52ebc64d623ca038038bc27', 'Template 1', '', NULL, '2023-09-11 15:42:47');

-- --------------------------------------------------------

--
-- Table structure for table `template_blocks`
--

DROP TABLE IF EXISTS `template_blocks`;
CREATE TABLE IF NOT EXISTS `template_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_template` int(11) NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `user_created` int(11) DEFAULT NULL,
  `datetime_created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_template` (`id_template`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `template_blocks`
--

INSERT INTO `template_blocks` (`id`, `id_template`, `code`, `name`, `content`, `user_created`, `datetime_created`) VALUES
(2, 6, 'd1942f189c31983ed21a8aa7c9589fa9', 'Block info', 'Công ty TNHH An Thịnh', NULL, '2023-09-11 15:48:05');

-- --------------------------------------------------------

--
-- Table structure for table `template_pages`
--

DROP TABLE IF EXISTS `template_pages`;
CREATE TABLE IF NOT EXISTS `template_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_template` int(11) NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `is_dynamic` tinyint(1) NOT NULL,
  `user_created` int(11) DEFAULT NULL,
  `datetime_created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_template` (`id_template`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `template_pages`
--

INSERT INTO `template_pages` (`id`, `id_template`, `code`, `name`, `file`, `is_dynamic`, `user_created`, `datetime_created`) VALUES
(7, 6, 'd874eb9923d3b481764a924017ce29ff', 'Trang chủ', 'index.php', 0, NULL, '2023-09-11 15:46:18'),
(8, 6, 'f6e8a5b10c8d2c9f24cd31a23ce3ad65', 'Giới thiệu', 'about.php', 0, NULL, '2023-09-11 15:46:32');

-- --------------------------------------------------------

--
-- Table structure for table `template_technologies`
--

DROP TABLE IF EXISTS `template_technologies`;
CREATE TABLE IF NOT EXISTS `template_technologies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_template` int(11) NOT NULL,
  `id_technologie` int(11) NOT NULL,
  `datetime_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_template` (`id_template`),
  KEY `id_technologie` (`id_technologie`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `template_varibles`
--

DROP TABLE IF EXISTS `template_varibles`;
CREATE TABLE IF NOT EXISTS `template_varibles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_template` int(11) NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `varible_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_created` int(11) DEFAULT NULL,
  `datetime_created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_template` (`id_template`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `template_varibles`
--

INSERT INTO `template_varibles` (`id`, `id_template`, `code`, `name`, `varible_type`, `value`, `user_created`, `datetime_created`) VALUES
(3, 6, 'e5a03b101c9278dee5b30f8de11887ef', 'var1', 'text', 'Nguyễn Văn Tý An', NULL, '2023-09-11 15:47:42'),
(4, 6, '59b147ddf73d528f3100ad37d99a6a1d', 'var2', 'int', '100', NULL, '2023-09-11 15:47:51');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8 NOT NULL,
  `auth_key` varchar(32) CHARACTER SET utf8 NOT NULL,
  `password_hash` varchar(255) CHARACTER SET utf8 NOT NULL,
  `confirmation_token` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `superadmin` smallint(6) DEFAULT '0',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `registration_ip` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
  `bind_to_ip` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(128) CHARACTER SET utf8 DEFAULT NULL,
  `email_confirmed` smallint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `confirmation_token`, `status`, `superadmin`, `created_at`, `updated_at`, `registration_ip`, `bind_to_ip`, `email`, `email_confirmed`) VALUES
(1, 'superadmin', 'MDvwUlYvBDOYlfwXEkNhRChWr2utQ3xU', '$2y$13$.82.TmKU5VxndDwYIY8KOeQFIn7WJ6tZinx6mz0MGdkqmpYC0wmHK', NULL, 1, 1, 1695691643, 1695691643, NULL, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_visit_log`
--

DROP TABLE IF EXISTS `user_visit_log`;
CREATE TABLE IF NOT EXISTS `user_visit_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` varchar(255) CHARACTER SET utf8 NOT NULL,
  `ip` varchar(15) CHARACTER SET utf8 NOT NULL,
  `language` char(2) CHARACTER SET utf8 NOT NULL,
  `user_agent` varchar(255) CHARACTER SET utf8 NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `visit_time` int(11) NOT NULL,
  `browser` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `os` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_visit_log`
--

INSERT INTO `user_visit_log` (`id`, `token`, `ip`, `language`, `user_agent`, `user_id`, `visit_time`, `browser`, `os`) VALUES
(1, '651233ac68058', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695691692, 'Chrome', 'Windows'),
(2, '651236d4e41f3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695692500, 'Chrome', 'Windows'),
(3, '6512462aa9eb3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695696426, 'Chrome', 'Windows'),
(4, '65137e1b21d83', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695776283, 'Chrome', 'Windows'),
(5, '65152884d18a2', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695885444, 'Chrome', 'Windows'),
(6, '65167bc86b56f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1695972296, 'Chrome', 'Windows'),
(7, '651fc82504a1f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1696581669, 'Chrome', 'Windows'),
(8, '65294c755aebb', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1697205365, 'Chrome', 'Windows'),
(9, '65295a386d589', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1697208888, 'Chrome', 'Windows'),
(10, '652d5011ee601', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1697468434, 'Chrome', 'Windows'),
(11, '652e4ad038376', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1697532624, 'Chrome', 'Windows'),
(12, '652e4b0664a5e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 1, 1697532678, 'Chrome', 'Windows'),
(13, '6535c66babd70', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1698023019, 'Chrome', 'Windows'),
(14, '653f6657106a4', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1698653783, 'Chrome', 'Windows'),
(15, '65449a2cbcaff', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1698994732, 'Chrome', 'Windows'),
(16, '65449a409b40e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1698994752, 'Chrome', 'Windows'),
(17, '654839f01d33e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1699232240, 'Chrome', 'Windows'),
(18, '65498b0e1a435', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1699318542, 'Chrome', 'Windows'),
(19, '654c30af3f6b2', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1699492015, 'Chrome', 'Windows'),
(20, '654d8251ec3db', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 1, 1699578449, 'Chrome', 'Windows'),
(21, '6552c5c3166bb', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1699923395, 'Chrome', 'Windows'),
(22, '65556baa09cc4', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1700096938, 'Chrome', 'Windows'),
(23, '6556ba7927cfa', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1700182649, 'Chrome', 'Windows'),
(24, '655ea55da9335', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1700701533, 'Chrome', 'Windows'),
(25, '655ff4cb95ae2', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1700787403, 'Chrome', 'Windows'),
(26, '6563f2c74ad32', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701049031, 'Chrome', 'Windows'),
(27, '65668958eaae0', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701218648, 'Chrome', 'Windows'),
(28, '656696bf09e09', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701222079, 'Chrome', 'Windows'),
(29, '656990dc9d085', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701417180, 'Chrome', 'Windows'),
(30, '656d21257611e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701650725, 'Chrome', 'Windows'),
(31, '656d774245afa', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701672770, 'Chrome', 'Windows'),
(32, '656e743392498', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701737523, 'Chrome', 'Windows'),
(33, '656ed00f1ba53', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701761039, 'Chrome', 'Windows'),
(34, '656fc4e0009c2', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1701823712, 'Chrome', 'Windows');

-- --------------------------------------------------------

--
-- Table structure for table `website`
--

DROP TABLE IF EXISTS `website`;
CREATE TABLE IF NOT EXISTS `website` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_template` int(11) NOT NULL,
  `user_created` int(11) DEFAULT NULL,
  `datetime_created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_template` (`id_template`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `website`
--

INSERT INTO `website` (`id`, `id_template`, `user_created`, `datetime_created`) VALUES
(13, 6, NULL, '2023-09-11 16:10:55'),
(14, 6, NULL, '2023-09-12 07:46:33'),
(15, 6, NULL, '2023-09-13 08:10:08');

-- --------------------------------------------------------

--
-- Table structure for table `website_blocks`
--

DROP TABLE IF EXISTS `website_blocks`;
CREATE TABLE IF NOT EXISTS `website_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_website` int(11) NOT NULL,
  `id_template_block` int(11) NOT NULL,
  `content` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `id_website` (`id_website`),
  KEY `id_template_block` (`id_template_block`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `website_blocks`
--

INSERT INTO `website_blocks` (`id`, `id_website`, `id_template_block`, `content`) VALUES
(3, 13, 2, '<p>Công ty TNHH An <b>Thịnh </b>nnnn</p><ul><li>fdsfsaf</li><li>gfdsgsdg</li><li>gdsgag</li></ul><p><img src=\"/uploads/images/8f53295a73878494e9bc8dd6c3c7104f.jpg\" style=\"width: 100%;\"><br></p><p>\r\n</p>'),
(4, 14, 2, 'Công ty TNHH An Thịnh'),
(5, 15, 2, 'Công ty TNHH An Thịnh');

-- --------------------------------------------------------

--
-- Table structure for table `website_pages`
--

DROP TABLE IF EXISTS `website_pages`;
CREATE TABLE IF NOT EXISTS `website_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_website` int(11) NOT NULL,
  `id_template_page` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_website` (`id_website`),
  KEY `id_templage_page` (`id_template_page`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `website_pages`
--

INSERT INTO `website_pages` (`id`, `id_website`, `id_template_page`) VALUES
(25, 13, 7),
(26, 13, 8),
(27, 14, 7),
(28, 14, 8),
(29, 15, 7),
(30, 15, 8);

-- --------------------------------------------------------

--
-- Table structure for table `website_varibles`
--

DROP TABLE IF EXISTS `website_varibles`;
CREATE TABLE IF NOT EXISTS `website_varibles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_website` int(11) NOT NULL,
  `id_template_varible` int(11) NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_website` (`id_website`),
  KEY `id_templage_varible` (`id_template_varible`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `website_varibles`
--

INSERT INTO `website_varibles` (`id`, `id_website`, `id_template_varible`, `value`) VALUES
(7, 13, 3, 'Nguyễn Văn Tý An 123'),
(8, 13, 4, '1012'),
(9, 14, 3, 'Nguyễn Văn Tý An'),
(10, 14, 4, '100'),
(11, 15, 3, 'Nguyễn Văn Tý An'),
(12, 15, 4, '100');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_assignment`
--
ALTER TABLE `auth_assignment`
  ADD CONSTRAINT `auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_assignment_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `auth_item`
--
ALTER TABLE `auth_item`
  ADD CONSTRAINT `auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_auth_item_group_code` FOREIGN KEY (`group_code`) REFERENCES `auth_item_group` (`code`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cua_cay_nhom`
--
ALTER TABLE `cua_cay_nhom`
  ADD CONSTRAINT `cua_cay_nhom_ibfk_1` FOREIGN KEY (`id_he_nhom`) REFERENCES `cua_he_nhom` (`id`);

--
-- Constraints for table `cua_du_an_chi_tiet`
--
ALTER TABLE `cua_du_an_chi_tiet`
  ADD CONSTRAINT `cua_du_an_chi_tiet_ibfk_1` FOREIGN KEY (`id_du_an`) REFERENCES `cua_du_an` (`id`),
  ADD CONSTRAINT `cua_du_an_chi_tiet_ibfk_2` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`);

--
-- Constraints for table `cua_kho_nhom`
--
ALTER TABLE `cua_kho_nhom`
  ADD CONSTRAINT `cua_kho_nhom_ibfk_1` FOREIGN KEY (`id_cay_nhom`) REFERENCES `cua_cay_nhom` (`id`);

--
-- Constraints for table `cua_kho_nhom_lich_su`
--
ALTER TABLE `cua_kho_nhom_lich_su`
  ADD CONSTRAINT `cua_kho_nhom_lich_su_ibfk_1` FOREIGN KEY (`id_kho_nhom`) REFERENCES `cua_kho_nhom` (`id`);

--
-- Constraints for table `cua_kho_vat_tu_lich_su`
--
ALTER TABLE `cua_kho_vat_tu_lich_su`
  ADD CONSTRAINT `cua_kho_vat_tu_lich_su_ibfk_1` FOREIGN KEY (`id_kho_vat_tu`) REFERENCES `cua_kho_vat_tu` (`id`);

--
-- Constraints for table `cua_mau_cua`
--
ALTER TABLE `cua_mau_cua`
  ADD CONSTRAINT `cua_mau_cua_ibfk_1` FOREIGN KEY (`id_he_nhom`) REFERENCES `cua_he_nhom` (`id`),
  ADD CONSTRAINT `cua_mau_cua_ibfk_2` FOREIGN KEY (`id_loai_cua`) REFERENCES `cua_loai_cua` (`id`),
  ADD CONSTRAINT `cua_mau_cua_ibfk_3` FOREIGN KEY (`id_du_an`) REFERENCES `cua_du_an` (`id`);

--
-- Constraints for table `cua_mau_cua_nhom`
--
ALTER TABLE `cua_mau_cua_nhom`
  ADD CONSTRAINT `cua_mau_cua_nhom_ibfk_1` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`),
  ADD CONSTRAINT `cua_mau_cua_nhom_ibfk_2` FOREIGN KEY (`id_cay_nhom`) REFERENCES `cua_cay_nhom` (`id`);

--
-- Constraints for table `cua_mau_cua_vach`
--
ALTER TABLE `cua_mau_cua_vach`
  ADD CONSTRAINT `cua_mau_cua_vach_ibfk_1` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`),
  ADD CONSTRAINT `cua_mau_cua_vach_ibfk_2` FOREIGN KEY (`id_vach`) REFERENCES `cua_he_vach` (`id`);

--
-- Constraints for table `cua_mau_cua_vat_tu`
--
ALTER TABLE `cua_mau_cua_vat_tu`
  ADD CONSTRAINT `cua_mau_cua_vat_tu_ibfk_1` FOREIGN KEY (`id_kho_vat_tu`) REFERENCES `cua_kho_vat_tu` (`id`),
  ADD CONSTRAINT `cua_mau_cua_vat_tu_ibfk_2` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`);

--
-- Constraints for table `cua_toi_uu`
--
ALTER TABLE `cua_toi_uu`
  ADD CONSTRAINT `cua_toi_uu_ibfk_1` FOREIGN KEY (`id_mau_cua`) REFERENCES `cua_mau_cua` (`id`),
  ADD CONSTRAINT `cua_toi_uu_ibfk_2` FOREIGN KEY (`id_mau_cua_nhom`) REFERENCES `cua_mau_cua_nhom` (`id`),
  ADD CONSTRAINT `cua_toi_uu_ibfk_3` FOREIGN KEY (`id_ton_kho_nhom`) REFERENCES `cua_kho_nhom` (`id`);

--
-- Constraints for table `template_blocks`
--
ALTER TABLE `template_blocks`
  ADD CONSTRAINT `template_blocks_ibfk_1` FOREIGN KEY (`id_template`) REFERENCES `template` (`id`);

--
-- Constraints for table `template_pages`
--
ALTER TABLE `template_pages`
  ADD CONSTRAINT `template_pages_ibfk_1` FOREIGN KEY (`id_template`) REFERENCES `template` (`id`);

--
-- Constraints for table `template_technologies`
--
ALTER TABLE `template_technologies`
  ADD CONSTRAINT `template_technologies_ibfk_1` FOREIGN KEY (`id_technologie`) REFERENCES `technologies` (`id`),
  ADD CONSTRAINT `template_technologies_ibfk_2` FOREIGN KEY (`id_template`) REFERENCES `template` (`id`);

--
-- Constraints for table `template_varibles`
--
ALTER TABLE `template_varibles`
  ADD CONSTRAINT `template_varibles_ibfk_1` FOREIGN KEY (`id_template`) REFERENCES `template` (`id`);

--
-- Constraints for table `user_visit_log`
--
ALTER TABLE `user_visit_log`
  ADD CONSTRAINT `user_visit_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `website`
--
ALTER TABLE `website`
  ADD CONSTRAINT `website_ibfk_1` FOREIGN KEY (`id_template`) REFERENCES `template` (`id`);

--
-- Constraints for table `website_blocks`
--
ALTER TABLE `website_blocks`
  ADD CONSTRAINT `website_blocks_ibfk_1` FOREIGN KEY (`id_template_block`) REFERENCES `template_blocks` (`id`),
  ADD CONSTRAINT `website_blocks_ibfk_2` FOREIGN KEY (`id_website`) REFERENCES `website` (`id`);

--
-- Constraints for table `website_pages`
--
ALTER TABLE `website_pages`
  ADD CONSTRAINT `website_pages_ibfk_1` FOREIGN KEY (`id_template_page`) REFERENCES `template_pages` (`id`),
  ADD CONSTRAINT `website_pages_ibfk_2` FOREIGN KEY (`id_website`) REFERENCES `website` (`id`);

--
-- Constraints for table `website_varibles`
--
ALTER TABLE `website_varibles`
  ADD CONSTRAINT `website_varibles_ibfk_1` FOREIGN KEY (`id_website`) REFERENCES `website` (`id`),
  ADD CONSTRAINT `website_varibles_ibfk_2` FOREIGN KEY (`id_template_varible`) REFERENCES `template_varibles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
